from collections import namedtuple

import pandas
import pyarrow as pa
import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.types_pb2 as proto_types

import snowflake.snowpark_connect.tcm as tcm
from snowflake import snowpark
from snowflake.snowpark_connect.constants import SERVER_SIDE_SESSION_ID
from snowflake.snowpark_connect.execute_plan.utils import (
    arrow_table_to_arrow_bytes,
    pandas_to_arrow_batches_bytes,
)
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.type_mapping import (
    map_snowpark_types_to_pyarrow_types,
    snowpark_to_proto_type,
)

QueryResult = namedtuple("QueryResult", ["query_id", "arrow_schema", "spark_schema"])


def map_execution_root(
    request: proto_base.ExecutePlanRequest,
) -> list[proto_base.ExecutePlanResponse | QueryResult]:
    result_df: snowpark.DataFrame | pandas.DataFrame = map_relation(request.plan.root)
    if isinstance(result_df, snowpark.DataFrame):
        snowpark_schema = result_df.schema
        schema = snowpark_to_proto_type(
            snowpark_schema, result_df._column_map, result_df
        )

        if tcm.TCM_MODE:
            # TCM result handling:
            # - small result (only one batch): just return the executePlanResponse
            # - large result (more than one batch): return a tuple with query UUID, arrow schema, and spark schema.
            # If TCM_RETURN_QUERY_ID_FOR_SMALL_RESULT is true, all results will be treated as large result.
            is_large_result = False
            second_batch = False
            first_arrow_table = None
            # TODO: SNOW-2039432 use to_arrow_batches once it is fixed in sproc-python-connector
            for pandas_df in result_df.to_pandas_batches():
                arrow_table = pa.Table.from_pandas(pandas_df)
                if second_batch:
                    is_large_result = True
                    break
                first_arrow_table = arrow_table
                second_batch = True
            if not tcm.TCM_RETURN_QUERY_ID_FOR_SMALL_RESULT and not is_large_result:
                arrow_table = first_arrow_table
            else:
                # get query uuid from the collected dataframe
                query_id = result_df.session._conn._cursor.sfqid
                # return query id and serialized schemas
                arrow_schema = pa.schema(
                    map_snowpark_types_to_pyarrow_types(
                        snowpark_schema,
                        pa.struct(first_arrow_table.schema),
                        rename_struct_columns=True,
                    )
                )
                serialized_arrow_schema = arrow_schema.serialize().to_pybytes()
                spark_schema = proto_types.DataType(**schema)
                return [
                    QueryResult(
                        query_id,
                        serialized_arrow_schema,
                        spark_schema.SerializeToString(),
                    )
                ]
        else:
            arrow_table = result_df.to_arrow()
        row_count = arrow_table.num_rows
        if arrow_table.num_rows == 0:
            # empty result needs special processing
            pandas_df = result_df.to_pandas()
            data_bytes = pandas_to_arrow_batches_bytes(pandas_df)
        else:
            data_bytes = arrow_table_to_arrow_bytes(arrow_table, snowpark_schema)
    else:
        pandas_df = result_df
        data_bytes = pandas_to_arrow_batches_bytes(pandas_df)
        row_count = len(pandas_df)
        schema = None
    return [
        proto_base.ExecutePlanResponse(
            session_id=request.session_id,
            operation_id=SERVER_SIDE_SESSION_ID,
            arrow_batch=proto_base.ExecutePlanResponse.ArrowBatch(
                row_count=row_count,
                data=data_bytes,
            ),
            schema=schema,
        ),
    ]
