import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer import analyzer_utils
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.read.map_read import ReaderConfig
from snowflake.snowpark_connect.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_read_parquet(
    rel: relation_proto.Relation,
    schema: str | None,
    session: snowpark.Session,
    paths: list[str],
    options: ReaderConfig,
) -> snowpark.DataFrame:
    """
    Read a Parquet file into a Snowpark DataFrame.

    We leverage the stage that is already created in the map_read function that
    calls this.
    """

    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise SnowparkConnectNotImplementedError(
            "Streaming is not supported for Parquet files."
        )
    else:
        snowpark_options = options.convert_to_snowpark_args()
        assert schema is None, "Read PARQUET does not support user schema"
        reader = session.read.options(snowpark_options)
        df = reader.parquet(paths[0])
        if len(paths) > 1:
            for p in paths[1:]:
                reader._user_schema = None
                df = df.union_all(reader.parquet(p))

        renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(
            df, rel.common.plan_id
        )
        return build_column_map(
            renamed_df,
            [analyzer_utils.unquote_if_quoted(c) for c in df.columns],
            snowpark_column_names,
            [f.datatype for f in df.schema.fields],
        )
