import random
import string
import time
from typing import Sequence

import pyspark.sql.connect.proto.relations_pb2 as relation_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import (
    ColumnNameMap,
    make_column_names_snowpark_compatible,
)
from snowflake.snowpark_connect.relation.map_relation import map_relation


def get_df_with_partition_row_number(
    df: snowpark.DataFrame, plan_id: int | None, row_number_column_name: str
) -> snowpark.DataFrame:
    """
    Add a row number for each row in each partition for the given df, where
    the df is partition based on all columns.
    For example:
    +---+---+         will become           +---+---+------------+
    | C1| C2|                               | C1| C2| ROW_NUMBER |
    +---+---+                               +---+---+------------+
    |  a|  1|                               |  a|  1|  0         |
    |  a|  1|                               |  a|  1|  1         |
    |  a|  2|                               |  a|  2|  0         |
    |  c|  4|                               |  c|  4|  0         |
    +---+---+                               +---+---+------------+
    """
    row_number_snowpark_column_name = make_column_names_snowpark_compatible(
        [row_number_column_name], plan_id, len(df._column_map.get_spark_columns())
    )[0]
    row_number_snowpark_column = (
        snowpark_fn.row_number()
        .over(
            snowpark.window.Window.partition_by(
                *df._column_map.get_snowpark_columns()
            ).order_by(snowpark_fn.lit(1))
        )
        .alias(row_number_snowpark_column_name)
    )

    df_with_partition_number = df.select(
        *df._column_map.get_snowpark_columns(), row_number_snowpark_column
    )
    return df_with_partition_number


def random_string(
    length: int,
    prefix: str = "",
    suffix: str = "",
    choices: Sequence[str] = string.ascii_lowercase,
) -> str:
    """Our convenience function to generate random string for object names.

    Args:
        length: How many random characters to choose from choices.
            length would be at least 6 for avoiding collision
        prefix: Prefix to add to random string generated.
        suffix: Suffix to add to random string generated.
        choices: A generator of things to choose from.
    """
    random_part = "".join([random.choice(choices) for _ in range(length)]) + str(
        time.time_ns()
    )

    return "".join([prefix, random_part, suffix])


def get_semantic_string(rel: relation_proto.Relation) -> str:
    """Calculate semantic hash of the input relation proto.
    This function parse the proto into Snowpark execution queries and calculate the hash of the parsed query strings.

    Args:
        rel: An input relation
    """
    queries = [
        query
        for query_list in map_relation(rel)._plan.execution_queries.values()
        for query in query_list
    ]
    for query in queries:
        # query id is randomly generated, which will affect the hash result.
        query.query_id_place_holder = ""

    return "".join([str(query) for query in queries])


def snowpark_functions_col(name: str, column_map: ColumnNameMap) -> snowpark.Column:
    """
    Return snowpark column, by default have parameter "_is_qualified_name" on to support nested StructuredType
    """
    is_qualified_name = name not in column_map.get_snowpark_columns()
    return snowpark_fn.col(name, _is_qualified_name=is_qualified_name)
