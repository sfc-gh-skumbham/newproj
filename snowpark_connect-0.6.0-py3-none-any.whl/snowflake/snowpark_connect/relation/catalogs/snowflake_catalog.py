import typing

import pandas
import pyspark.sql.connect.proto.types_pb2 as types_proto

from snowflake import snowpark
from snowflake.snowpark import functions
from snowflake.snowpark.types import BooleanType
from snowflake.snowpark_connect import column_name_handler
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.relation.catalogs.abstract_spark_catalog import (
    AbstractSparkCatalog,
    CatalogMetadata,
)
from snowflake.snowpark_connect.type_mapping import proto_to_snowpark_type
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


class SnowflakeCatalog(AbstractSparkCatalog):
    def __init__(self) -> None:
        super().__init__()
        self.metadata = CatalogMetadata(name="spark_catalog", description=None)

    def listDatabases(
        self,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """List all databases accessible in Snowflake with an optional name to filter by."""
        catalog = snowpark.Session.builder.getOrCreate().catalog

        dbs = catalog.list_databases(pattern=pattern)
        names: list[str] = list()
        catalogs: list[None] = list()
        descriptions: list[str | None] = list()
        locationUris: list[str] = list()
        for db in dbs:
            names.append(db.name)
            catalogs.append(None)
            descriptions.append(db.comment)
            locationUris.append(f"snowflake://{db.name}")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "description": descriptions,
                "locationUri": locationUris,
            }
        )

    def getDatabase(
        self,
        dbName: str,
    ) -> pandas.DataFrame:
        """Listing a single database that's accessible in Snowflake."""
        return self.listDatabases(pattern=dbName)

    def databaseExists(
        self,
        dbName: str,
    ) -> pandas.DataFrame:
        """Whether a database with provided name exists in Snowflake."""
        return pandas.DataFrame({"exists": [not self.getDatabase(dbName).empty]})

    def listTables(
        self,
        dbName: typing.Optional[str] = None,
        schemaName: typing.Optional[str] = None,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """Listing all tables/views accessible in Snowflake, optionally filterable on database, schema, and a pattern for the table names."""
        # In all of the other functions we keep with the Spark naming, but in this function dbName refers to a
        # a Snowflake database and schemaName refers to a Snowflake schema. This is necessary because of the
        # tableName possibly being a multi-layer-namespace identifier in tableExists.
        catalog = snowpark.Session.builder.getOrCreate().catalog
        tables = catalog.list_tables(
            database=dbName,
            schema=schemaName,
            pattern=pattern.upper() if isinstance(pattern, str) else pattern,
        )
        views = catalog.list_views(
            database=dbName,
            schema=schemaName,
            pattern=pattern.upper() if isinstance(pattern, str) else pattern,
        )
        names: list[str] = list()
        catalogs: list[None] = list()
        namespaces: list[list[str | None]] = list()
        names: list[str] = list()
        descriptions: list[str | None] = list()
        table_types: list[str | None] = list()
        is_temporaries: list[bool] = list()
        for table in tables:
            names.append(table.name)
            catalogs.append(None)  # TODO: change this with catalog support
            namespaces.append([table.database_name, table.schema_name])
            descriptions.append(table.comment)
            table_types.append(table.kind)
            is_temporaries.append(table.kind == "TEMPORARY")
        for view in views:
            names.append(view.name)
            catalogs.append(None)  # TODO: change this with catalog support
            namespaces.append([view.database_name, view.schema_name])
            descriptions.append(view.comment)
            table_types.append(view.kind)
            is_temporaries.append(view.kind == "TEMPORARY")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "namespace": namespaces,
                "description": descriptions,
                "tableType": table_types,
                "isTemporary": is_temporaries,
            }
        )

    def getTable(
        self,
        tableName: str,
    ) -> pandas.DataFrame:
        """Listing a single table/view with provided name that's accessible in Snowflake."""
        return self.listTables(pattern=tableName)

    def tableExists(
        self,
        tableName: str,
        dbName: typing.Optional[str],
    ) -> pandas.DataFrame:
        """Whether a table/view with provided name exists in Snowflake, optionally filterable with dbName.
        If no database is specified, first try to treat tableName as a multi-layer-namespace identifier
        (or fully qualified name), then try tableName as a normal table name in the current database if necessary.
        Argument dbName is not actually implemented yet while we figure out how to map databases from Spark to Snowflake.
        """
        db_name = None if dbName == "" else dbName
        if db_name is not None:
            current_schema = (
                snowpark.Session.builder.getOrCreate().catalog.get_current_schema()
            )
            if current_schema is None:
                raise SnowparkConnectNotImplementedError(
                    "Current schema cannot be determined. Please set it explicitly, or use a multi-layer-namespace identifier."
                )
            tables = self.listTables(
                dbName=db_name, schemaName=current_schema, pattern=tableName
            )
        else:
            match tableName.split("."):
                case [t]:
                    tables = self.listTables(pattern=t)
                case [s, t]:
                    tables = self.listTables(schemaName=s, pattern=t)
                case [d, s, t]:
                    tables = self.listTables(dbName=d, schemaName=s, pattern=t)
                case _:
                    raise ValueError(f"Unexpected table name format: {tableName}")
        return pandas.DataFrame(
            {
                "exists": [not tables.empty],
            }
        )

    def listColumns(
        self,
        tableName: str,
        dbName: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """List all columns in a table/view, optionally database name filter can be provided."""
        catalog = snowpark.Session.builder.getOrCreate().catalog
        columns = catalog.list_columns(
            schema=dbName,
            table_name=tableName,
        )
        names: list[str] = list()
        descriptions: list[str | None] = list()
        data_types: list[str] = list()
        nullables: list[bool] = list()
        is_partitions: list[bool] = list()
        is_buckets: list[bool] = list()
        for column in columns:
            names.append(column.name)
            descriptions.append(column.comment)
            data_types.append(column.datatype)
            nullables.append(bool(column.nullable))
            is_partitions.append(False)
            is_buckets.append(False)

        return pandas.DataFrame(
            {
                "name": names,
                "description": descriptions,
                "dataType": data_types,
                "nullable": nullables,
                "isPartition": is_partitions,
                "isBucket": is_buckets,
            }
        )

    def currentDatabase(self) -> pandas.DataFrame:
        """Get the currently used database's name."""
        catalog = snowpark.Session.builder.getOrCreate().catalog
        db_name = catalog.get_current_database()
        assert db_name is not None, "current database could not be confirmed"
        if db_name[0] == '"' and db_name[-1] == '"':
            new_db_name = db_name[1:-1]
            if new_db_name.upper() == new_db_name:
                # Only remove the double quotes if the identifier is all upper case
                db_name = new_db_name
        return pandas.DataFrame({"current_database": [db_name]})

    def setCurrentDatabase(
        self,
        db_name: str,
    ) -> pandas.DataFrame:
        """Set the currently used database's name."""
        catalog = snowpark.Session.builder.getOrCreate().catalog
        catalog.setCurrentDatabase(db_name)
        return pandas.DataFrame({"current_database": [db_name]})

    def dropGlobalTempView(
        self,
        view_name: str,
    ) -> snowpark.DataFrame:
        session = snowpark.Session.builder.getOrCreate()
        schema = global_config.spark_sql_globalTempDatabase
        result_df = session.sql(
            "drop view if exists identifier(?)", params=[f"{schema}.{view_name}"]
        )
        result_df = result_df.select(
            functions.contains('"status"', functions.lit("successfully dropped")).alias(
                "value"
            )
        )
        columns = ["value"]
        return column_name_handler.build_column_map(
            result_df, columns, columns, [BooleanType()]
        )

    def dropTempView(
        self,
        view_name: str,
    ) -> snowpark.DataFrame:
        """Drop the current temporary view."""
        session = snowpark.Session.builder.getOrCreate()
        result_df = session.sql("drop view if exists identifier(?)", params=[view_name])
        result_df = result_df.select(
            functions.contains('"status"', functions.lit("successfully dropped")).alias(
                "value"
            )
        )
        columns = ["value"]
        return column_name_handler.build_column_map(
            result_df, columns, columns, [BooleanType()]
        )

    def createTable(
        self,
        tableName: str,
        path: str,
        source: str,
        schema: types_proto.DataType,
        description: str,
        **options: typing.Any,
    ) -> snowpark.DataFrame:
        """Create either an external, or a managed table.

        If path is supplied in which the data for this table exists. When path is specified, an external table is
        created from the data at the given path. Otherwise a managed table is created.

        In case a managed table is being created, schema is required.
        """
        if source == "":
            source = global_config.get("spark.sql.sources.default")
        if source not in ("csv", "json", "avro", "parquet", "orc", "xml"):
            raise SnowparkConnectNotImplementedError(
                f"Source '{source}' is not currently supported by Catalog.createTable. "
                "Maybe default value through 'spark.sql.sources.default' should be set."
            )
        session = snowpark.Session.builder.getOrCreate()
        if path == "":
            # Managed table
            if schema.ByteSize() == 0:
                raise SnowparkConnectNotImplementedError(
                    f"Unable to infer schema for {source.upper()}. It must be specified manually.",
                )
            sp_schema = proto_to_snowpark_type(schema)
            columns = [c.name for c in schema.struct.fields]
            column_types = [f.datatype for f in sp_schema.fields]
            return column_name_handler.build_column_map(
                session.createDataFrame([], sp_schema), columns, columns, column_types
            )
        else:
            # External table
            raise SnowparkConnectNotImplementedError(
                "External table creation is not supported currently."
            )
