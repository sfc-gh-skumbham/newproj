import typing
from abc import ABC, abstractmethod
from dataclasses import dataclass

import pandas
import pyspark.sql.connect.proto.common_pb2 as common_proto
import pyspark.sql.connect.proto.types_pb2 as types_proto

from snowflake import snowpark
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


class AbstractSparkCatalog(ABC):
    def __init__(self) -> None:
        self.cache: set[str] = set()

    @abstractmethod
    def createTable(
        self,
        tableName: str,
        path: str,
        source: str,
        schema: types_proto.DataType,
        description: str,
        **options: typing.Any,
    ) -> snowpark.DataFrame:
        raise SnowparkConnectNotImplementedError("createTable is not implemented")

    @abstractmethod
    def listDatabases(
        self,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("listDatabases is not implemented")

    @abstractmethod
    def getDatabase(
        self,
        dbName: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("getDatabase is not implemented")

    @abstractmethod
    def databaseExists(
        self,
        dbName: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("databaseExists is not implemented")

    @abstractmethod
    def listTables(
        self,
        dbName: typing.Optional[str] = None,
        schemaName: typing.Optional[str] = None,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("listTables is not implemented")

    @abstractmethod
    def getTable(
        self,
        tableName: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("getTable is not implemented")

    @abstractmethod
    def tableExists(
        self,
        tableName: str,
        dbName: typing.Optional[str],
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("tableExists is not implemented")

    @abstractmethod
    def listColumns(
        self,
        tableName: str,
        dbName: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("listColumns is not implemented")

    @abstractmethod
    def currentDatabase(self) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("currentDatabase is not implemented")

    @abstractmethod
    def setCurrentDatabase(
        self,
        db_name: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError(
            "setCurrentDatabase is not implemented"
        )

    @abstractmethod
    def dropGlobalTempView(
        self,
        view_name: str,
    ) -> snowpark.DataFrame:
        raise SnowparkConnectNotImplementedError(
            "dropGlobalTempView is not implemented"
        )

    @abstractmethod
    def dropTempView(
        self,
        view_name: str,
    ) -> snowpark.DataFrame:
        raise SnowparkConnectNotImplementedError("dropTempView is not implemented")

    def cacheTable(
        self,
        tableName: str,
        storageLevel: typing.Optional[common_proto.StorageLevel] = None,
    ) -> pandas.DataFrame:
        self.cache.add(tableName)
        return pandas.DataFrame()

    def clearCache(self) -> pandas.pandas.DataFrame:
        self.cache = set()
        return pandas.DataFrame()

    def isCached(self, tableName: str) -> pandas.DataFrame:
        return pandas.DataFrame({"cached": [tableName in self.cache]})

    def refreshByPath(self, path: str) -> pandas.DataFrame:
        return pandas.DataFrame()

    def refreshTable(self, tableName: str) -> pandas.DataFrame:
        return pandas.DataFrame()

    def uncacheTable(self, tableName: str) -> pandas.DataFrame:
        self.cache.remove(tableName)
        return pandas.DataFrame()


@dataclass
class CatalogMetadata:
    name: str
    description: str = None
