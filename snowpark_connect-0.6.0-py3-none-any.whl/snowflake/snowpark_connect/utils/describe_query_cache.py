import hashlib
import re
import threading
import time
from typing import Any

from snowflake import snowpark
from snowflake.connector.cursor import ResultMetadataV2
from snowflake.snowpark._internal.server_connection import ServerConnection
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger

DESCRIBE_CACHE_TTL_SECONDS = 15
USE_DESCRIBE_QUERY_CACHE = True

DDL_DETECTION_PATTERN = re.compile(r"^\s*(CREATE|ALTER|DROP|RENAME)\b", re.IGNORECASE)


class DescribeQueryCache:
    def __init__(self) -> None:
        self._cache = {}
        self._lock = threading.Lock()

    @staticmethod
    def _hash_query(sql_query: str) -> str:
        return hashlib.md5(sql_query.encode("utf-8")).hexdigest()

    def get(self, sql_query: str) -> list[ResultMetadataV2] | None:
        key = self._hash_query(sql_query)
        current_time = time.monotonic()

        # TODO: maybe too much locking, we could use read-write lock also. Or a thread safe dictionary.
        with self._lock:
            if key in self._cache:
                result, timestamp = self._cache[key]
                if current_time < timestamp + DESCRIBE_CACHE_TTL_SECONDS:
                    logger.debug(
                        f"Returning query result from cache for query: {sql_query[:20]}"
                    )
                    return result
                else:
                    logger.debug(
                        f"Had a cached entry, but it expired for query: {sql_query[:20]}"
                    )
                    del self._cache[key]
        return None

    def put(self, sql_query: str, result: list[ResultMetadataV2] | None) -> None:
        if result is None:
            return
        logger.debug(f"Putting into cache for query: {sql_query[:20]}...")
        key = self._hash_query(sql_query)
        timestamp = time.monotonic()
        with self._lock:
            self._cache[key] = (result, timestamp)

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()


def instrument_session_for_describe_cache(session: snowpark.Session):
    session._describe_query_cache = DescribeQueryCache()

    def update_cache_for_query(query: str):
        cache = None
        cache_instance = getattr(session, "_describe_query_cache", None)
        if isinstance(cache_instance, DescribeQueryCache):
            cache = cache_instance

        # TODO: This is very broad right now. We should be able to reduce the scope of clearing.
        if DDL_DETECTION_PATTERN.search(query):
            logger.debug(f"DDL detected, clearing describe query cache: '{query}'")
            cache.clear()

    def wrap_execute(wrapped_fn):
        def fn(query: str, **kwargs):
            update_cache_for_query(query)
            return wrapped_fn(query, **kwargs)

        return fn

    # This is a wrapper to cache describe queries.
    def cached_describe_internal(session, wrapped_fn):
        def fn(*args: Any, **kwargs: Any) -> list[ResultMetadataV2] | None:

            if not USE_DESCRIBE_QUERY_CACHE:
                return wrapped_fn(*args, **kwargs)

            # Query should be first arg
            if args and isinstance(args[0], str):
                query = args[0]
            else:
                logger.debug(
                    "Warning: Could not extract query string from args in cached_describe_internal. Skipping cache."
                )
                return wrapped_fn(*args, **kwargs)  # Call original

            # TODO cache on cursor - does it make sense?
            cache = None
            cache_instance = getattr(session, "_describe_query_cache", None)
            if isinstance(cache_instance, DescribeQueryCache):
                cache = cache_instance

            if cache:
                cached_result = cache.get(query)
                if cached_result is not None:
                    return cached_result

            # No cache hit, so we call the orig describe function and make a snowflake query
            result = wrapped_fn(*args, **kwargs)

            if cache and result is not None:
                cache.put(query, result)

            return result

        return fn

    # TODO: is there a better way to intercept queries?
    orig_cursor_getter = ServerConnection._cursor.fget

    def cursor_wrapper(conn):
        cursor = orig_cursor_getter(conn)
        if hasattr(cursor, "_instrumented_describe") and cursor._instrumented_describe:
            return cursor

        cursor.execute = wrap_execute(cursor.execute)

        # Override describe so that we can stop queries from being sent to Snowflake if they are
        # already in the cache.
        # TODO: Test with multiple sessions to confirm we don't cross them
        cursor._describe_internal = cached_describe_internal(
            session, cursor._describe_internal
        )

        cursor._instrumented_describe = True
        return cursor

    setattr(ServerConnection, "_cursor", property(cursor_wrapper))  # noqa: B010
