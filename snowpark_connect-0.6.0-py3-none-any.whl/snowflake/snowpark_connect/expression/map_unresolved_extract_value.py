import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark.column import Column
from snowflake.snowpark.types import ArrayType, LongType
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.typed_column import TypedColumn


def _check_if_array_type(
    child_typed_column: Column,
    extract_typed_column: Column,
    typer: ExpressionTyper,
):
    extract_typed_column_type = typer.type(extract_typed_column)
    container_type = typer.type(child_typed_column)
    return (
        len(extract_typed_column_type) == 1
        and isinstance(extract_typed_column_type[0], ArrayType)
        and len(container_type) == 1
        and isinstance(container_type[0], LongType)
    )


def map_unresolved_extract_value(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    from snowflake.snowpark_connect.expression.map_expression import (
        map_single_column_expression,
    )

    child_name, child_typed_column = map_single_column_expression(
        exp.unresolved_extract_value.child, column_mapping, typer
    )
    extract_name, extract_typed_column = map_single_column_expression(
        exp.unresolved_extract_value.extraction,
        column_mapping,
        typer,
    )
    spark_function_name = f"{child_name}[{extract_name}]"
    result_exp = child_typed_column.col.getItem(
        Column._to_expr(extract_typed_column.col).value
    )

    spark_sql_ansi_enabled = global_config.spark_sql_ansi_enabled

    if spark_sql_ansi_enabled and _check_if_array_type(
        extract_typed_column.col, child_typed_column.col, typer
    ):

        result_exp = snowpark_fn.when(
            snowpark_fn.array_size(child_typed_column.col) >= extract_typed_column.col,
            child_typed_column.col.getItem("[snowpark_connect::INVALID_ARRAY_INDEX]"),
        ).otherwise(result_exp)

    return spark_function_name, TypedColumn(result_exp, lambda: typer.type(result_exp))
