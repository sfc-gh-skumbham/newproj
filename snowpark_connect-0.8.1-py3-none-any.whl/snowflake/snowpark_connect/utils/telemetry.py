from enum import Enum, unique
from typing import Any, Dict, Optional

from snowflake.connector import SnowflakeConnection
from snowflake.connector.telemetry import (
    TelemetryClient as PCTelemetryClient,
    TelemetryData as PCTelemetryData,
    TelemetryField as PCTelemetryField,
)
from snowflake.connector.time_util import get_time_millis
from snowflake.snowpark._internal.telemetry import safe_telemetry
from snowflake.snowpark._internal.utils import (
    get_os_name,
    get_python_version,
    is_in_stored_procedure,
)
from snowflake.snowpark.version import VERSION as snowpark_version
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.version import VERSION as sas_version


@unique
class TelemetryField(Enum):
    # constants
    KEY_ERROR_MSG = "error_msg"
    # Message keys for telemetry
    KEY_VERSION = "version"
    KEY_PYTHON_VERSION = "python_version"
    KEY_SNOWPARK_VERSION = "snowpark_version"
    KEY_OS = "operating_system"
    KEY_DATA = "data"
    KEY_START_TIME = "start_time"
    # Telemetry type
    TYPE_SERVER_STARTED = "server_started"
    TYPE_NOT_IMPLEMENTED_ERROR = "not_implemented_error"


def get_snowpark_version() -> str:
    return ".".join([str(d) for d in snowpark_version if d is not None])


def get_sas_version() -> str:
    return ".".join([str(d) for d in sas_version if d is not None])


class TelemetryClient:
    def __init__(self, conn: SnowflakeConnection) -> None:
        self.telemetry: PCTelemetryClient = (
            None if is_in_stored_procedure() else conn._telemetry
        )
        self.source: str = "SnowflakeAcceleratedSpark"
        self.snowpark_version: str = get_snowpark_version()
        self.python_version: str = get_python_version()
        self.version: str = get_sas_version()
        self.os: str = get_os_name()

    def _send(self, msg: Dict, timestamp: Optional[int] = None):
        if self.telemetry:
            if not timestamp:
                timestamp = get_time_millis()
            telemetry_data = PCTelemetryData(message=msg, timestamp=timestamp)
            self.telemetry.try_add_log_to_batch(telemetry_data)

    def _create_basic_telemetry_data(self, telemetry_type: str) -> Dict[str, Any]:
        return {
            PCTelemetryField.KEY_SOURCE.value: self.source,
            TelemetryField.KEY_VERSION.value: self.version,
            TelemetryField.KEY_SNOWPARK_VERSION.value: self.snowpark_version,
            TelemetryField.KEY_PYTHON_VERSION.value: self.python_version,
            TelemetryField.KEY_OS.value: self.os,
            PCTelemetryField.KEY_TYPE.value: telemetry_type,
        }

    @safe_telemetry
    def send_server_started_telemetry(self):
        message = {
            **self._create_basic_telemetry_data(
                TelemetryField.TYPE_SERVER_STARTED.value
            ),
            TelemetryField.KEY_DATA.value: {
                TelemetryField.KEY_START_TIME.value: get_time_millis(),
            },
        }
        self._send(message)

    @safe_telemetry
    def send_not_implemented_error_telemetry(self, error_msg: str):
        message = {
            **self._create_basic_telemetry_data(
                TelemetryField.TYPE_NOT_IMPLEMENTED_ERROR.value
            ),
            TelemetryField.KEY_DATA.value: {
                TelemetryField.KEY_ERROR_MSG.value: error_msg,
            },
        }
        self._send(message)


class SnowparkConnectNotImplementedError(NotImplementedError):
    def __init__(self, message: str = None) -> None:
        # Pass the message to the parent class
        session = get_or_create_snowpark_session()
        session._sas_telemetry_client.send_not_implemented_error_telemetry(message)
        super().__init__(message)
