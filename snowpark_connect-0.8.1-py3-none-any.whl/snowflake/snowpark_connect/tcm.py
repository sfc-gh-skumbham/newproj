TCM_MODE = False
TCM_RETURN_QUERY_ID_FOR_SMALL_RESULT = (
    False  # If true, all result will be returned as query's uuid
)
