#!/usr/bin/env python

"""The utility file for running spark-submit cluster mode.
"""

import argparse
import logging
import os
import random
import string
import tempfile
import textwrap
import time
from abc import ABC, abstractmethod
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import yaml

from snowflake import snowpark
from snowflake.connector.backoff_policies import exponential_backoff
from snowflake.connector.config_manager import CONFIG_MANAGER
from snowflake.snowpark_submit.file_path import BaseFilePath

SPCS_SPEC_FILE = "spcs_spec.yaml"
COMMON_NEEDED_CONFIGS = [
    "compute_pool",
    "warehouse",
]

logger = logging.getLogger("snowflake_spark_submit")
logger.setLevel(logging.DEBUG)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - [Thread %(thread)d] - %(message)s"
)
console_handler.setFormatter(formatter)

# Display the logs to the console
logger.addHandler(console_handler)


def generate_random_name(
    length: int = 8,
    prefix: str = "",
    suffix: str = "",
    choices: Sequence[str] = string.ascii_lowercase,
) -> str:
    """Our convenience function to generate random string for object names.
    Args:
        length: How many random characters to choose from choices.
            length would be at least 6 for avoiding collision
        prefix: Prefix to add to random string generated.
        suffix: Suffix to add to random string generated.
        choices: A generator of things to choose from.
    """
    random_part = "".join([random.choice(choices) for _ in range(length)]) + str(
        time.time_ns()
    )

    return "".join([prefix, random_part, suffix])


class JobRunner(ABC):
    @abstractmethod
    def _generate_client_container_args(
        self, client_src_zip_file_path: str
    ) -> list[str]:
        """
        Generates the args list for client container.

        Args:
            client_src_zip_file_path: zip file path inside container that contains customers'
            local dependencies.

        Returns:
            args list of client container.
        """
        pass

    @abstractmethod
    def _client_image_path_sys_registry(self) -> str:
        """
        Docker image full path inside SPCS system registry for client container.
        """
        pass

    @abstractmethod
    def _server_image_path_sys_registry(self) -> str:
        """
        Docker image full path inside SPCS system registry for server container.
        """
        pass

    @abstractmethod
    def _client_image_name_override(self) -> str:
        """
        Docker image override relative path inside SPCS account registry for client container.
        """
        pass

    @abstractmethod
    def _server_image_name_override(self) -> str:
        """
        Docker image override relative path inside SPCS account registry for server container.
        """
        pass

    @abstractmethod
    def _add_additional_jars_to_classpath(self) -> None:
        """
        Adds additional jar resources to Spark's classpath.
        """
        pass

    @abstractmethod
    def _use_system_registry(self) -> bool:
        """
        Whether to use system registry for client and server container images.
        """
        pass

    @abstractmethod
    def _override_args(self) -> None:
        """
        Override the default args if needed.
        """
        pass

    def __init__(
        self,
        args: argparse.Namespace,
        generate_spark_cmd_args: Callable[[argparse.Namespace], list[str]],
        client_working_dir: str,
        temp_stage_mount_dir: str,
        current_dir: str,
    ) -> None:
        needed_configs = list(COMMON_NEEDED_CONFIGS)
        if not self._use_system_registry():
            needed_configs.extend(["database", "schema", "spcs_repo_name"])

        self.args = args

        # Overrides args if needed
        self._override_args()

        self.generate_spark_cmd_args = (
            generate_spark_cmd_args  # need to generate on the fly
        )
        assert client_working_dir.endswith(
            "/"
        ), "client_working_dir should end with '/'"
        self.client_working_dir = client_working_dir
        assert temp_stage_mount_dir.endswith(
            "/"
        ), "temp_stage_mount_dir should end with '/'"
        self.temp_stage_mount_dir = temp_stage_mount_dir
        self.current_dir = current_dir
        self.client_app_language = "scala"  # default to scala

        configs = {}
        try:
            if self.args.snowflake_connection_name in CONFIG_MANAGER["connections"]:
                configs = CONFIG_MANAGER["connections"][
                    self.args.snowflake_connection_name
                ]
        except Exception as e:
            # errors like file access permission denied
            logger.error(
                "Failed to load connection configs from connections.toml. Error: %s", e
            )

        for config in needed_configs:
            default = str(configs[config]) if config in configs else None
            setattr(self, config, getattr(self.args, config, None) or default)

        if not self._use_system_registry():
            self.spcs_repo_path = (
                f"/{self.database}/{self.schema}/{self.spcs_repo_name}"
            )

        custom_session_configs = {
            "connection_name": self.args.snowflake_connection_name
        }
        if self.args.account:
            custom_session_configs["account"] = self.args.account
        if self.args.user:
            custom_session_configs["user"] = self.args.user
        if self.args.password:
            custom_session_configs["password"] = self.args.password
        if self.args.role:
            custom_session_configs["role"] = self.args.role
        if self.args.host:
            custom_session_configs["host"] = self.args.host
        if self.args.database:
            custom_session_configs["database"] = self.args.database
        if self.args.schema:
            custom_session_configs["schema"] = self.args.schema
        if self.args.warehouse:
            custom_session_configs["warehouse"] = self.args.warehouse
        custom_session_configs["protocol"] = "https"
        custom_session_configs["port"] = 443

        self._snowpark_session: snowpark.Session = snowpark.Session.builder.configs(
            custom_session_configs
        ).create()

    def prepare_spcs_spec(
        self,
        temp_stage_name: str,
        client_src_zip_file_path: str,
        server_image_name: str = "snowpark-connect-server:latest",
        client_image_name: str = "snowpark-connect-client:latest",
        service_name: str = "snowpark_connect_job_service",
    ):
        # TODO: more options can be added
        #  resources (CPU, memory etc.)
        #  secrets
        #  volumes (@stagename)
        #  metricConfig
        #  serviceRoles
        logger.debug("start preparing spcs_spec")
        spcs_spec_template_path = os.path.join(
            self.current_dir, "resources/spcs_spec.template.yaml"
        )
        with open(spcs_spec_template_path) as f:
            spcs_spec_dict = yaml.safe_load(f)

        spec = spcs_spec_dict["spec"]

        # snowpark connect server container
        server_container = spec["container"][0]

        logger.debug("USE_SYSTEM_IMAGE_REGISTRY: %s", self._use_system_registry())
        if self._use_system_registry():
            server_container["image"] = self._server_image_path_sys_registry()
        else:
            server_container["image"] = self.spcs_repo_path + f"/{server_image_name}"

        if getattr(self, "warehouse", None):
            server_container["env"]["SNOWFLAKE_WAREHOUSE"] = self.warehouse

        # snowpark connect client container
        client_container = spec["container"][1]
        if self._use_system_registry():
            client_container["image"] = self._client_image_path_sys_registry()
        else:
            client_container["image"] = self.spcs_repo_path + f"/{client_image_name}"
        client_container["env"]["SERVICE_NAME"] = service_name
        client_container["args"] = self._generate_client_container_args(
            client_src_zip_file_path
        )

        spec["volumes"][0]["source"] = f"@{temp_stage_name}"
        if self.args.snowflake_log_level:
            spec["logExporters"]["eventTableConfig"][
                "logLevel"
            ] = self.args.snowflake_log_level

        spcs_spec_yaml = yaml.dump(spcs_spec_dict, default_flow_style=False)
        logger.debug(spcs_spec_yaml)

        return spcs_spec_yaml

    def upload_client_files(self, temp_stage_name):
        # TODO: use file_path to filter out only local paths
        file_path = Path(self.args.filename)
        self.args.filename = self.client_working_dir + file_path.name
        files_for_zip = [file_path]

        # TODO: support non-local files
        if self.client_app_language == "scala":
            if self.args.jars:
                # TODO: use file_path to filter out only local paths
                jar_paths = [Path(jar) for jar in self.args.jars.split(",")]
                files_for_zip.extend(jar_paths)
        elif self.client_app_language == "python":
            if self.args.py_files:
                # TODO: use file_path to filter out only local paths
                py_file_paths = [
                    Path(py_file) for py_file in self.args.py_files.split(",")
                ]
                files_for_zip.extend(py_file_paths)

        import zipfile

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            zip_file_name = (
                generate_random_name(prefix="snowpark_submit_files_") + ".zip"
            )
            zip_file_path = tmp_path / zip_file_name
            with zipfile.ZipFile(zip_file_path, "w") as zipf:
                for file in files_for_zip:
                    logger.debug(f"zipping file {file.name}")
                    zipf.write(file, arcname=file.name)

            logger.debug(
                f"Created archive {zip_file_path} for uploading the client src file and other dependencies."
            )

            # Upload the archive
            upload_zip_sql = f"PUT file://{zip_file_path.resolve()} @{temp_stage_name} AUTO_COMPRESS=FALSE OVERWRITE=TRUE;"
            self._snowpark_session.sql(upload_zip_sql).collect()
            logger.debug(
                f"Uploaded the archive {zip_file_path} to the temporary stage {temp_stage_name}."
            )

        stage_content = self._snowpark_session.sql(f"ls @{temp_stage_name}").collect()
        logger.debug(stage_content)
        return self.temp_stage_mount_dir + zip_file_name

    def _adjust_file_path_arg(
        self, arg_value: str, separator: str | None = None
    ) -> str:
        if not arg_value:
            return ""

        file_paths = [
            BaseFilePath.parse_file_path(
                client_path=path,
                local_file_base_path=self.client_working_dir,
                stage_file_base_path=self.temp_stage_mount_dir,
            ).get_file_path_in_container()
            for path in arg_value.split(separator)
        ]
        return separator.join(file_paths) if separator else file_paths[0]

    def adjust_file_paths(self):
        if self.client_app_language == "scala":
            if self.args.jars:
                self.args.jars = self._adjust_file_path_arg(
                    self.args.jars, separator=","
                )

            if self.args.driver_class_path:
                self.args.driver_class_path = self._adjust_file_path_arg(
                    self.args.driver_class_path, separator=":"
                )
        elif self.client_app_language == "python":
            if self.args.py_files:
                self.args.py_files = self._adjust_file_path_arg(
                    self.args.py_files, separator=","
                )

        # TODO: what if program args have file paths?
        self.args.filename = self._adjust_file_path_arg(self.args.filename)

    def _add_class_paths(self, jar_paths: list[str]):
        if self.args.driver_class_path is None:
            self.args.driver_class_path = ":".join(jar_paths)
        else:
            self.args.driver_class_path = ":".join(
                [jar_paths] + [self.args.driver_class_path]
            )
        logger.debug("driver_class_path: %s", self.args.driver_class_path)

    def wait_for_service_completion(self, service_name: str):
        backoff_gen = exponential_backoff()()
        while True:
            terminated = self.describe(service_name=service_name)[1]
            if terminated or terminated is None:
                break
            sleep = next(backoff_gen)
            logger.debug("sleep for %d seconds", sleep)
            time.sleep(sleep)

    def run(self):
        # TODO: required deps - pyyaml.
        # TODO: currently this experiment app supports only scala 2.12 and spark 3.5.3. We need a way for customer to specify which version of scala and spark to use.
        # TODO: support following arguments
        #  external access integrations
        #  trace level
        #  metrics level
        #  snowflake secrets
        # TODO: better way of terminating the job service, e.g. heartbeat

        server_image_name = self._server_image_name_override()
        if self.args.filename.endswith(".jar"):
            self.client_app_language = "scala"
        elif self.args.filename.endswith(".py"):
            self.client_app_language = "python"
        else:
            raise ValueError(
                f"Only .jar and .py files are supported now. {self.args.filename} is provided."
            )

        client_image_name = self._client_image_name_override()

        # step 1, upload client files to stage
        # TODO: we should support the mode of mixing local files, stage files and cloud files.
        if self.args.snowflake_stage:
            # customer should upload all required files
            temp_stage_name = self.args.snowflake_stage[1:]  # remove '@' prefix
            client_src_zip_file_path = None
        else:
            temp_stage_name = self.create_temp_stage_for_upload()
            client_src_zip_file_path = self.upload_client_files(temp_stage_name)

        # step 1.5, adjusts file path related args
        self.adjust_file_paths()
        if self.client_app_language == "scala":
            # Adds additional jars to classpath if needed
            self._add_additional_jars_to_classpath()

        # step 2, prepare SPCS specs
        service_name = (
            generate_random_name(prefix="snowpark_submit_job_service_").upper()
            if not self.args.snowflake_workload_name
            else self.args.snowflake_workload_name.upper()
        )
        logger.debug("service_name: %s", service_name)
        comment = getattr(self.args, "comment", None)
        spcs_spec_yaml = self.prepare_spcs_spec(
            temp_stage_name=temp_stage_name,
            client_src_zip_file_path=client_src_zip_file_path,
            server_image_name=server_image_name,
            client_image_name=client_image_name,
            service_name=service_name,
        )

        # step 3, spins up SPCS service
        logger.debug("Start running SPCS job service %s", service_name)
        execute_spcs_sql = f"""
EXECUTE JOB SERVICE
    IN COMPUTE POOL {self.compute_pool}
    NAME={service_name}{f'''
    COMMENT='{comment}' ''' if comment else ''}
    ASYNC = TRUE
    FROM SPECIFICATION $$
{textwrap.indent(spcs_spec_yaml, ' ' * 4)}
    $$
    """
        self._snowpark_session.sql(f"drop service if exists {service_name}").collect()
        logger.debug(execute_spcs_sql)
        # TODO: return -1 when error
        try:
            res = self._snowpark_session.sql(execute_spcs_sql).collect()
            logger.debug(res)
            logger.debug(
                "Job %s has been submitted and running asynchorously in SPCS. Please find logs in event table.",
                service_name,
            )
            # SQLs to extract logs from event table. The SYSTEM$GET_SERVICE_LOGS function is not available after service is dropped.
            # And SPCS team is working on an easy function to extract logs from event table. ETA early May.
            log_line = f"""
            SHOW PARAMETERS LIKE 'EVENT_TABLE' IN ACCOUNT;
            select *
            from <event table from above query result>
            where RESOURCE_ATTRIBUTES['snow.service.type'] = 'Job'
            and RESOURCE_ATTRIBUTES['snow.service.container.name'] = 'client' -- or 'server' for server log
            and RESOURCE_ATTRIBUTES['snow.service.name'] = '{service_name}'
            and timestamp > dateadd('minute', -10, current_timestamp()) -- adjust timestamp for your case
            order by timestamp
            ;
            """
            logger.info(
                "To fetch logs from event table, please run the following SQLs: %s",
                log_line,
            )

            logger.info(
                f"To monitor the progress of the job, run following command: snowpark-submit --job-status --job-id {service_name} [--display-logs]"
            )
            if self.args.wait_for_completion:
                self.wait_for_service_completion(service_name)
        except Exception as e:
            logger.error(e)

        self._snowpark_session.close()

        return 0

    def create_temp_stage_for_upload(self):
        # Create a temporary stage for uploading files
        temp_stage_name = generate_random_name(prefix="sf_spark_submit_temp_stage_")

        # currently azure only supports SNOWFLAKE_SSE encryption type. aws supports both SNOWFLAKE_FULL/SSE
        create_stage_sql = f"CREATE OR REPLACE TEMPORARY STAGE {temp_stage_name} ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE') DIRECTORY = ( ENABLE = true );"
        self._snowpark_session.sql(create_stage_sql).collect()

        return temp_stage_name

    def describe(
        self, service_name: str | None = None, display_logs: bool = False
    ) -> tuple[int, bool | None]:
        """
        return -> (exit status code, is_service_terminated [True/False] or None if service does not exist)
        """
        workload_name = service_name or self.args.snowflake_workload_name.upper()
        if not workload_name:
            logger.error("Missing mandatory option --snowflake-workload-name")
            return 1, None
        service_status_result = self._snowpark_session.sql(
            f"DESCRIBE SERVICE {workload_name};"
        ).collect()

        if not service_status_result:
            logger.error(
                f"Workload with name {workload_name} does not exist or has already been deleted."
            )
            return 1, None

        # Gets the job status information from JOB SERVICE from SPCS
        service_status = service_status_result[0]["status"]
        service_created_on = (
            service_status_result[0]["created_on"]
            .astimezone(timezone.utc)
            .isoformat(sep=" ", timespec="microseconds")
        )
        terminated = service_status.upper() in [
            "FAILED",
            "DONE",
            "SUSPENDED",
            "DELETED",
            "INTERNAL_ERROR",
        ]
        terminated_at = None
        if terminated:
            terminated_at = (
                datetime.fromisoformat(service_status_result[0]["updated_on"])
                .astimezone(timezone.utc)
                .isoformat(sep=" ", timespec="microseconds")
            )

        # Gets the job status information from JOB SERVICE containers from SPCS
        job_status_result = self._snowpark_session.sql(
            f"SHOW SERVICE CONTAINERS IN SERVICE {workload_name};"
        ).collect()
        job_status = job_status_result[0]["service_status"]

        # Format job start time if it exists
        job_start_time_result = job_status_result[0]["start_time"]
        job_start_time = (
            datetime.fromisoformat(job_start_time_result)
            .astimezone(timezone.utc)
            .isoformat(sep=" ", timespec="microseconds")
            if job_start_time_result
            else None
        )
        job_exit_code = job_status_result[0]["last_exit_code"]

        # Prints the unified status. All timestamp are in UTC.
        logger.info(f"Snowflake Workload Name: {workload_name}")
        logger.info(f"Service Status: {service_status}")
        logger.info(f"Workload Status: {job_status}")
        logger.info(f"Created On: {service_created_on}")
        logger.info(f"Started At: {job_start_time}")
        logger.info(f"Terminated At: {terminated_at}")
        logger.info(f"Exit Code: {job_exit_code}")

        if display_logs or self.args.display_logs:
            event_table_result = self._snowpark_session.sql(
                "SHOW PARAMETERS LIKE 'EVENT_TABLE' IN ACCOUNT;"
            ).collect()
            if not event_table_result:
                logger.error("Event table has not been configured.")
                return 0, terminated

            log_start_time = job_start_time

            log_end_time = terminated_at
            if not terminated:
                now = datetime.now().astimezone(timezone.utc)  # Attach local timezone
                log_end_time = now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] + now.strftime(
                    " %z"
                )

            event_table_sql = f"""
select timestamp, value
from {event_table_result[0]["value"]}
where RESOURCE_ATTRIBUTES['snow.service.type'] = 'Job'
and RESOURCE_ATTRIBUTES['snow.service.container.name'] = 'client'
and RESOURCE_ATTRIBUTES['snow.service.name'] = '{workload_name}'
and timestamp >= '{log_start_time}'
and timestamp <= '{log_end_time}'
order by timestamp asc;
"""
            logger.info("Application Logs:")

            # Prints the client container logs with timestamp
            logs_df = self._snowpark_session.sql(event_table_sql)
            rows = logs_df.collect()

            # Print each row with space separator
            for row in rows:
                logger.info(" ".join(str(x) for x in row))

        return 0, terminated
