import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from pyspark.errors.exceptions.base import AnalysisException

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark.types import StructType
from snowflake.snowpark_connect import dataframe_name_handler
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.attribute_handling import (
    split_fully_qualified_spark_name,
)


def check_struct_and_get_field_datatype(field_name, schema):
    if isinstance(schema, StructType):
        if field_name in schema.names:
            return schema.__getitem__(field_name).datatype
        else:
            raise AnalysisException(
                f"[FIELD_NOT_FOUND] No such struct field `{field_name}` in `{schema.field}`"
            )
    else:
        None


def map_unresolved_star(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    if exp.unresolved_star.HasField("unparsed_target"):
        unparsed_target = exp.unresolved_star.unparsed_target
        name_parts = split_fully_qualified_spark_name(unparsed_target)

        assert (
            len(name_parts) > 1 and name_parts[-1] == "*"
        ), f"Unable to parse unparsed_target {unparsed_target}"

        prefix_candidate = (
            column_mapping.get_snowpark_column_name_from_spark_column_name(
                name_parts[0], allow_non_exists=True
            )
        )

        if prefix_candidate is None:
            if dataframe_name_handler.is_df_name(name_parts[0]):
                name_parts[0] = None
            else:
                raise AnalysisException(
                    f"[CANNOT_RESOLVE_STAR_EXPAND] Cannot resolve `{unparsed_target}`. Please check that the specified table or struct exists and is accessible in the input columns."
                )
        else:
            name_parts[0] = prefix_candidate

        if name_parts[0]:  # semi-structured data types
            candidate_leaf_field = typer.df.schema

            for subfield in name_parts[:-1]:
                if (
                    candidate_leaf_field := check_struct_and_get_field_datatype(
                        subfield, candidate_leaf_field
                    )
                ) is None:
                    raise ValueError("Can only star expand struct data types.")

            parsed_target_sql_expr = ":".join(name_parts[:-1])

            spark_names = candidate_leaf_field.names
            all_snowpark_names = [
                f"{parsed_target_sql_expr}:{spark_name}" for spark_name in spark_names
            ]
            final_sql_expr = snowpark_fn.sql_expr(", ".join(all_snowpark_names))
            return spark_names, TypedColumn(
                final_sql_expr, lambda: typer.type(final_sql_expr)
            )

    result_exp = snowpark_fn.col("*", _is_qualified_name=True)
    return ["*"], TypedColumn(result_exp, lambda: typer.type(result_exp))
