from snowflake import snowpark
from snowflake.snowpark import Column, DataFrame
from snowflake.snowpark._internal.analyzer.expression import (
    Attribute,
    Literal,
    UnresolvedAttribute,
)
from snowflake.snowpark.types import DataType, LongType, StructField, StructType
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.utils.context import get_outer_dataframes
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session


class ExpressionTyper:
    def __init__(self, df: DataFrame) -> None:
        self.df = df

    def type(self, column: Column) -> list[DataType]:
        types = None
        expr = column._expression if hasattr(column, "_expression") else None
        match expr:
            case UnresolvedAttribute() | Attribute():
                # there is a chance that df.schema is already evaluated
                types = [
                    f.datatype
                    for f in self.df.schema.fields
                    if (
                        f.name == expr.name
                        or (
                            (not global_config.spark_sql_caseSensitive)
                            and f.name.lower() == expr.name.lower()
                        )
                    )
                ]  # doesn't work for nested attributes e.g. `"properties-3":"salary"`
            case Literal():
                types = [expr.datatype]

        # df.select().schema results in DESCRIBE call to Snowflake, so avoid it if possible
        if not types:
            df = self.df
            for outer_df in get_outer_dataframes():
                df = df.join(outer_df)
            types = [f.datatype for f in df.select(column).schema.fields]

        return types

    @staticmethod
    def dummy_typer(session: snowpark.Session = None):
        """
        Get a dummy typer, which can be used to get expression types. Since typer requires a dataframe,
        the dummy typer is mainly used when there is no existing handy dataframe.

        Example:
            (_, typed_column) = map_single_column_expression(
                    expression, column_map, ExpressionTyper.dummy_typer(session)
                )
        """
        if session is None:
            session = get_or_create_snowpark_session()
        empty_df = session.create_dataframe(
            [], schema=StructType([StructField("id", LongType(), True)])
        )
        typer = ExpressionTyper(empty_df)
        return typer
