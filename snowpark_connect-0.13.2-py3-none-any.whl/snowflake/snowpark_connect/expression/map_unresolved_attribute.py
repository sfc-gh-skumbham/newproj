import re
from typing import Tuple

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark._internal.utils import quote_name
from snowflake.snowpark.types import StructType
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.attribute_handling import (
    split_fully_qualified_spark_name,
)
from snowflake.snowpark_connect.utils.context import (
    get_alias_map,
    get_outer_dataframes,
    get_plan_id_map,
)

SPARK_QUOTED = re.compile("^(`.*`)$", re.DOTALL)


def map_unresolved_attribute(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    attr_name = exp.unresolved_attribute.unparsed_identifier
    name_parts = split_fully_qualified_spark_name(attr_name)

    assert len(name_parts) > 0, f"Unable to parse input attribute: {attr_name}"

    attr_name = ".".join(name_parts)

    if exp.unresolved_attribute.HasField("plan_id"):
        target_df = get_plan_id_map(exp.unresolved_attribute.plan_id)
        typer = ExpressionTyper(target_df)
        assert (
            target_df is not None
        ), f"resolving an attribute of a unresolved dataframe {exp.unresolved_attribute.plan_id}"
        snowpark_name = (
            target_df._column_map.get_snowpark_column_name_from_spark_column_name(
                name_parts[0]
            )
        )
        col = target_df.col(snowpark_name)
        # for struct columns when accessed, spark use just the leaf field name rather than fully attributed one
        if isinstance(typer.type(col)[0], StructType):
            attr_name = name_parts[-1]
        for child_name in name_parts[1:]:
            col = col.getItem(child_name)
    else:
        snowpark_name = column_mapping.get_snowpark_column_name_from_spark_column_name(
            name_parts[0], allow_non_exists=True
        )
        if snowpark_name is None:
            # check for alias
            (alias_name, col_name) = _parse_spark_column_alias(attr_name)
            if col_name is not None and alias_name in get_alias_map():
                alias_df = get_alias_map()[alias_name]
                typer = ExpressionTyper(alias_df)
                snowpark_name = alias_df._column_map.get_snowpark_column_name_from_spark_column_name(
                    col_name
                )
                col = alias_df.col(snowpark_name)
                return col_name, TypedColumn(col, lambda: typer.type(col))

            for outer_df in get_outer_dataframes():
                snowpark_name = outer_df._column_map.get_snowpark_column_name_from_spark_column_name(
                    name_parts[0]
                )
                if snowpark_name is not None:
                    break
            else:
                # Column does not exist. Pass in dummy column name for lazy error throwing.
                snowpark_name = attr_name

        if len(name_parts) > 1:
            if isinstance(typer.type(snowpark_fn.col(snowpark_name))[0], StructType):
                attr_name = name_parts[-1]
            # Add the quotes to match the snowpark schema. We added them to escape special character in the child names.
            child_chain = ".".join([quote_name(name, True) for name in name_parts[1:]])
            snowpark_name = f"""{snowpark_name}.{child_chain}"""
            col = snowpark_fn.col(
                snowpark_name,
                _is_qualified_name=True,
            )
        else:
            col = snowpark_fn.col(snowpark_name)

    return (attr_name, TypedColumn(col, lambda: typer.type(col)))


def _parse_spark_column_alias(attr_name: str) -> Tuple[str, str | None]:
    """Parse df_alias.col to (df_alias, col)"""
    # TODO: properly handle alias and column names that contains ` and .
    res = attr_name.split(".")
    if len(res) == 1:
        return res[0], None
    return res[0], res[1]
