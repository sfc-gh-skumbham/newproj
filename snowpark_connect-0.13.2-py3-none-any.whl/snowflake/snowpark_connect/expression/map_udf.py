import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import proto_to_snowpark_type
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.utils.udf_helper import (
    SnowparkUDF,
    gen_input_types,
    infer_snowpark_arguments,
    process_udf_in_sproc,
    require_creating_udf_in_sproc,
    udf_check,
)
from snowflake.snowpark_connect.utils.udf_utils import (
    ProcessCommonInlineUserDefinedFunction,
)


def register_udf(
    udf_proto: expressions_proto.CommonInlineUserDefinedFunction,
) -> SnowparkUDF:
    udf_check(udf_proto)
    kwargs = {
        "common_inline_user_defined_function": udf_proto,
        "called_from": "register_udf",
        "return_type": proto_to_snowpark_type(udf_proto.python_udf.output_type),
        "udf_packages": global_config.get("snowpark.connect.udf.packages", ""),
    }

    if require_creating_udf_in_sproc(udf_proto):
        return process_udf_in_sproc(**kwargs)
    else:
        udf_processor = ProcessCommonInlineUserDefinedFunction(**kwargs)
        session = get_or_create_snowpark_session()
        udf = udf_processor.create_udf()
        udf = SnowparkUDF(
            name=udf.name, input_types=udf._input_types, return_type=udf._return_type
        )
        # the create udf does register the udf but this seems to be for the client side check
        # TODO: check if this is needed
        session._udfs[udf_proto.function_name.lower()] = udf
        return udf


def map_common_inline_user_defined_udf(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    udf_proto = exp.common_inline_user_defined_function
    udf_check(udf_proto)
    snowpark_udf_arg_names, snowpark_udf_args = infer_snowpark_arguments(
        udf_proto, column_mapping, typer
    )
    input_types = gen_input_types(snowpark_udf_args, typer)
    kwargs = {
        "common_inline_user_defined_function": udf_proto,
        "input_types": input_types,
        "called_from": "map_common_inline_user_defined_udf",
        "return_type": proto_to_snowpark_type(udf_proto.python_udf.output_type),
        "udf_packages": global_config.get("snowpark.connect.udf.packages", ""),
    }
    if require_creating_udf_in_sproc(udf_proto):
        snowpark_udf = process_udf_in_sproc(**kwargs)
    else:
        udf_processor = ProcessCommonInlineUserDefinedFunction(**kwargs)
        udf = udf_processor.create_udf()
        snowpark_udf = SnowparkUDF(
            name=udf.name, input_types=udf._input_types, return_type=udf._return_type
        )
    return (
        f"{udf_proto.function_name}({', '.join(snowpark_udf_arg_names)})",
        TypedColumn(
            snowpark_fn.call_udf(snowpark_udf.name, *snowpark_udf_args),
            lambda: [snowpark_udf.return_type],
        ),
    )
