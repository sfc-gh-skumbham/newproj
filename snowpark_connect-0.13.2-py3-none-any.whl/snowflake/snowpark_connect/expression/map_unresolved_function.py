import datetime
import functools
import inspect
import math
import operator
import random
import string
import sys
import tempfile
import time
import uuid
from collections import defaultdict
from contextlib import suppress
from decimal import Decimal
from functools import partial, reduce
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote, unquote

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from google.protobuf.message import Message
from pyspark.errors.exceptions.base import (
    AnalysisException,
    IllegalArgumentException,
    NumberFormatException,
    SparkRuntimeException,
)
from pyspark.sql.types import _parse_datatype_json_string

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark import Column, Session
from snowflake.snowpark._internal.analyzer.unary_expression import Alias
from snowflake.snowpark.types import (
    ArrayType,
    BinaryType,
    BooleanType,
    ByteType,
    DataType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    MapType,
    NullType,
    ShortType,
    StringType,
    StructField,
    StructType,
    TimestampTimeZone,
    TimestampType,
    VariantType,
    _FractionalType,
    _IntegralType,
    _NumericType,
)
from snowflake.snowpark_connect.column_name_handler import (
    ColumnNameMap,
    set_schema_getter,
)
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.constants import (
    DUPLICATE_KEY_FOUND_ERROR_TEMPLATE,
    SPARK_TZ_ABBREVIATIONS_OVERRIDES,
    STRUCTURED_TYPES_ENABLED,
)
from snowflake.snowpark_connect.expression.literal import get_literal_field_and_name
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.relation.catalogs.utils import CURRENT_CATALOG_NAME
from snowflake.snowpark_connect.type_mapping import (
    map_pyspark_types_to_snowpark_types,
    map_snowpark_to_pyspark_types,
    map_spark_number_format_expression,
    map_spark_timestamp_format_expression,
    map_type_string_to_snowpark_type,
    parse_ddl_string,
)
from snowflake.snowpark_connect.typed_column import (
    TypedColumn,
    TypedColumnWithDeferredCast,
)
from snowflake.snowpark_connect.utils.context import (
    get_is_aggregate_function,
    get_is_evaluating_sql,
    get_spark_version,
    is_in_pivot,
    is_window_enabled,
    resolving_fun_args,
    resolving_lambda_function,
    set_is_aggregate_function,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)
from snowflake.snowpark_connect.utils.udf_cache import (
    cached_udaf,
    cached_udf,
    cached_udtf,
    register_cached_java_udf,
    register_cached_sql_udf,
)
from snowflake.snowpark_connect.utils.xxhash64 import (
    DEFAULT_SEED,
    xxhash64_double,
    xxhash64_float,
    xxhash64_int,
    xxhash64_long,
    xxhash64_string,
)

MAX_UINT64 = 2**64 - 1
MIN_INT64 = -(2**63)
SYMBOL_FUNCTIONS = {"<", ">", "<=", ">=", "!=", "+", "-", "*", "/", "%", "div"}
NAN, INFINITY = float("nan"), float("inf")


def _validate_numeric_args(
    function_name: str, typed_args: list, snowpark_args: list
) -> list:
    """Validates that the first two arguments are numeric types. Follows spark and casts strings to double.

    Args:
        function_name: Name of the function being validated (for error message)
        typed_args: List of TypedColumn arguments to check
        snowpark_args: List of Column objects that may be modified

    Returns:
        Modified snowpark_args with string columns cast to DoubleType

    Raises:
        TypeError: If arguments cannot be converted to numeric types
    """
    if len(typed_args) < 2:
        raise ValueError(f"{function_name} requires at least 2 arguments")

    modified_args = list(snowpark_args)

    # Looping so that we can adjust for fewer/more arguments in the future if needed.
    for i in range(2):
        arg_type = typed_args[i].typ

        match arg_type:
            case _NumericType():
                continue
            case StringType():
                # Cast strings to doubles following Spark
                # https://github.com/apache/spark/blob/master/sql/catalyst/src/main/scala/org/apache/spark/sql/catalyst/analysis/TypeCoercion.scala#L204
                modified_args[i] = snowpark_fn.try_cast(snowpark_args[i], DoubleType())
            case _:
                raise TypeError(
                    f"Data type mismatch: {function_name} requires numeric types, but got {typed_args[0].typ} and {typed_args[1].typ}."
                )

    return modified_args


def get_timestamp_type():
    match global_config["spark.sql.timestampType"]:
        case "TIMESTAMP_LTZ":
            timestamp_type = TimestampType(TimestampTimeZone.LTZ)
        case "TIMESTAMP_NTZ":
            timestamp_type = TimestampType(TimestampTimeZone.NTZ)
        case "TIMESTAMP_TZ":
            timestamp_type = TimestampType(TimestampTimeZone.TZ)
        case _:
            timestamp_type = TimestampType(TimestampTimeZone.DEFAULT)
    return timestamp_type


def unwrap_literal(exp: expressions_proto.Expression):
    """Workaround for Snowpark functions generating invalid SQL when used with fn.lit (SNOW-1871954)"""
    return get_literal_field_and_name(exp.literal)[0]


def _coerce_for_equality(
    left: TypedColumn, right: TypedColumn
) -> tuple[Column, Column]:
    if left.typ == right.typ:
        return left.col, right.col

    # To avoid handling both (A, B) and (B, A), swap them in the second case, then swap back at the end.
    if type(left.typ).__name__ > type(right.typ).__name__:
        left, right = right, left
        swap = True
    else:
        swap = False

    left_col = left.col
    right_col = right.col

    match (left.typ, right.typ):
        case (BooleanType(), IntegerType()):
            left_col = left_col.cast(LongType())
        case (BooleanType(), LongType()):
            left_col = left_col.cast(LongType())
        case (BooleanType(), FloatType()):
            left_col = left_col.cast(IntegerType()).cast(FloatType())
        case (BooleanType(), DoubleType()):
            left_col = left_col.cast(IntegerType()).cast(DoubleType())
        case (BooleanType(), StringType()):
            right_col = right_col.try_cast(BooleanType())
        case (IntegerType(), StringType()):
            right_col = right_col.try_cast(LongType())
        case (LongType(), StringType()):
            right_col = right_col.try_cast(LongType())
        case (FloatType(), StringType()):
            right_col = right_col.try_cast(FloatType())
        case (DoubleType(), StringType()):
            right_col = right_col.try_cast(DoubleType())
        case (DecimalType(), StringType()):
            right_col = right_col.try_cast(DoubleType())

    if swap:
        return right_col, left_col
    else:
        return left_col, right_col


def map_unresolved_function(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    from snowflake.snowpark_connect.expression.map_expression import map_expression

    session = Session.get_active_session()

    args_types = list(
        map(lambda a: a.WhichOneof("expr_type"), exp.unresolved_function.arguments)
    )
    # Functions that accept lambda parameters are handled separately to keep the resolution of other functions simple.
    # Lambda parameter types often depend on the types of other arguments passed to the function.
    if "lambda_function" in args_types:
        return _resolve_function_with_lambda(exp, column_mapping, typer)
    if get_is_aggregate_function()[1]:
        set_is_aggregate_function(
            (exp.unresolved_function.function_name, get_is_aggregate_function()[1])
        )

    def _resolve_args_expressions(exp: expressions_proto.Expression):
        def _resolve_fn_arg(exp):
            with resolving_fun_args():
                return map_expression(exp, column_mapping, typer)

        def _unalias_column(tc: TypedColumn) -> TypedColumn:
            # This is required to avoid SQL compilation errors when aliases are used inside subexpressions.
            # We unwrap such aliases and use a child expression for snowpark's evaluation.
            if hasattr(tc.col, "_expression"):
                col_exp = tc.col._expression
                if isinstance(col_exp, Alias):
                    return TypedColumn(Column(col_exp.child), lambda: tc.types)
            return tc

        resolved = [_resolve_fn_arg(arg) for arg in exp.unresolved_function.arguments]
        resolved_without_alias = [
            (names, _unalias_column(tc)) for names, tc in resolved
        ]
        not_empty = list(filter(lambda x: not x[1].is_empty(), resolved_without_alias))
        return zip(*not_empty) if not_empty else ([], [])

    resolved_snowpark_args: tuple[list[str], list[TypedColumn]] = (
        _resolve_args_expressions(exp)
        if len(exp.unresolved_function.arguments) > 0
        else ([], [])
    )

    snowpark_arg_names, snowpark_typed_args = resolved_snowpark_args

    snowpark_arg_names: List[str] = [n for names in snowpark_arg_names for n in names]
    snowpark_args: List[Column] = [arg.col for arg in snowpark_typed_args]

    # default function name
    spark_function_name = (
        f"({snowpark_arg_names[0]} {exp.unresolved_function.function_name} {snowpark_arg_names[1]})"
        if exp.unresolved_function.function_name in SYMBOL_FUNCTIONS
        else f"{exp.unresolved_function.function_name}({', '.join(snowpark_arg_names)})"
    )
    spark_col_names = []
    spark_sql_ansi_enabled = global_config.spark_sql_ansi_enabled

    function_name = exp.unresolved_function.function_name.lower()
    result_type: Optional[DataType | List[DateType]] = None

    def _type_with_typer(col: Column) -> TypedColumn:
        """If you can, avoid using this function. Typer most likely has to call GS to resovle type which is expensive."""
        return TypedColumn(col, lambda: typer.type(col))

    def _resolve_aggregate_exp(
        result_exp: Column, default_result_type: DataType
    ) -> TypedColumn:
        if is_in_pivot():
            # it's not possible to cast the result in pivot
            return _type_with_typer(result_exp)
        elif is_window_enabled():
            # defer casting to capture whole window expression
            return TypedColumnWithDeferredCast(
                result_exp, lambda: [default_result_type]
            )
        else:
            return TypedColumn(
                snowpark_fn.cast(result_exp, default_result_type),
                lambda: [default_result_type],
            )

    def _validate_arity(
        valid_arity: int | list[int] | tuple[Optional[int], Optional[int]]
    ) -> None:
        """
        Validates that the number of arguments passed to a function matches the expected arity.
        Args:
            valid_arity: Can be:
                - An integer specifying the exact required number of arguments
                - A list of integers specifying valid argument counts
                - A tuple (min_arity, None) specifying a minimum number of arguments
                - A tuple (None, max_arity) specifying a maximum number of arguments
        Raises:
            AnalysisException: If the number of actual arguments doesn't match the expected arity
        """
        arity = len(snowpark_args)
        match valid_arity:
            case expected if isinstance(expected, int):
                invalid = arity != expected
                expected_arity = expected
            case (min_arity, None):
                invalid = arity < min_arity
                expected_arity = f"> {min_arity-1}"
            case (None, max_arity):
                invalid = arity > max_arity
                expected_arity = f"< {max_arity+1}"
            case _:
                invalid = arity not in valid_arity
                expected_arity = str(valid_arity)

        if invalid:
            raise AnalysisException(
                f"[WRONG_NUM_ARGS.WITHOUT_SUGGESTION] The `{function_name}` requires {expected_arity} parameters but the actual number is {arity}."
            )

    match function_name:
        case func_name if get_is_evaluating_sql() and func_name.lower() in session._udfs:
            # TODO: In Spark, UDFs can override built-in functions in SQL,
            # but not in DataFrame ops.
            udf = session._udfs[func_name.lower()]
            result_exp = snowpark_fn.call_udf(
                udf.name,
                *(snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args),
            )
            result_type = udf.return_type
        case func_name if get_is_evaluating_sql() and func_name.lower() in session._udtfs:
            udtf, spark_col_names = session._udtfs[func_name.lower()]
            result_exp = udtf(
                *(snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args)
            )
            result_type = [f.datatype for f in udtf._output_schema]
        case "!=":
            result_exp = TypedColumn(
                snowpark_args[0] != snowpark_args[1], lambda: [BooleanType()]
            )
        case "%" | "mod":
            if spark_sql_ansi_enabled:
                result_exp = snowpark_args[0] % snowpark_args[1]
            else:
                # when divisor is zero return None instead of error.
                result_exp = snowpark_fn.when(
                    snowpark_args[1] == 0, snowpark_fn.lit(None)
                ).otherwise(snowpark_args[0] % snowpark_args[1])
            # TODO SNOW-2034420: resolve return type
            result_exp = _type_with_typer(result_exp)
        case "*":
            result_exp = snowpark_args[0] * snowpark_args[1]
            # TODO SNOW-2034420: resolve return type
            result_exp = _type_with_typer(result_exp)
        case "+":
            result_exp = snowpark_args[0] + snowpark_args[1]
            # TODO SNOW-2034420: resolve return type
            result_exp = _type_with_typer(result_exp)
        case "-":
            result_exp = snowpark_args[0] - snowpark_args[1]
            # TODO SNOW-2034420: resolve return type
            result_exp = _type_with_typer(result_exp)
        case "/":
            if spark_sql_ansi_enabled:
                result_exp = snowpark_args[0] / snowpark_args[1]
            elif isinstance(
                snowpark_typed_args[0].typ, (IntegerType, LongType, ShortType)
            ) and isinstance(
                snowpark_typed_args[1].typ, (IntegerType, LongType, ShortType)
            ):
                #  Check if both arguments are integer types. Snowpark performs integer division, and precision is lost.
                #  Cast to double and perform division
                result_exp = _divnull(
                    snowpark_args[0].cast(DoubleType()),
                    snowpark_args[1].cast(DoubleType()),
                )
            else:
                # Perform division directly
                result_exp = _divnull(snowpark_args[0], snowpark_args[1])
            # TODO SNOW-2034420: resolve return type
            result_exp = _type_with_typer(result_exp)
        case "~":
            result_exp = TypedColumn(
                snowpark_fn.bitnot(snowpark_args[0]),
                lambda: snowpark_typed_args[0].types,
            )
            spark_function_name = f"~{snowpark_arg_names[0]}"
        case "<":
            result_exp = TypedColumn(
                snowpark_args[0] < snowpark_args[1], lambda: [BooleanType()]
            )
        case "<=":
            result_exp = TypedColumn(
                snowpark_args[0] <= snowpark_args[1], lambda: [BooleanType()]
            )
        case "<=>":
            # eqNullSafe
            rarg_name = snowpark_arg_names[1]
            typ = snowpark_typed_args[1].typ
            if typ == DoubleType() or typ == FloatType():
                if rarg_name == "nan":
                    rarg_name = "NaN"

            spark_function_name = f"({snowpark_arg_names[0]} <=> {rarg_name})"
            left, right = _coerce_for_equality(
                snowpark_typed_args[0], snowpark_typed_args[1]
            )
            result_exp = TypedColumn(left.eqNullSafe(right), lambda: [BooleanType()])
        case "==" | "=":
            spark_function_name = f"({snowpark_arg_names[0]} = {snowpark_arg_names[1]})"
            left, right = _coerce_for_equality(
                snowpark_typed_args[0], snowpark_typed_args[1]
            )
            result_exp = TypedColumn(left == right, lambda: [BooleanType()])
        case ">":
            result_exp = TypedColumn(
                snowpark_args[0] > snowpark_args[1], lambda: [BooleanType()]
            )
        case ">=":
            result_exp = TypedColumn(
                snowpark_args[0] >= snowpark_args[1], lambda: [BooleanType()]
            )
        case "&":
            spark_function_name = f"({snowpark_arg_names[0]} & {snowpark_arg_names[1]})"
            result_exp = TypedColumn(
                snowpark_args[0].bitwiseAnd(snowpark_args[1]),
                lambda: [LongType()],
            )
        case "|":
            spark_function_name = f"({snowpark_arg_names[0]} | {snowpark_arg_names[1]})"
            result_exp = TypedColumn(
                snowpark_args[0].bitwiseOR(snowpark_args[1]),
                lambda: [LongType()],
            )
        case "^":
            spark_function_name = f"({snowpark_arg_names[0]} ^ {snowpark_arg_names[1]})"
            result_exp = TypedColumn(
                snowpark_args[0].bitwiseXOR(snowpark_args[1]),
                lambda: [LongType()],
            )
        case "abs":
            input_type = snowpark_typed_args[0].typ
            if isinstance(input_type, StringType):
                result_exp = snowpark_fn.abs(
                    snowpark_fn.cast(snowpark_args[0], DoubleType())
                )
                result_type = DoubleType()
            else:
                result_exp = snowpark_fn.abs(snowpark_args[0])
                result_type = input_type
        case "acos":
            spark_function_name = f"ACOS({snowpark_arg_names[0]})"
            result_exp = TypedColumn(
                snowpark_fn.when(
                    (snowpark_args[0] < -1) | (snowpark_args[0] > 1), NAN
                ).otherwise(snowpark_fn.acos(snowpark_args[0])),
                lambda: [DoubleType()],
            )
        case "acosh":
            spark_function_name = f"ACOSH({snowpark_arg_names[0]})"
            result_exp = TypedColumn(
                snowpark_fn.when((snowpark_args[0] < 1), NAN).otherwise(
                    snowpark_fn.acosh(snowpark_args[0])
                ),
                lambda: [DoubleType()],
            )
        case "add_months":
            result_exp = TypedColumn(
                _try_to_cast(
                    "try_to_date",
                    snowpark_fn.add_months(
                        snowpark_fn.to_date(snowpark_args[0]), snowpark_args[1]
                    ),
                    snowpark_args[0],
                ),
                lambda: [DateType()],
            )
        case "aes_decrypt":
            result_exp = TypedColumn(
                _aes_helper(
                    "DECRYPT",
                    snowpark_args[0],
                    snowpark_args[1],
                    snowpark_args[4],
                    snowpark_args[2],
                    snowpark_args[3],
                ),
                lambda: [BinaryType()],
            )
        case "aes_encrypt":
            result_exp = TypedColumn(
                _aes_helper(
                    "ENCRYPT",
                    snowpark_args[0],
                    snowpark_args[1],
                    snowpark_args[5],
                    snowpark_args[2],
                    snowpark_args[3],
                ),
                lambda: [BinaryType()],
            )
        case "and":
            spark_function_name = (
                f"({snowpark_arg_names[0]} AND {snowpark_arg_names[1]})"
            )
            result_exp = TypedColumn(
                snowpark_args[0] & snowpark_args[1], lambda: [BooleanType()]
            )
        case "any":
            if (
                snowpark_typed_args[0].typ != BooleanType()
                and snowpark_typed_args[0].typ != NullType()
            ):
                raise AnalysisException(
                    f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "any({snowpark_arg_names[0]})" due to data type mismatch: Parameter 1 requires the "BOOLEAN" type, however "{snowpark_arg_names[0]}" has the type {snowpark_typed_args[0].typ.simpleString().upper()}.'
                )
            result_exp = TypedColumn(
                snowpark_fn.max(snowpark_args[0]),
                lambda: [BooleanType()],
            )
        case "any_value":
            # SNOW-1955766: Support ignore null parameter
            result_exp = TypedColumn(
                snowpark_fn.any_value(*snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "approx_count_distinct":
            match snowpark_args:
                case [data]:
                    result_exp = TypedColumn(
                        snowpark_fn.approx_count_distinct(data),
                        lambda: [LongType()],
                    )
                case [_, _]:
                    raise SnowparkConnectNotImplementedError(
                        "'rsd' parameter is not supported"
                    )
        case "approx_percentile" | "percentile_approx":
            # SNOW-1955784: Support accuracy parameter

            # Even though the Spark function accepts a Column for percentage, it will fail unless it's a literal.
            # Therefore, we can do error checking right here.
            def _check_percentage(exp: expressions_proto.Expression) -> Column:
                perc = unwrap_literal(exp)
                if not 0.0 <= perc <= 1.0:
                    raise AnalysisException("percentage must be between [0.0, 1.0]")
                return snowpark_fn.lit(perc)

            if isinstance(snowpark_typed_args[1].typ, ArrayType):
                # Snowpark doesn't accept a list of percentile values.
                # This is a workaround to fetch percentile arguments and invoke the snowpark_fn.approx_percentile serially.
                array_func = exp.unresolved_function.arguments[1].unresolved_function
                assert array_func.function_name == "array", array_func

                result_exp = snowpark_fn.array_construct(
                    *[
                        snowpark_fn.approx_percentile(
                            snowpark_args[0], _check_percentage(arg)
                        )
                        for arg in array_func.arguments
                    ]
                )
                result_exp = snowpark_fn.cast(
                    result_exp,
                    ArrayType(element_type=DoubleType(), contains_null=False),
                )
                result_type = ArrayType(element_type=DoubleType(), contains_null=False)
            else:
                result_exp = TypedColumn(
                    snowpark_fn.approx_percentile(
                        snowpark_args[0],
                        _check_percentage(exp.unresolved_function.arguments[1]),
                    ),
                    lambda: [DoubleType()],
                )
        case "array":
            if len(snowpark_args) == 0:
                result_exp = snowpark_fn.cast(
                    snowpark_fn.array_construct(), ArrayType(NullType())
                )
                result_type = ArrayType(NullType())
            else:
                result_exp = snowpark_fn.array_construct(
                    *[
                        typed_arg.column(to_semi_structure=True)
                        for typed_arg in snowpark_typed_args
                    ]
                )
                arg_types = [t for tc in snowpark_typed_args for t in tc.types]
                if spark_sql_ansi_enabled:
                    element_type = next(
                        (typ for typ in arg_types if not isinstance(typ, NullType)),
                        NullType(),
                    )
                else:
                    element_type = _find_common_type(arg_types)
                result_exp = TypedColumn(
                    snowpark_fn.cast(result_exp, ArrayType(element_type)),
                    lambda: [ArrayType(element_type)],
                )
                result_type = ArrayType(element_type)
        case "array_append":
            result_exp = TypedColumn(
                snowpark_fn.array_append(snowpark_args[0], snowpark_args[1]),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_compact":
            result_exp = TypedColumn(
                snowpark_fn.array_compact(snowpark_args[0]),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_contains":
            array_type = snowpark_typed_args[0].typ
            if not isinstance(array_type, ArrayType):
                raise AnalysisException(
                    f"Expected argument '{snowpark_arg_names[0]}' to have an ArrayType."
                )
            if not (
                isinstance(array_type.element_type, _NumericType)
                and isinstance(snowpark_typed_args[1].typ, _NumericType)
            ) and (array_type.element_type != snowpark_typed_args[1].typ):
                raise AnalysisException(
                    '[DATATYPE_MISMATCH.ARRAY_FUNCTION_DIFF_TYPES] Cannot resolve "array_contains(arr, val)" due to data type mismatch: Input to `array_contains` should have been "ARRAY" followed by a value with same element type'
                )
            value = (
                snowpark_fn.cast(snowpark_args[1], array_type.element_type)
                if array_type.structured
                else snowpark_fn.to_variant(snowpark_args[1])
            )

            result_exp = TypedColumn(
                snowpark_fn.array_contains(value, snowpark_args[0]),
                lambda: [BooleanType()],
            )
        case "array_distinct":
            result_exp = TypedColumn(
                snowpark_fn.array_distinct(snowpark_args[0]),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_except":
            result_exp = TypedColumn(
                snowpark_fn.array_except(*snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_insert":
            data = snowpark_args[0]
            spark_index = snowpark_args[1]
            el = snowpark_args[2]

            snow_index = (
                snowpark_fn.when(
                    spark_index < (snowpark_fn.array_size(data) * snowpark_fn.lit(-1)),
                    spark_index + 1,
                )
                .when(spark_index < 0, snowpark_fn.array_size(data) + spark_index + 1)
                # Trigger an exception by using a string instead of an integer.
                .when(
                    spark_index == 0,
                    snowpark_fn.lit(
                        "[snowpark_connect::INVALID_INDEX_OF_ZERO] The index 0 is invalid. An index shall be either < 0 or > 0 (the first element has index 1)."
                    ),
                )
                .otherwise(spark_index - 1)
            )

            result_exp = TypedColumn(
                snowpark_fn.array_insert(data, snow_index, el),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_intersect":
            result_exp = TypedColumn(
                snowpark_fn.array_intersection(*snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_join":
            match snowpark_args:
                case [data, delimiter]:
                    data = snowpark_fn.cast(data, VariantType())
                    data = snowpark_fn.function("filter")(
                        data, snowpark_fn.sql_expr("x -> x IS NOT NULL")
                    )
                    result_exp = snowpark_fn.array_to_string(data, delimiter)
                case [data, delimiter, _]:
                    null_replacement = unwrap_literal(
                        exp.unresolved_function.arguments[2]
                    )
                    data = snowpark_fn.cast(data, VariantType())
                    data = snowpark_fn.function("transform")(
                        data,
                        snowpark_fn.sql_expr(f"x -> IFNULL(x,'{null_replacement}')"),
                    )
                    result_exp = snowpark_fn.array_to_string(data, delimiter)
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = TypedColumn(result_exp, lambda: [StringType()])
        case "array_max":
            result_exp = TypedColumn(
                snowpark_fn.array_max(snowpark_args[0]),
                lambda: [snowpark_typed_args[0].typ.element_type],
            )
        case "array_min":
            result_exp = TypedColumn(
                snowpark_fn.array_min(snowpark_args[0]),
                lambda: [snowpark_typed_args[0].typ.element_type],
            )
        case "array_position":
            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_args[0])
                | snowpark_fn.is_null(snowpark_args[1]),
                snowpark_fn.lit(None),
            ).otherwise(
                snowpark_fn.coalesce(
                    snowpark_fn.array_position(snowpark_args[1], snowpark_args[0]),
                    snowpark_fn.lit(-1),
                )
                + 1
            )
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "array_prepend":
            result_exp = TypedColumn(
                snowpark_fn.array_prepend(snowpark_args[0], snowpark_args[1]),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_remove":
            array_type = snowpark_typed_args[0].typ
            assert isinstance(
                array_type, ArrayType
            ), f"Expected argument '{snowpark_arg_names[0]}' to have an ArrayType."
            result_exp = snowpark_fn.array_remove(snowpark_args[0], snowpark_args[1])
            if array_type.structured and array_type.element_type is not None:
                result_exp = snowpark_fn.cast(result_exp, array_type)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "array_repeat":

            @cached_udf(
                input_types=[VariantType(), LongType()],
                return_type=ArrayType(),
            )
            def _array_repeat(elem, n):
                return [elem] * n

            result_exp = snowpark_fn.cast(
                _array_repeat(
                    snowpark_fn.cast(snowpark_args[0], VariantType()), snowpark_args[1]
                ),
                ArrayType(snowpark_typed_args[0].typ),
            )
            result_exp = TypedColumn(
                result_exp, lambda: [ArrayType(snowpark_typed_args[0].typ)]
            )
        case "array_size" | "cardinality":
            array_type = snowpark_typed_args[0].typ
            if not isinstance(array_type, ArrayType):
                raise AnalysisException(
                    f"Expected argument '{snowpark_arg_names[0]}' to have an ArrayType."
                )
            result_exp = TypedColumn(
                snowpark_fn.array_size(*snowpark_args), lambda: [LongType()]
            )
        case "array_sort":
            result_exp = TypedColumn(
                snowpark_fn.array_sort(*snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "array_union":
            result_exp = snowpark_fn.array_distinct(
                snowpark_fn.array_cat(*snowpark_args)
            )
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "arrays_overlap":
            array1, array2 = snowpark_args

            array1_is_not_empty = snowpark_fn.array_size(array1) > 0
            array2_is_not_empty = snowpark_fn.array_size(array2) > 0

            array1_contains_nulls = snowpark_fn.array_contains(
                snowpark_fn.lit(None), array1
            )
            array2_contains_nulls = snowpark_fn.array_contains(
                snowpark_fn.lit(None), array2
            )

            filter_function = snowpark_fn.function("FILTER")
            is_not_null_filter = snowpark_fn.sql_expr("x -> x IS NOT NULL")

            array1_no_nulls = filter_function(array1, is_not_null_filter)
            array2_no_nulls = filter_function(array2, is_not_null_filter)

            arrays_overlap = snowpark_fn.arrays_overlap(
                array1_no_nulls, array2_no_nulls
            )

            result_exp = (
                snowpark_fn.when(
                    arrays_overlap == snowpark_fn.lit(True), arrays_overlap
                )
                .when(
                    array1_is_not_empty
                    & array2_is_not_empty
                    & (array1_contains_nulls | array2_contains_nulls),
                    snowpark_fn.lit(None),
                )
                .otherwise(snowpark_fn.lit(False))
            )
            result_exp = TypedColumn(result_exp, lambda: [BooleanType()])
        case "arrays_zip":
            # TODO: assign type
            result_exp = snowpark_fn.arrays_zip(*snowpark_args)
            result_exp = _type_with_typer(result_exp)
        case "asc":
            result_exp = TypedColumn(
                snowpark_fn.asc(snowpark_args[0]), lambda: snowpark_typed_args[0].types
            )
        case "ascii":
            # Snowflake's ascii function doesn't match PySpark's however the unicode function does.
            unicode_function = snowpark_fn.function("unicode")
            result_exp = TypedColumn(
                unicode_function(snowpark_args[0]), lambda: [LongType()]
            )
        case "asin":
            spark_function_name = f"ASIN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                (snowpark_args[0] < -1) | (snowpark_args[0] > 1), NAN
            ).otherwise(snowpark_fn.asin(snowpark_args[0]))
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "asinh":
            spark_function_name = f"ASINH({snowpark_arg_names[0]})"
            result_exp = TypedColumn(
                snowpark_fn.asinh(snowpark_args[0]), lambda: [DoubleType()]
            )
        case "assert_true":

            @cached_udf(
                input_types=[BooleanType(), StringType()],
                return_type=StringType(),
            )
            def _assert_true(expr, message=None):
                if not expr:
                    raise ValueError(message)

            result_exp = TypedColumn(
                _assert_true(*snowpark_args), lambda: [StringType()]
            )
        case "atan":
            spark_function_name = f"ATAN({snowpark_arg_names[0]})"
            result_exp = TypedColumn(
                snowpark_fn.atan(snowpark_args[0]), lambda: [DoubleType()]
            )
        case "atan2":
            spark_function_name = (
                f"ATAN2({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = TypedColumn(
                snowpark_fn.atan2(snowpark_args[0], snowpark_args[1]),
                lambda: [DoubleType()],
            )
        case "atanh":
            spark_function_name = f"ATANH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                (snowpark_args[0] < -1) | (snowpark_args[0] > 1), NAN
            ).otherwise(snowpark_fn.atanh(snowpark_args[0]))
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "avg" | "mean":
            spark_function_name = f"avg({snowpark_arg_names[0]})"
            input_type = snowpark_typed_args[0].typ
            if isinstance(input_type, DecimalType):
                result_type = _bounded_decimal(
                    input_type.precision + 4, input_type.scale + 4
                )
            else:
                result_type = DoubleType()

            result_exp = _resolve_aggregate_exp(
                snowpark_fn.avg(snowpark_args[0]),
                result_type,
            )
        case "base64":
            base64_encoding_function = snowpark_fn.function("base64_encode")
            result_exp = TypedColumn(
                base64_encoding_function(snowpark_args[0]), lambda: [StringType()]
            )
        case "bin":

            @cached_udf(
                input_types=[VariantType()],
                return_type=StringType(),
            )
            def _to_bin_udf(intval):
                try:
                    intval = int(intval)
                except (ValueError, TypeError):
                    return None

                return format(intval if intval >= 0 else (1 << 64) + intval, "b")

            result_exp = TypedColumn(
                _to_bin_udf(snowpark_fn.cast(snowpark_args[0], VariantType())),
                lambda: [StringType()],
            )
        case "bit_and":
            bit_and_agg_function = snowpark_fn.function("BITAND_AGG")
            result_exp = TypedColumn(
                bit_and_agg_function(snowpark_args[0]), lambda: [LongType()]
            )
        case "bit_count":

            @cached_udf(
                input_types=[VariantType()],
                return_type=LongType(),
            )
            def _bit_count_udf(intval):
                try:
                    return int(intval).bit_count()
                except (ValueError, TypeError):
                    return None

            result_exp = _bit_count_udf(
                snowpark_fn.cast(snowpark_args[0], VariantType())
            )
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "bit_get" | "getbit":
            bit_get_function = snowpark_fn.function("GETBIT")
            result_exp = TypedColumn(
                bit_get_function(*snowpark_args), lambda: [LongType()]
            )
        case "bit_length":
            bit_length_function = snowpark_fn.function("bit_length")
            result_exp = TypedColumn(
                bit_length_function(snowpark_args[0]), lambda: [LongType()]
            )
        case "bit_or":
            bit_or_agg_function = snowpark_fn.function("BITOR_AGG")
            result_exp = TypedColumn(
                bit_or_agg_function(snowpark_args[0]), lambda: [LongType()]
            )
        case "bit_xor":
            bit_xor_agg_function = snowpark_fn.function("BITXOR_AGG")
            result_exp = TypedColumn(
                bit_xor_agg_function(snowpark_args[0]), lambda: [LongType()]
            )
        case "bitmap_bit_position":
            result_exp = TypedColumn(
                snowpark_fn.bitmap_bit_position(snowpark_args[0]),
                lambda: [LongType()],
            )
        case "bitmap_bucket_number":
            result_exp = TypedColumn(
                snowpark_fn.bitmap_bucket_number(snowpark_args[0]),
                lambda: [LongType()],
            )
        case "bool_and" | "every":
            bool_and_agg_function = snowpark_fn.function("booland_agg")
            result_exp = TypedColumn(
                bool_and_agg_function(*snowpark_args), lambda: [BooleanType()]
            )
        case "bool_or":
            bool_or_agg_function = snowpark_fn.function("boolor_agg")
            result_exp = TypedColumn(
                bool_or_agg_function(*snowpark_args), lambda: [BooleanType()]
            )
        case "bround":
            scale = (
                unwrap_literal(exp.unresolved_function.arguments[1])
                if len(snowpark_args) > 1
                else 0
            )

            match snowpark_typed_args[0].typ:
                case DecimalType():
                    result_exp = snowpark_fn.bround(
                        snowpark_args[0], snowpark_fn.lit(scale)
                    )
                    # TODO SNOW-2034495: type
                    result_exp = _type_with_typer(result_exp)
                case _:
                    # TODO: Snowflake's bround only supports decimal, not floating point types.
                    # If fixing this in Snowflake takes some time, we should change to use a UDF here for float.
                    # For now, this is just an approximation by casting to Decimal and casting back.
                    scale_for_decimal = 0 if scale < 0 else min(scale + 2, 38)
                    result_exp = snowpark_fn.cast(
                        snowpark_fn.bround(
                            snowpark_fn.to_decimal(
                                snowpark_args[0], 38, scale_for_decimal
                            ),
                            snowpark_fn.lit(scale),
                        ),
                        snowpark_typed_args[0].typ,
                    )
                    result_type = snowpark_typed_args[0].typ
        case "btrim" | "trim":
            args = [
                snowpark_fn.to_char(typed_arg.col, snowpark_fn.lit("utf-8"))
                if isinstance(typed_arg.typ, BinaryType)
                else typed_arg.col
                for typed_arg in snowpark_typed_args
            ]
            result_exp = TypedColumn(snowpark_fn.trim(*args), lambda: [StringType()])
            if len(args) == 2 and function_name == "trim":
                spark_function_name = (
                    f"TRIM(BOTH {snowpark_arg_names[1]} FROM {snowpark_arg_names[0]})"
                )
        case "cbrt":
            spark_function_name = f"CBRT({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] < 0,
                -snowpark_fn.pow(-snowpark_args[0], snowpark_fn.lit(1 / 3)),
            ).otherwise(snowpark_fn.pow(snowpark_args[0], snowpark_fn.lit(1 / 3)))
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "ceil" | "ceiling":
            if len(snowpark_args) == 1:
                fn_name = (
                    function_name.upper() if function_name == "ceil" else function_name
                )
                spark_function_name = f"{fn_name}({snowpark_arg_names[0]})"
                result_exp = snowpark_fn.cast(
                    snowpark_fn.ceil(snowpark_args[0]), LongType()
                )
                result_exp = TypedColumn(result_exp, lambda: [LongType()])
            elif len(snowpark_args) == 2:
                fn_name = function_name.lower()
                if not isinstance(
                    snowpark_typed_args[1].typ, IntegerType
                ) and not isinstance(snowpark_typed_args[1].typ, LongType):
                    raise AnalysisException(
                        f"The 'scale' parameter of function '{function_name}' needs to be a int literal."
                    )
                spark_function_name = (
                    f"{fn_name}({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
                )
                result_exp = snowpark_fn.ceil(
                    snowpark_args[0] * pow(10.0, snowpark_args[1])
                ) / pow(10.0, snowpark_args[1])
                if int(snowpark_arg_names[1]) <= 0:
                    result_exp = snowpark_fn.cast(result_exp, LongType())
                    result_exp = TypedColumn(result_exp, lambda: [LongType()])
                else:
                    result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
            else:
                raise AnalysisException(
                    f"[WRONG_NUM_ARGS.WITHOUT_SUGGESTION] The `{function_name}` requires 2 parameters but the actual number is {len(snowpark_args)}."
                )
        case "chr" | "char":
            result_exp = snowpark_fn.when(
                (snowpark_args[0] > 256), snowpark_fn.char(snowpark_args[0] % 256)
            ).otherwise(snowpark_fn.char(snowpark_args[0]))
            result_exp = TypedColumn(result_exp, lambda: [StringType()])
        case "coalesce":
            _validate_arity((1, None))
            match len(snowpark_args):
                case 1:
                    result_exp = TypedColumn(
                        snowpark_args[0], lambda: snowpark_typed_args[0].types
                    )
                case _:
                    result_type = _find_common_type(
                        [arg.typ for arg in snowpark_typed_args]
                    )
                    result_exp = snowpark_fn.coalesce(
                        *[col.cast(result_type) for col in snowpark_args]
                    )
        case "col":
            # TODO: assign type
            result_exp = snowpark_fn.col(*snowpark_args)
            result_exp = _type_with_typer(result_exp)
        case "collect_list" | "array_agg":
            # TODO: SNOW-1967177 - Support structured types in array_agg
            result_exp = snowpark_fn.cast(
                snowpark_fn.array_agg(
                    snowpark_typed_args[0].column(to_semi_structure=True)
                ),
                ArrayType(snowpark_typed_args[0].typ),
            )
            result_exp = TypedColumn(
                result_exp, lambda: [ArrayType(snowpark_typed_args[0].typ)]
            )
            spark_function_name = f"collect_list({snowpark_arg_names[0]})"
        case "collect_set":
            # Convert to a semi-structured type. TODO SNOW-1953065 - Support structured types in array_unique_agg.
            result_exp = snowpark_fn.cast(
                snowpark_fn.array_unique_agg(
                    snowpark_typed_args[0].column(to_semi_structure=True)
                ),
                ArrayType(snowpark_typed_args[0].typ),
            )
            result_exp = TypedColumn(
                result_exp, lambda: [ArrayType(snowpark_typed_args[0].typ)]
            )
        case "column":
            # TODO: assign type
            result_exp = snowpark_fn.column(*snowpark_args)
            result_exp = _type_with_typer(result_exp)
        case "concat":
            result_type = _find_common_type([arg.typ for arg in snowpark_typed_args])
            if len(snowpark_args) == 0:
                result_exp = TypedColumn(snowpark_fn.lit(""), lambda: [StringType()])
            elif len(snowpark_args) == 1:
                result_exp = TypedColumn(
                    snowpark_args[0],
                    lambda: [
                        result_type
                        if isinstance(result_type, ArrayType)
                        else StringType()
                    ],
                )
            elif isinstance(result_type, ArrayType):
                result_exp = functools.reduce(
                    lambda acc, tc: snowpark_fn.array_cat(
                        acc, tc.column(to_semi_structure=True)
                    ),
                    snowpark_typed_args[2:],
                    snowpark_fn.array_cat(
                        snowpark_typed_args[0].column(to_semi_structure=True),
                        snowpark_typed_args[1].column(to_semi_structure=True),
                    ),
                ).cast(result_type)
            else:
                result_exp = TypedColumn(
                    snowpark_fn.concat(*snowpark_args), lambda: [StringType()]
                )
        case "concat_ws":
            delimiter = unwrap_literal(exp.unresolved_function.arguments[0])
            result_exp = snowpark_fn._concat_ws_ignore_nulls(
                delimiter, *snowpark_args[1:]
            )
            result_exp = TypedColumn(result_exp, lambda: [StringType()])
        case "contains":
            result_exp = TypedColumn(
                snowpark_args[0].contains(snowpark_args[1]), lambda: [BooleanType()]
            )
        case "conv":

            @cached_udf(
                input_types=[
                    StringType(),
                    LongType(),
                    LongType(),
                ],
                return_type=StringType(),
            )
            def _to_conv_udf(val, from_base, to_base):
                try:
                    if val is None:
                        return None
                    num = int(val, base=from_base)
                    if num == 0:
                        return "0"
                    is_negative = num < 0
                    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    result = ""
                    num = abs(num)
                    while num > 0:
                        result = digits[num % to_base] + result
                        num //= to_base
                    return "-" + result if is_negative else result
                except (ValueError, TypeError):
                    return "0"

            result_exp = _to_conv_udf(
                snowpark_fn.cast(snowpark_args[0], StringType()),
                snowpark_fn.cast(snowpark_args[1], LongType()),
                snowpark_fn.cast(snowpark_args[2], LongType()),
            )
            result_exp = TypedColumn(result_exp, lambda: [StringType()])

        case "convert_timezone":
            if len(snowpark_args) == 3:
                result_exp = snowpark_fn.convert_timezone(
                    snowpark_args[1], snowpark_args[2], snowpark_args[0]
                )
            else:
                result_exp = snowpark_fn.convert_timezone(*snowpark_args)

            result_exp = TypedColumn(result_exp, lambda: [TimestampType()])

        case "corr":
            col1_type = snowpark_typed_args[0].typ
            col2_type = snowpark_typed_args[1].typ
            if not isinstance(col1_type, _NumericType) or not isinstance(
                col2_type, _NumericType
            ):
                result_exp = snowpark_fn.corr(
                    snowpark_fn.lit(None), snowpark_fn.lit(None)
                )
            else:
                result_exp = snowpark_fn.corr(*snowpark_args)
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "cos":
            spark_function_name = f"COS({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cos(snowpark_args[0])
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "cosh":
            spark_function_name = f"COSH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cosh(snowpark_args[0])
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "cot":
            spark_function_name = f"COT({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.function("cot")(snowpark_args[0])
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "count":
            if exp.unresolved_function.is_distinct:
                result_exp = snowpark_fn.count_distinct(*snowpark_args)
                spark_function_name = spark_function_name.replace(
                    "count(", "count(DISTINCT ", 1
                )
            else:
                if (
                    exp.unresolved_function.arguments[0].HasField("expression_string")
                    and exp.unresolved_function.arguments[
                        0
                    ].expression_string.expression
                    == "*"
                ) or exp.unresolved_function.arguments[0].HasField("unresolved_star"):
                    spark_function_name = "count(1)"
                result_exp = snowpark_fn.count(*snowpark_args)
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "count_if":
            result_exp = snowpark_fn.call_function("COUNT_IF", snowpark_args[0])
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "covar_pop":
            col1_type = snowpark_typed_args[0].typ
            col2_type = snowpark_typed_args[1].typ
            if not isinstance(col1_type, _NumericType) or not isinstance(
                col2_type, _NumericType
            ):
                raise TypeError(
                    f"Data type mismatch: covar_pop requires numeric types, "
                    f"but got {col1_type} and {col2_type}."
                )
            result_exp = snowpark_fn.covar_pop(
                snowpark_args[0],
                snowpark_args[1],
            )
            result_type = DoubleType()
        case "covar_samp":
            col1_type = snowpark_typed_args[0].typ
            col2_type = snowpark_typed_args[1].typ
            if not isinstance(col1_type, _NumericType) or not isinstance(
                col2_type, _NumericType
            ):
                raise TypeError(
                    f"Data type mismatch: covar_samp requires numeric types, "
                    f"but got {col1_type} and {col2_type}."
                )
            result_exp = snowpark_fn.covar_samp(snowpark_args[0], snowpark_args[1])
            result_type = DoubleType()
        case "crc32":
            if (
                not isinstance(snowpark_typed_args[0].typ, BinaryType)
                and not isinstance(snowpark_typed_args[0].typ, StringType)
                and not isinstance(snowpark_typed_args[0].typ, VariantType)
            ):
                raise AnalysisException(
                    f"[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve crc32({snowpark_args[0]}) due to data type mismatch: Input requires the BINARY type, however {snowpark_args[0]} has the type {snowpark_typed_args[0].typ}."
                )

            # UDF to calculate the unsigned CRC32 value of data in bytes. Returns the CRC32 value
            # as a 32-bit INT, or None if the input is None.
            @cached_udf(
                input_types=[snowpark_typed_args[0].typ],
                return_type=IntegerType(),
            )
            def _crc32(data):
                import zlib

                if data is None:
                    return None

                if isinstance(data, bytes) or isinstance(data, bytearray):
                    crc32_value = zlib.crc32(data)
                else:
                    crc32_value = zlib.crc32(data.encode("utf-8"))

                return crc32_value

            result_exp = _crc32(snowpark_args[0])
            result_type = IntegerType()

        case "csc":
            spark_function_name = f"CSC({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_args[0]), snowpark_fn.lit(NAN)
            ).otherwise(
                snowpark_fn.coalesce(
                    _divnull(snowpark_fn.lit(1.0), snowpark_fn.sin(snowpark_args[0])),
                    snowpark_fn.lit(INFINITY),
                )
            )
            # TODO: can we resolve the return type?
            result_exp = _type_with_typer(result_exp)
        case "cume_dist":
            result_exp = TypedColumn(snowpark_fn.cume_dist(), lambda: [DoubleType()])
        case "current_catalog":
            result_exp = snowpark_fn.lit(CURRENT_CATALOG_NAME)
            result_type = StringType()
        case "current_database" | "current_schema":  # schema is an alias for database in Spark SQL
            result_exp = TypedColumn(
                snowpark_fn.current_schema(), lambda: [StringType()]
            )
            spark_function_name = "current_database()"
        case "current_date" | "curdate":
            result_exp = TypedColumn(snowpark_fn.current_date(), lambda: [DateType()])
            spark_function_name = "current_date()"
        case "current_timestamp" | "now":
            result_exp = snowpark_fn.cast(
                snowpark_fn.current_timestamp(),
                get_timestamp_type(),
            )
            result_exp = TypedColumn(result_exp, lambda: [get_timestamp_type()])
        case "current_timezone":
            result_exp = snowpark_fn.lit(global_config.spark_sql_session_timeZone)
            result_type = StringType()
        case "current_user" | "user":
            result_exp = TypedColumn(snowpark_fn.current_user(), lambda: [StringType()])
            spark_function_name = "current_user()"
        case "date_add" | "dateadd":
            if len(snowpark_args) != 2:
                # SQL supports a 3-argument call that gets mapped to timestamp_add -
                # however, if the first argument is invalid, we end up here.
                raise AnalysisException("date_add takes 2 arguments")
            arg_2 = snowpark_typed_args[1].typ
            if isinstance(arg_2, StringType):
                with suppress(Exception):
                    if str(int(snowpark_arg_names[1])) == snowpark_arg_names[1]:
                        arg_2 = IntegerType()

            if not isinstance(arg_2, _IntegralType):
                raise AnalysisException(
                    f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "date_add({snowpark_arg_names[0]}, {snowpark_arg_names[1]})" due to data type mismatch: Parameter 2 requires the ("INT" or "SMALLINT" or "TINYINT") type, however "{snowpark_arg_names[1]}" has the type "{str(arg_2)}".'
                )

            result_exp = _try_to_cast(
                "try_to_date",
                snowpark_fn.cast(snowpark_fn.date_add(*snowpark_args), DateType()),
                snowpark_args[0],
            )
            result_exp = TypedColumn(result_exp, lambda: [DateType()])
            spark_function_name = (
                f"date_add({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
        case "date_diff" | "datediff":
            if len(snowpark_args) != 2:
                # SQL supports a 3-argument call that gets mapped to timestamp_diff -
                # however, if the first argument is invalid, we end up here.
                raise AnalysisException("date_diff takes 2 arguments")
            result_exp = _try_to_cast(
                "try_to_date",
                snowpark_fn.datediff("day", snowpark_args[1], snowpark_args[0]),
                snowpark_args[0],
                snowpark_args[1],
            )
            result_type = LongType()
        case "date_format":
            assert (
                len(exp.unresolved_function.arguments) == 2
            ), "date_format takes 2 arguments"
            result_exp = snowpark_fn.date_format(
                snowpark_args[0],
                snowpark_fn.lit(
                    map_spark_timestamp_format_expression(
                        exp.unresolved_function.arguments[1]
                    )
                ),
            )
            result_exp = TypedColumn(result_exp, lambda: [StringType()])
        case "date_from_unix_date":
            result_exp = snowpark_fn.date_add(
                snowpark_fn.to_date(snowpark_fn.lit("1970-01-01")), snowpark_args[0]
            )
            result_exp = TypedColumn(result_exp, lambda: [DateType()])
        case "date_sub":
            arg_2 = snowpark_typed_args[1].typ
            if isinstance(arg_2, StringType):
                with suppress(Exception):
                    if str(int(snowpark_arg_names[1])) == snowpark_arg_names[1]:
                        arg_2 = IntegerType()

            if not isinstance(arg_2, _IntegralType):
                raise AnalysisException(
                    f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "date_sub({snowpark_arg_names[0]}, {snowpark_arg_names[1]})" due to data type mismatch: Parameter 2 requires the ("INT" or "SMALLINT" or "TINYINT") type, however "{snowpark_arg_names[1]}" has the type "{str(arg_2)}".'
                )
            result_exp = _try_to_cast(
                "try_to_date",
                snowpark_fn.to_date(
                    snowpark_fn.date_sub(snowpark_args[0], snowpark_args[1])
                ),
                snowpark_args[0],
            )
            result_exp = TypedColumn(result_exp, lambda: [DateType()])
            spark_function_name = (
                f"date_sub({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
        case "date_trunc":
            part = unwrap_literal(exp.unresolved_function.arguments[0])
            result_exp = _try_to_cast(
                "try_to_date",
                snowpark_fn.cast(
                    snowpark_fn.date_trunc(
                        part, snowpark_fn.to_timestamp(snowpark_args[1])
                    ),
                    TimestampType(snowpark.types.TimestampTimeZone.NTZ),
                ),
                snowpark_args[1],
            )
            result_type = TimestampType()
        case "dayofmonth" | "day":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.dayofmonth(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.dayofmonth(
                    snowpark_fn.to_date(snowpark_args[0])
                )
            result_type = LongType()
        case "dayofweek":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.dayofweek(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                ) + snowpark_fn.lit(1)
            else:
                result_exp = snowpark_fn.dayofweek(
                    snowpark_fn.to_date(snowpark_args[0])
                ) + snowpark_fn.lit(1)
            result_type = LongType()
        case "dayofyear":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.dayofyear(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.dayofyear(
                    snowpark_fn.to_date(snowpark_args[0])
                )
            result_type = LongType()
        case "date_part" | "datepart" | "extract":
            field_lit: str | None = unwrap_literal(exp.unresolved_function.arguments[0])

            if field_lit is None:
                result_exp = snowpark_fn.lit(None)
                result_type = DoubleType()
            else:
                field_lit = field_lit.lower()

                result_exp = snowpark_fn.date_part(field_lit, snowpark_args[1])
                result_type = LongType()

                if field_lit in ("dayofweek", "weekday", "dow", "dw"):
                    result_exp += 1

                if field_lit in ("second", "s", "sec", "seconds", "secs"):
                    result_type = DecimalType(8, 6)

                    s_part = snowpark_fn.cast(result_exp, DoubleType())
                    ns_part = snowpark_fn.cast(
                        snowpark_fn.date_part("ns", snowpark_args[1]), DoubleType()
                    )

                    result_exp = s_part + (ns_part / snowpark_fn.lit(1e9))
                    result_exp = snowpark_fn.cast(result_exp, result_type)

            if function_name in ("datepart", "extract"):
                spark_function_name = f"{function_name}({snowpark_arg_names[0]} FROM {snowpark_arg_names[1]})"
        case "decode":
            match snowpark_typed_args[0].typ:
                case BinaryType():

                    @cached_udf(
                        input_types=[BinaryType(), StringType()],
                        return_type=StringType(),
                    )
                    def _decode(s, f):
                        if None in (s, f):
                            return None
                        if f.lower() == "utf-16":
                            return s[2:].decode("utf-16be")
                        return s.decode(f)

                    result_exp = _decode(*snowpark_args)
                case _:
                    result_exp = snowpark_fn.cast(snowpark_args[0], StringType())
            result_type = StringType()
        case "degrees":
            spark_function_name = f"DEGREES({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.degrees(snowpark_args[0])
            result_type = DoubleType()
        case "dense_rank":
            result_exp = snowpark_fn.dense_rank()
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "desc":
            result_exp = TypedColumn(
                snowpark_fn.desc(snowpark_args[0]), lambda: snowpark_typed_args[0].types
            )
        case "div":
            # Only called from SQL, either as `a div b` or `div(a, b)`
            # Convert it into `(a - a % b) / b`.
            result_exp = snowpark_fn.cast(
                (snowpark_args[0] - snowpark_args[0] % snowpark_args[1])
                / snowpark_args[1],
                LongType(),
            )
            if not spark_sql_ansi_enabled:
                result_exp = snowpark_fn.when(
                    snowpark_args[1] == 0, snowpark_fn.lit(None)
                ).otherwise(result_exp)
            result_type = LongType()
        case "e":
            spark_function_name = "E()"
            result_exp = snowpark_fn.lit(math.e)
            result_type = FloatType()
        case "element_at":
            spark_index = snowpark_args[1]
            data = snowpark_typed_args[0].col
            typ = snowpark_typed_args[0].typ
            match typ:
                case ArrayType():
                    result_exp = snowpark_fn.when(
                        spark_index < 0,
                        snowpark_fn.element_at(
                            data,
                            snowpark_fn.array_size(data) + spark_index,
                        ),
                    ).otherwise(snowpark_fn.element_at(data, spark_index - 1))
                    result_type = typ.element_type
                case MapType():
                    result_exp = snowpark_fn.element_at(data, spark_index)
                    result_type = typ.value_type
                case _:
                    raise SnowparkConnectNotImplementedError(
                        f"Unsupported type {typ} for element_at function"
                    )
        case "elt":
            n = snowpark_args[0]

            values = snowpark_fn.array_construct(*snowpark_args[1:])

            if spark_sql_ansi_enabled:

                @cached_udf
                def _raise_out_of_bounds_error(n: int) -> str:
                    raise ValueError(
                        f"ArrayIndexOutOfBoundsException: {n} is not within the input bounds."
                    )

                values_size = snowpark_fn.lit(len(snowpark_args) - 1)

                result_exp = (
                    snowpark_fn.when(snowpark_fn.is_null(n), snowpark_fn.lit(None))
                    .when(
                        (snowpark_fn.lit(1) <= n) & (n <= values_size),
                        snowpark_fn.get(
                            values, snowpark_fn.nvl(n - 1, snowpark_fn.lit(0))
                        ),
                    )
                    .otherwise(_raise_out_of_bounds_error(n))
                )
            else:
                result_exp = snowpark_fn.when(
                    snowpark_fn.is_null(n), snowpark_fn.lit(None)
                ).otherwise(
                    snowpark_fn.get(values, snowpark_fn.nvl(n - 1, snowpark_fn.lit(0)))
                )

            result_exp = snowpark_fn.cast(result_exp, StringType())
            result_type = StringType()
        case "encode":

            @cached_udf(
                input_types=[StringType(), StringType()],
                return_type=BinaryType(),
            )
            def _encode(s: str, f: str):
                if None in (s, f):
                    return None
                if f.lower() == "utf-16":
                    return (b"\xfe\xff" if s else b"") + s.encode("utf-16be")
                return s.encode(f)

            result_exp = _encode(*snowpark_args)
            result_type = BinaryType()
        case "endswith":
            result_exp = snowpark_args[0].endswith(snowpark_args[1])
            result_type = BooleanType()
        case "equal_null":
            result_exp = snowpark_fn.equal_null(*snowpark_args)
            result_type = BooleanType()
        case "exp":
            spark_function_name = f"EXP({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.exp(*snowpark_args)
            result_type = DoubleType()
        case "explode":
            result_exp = snowpark_fn.explode(snowpark_args[0])
            t = snowpark_typed_args[0].typ
            match t:
                case ArrayType():
                    spark_col_names = ["col"]
                    result_type = t.element_type
                case _:
                    spark_col_names = ["key", "value"]
                    result_type = [t.key_type, t.value_type]
        case "explode_outer":
            result_exp = snowpark_fn.explode_outer(snowpark_args[0])
            t = snowpark_typed_args[0].typ
            match t:
                case ArrayType():
                    spark_col_names = ["col"]
                    result_type = t.element_type
                case _:
                    spark_col_names = ["key", "value"]
                    result_type = [t.key_type, t.value_type]
        case "expm1":
            spark_function_name = f"EXPM1({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.exp(*snowpark_args) - 1
            result_type = DoubleType()
        case "factorial":
            # For floating-point types, truncate by casting to LongType first
            if isinstance(
                snowpark_typed_args[0].typ, (DoubleType, FloatType, DecimalType)
            ):
                result_exp = snowpark_fn.factorial(snowpark_fn.floor(snowpark_args[0]))
            else:
                result_exp = snowpark_fn.factorial(*snowpark_args)
            result_type = LongType()
        case "find_in_set":
            element_sep = snowpark_fn.lit(",")
            array = snowpark_fn.cast(
                snowpark_fn.split(snowpark_args[1], element_sep),
                ArrayType(StringType()),
            )

            result_exp = snowpark_fn.when(
                snowpark_fn.contains(snowpark_args[0], snowpark_fn.lit(",")),
                snowpark_fn.lit(None),
            ).otherwise(snowpark_fn.array_position(snowpark_args[0], array))

            any_arg_is_null = snowpark_args[0].is_null() | snowpark_args[1].is_null()

            result_exp = snowpark_fn.when(
                any_arg_is_null, snowpark_fn.lit(None)
            ).otherwise(
                snowpark_fn.call_function(
                    "nvl2", result_exp, result_exp + 1, snowpark_fn.lit(0)
                )
            )
            result_type = LongType()
        case "first":
            if not is_window_enabled():
                # If first not used in window expression, it should act as aggregate function.
                # According to PySpark docs, ignore_nulls can be a Column - but it doesn't make sense and doesn't work.
                # So assume it's a literal.
                ignore_nulls = unwrap_literal(exp.unresolved_function.arguments[1])

                class FirstUDAF:
                    def __init__(self) -> None:
                        self._value = None
                        self._done = False

                    @property
                    def aggregate_state(self):
                        return self._value

                    def accumulate(self, input_value):
                        if not (self._done or (ignore_nulls and input_value is None)):
                            self._value = input_value
                            self._done = True

                    def merge(self, other_value):
                        if not (self._done or (ignore_nulls and other_value is None)):
                            self._value = other_value
                            self._done = True

                    def finish(self):
                        return self._value

                _first_udaf = cached_udaf(
                    FirstUDAF,
                    return_type=snowpark_typed_args[0].typ,
                    input_types=[snowpark_typed_args[0].typ],
                )

                result_exp = _first_udaf(snowpark_args[0])
                spark_function_name = f"first({snowpark_arg_names[0]})"
            else:
                result_exp = _resolve_first_value(exp, snowpark_args)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "first_value":
            result_exp = TypedColumn(
                _resolve_first_value(exp, snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "flatten":
            # SNOW-1890247 - Update this when SQL provides a structured version of flatten
            result_exp = snowpark_fn.cast(
                snowpark_fn.array_flatten(
                    snowpark_fn.cast(snowpark_args[0], VariantType())
                ),
                snowpark_typed_args[0].typ.element_type,
            )
            # TODO: do we need to resolve integral types to LongType?
            result_type = snowpark_typed_args[0].typ.element_type
        case "floor":
            if len(snowpark_args) == 1:
                spark_function_name = f"FLOOR({snowpark_arg_names[0]})"
                result_exp = snowpark_fn.cast(
                    snowpark_fn.floor(snowpark_args[0]), LongType()
                )
                result_exp = TypedColumn(result_exp, lambda: [LongType()])
                result_type = LongType()
            elif len(snowpark_args) == 2:
                if not isinstance(
                    snowpark_typed_args[1].typ, IntegerType
                ) and not isinstance(snowpark_typed_args[1].typ, LongType):
                    raise AnalysisException(
                        "The 'scale' parameter of function 'floor' needs to be a int literal."
                    )
                spark_function_name = (
                    f"floor({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
                )
                result_exp = snowpark_fn.floor(
                    snowpark_args[0] * pow(10.0, snowpark_args[1])
                ) / pow(10.0, snowpark_args[1])
                if int(snowpark_arg_names[1]) <= 0:
                    result_exp = snowpark_fn.cast(result_exp, LongType())
                    result_exp = TypedColumn(result_exp, lambda: [LongType()])
                else:
                    result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
            else:
                raise AnalysisException(
                    f"[WRONG_NUM_ARGS.WITHOUT_SUGGESTION] The `floor` requires 2 parameters but the actual number is {len(snowpark_args)}."
                )
        case "format_number":
            col, scale = snowpark_args
            col_type = snowpark_typed_args[0].typ

            if not isinstance(col_type, _NumericType):
                raise TypeError(
                    f'Data type mismatch: Parameter 1 of format_number requires  the "NUMERIC" type, however was {col_type}.'
                )

            @cached_udf(
                input_types=[StringType(), LongType()],
                return_type=StringType(),
            )
            def format_number_udf(x: Optional[str], d: int) -> str:
                if x is None:
                    return None

                import decimal

                num = decimal.Decimal(x)

                return "NaN" if num.is_nan() else f"{num:,.{d}f}"

            result_exp = snowpark_fn.when(
                scale < 0,
                snowpark_fn.lit(None),
            ).otherwise(format_number_udf(snowpark_fn.cast(col, StringType()), scale))
            result_type = StringType()
        case "format_string" | "printf":

            @cached_udf(
                input_types=[StringType(), ArrayType()],
                return_type=StringType(),
            )
            def _format_string(fmt: str, args: list) -> Optional[str]:
                mapped_args = map(lambda x: "null" if x is None else x, args)

                try:
                    return fmt % tuple(mapped_args)
                except TypeError:
                    return None

            result_exp = _format_string(
                snowpark_args[0], snowpark_fn.array_construct(*snowpark_args[1:])
            )
            result_type = StringType()
        case "from_csv":
            snowpark_args = [
                typed_arg.column(to_semi_structure=True)
                for typed_arg in snowpark_typed_args
            ]

            @cached_udf(
                return_type=StructType(),
                input_types=[StringType(), StringType(), StructType()],
            )
            def _from_csv(csv_data: str, schema: str, options: Optional[dict]):
                max_chars_per_column = -1
                sep = ","

                python_to_snowflake_type = {
                    "str": "STRING",
                    "bool": "BOOLEAN",
                    "dict": "OBJECT",
                    "list": "ARRAY",
                }

                if options is not None:
                    if not isinstance(options, dict):
                        raise TypeError(
                            "[INVALID_OPTIONS.NON_MAP_FUNCTION] Invalid options: Must use the `map()` function for options."
                        )

                    max_chars_per_column = options.get(
                        "maxCharsPerColumn", max_chars_per_column
                    )
                    max_chars_per_column = int(max_chars_per_column)
                    sep = options.get("sep", sep)
                    for k, v in options.items():
                        if not isinstance(k, str) or not isinstance(v, str):
                            k_type = python_to_snowflake_type.get(
                                type(k).__name__, type(k).__name__.upper()
                            )
                            v_type = python_to_snowflake_type.get(
                                type(v).__name__, type(v).__name__.upper()
                            )
                            raise TypeError(
                                f'[INVALID_OPTIONS.NON_STRING_TYPE] Invalid options: A type of keys and values in `map()` must be string, but got "MAP<{k_type}, {v_type}>".'
                            )

                csv_data = csv_data.split(sep)
                schemas = schema.split(",")
                assert len(csv_data) == len(
                    schemas
                ), "length of data and schema mismatch"

                def _parse_one_schema(sc):
                    parts = [i for i in sc.split(" ") if len(i) != 0]
                    assert len(parts) == 2, f"{sc} is not a valid schema"
                    return parts[0], parts[1]

                results = {}
                for i in range(len(csv_data)):
                    alias, datatype = _parse_one_schema(schemas[i])
                    results[alias] = csv_data[i]
                    if (
                        max_chars_per_column != -1
                        and len(str(csv_data[i])) > max_chars_per_column
                    ):
                        raise ValueError(
                            f"Max chars per column exceeded {max_chars_per_column}: {str(csv_data[i])}"
                        )

                return results

            spark_function_name = f"from_csv({snowpark_arg_names[0]})"
            ddl_schema = parse_ddl_string(snowpark_arg_names[1], True)

            if len(snowpark_arg_names) > 2 and snowpark_arg_names[2].startswith(
                "named_struct"
            ):
                raise TypeError(
                    "[INVALID_OPTIONS.NON_MAP_FUNCTION] Invalid options: Must use the `map()` function for options."
                )

            match snowpark_args:
                case [csv_data, schemas]:
                    csv_result = _from_csv(
                        snowpark_fn.cast(csv_data, StringType()),
                        schemas,
                        snowpark_fn.lit(None),
                    )
                case [csv_data, schemas, options]:
                    csv_result = _from_csv(
                        snowpark_fn.cast(csv_data, StringType()), schemas, options
                    )
                case _:
                    raise ValueError("Unrecognized from_csv parameters")

            result_exp = snowpark_fn.cast(csv_result, ddl_schema)
            result_type = ddl_schema
        case "from_json":
            # TODO: support options.
            spark_function_name = f"from_json({snowpark_arg_names[0]})"
            lit_schema = unwrap_literal(exp.unresolved_function.arguments[1])

            try:
                spark_schema = _parse_datatype_json_string(lit_schema)
                result_type = map_pyspark_types_to_snowpark_types(spark_schema)
            except ValueError as e:
                # it's valid to fall into here in some cases, so only logger.debug not logger.error
                logger.debug("Failed to parse datatype json string: %s", e)
                result_type = map_type_string_to_snowpark_type(lit_schema)

            # if the result is a map, the column is named "entries"
            if isinstance(result_type, MapType):
                spark_function_name = "entries"

            # try to parse first, since spark returns null for invalid json
            result_exp = snowpark_fn.call_function("try_parse_json", snowpark_args[0])

            # helper function to make sure we have the expected array element type
            def _element_type_matches(
                array_exp: Column, element_type: DataType
            ) -> Column:
                if isinstance(element_type, StructType) or isinstance(
                    element_type, MapType
                ):
                    # we need to confirm that all elements are objects, we don't care about the schema here
                    return snowpark_fn.call_function(
                        "reduce",
                        array_exp,
                        snowpark_fn.lit(True),
                        snowpark_fn.sql_expr(
                            "(acc, e) -> acc and (strip_null_value(e) is null or is_object(e))"
                        ),
                    )

                if isinstance(element_type, ArrayType):
                    # we need to recursively go down and check nested arrays
                    # then bubble up the result
                    analyzer = Session.get_active_session()._analyzer
                    fn_sql = analyzer.analyze(
                        _element_type_matches(
                            snowpark_fn.col("x"), element_type.element_type
                        )._expression,
                        defaultdict(),
                    )

                    return snowpark_fn.call_function(
                        "reduce",
                        snowpark_fn.call_function(
                            "transform",
                            array_exp,
                            snowpark_fn.sql_expr(
                                f"x -> (strip_null_value(x) is null or is_array(x)) and {fn_sql}"
                            ),
                        ),
                        snowpark_fn.lit(True),
                        snowpark_fn.sql_expr("(acc, e) -> acc and nvl(e, true)"),
                    )

                # let's optimistically assume that any simple type can be coerced to the expected type automatically
                return snowpark_fn.lit(True)

            # There is a known limitation in snowflake while casting semi structured data to structured data
            # that if some keys are missing in value the cast would fail
            # we need to make sure it has the same "shape" as the result_type.
            # This function will construct an expression
            # that will convert the parsed json to the expected type.
            def _coerce_to_type(
                exp: Column, t: DataType, top_level: bool = True
            ) -> Column:
                if isinstance(t, StructType):
                    key_values = []
                    for field in t.fields:
                        key_values.append(snowpark_fn.lit(field.name))
                        key_values.append(
                            _coerce_to_type(
                                snowpark_fn.get(exp, snowpark_fn.lit(field.name)),
                                field.datatype,
                                False,
                            )
                        )
                    # spark will not return null for top level structs, so we need to handle that
                    if top_level:
                        return snowpark_fn.object_construct_keep_null(*key_values)
                    else:
                        return snowpark_fn.when(
                            snowpark_fn.as_object(exp).is_null(), snowpark_fn.lit(None)
                        ).otherwise(snowpark_fn.object_construct_keep_null(*key_values))
                elif isinstance(t, ArrayType):
                    if top_level and isinstance(t.element_type, StructType):
                        # Spark can still wrap a single value in an array if the internal type is a struct
                        arr_exp = snowpark_fn.to_array(exp)
                    else:
                        # if it's not a struct, we can return null for any non-array values
                        arr_exp = snowpark_fn.as_array(exp)
                    # adjust the parsed json to match the expected type so that we can cast it later
                    analyzer = Session.get_active_session()._analyzer
                    fn_sql = analyzer.analyze(
                        _coerce_to_type(
                            snowpark_fn.col("x"), t.element_type, False
                        )._expression,
                        defaultdict(),
                    )

                    # if there's even a single incorrect element, return null
                    return snowpark_fn.when(
                        _element_type_matches(arr_exp, t.element_type),
                        snowpark_fn.call_function(
                            "transform", arr_exp, snowpark_fn.sql_expr(f"x -> {fn_sql}")
                        ),
                    ).otherwise(snowpark_fn.lit(None))
                elif isinstance(t, MapType):
                    return snowpark_fn.as_object(exp)
                else:
                    return exp

            result_exp = snowpark_fn.cast(
                _coerce_to_type(result_exp, result_type), result_type
            )
        case "from_unixtime":
            match exp.unresolved_function.arguments:
                case [_]:
                    result_exp = snowpark_fn.to_char(
                        _try_to_cast(
                            "try_to_timestamp",
                            snowpark_fn.to_timestamp(snowpark_args[0]),
                            snowpark_args[0],
                        ),
                        snowpark_fn.lit("YYYY-MM-DD HH24:MI:SS"),
                    )
                    spark_function_name = (
                        f"from_unixtime({snowpark_arg_names[0]}, yyyy-MM-dd HH:mm:ss)"
                    )
                case [_, _]:
                    try:
                        result_exp = snowpark_fn.to_char(
                            _try_to_cast(
                                "try_to_timestamp",
                                snowpark_fn.to_timestamp(snowpark_args[0]),
                                snowpark_args[0],
                            ),
                            map_spark_timestamp_format_expression(
                                exp.unresolved_function.arguments[1]
                            ),
                        )
                    except SnowparkConnectNotImplementedError:
                        # The second argument must either be a string or none. It can't be a column.
                        # So if it's anything that isn't a literal, we catch the error and just return NULL
                        result_exp = snowpark_fn.lit(None)
                case _:
                    raise AnalysisException(
                        f"[WRONG_NUM_ARGS.WITHOUT_SUGGESTION] The `from_unixtime` requires [1, 2] parameters but the actual number is {len(snowpark_args)}."
                    )
            result_type = StringType()
        case "from_utc_timestamp":

            @cached_udf(
                input_types=[StringType()],
                return_type=StringType(),
            )
            def map_from_spark_tz(tz):
                return SPARK_TZ_ABBREVIATIONS_OVERRIDES.get(tz, tz)

            target_tz = map_from_spark_tz(snowpark_args[1])
            result_exp = _try_to_cast(
                "try_to_timestamp",
                snowpark_fn.from_utc_timestamp(snowpark_args[0], target_tz),
                snowpark_args[0],
            )
            result_type = TimestampType(TimestampTimeZone.NTZ)
        case "get":
            if exp.unresolved_function.arguments[1].HasField("literal"):
                index = unwrap_literal(exp.unresolved_function.arguments[1])
                if index < 0:
                    result_exp = snowpark_fn.lit(None)
                else:
                    result_exp = snowpark_fn.get(*snowpark_args)
            else:
                result_exp = snowpark_fn.when(
                    snowpark_args[1] < 0,
                    snowpark_fn.lit(None),
                ).otherwise(snowpark_fn.get(*snowpark_args))
            result_exp = TypedColumn(
                result_exp, lambda: [snowpark_typed_args[0].typ.element_type]
            )
        case "get_json_object":
            json_str = snowpark_args[0]
            json_path = unwrap_literal(exp.unresolved_function.arguments[1])

            if json_path is None:
                result_exp = snowpark_fn.lit(None)
            else:
                # Snowflake JSON paths do not start with '$.', which is required in Spark
                if json_path.startswith("$."):
                    json_path = json_path[2:]

                result_exp = snowpark_fn.when(
                    snowpark_fn.is_null(snowpark_fn.check_json(json_str)),
                    snowpark_fn.json_extract_path_text(
                        json_str, snowpark_fn.lit(json_path)
                    ),
                ).otherwise(snowpark_fn.lit(None))
            result_type = StringType()
        case "greatest":
            result_exp = snowpark_fn.greatest(*snowpark_args)
            result_exp = TypedColumn(
                result_exp,
                lambda: [_find_common_type([a.typ for a in snowpark_typed_args])],
            )
        case "grouping" | "grouping_id":
            # grouping_id is not an alias for grouping in PySpark, but Snowflake's implementation handles both
            result_exp = snowpark_fn.grouping(*snowpark_args)
            result_type = LongType()
        case "hash":
            # TODO: See the spark-compatibility-issues.md explanation, this is quite different from Spark.
            result_exp = snowpark_fn.hash(*snowpark_args)
            result_type = LongType()
        case "hex":
            data = snowpark_fn.cast(snowpark_args[0], VariantType())

            # We need as many 'X' as there are digits. The longest possible 'long' type has 16 digits.
            format_string = "FMXXXXXXXXXXXXXXXX"

            # Hex supports string, binary, integer/long.
            # We can use TO_CHAR for numbers and HEX_ENCODE for string and binary
            result_exp = (
                snowpark_fn.when(
                    snowpark_fn.is_integer(data),
                    snowpark_fn.to_char(
                        # The cast to integer is done because to_char in snowflake doesn't take
                        # two arguments for certain other types.
                        snowpark_fn.cast(data, LongType()),
                        format_string,
                    ),
                )
                .when(
                    snowpark_fn.is_double(data),
                    snowpark_fn.to_char(
                        # While float/double aren't officially supported in the spark documentation, they work.
                        # They are treated as integer, but after floor.
                        snowpark_fn.cast(snowpark_fn.floor(data), LongType()),
                        format_string,
                    ),
                )
                .otherwise(snowpark_fn.function("HEX_ENCODE")(*snowpark_args))
            )
            result_type = StringType()
        case "histogram_numeric":
            aggregate_input_typ = snowpark_typed_args[0].typ
            histogram_return_type = ArrayType(
                StructType(
                    [
                        StructField("x", aggregate_input_typ, _is_column=False),
                        StructField("y", FloatType(), _is_column=False),
                    ]
                )
            )

            class HistogramNumericUDAF:
                """
                Most of the code was taken from Spark implementation: https://github.com/apache/spark/blob/master/sql/catalyst/src/main/java/org/apache/spark/sql/util/NumericHistogram.java#L36
                This UDAF is executed on multiple nodes, we have no control over the order of execution, hence there
                will be differences between Spark and Snowflake implementations. Function creates approximation so the
                result should be either way good enough.
                """

                from datetime import date, datetime, time, timedelta

                def __init__(self) -> None:

                    # init the RNG for breaking ties in histogram merging. A fixed seed is specified here
                    # to aid testing, but can be eliminated to use a time-based seed (which would
                    # make the algorithm non-deterministic).
                    self.random_seed = (31183 ^ 0x5DEECE66D) & ((1 << 48) - 1)
                    self.random_multiplier = 0x5DEECE66D
                    self.random_addend = 0xB
                    self.random_mask = (1 << 48) - 1
                    self.n_bins = 0
                    self.n_used_bins = 0
                    self.bins = []
                    self.typ = None

                @property
                def aggregate_state(self):
                    return (self.n_bins, self.n_used_bins, self.bins, self.typ)

                def accumulate(self, value, n_bins: int):
                    if self.n_bins == 0:
                        self.n_bins = n_bins
                        self.bins = []
                        self.n_used_bins = 0

                    if value is None:
                        return

                    self.typ = type(value)
                    parsed_value = self.parse_value(value)

                    self.add(parsed_value)

                def parse_value(self, value):
                    """
                    Converts input value into the proper numeric type so that algorithm can be executed.
                    Supported Snowflake types are:
                    * DATE
                    * NUMBER
                    * FLOAT
                    * TIMESTAMP_LTZ
                    * TIMESTAMP_NTZ
                    * TIMESTAMP_TZ
                    All these types are supported in the spark function histogram_numeric.
                    """

                    parsed_value = 0.0
                    if isinstance(value, datetime.datetime):
                        parsed_value = value.timestamp()
                    elif isinstance(value, datetime.date):
                        epoch = datetime.date(1970, 1, 1)
                        delta = value - epoch
                        parsed_value = delta.days
                    elif isinstance(value, (int, float)):
                        parsed_value = value
                    elif isinstance(value, Decimal):
                        parsed_value = float(value)
                    return parsed_value

                def finish(self):
                    return [
                        {"x": self.map_output(bin[0]), "y": bin[1]} for bin in self.bins
                    ]

                def map_output(self, value):
                    if self.typ == datetime.datetime:
                        return datetime.datetime.fromtimestamp(value)
                    elif self.typ == datetime.date:
                        epoch = datetime.date(1970, 1, 1)
                        delta = datetime.timedelta(days=value)
                        return epoch + delta
                    elif self.typ == int:
                        return int(value)
                    elif self.typ == float:
                        return float(value)
                    elif self.typ == Decimal:
                        return Decimal(value)
                    else:
                        return None

                def _next(self, bits: int) -> int:
                    self.random_seed = (
                        self.random_seed * self.random_multiplier + self.random_addend
                    ) & self.random_mask
                    return self.random_seed >> (48 - bits)

                def _next_double(self) -> float:
                    a = self._next(26)
                    b = self._next(27)
                    return ((a << 27) + b) / float(1 << 53)

                def merge(self, other: tuple):
                    if other is None:
                        return

                    o_n_bins, o_n_used_bins, other_bins, o_typ = other

                    if self.typ is None:
                        self.typ = o_typ

                    if self.n_bins == 0 or self.n_used_bins == 0:
                        self.n_bins = o_n_bins
                        self.n_used_bins = o_n_used_bins
                        self.bins = [(o_bin[0], o_bin[1]) for o_bin in other_bins]
                    else:
                        tmp_bins = [(s_bin[0], s_bin[1]) for s_bin in self.bins]
                        tmp_bins.extend((o_bin[0], o_bin[1]) for o_bin in other_bins)
                        tmp_bins.sort(
                            key=lambda x: (x[0] is not None, math.isnan(x[0]), x[0])
                        )
                        self.bins = tmp_bins
                        self.n_used_bins += o_n_used_bins
                        self.trim()

                def add(self, v):
                    """
                    Adds a new data point to the histogram approximation. Make sure you have
                    called either allocate() or merge() first. This method implements Algorithm #1
                    from Ben-Haim and Tom-Tov, "A Streaming Parallel Decision Tree Algorithm", JMLR 2010.
                    """

                    # Binary search to find the closest bucket that v should go into.
                    # 'bin' should be interpreted as the bin to shift right in order to accomodate
                    # v. As a result, bin is in the range [0,N], where N means that the value v is
                    # greater than all the N bins currently in the histogram. It is also possible that
                    # a bucket centered at 'v' already exists, so this must be checked in the next step.
                    bin = 0
                    left, right = 0, self.n_used_bins
                    while left < right:
                        bin = (left + right) // 2
                        if self.bins[bin][0] > v:
                            right = bin
                        elif self.bins[bin][0] < v:
                            left = bin + 1
                        else:
                            break

                    # If we found an exact bin match for value v, then just increment that bin's count.
                    # Otherwise, we need to insert a new bin and trim the resulting histogram back to size.
                    # A possible optimization here might be to set some threshold under which 'v' is just
                    # assumed to be equal to the closest bin -- if fabs(v-bins[bin].x) < THRESHOLD, then
                    # just increment 'bin'. This is not done now because we don't want to make any
                    # assumptions about the range of numeric data being analyzed.
                    if bin < self.n_used_bins and self.bins[bin][0] == v:
                        self.bins[bin][1] += 1
                    else:
                        self.bins.insert(bin + 1, (v, 1.0))
                        self.n_used_bins += 1
                        if self.n_used_bins > self.n_bins:
                            # Trim the bins down to the correct number of bins.
                            self.trim()

                def trim(self):
                    """
                    Trims a histogram down to 'nbins' bins by iteratively merging the closest bins.
                    If two pairs of bins are equally close to each other, decide uniformly at random which
                    pair to merge, based on a PRNG.
                    """
                    while self.n_used_bins > self.n_bins:
                        # Find the closest pair of bins in terms of x coordinates. Break ties randomly.
                        smallest_diff = self.bins[1][0] - self.bins[0][0]
                        smallest_loc = 0
                        count = 1

                        for i in range(1, self.n_used_bins - 1):
                            diff = self.bins[i + 1][0] - self.bins[i][0]
                            if diff < smallest_diff:
                                smallest_diff = diff
                                smallest_loc = i
                                count = 1
                            elif diff == smallest_diff:
                                count += 1
                                if self._next_double() <= 1.0 / count:
                                    smallest_loc = i

                        # Merge the two closest bins into their average x location, weighted by their heights.
                        # The height of the new bin is the sum of the heights of the old bins.
                        bin1 = self.bins[smallest_loc]
                        bin2 = self.bins[smallest_loc + 1]
                        total_y = bin1[1] + bin2[1]
                        new_x = (bin1[0] * bin1[1] + bin2[0] * bin2[1]) / total_y

                        self.bins[smallest_loc] = (new_x, total_y)

                        # Shift the remaining bins left one position
                        self.bins.pop(smallest_loc + 1)
                        self.n_used_bins -= 1

            _histogram_numeric_udaf = cached_udaf(
                HistogramNumericUDAF,
                return_type=VariantType(),
                input_types=[aggregate_input_typ, IntegerType()],
            )

            result_exp = snowpark_fn.cast(
                _histogram_numeric_udaf(
                    snowpark_args[0], snowpark_fn.lit(snowpark_args[1])
                ),
                histogram_return_type,
            )
            result_type = histogram_return_type
        case "hll_sketch_agg":
            match snowpark_args:
                case [sketch]:
                    spark_function_name = (
                        f"{function_name}({snowpark_arg_names[0]}, 12)"
                    )
                    result_exp = snowpark_fn.call_function(
                        "DATASKETCHES_HLL_ACCUMULATE", sketch, snowpark_fn.lit(12)
                    )
                case [sketch, lgConfigK]:
                    result_exp = snowpark_fn.call_function(
                        "DATASKETCHES_HLL_ACCUMULATE", sketch, lgConfigK
                    )
            result_type = BinaryType()
        case "hll_sketch_estimate":
            result_exp = snowpark_fn.call_function(
                "DATASKETCHES_HLL_ESTIMATE", snowpark_args[0]
            ).cast(LongType())
            result_type = LongType()
        case "hll_union_agg":
            raise_error = _raise_error_udf_helper(BinaryType())
            args = exp.unresolved_function.arguments
            allow_different_lgConfigK = len(args) == 2 and unwrap_literal(args[1])
            spark_function_name = f"{function_name}({snowpark_arg_names[0]}, {str(allow_different_lgConfigK).lower()})"
            hll_union_agg_res = snowpark_fn.call_function(
                "DATASKETCHES_HLL_COMBINE", snowpark_args[0]
            )
            # lgConfigK is stored in the 4th byte of the sketch
            lgConfigK_count = snowpark_fn.count_distinct(
                snowpark_fn.substr(snowpark_args[0], 4, 1)
            )
            result_exp = (
                snowpark_fn.when(
                    snowpark_fn.lit(allow_different_lgConfigK), hll_union_agg_res
                )
                .when(lgConfigK_count == 1, hll_union_agg_res)
                .otherwise(
                    raise_error(
                        snowpark_fn.lit(
                            "[HLL_UNION_DIFFERENT_LG_K] Sketches have different `lgConfigK` values. Set the `allowDifferentLgConfigK` parameter to true to call `hll_union_agg` with different `lgConfigK` values."
                        )
                    )
                )
            )

            result_type = BinaryType()
        case "hll_union":
            fn = register_cached_sql_udf(
                ["binary", "binary"],
                "binary",
                """
                SELECT CASE
                    WHEN arg0 IS NULL OR arg1 IS NULL THEN NULL
                    ELSE DATASKETCHES_HLL_COMBINE(x)
                END FROM (
                    SELECT arg0 as x
                    UNION ALL
                    SELECT arg1 as x)
                """,
            )
            raise_error = _raise_error_udf_helper(BinaryType())
            args = exp.unresolved_function.arguments
            allow_different_lgConfigK = len(args) == 3 and unwrap_literal(args[2])
            spark_function_name = f"{function_name}({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, {str(allow_different_lgConfigK).lower()})"
            hll_union_res = fn(snowpark_args[0], snowpark_args[1])
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), hll_union_res)
                .when(snowpark_fn.is_null(snowpark_args[1]), hll_union_res)
                .when(snowpark_fn.lit(allow_different_lgConfigK), hll_union_res)
                .when(
                    # lgConfigK is stored in the 4th byte of the sketch
                    snowpark_fn.substr(snowpark_args[0], 4, 1).cast(BinaryType())
                    == snowpark_fn.substr(snowpark_args[1], 4, 1).cast(BinaryType()),
                    hll_union_res,
                )
                .otherwise(
                    raise_error(
                        snowpark_fn.lit(
                            "[HLL_UNION_DIFFERENT_LG_K] Sketches have different `lgConfigK` values. Set the `allowDifferentLgConfigK` parameter to true to call `hll_union` with different `lgConfigK` values."
                        )
                    )
                )
            )

            result_type = BinaryType()
        case "hour":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.hour(
                    snowpark_fn.builtin("try_to_timestamp")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.hour(
                    snowpark_fn.to_timestamp(snowpark_args[0])
                )
            result_type = LongType()
        case "hypot":
            spark_function_name = (
                f"HYPOT({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.sqrt(
                snowpark_args[0] * snowpark_args[0]
                + snowpark_args[1] * snowpark_args[1]
            )
            result_type = DoubleType()
        case "ifnull":
            result_exp = snowpark_fn.ifnull(*snowpark_args)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "ilike":
            # Snowpark is not supporting ilike, so using Snowflake builtin function
            ilike = snowpark_fn.builtin("ilike")
            result_exp = ilike(snowpark_args[0], snowpark_args[1])
            result_type = BooleanType()
        case "in":
            spark_function_name = (
                f"({snowpark_arg_names[0]} IN ({', '.join(snowpark_arg_names[1:])}))"
            )
            result_exp = snowpark_args[0].in_(snowpark_args[1:])
            result_type = BooleanType()
        case "in_multi_exp":
            spark_function_name = (
                f"({snowpark_arg_names[:-1]} IN ({', '.join(snowpark_arg_names[-1:])}))"
            )
            result_exp = snowpark_fn.in_(snowpark_args[:-1], snowpark_args[-1:])
            result_type = BooleanType()
        case "initcap":
            result_exp = snowpark_fn.initcap(snowpark_args[0], snowpark_fn.lit(" "))
            result_type = StringType()
        case "inline" | "inline_outer":
            input_type = snowpark_typed_args[0].typ

            if (
                not isinstance(input_type, ArrayType)
                or input_type.element_type is None
                or isinstance(input_type.element_type, NullType)
            ):
                try:
                    type_str = input_type.simpleString().upper()
                except Exception:
                    type_str = str(input_type)

                raise AnalysisException(
                    f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "inline({snowpark_arg_names[0]})" due to data type mismatch: Parameter 1 requires the "ARRAY<STRUCT>" type, however "{snowpark_arg_names[0]}" has the type {type_str}.'
                )

            is_outer = function_name == "inline_outer"

            class Inline:
                def process(self, arr, size, is_outer):
                    if (arr is None or len(arr) == 0) and is_outer:
                        yield tuple([None] * size)
                    elif arr is None:
                        yield
                    else:
                        # Max size is the largest length any element in arr gets to
                        # We need to know this to return the correct number of elements in el.values().
                        max_size = 0
                        elements = []
                        # Pre-process the element generator and determine the max size.
                        for el in arr:
                            if el is None:
                                elements.append(None)
                            else:
                                values = list(el.values())
                                elements.append(values)
                                max_size = max(max_size, len(values))
                        for el in elements:
                            if el is None:
                                yield tuple([None] * max_size)
                            else:
                                yield tuple(el)

            inline_udtf = cached_udtf(
                Inline,
                output_schema=input_type.element_type,
                input_types=[ArrayType(), LongType(), BooleanType()],
            )

            spark_col_names = list(f.name for f in input_type.element_type.fields)
            result_type = list(f.datatype for f in input_type.element_type.fields)
            result_exp = snowpark_fn.call_table_function(
                inline_udtf.name,
                snowpark_typed_args[0].column(to_semi_structure=True),
                snowpark_fn.lit(len(result_type)),
                snowpark_fn.lit(is_outer),
            )
        case "input_file_name":
            # TODO: Use METADATA$FILENAME to get an actual file name, but this requires a refactor, because this is not possible straightaway here.
            raise SnowparkConnectNotImplementedError(
                "input_file_name is not yet supported."
            )
        case "instr":
            result_exp = snowpark_fn.charindex(snowpark_args[1], snowpark_args[0])
            result_type = LongType()
        case "isnan":
            result_exp = snowpark_fn.equal_nan(snowpark_args[0])
            result_type = BooleanType()
        case "isnotnull":
            spark_function_name = f"({snowpark_arg_names[0]} IS NOT NULL)"
            result_exp = snowpark_args[0].isNotNull()
            result_type = BooleanType()
        case "isnull":
            spark_function_name = f"({snowpark_arg_names[0]} IS NULL)"
            result_exp = snowpark_args[0].isNull()
            result_type = BooleanType()
        case "java_method" | "reflect":
            class_name, method_name = snowpark_args[0], snowpark_args[1]
            method_args = snowpark_typed_args[2:]

            arg_types: list[DataType] = [arg.typ for arg in method_args]

            allowed_arg_types = {
                BooleanType(),
                ByteType(),
                IntegerType(),
                LongType(),
                FloatType(),
                DoubleType(),
                StringType(),
            }
            for arg_idx, arg_type in enumerate(arg_types):
                if arg_type not in allowed_arg_types:
                    spark_type = map_snowpark_to_pyspark_types(arg_type)

                    raise AnalysisException(
                        f"""[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "{spark_function_name}" due to data type mismatch: """
                        f"""Parameter {arg_idx+3} requires the ("BOOLEAN" or "TINYINT" or "SMALLINT" or "INT" or "BIGINT" or "FLOAT" or "DOUBLE" or "STRING") type, """
                        f"""however "{snowpark_arg_names[arg_idx+2]}" has the type "{spark_type.simpleString()}"."""
                    )

            arg_values = snowpark_fn.cast(
                snowpark_fn.array_construct(
                    *[arg.column(to_semi_structure=True) for arg in method_args]
                ),
                ArrayType(StringType()),
            )

            java_method_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.JavaMethodUdf.java_method",
                ["STRING", "STRING", "ARRAY(STRING)", "ARRAY(STRING)"],
                "STRING",
                packages=["com.snowflake:snowpark:1.15.0"],
            )

            # This can never be executed outside a sandboxed UDF due to security reasons
            result_exp = java_method_udf(
                class_name,
                method_name,
                arg_values,
                snowpark_fn.lit([arg_type.simple_string() for arg_type in arg_types]),
            )

            result_type = StringType()
        case "json_array_length":
            arr_exp = snowpark_fn.function("TRY_PARSE_JSON")(snowpark_args[0])
            result_exp = snowpark_fn.array_size(arr_exp)
            result_type = LongType()
        case "json_object_keys":
            obj_exp = snowpark_fn.function("TRY_PARSE_JSON")(
                snowpark_args[0], snowpark_fn.lit("d")
            )
            result_exp = snowpark_fn.object_keys(obj_exp).cast(
                ArrayType(StringType(), True)
            )
            result_exp = snowpark_fn.when(
                snowpark_fn.is_object(obj_exp),
                result_exp,
            ).otherwise(snowpark_fn.lit(None))
            result_type = ArrayType(StringType())
        case "json_tuple":
            analyzer = Session.get_active_session()._analyzer
            json = snowpark_fn.function("TRY_PARSE_JSON")(
                snowpark_args[0], snowpark_fn.lit("d")
            )
            fields = exp.unresolved_function.arguments[1:]
            fields = [unwrap_literal(f) for f in fields]
            fields = [
                snowpark_fn.to_json(snowpark_fn.get(json, snowpark_fn.lit(f)))
                for f in fields
            ]
            fields = [analyzer.analyze(f._expression, defaultdict()) for f in fields]
            result_exp = snowpark_fn.sql_expr(", ".join(fields))
            spark_col_names = [f"c{i}" for i in range(len(fields))]
            # TODO: will this always be a string?
            result_type = [StringType() for _ in range(len(fields))]
        case "kurtosis":
            result_exp = _resolve_aggregate_exp(
                snowpark_fn.kurtosis(snowpark_args[0]),
                DoubleType(),
            )
        case "lag":
            offset = unwrap_literal(exp.unresolved_function.arguments[1])
            default = snowpark_args[2] if len(snowpark_args) > 2 else None
            default_name = (
                "NULL"
                if default is None
                else map_expression(
                    exp.unresolved_function.arguments[2], column_mapping, typer
                )[0][0]
            )
            result_exp = snowpark_fn.lag(snowpark_args[0], offset, default)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
            spark_function_name = (
                f"lag({snowpark_arg_names[0]}, {offset}, {default_name})"
            )
        case "last":
            if not is_window_enabled():
                # If last function is not used in window expression, it should act as aggregate function.
                # According to PySpark docs, ignore_nulls can be a Column - but it doesn't make sense and doesn't work.
                # So assume it's a literal.
                ignore_nulls = unwrap_literal(exp.unresolved_function.arguments[1])

                class LastUDAF:
                    def __init__(self) -> None:
                        self._value = None

                    @property
                    def aggregate_state(self):
                        return self._value

                    def accumulate(self, input_value):
                        if not (ignore_nulls and input_value is None):
                            self._value = input_value

                    def merge(self, other_value):
                        if not (ignore_nulls and other_value is None):
                            self._value = other_value

                    def finish(self):
                        return self._value

                _last_udaf = cached_udaf(
                    LastUDAF,
                    return_type=snowpark_typed_args[0].typ,
                    input_types=[snowpark_typed_args[0].typ],
                )

                result_exp = _last_udaf(snowpark_args[0])
                spark_function_name = f"last({snowpark_arg_names[0]})"
            else:
                # when used in window function it should act as last_vale
                result_exp = _resolve_last_value(exp, snowpark_args)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "last_day":
            match snowpark_typed_args[0].typ:
                case DateType():
                    result_exp = snowpark_args[0]
                case TimestampType():
                    result_exp = snowpark_fn.to_date(snowpark_args[0])
                case StringType():
                    result_exp = (
                        snowpark_fn.builtin("try_to_date")(
                            snowpark_args[0],
                            snowpark_fn.lit(
                                map_spark_timestamp_format_expression(
                                    exp.unresolved_function.arguments[1]
                                )
                            ),
                        )
                        if len(snowpark_args) > 1
                        else snowpark_fn.builtin("try_to_date")(*snowpark_args)
                    )
                case _:
                    raise AnalysisException(
                        f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "last_day({snowpark_arg_names[0]}" due to data type mismatch: Parameter 1 requires the "DATE" type, however "{snowpark_arg_names[0]}" has the type "{snowpark_typed_args[0]}".'
                    )

            result_exp = snowpark_fn.last_day(result_exp)
            result_type = DateType()
        case "last_value":
            result_exp = TypedColumn(
                _resolve_last_value(exp, snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "lead":
            offset = unwrap_literal(exp.unresolved_function.arguments[1])
            default = snowpark_args[2] if len(snowpark_args) > 2 else None
            default_name = (
                "NULL"
                if default is None
                else map_expression(
                    exp.unresolved_function.arguments[2], column_mapping, typer
                )[0][0]
            )
            result_exp = snowpark_fn.lead(snowpark_args[0], offset, default)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
            spark_col_names = [
                f"lead({snowpark_arg_names[0]}, {offset}, {default_name})"
            ]
        case "least":
            result_exp = snowpark_fn.function("LEAST_IGNORE_NULLS")(*snowpark_args)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "left":
            result_exp = snowpark_fn.left(*snowpark_args)
            result_type = StringType()
        case "length" | "char_length" | "character_length":
            if exp.unresolved_function.arguments[0].HasField("literal"):
                # Only update the name if it has the literal field.
                # If it doesn't, it means it's binary data.
                arg_value = repr(unwrap_literal(exp.unresolved_function.arguments[0]))
                # repr is used to display proper column names when newlines or tabs are included in the string
                # However, this breaks with the usage of nested emojis.
                arg_value = arg_value[1:-1] if arg_value != "None" else "NULL"
                spark_function_name = (
                    f"{exp.unresolved_function.function_name}({arg_value})"
                )
            result_exp = snowpark_fn.length(snowpark_args[0])
            result_type = LongType()
        case "levenshtein":
            match snowpark_args:
                case [arg1, arg2]:
                    result_exp = snowpark_fn.editdistance(arg1, arg2)
                case [arg1, arg2, _]:
                    max_distance = unwrap_literal(exp.unresolved_function.arguments[2])

                    if max_distance >= 0:
                        # snowpark implementation
                        # a maximum distance can be specified. If the distance exceeds this value, the computation halts and returns the maximum distance.
                        # we are passing max_distance + 1 to make it compatible to spark
                        result_exp = snowpark_fn.editdistance(
                            arg1, arg2, max_distance + 1
                        )
                        result_exp = snowpark_fn.when(
                            result_exp >= max_distance + 1, snowpark_fn.lit(-1)
                        ).otherwise(result_exp)
                    else:
                        result_exp = snowpark_fn.when(
                            snowpark_fn.is_null(arg1) | snowpark_fn.is_null(arg2),
                            snowpark_fn.lit(None),
                        ).otherwise(snowpark_fn.lit(-1))
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_type = LongType()
        case "like":
            result_exp = snowpark_fn.call_function("like", *snowpark_args)
            result_type = BooleanType()
            spark_function_name = (
                f"{snowpark_arg_names[0]} LIKE {snowpark_arg_names[1]}"
            )
        case "ln":
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.ln(snowpark_args[0]))
            result_type = DoubleType()
        case "localtimestamp":
            result_exp = snowpark_fn.builtin("localtimestamp")()
            result_type = TimestampType(TimestampTimeZone.LTZ)
        case "locate":
            substr = unwrap_literal(exp.unresolved_function.arguments[0])
            value = snowpark_args[1]
            start_pos = unwrap_literal(exp.unresolved_function.arguments[2])

            if start_pos > 0:
                result_exp = snowpark_fn.locate(substr, value, start_pos)
            else:
                result_exp = snowpark_fn.when(
                    snowpark_fn.is_null(value),
                    snowpark_fn.lit(None),
                ).otherwise(snowpark_fn.lit(0))
            result_type = LongType()
        case "log":
            # This handles a SQL case where log can be called with a single element and no second element will be automatically padded.
            if len(snowpark_args) == 1:
                spark_function_name = f"LOG(E(), {snowpark_arg_names[0]})"
                result_exp = snowpark_fn.when(
                    snowpark_args[0] <= 0, snowpark_fn.lit(None)
                ).otherwise(snowpark_fn.ln(snowpark_args[0]))
                result_type = DoubleType()
            else:
                spark_function_name = (
                    f"LOG({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
                )
                result_exp = (
                    snowpark_fn.when(
                        snowpark_args[0] == 1,
                        snowpark_fn.when(snowpark_args[1] == 1, NAN).otherwise(
                            INFINITY
                        ),
                    )
                    .when(
                        (snowpark_args[1] <= 0) | (snowpark_args[0] == 0),
                        snowpark_fn.lit(None),
                    )
                    .otherwise(snowpark_fn.log(snowpark_args[0], snowpark_args[1]))
                )
                result_type = DoubleType()
        case "log10":
            spark_function_name = f"LOG10({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.log(10.0, snowpark_args[0]))
            result_type = DoubleType()
        case "log1p":
            spark_function_name = f"LOG1P({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.ln(snowpark_args[0] + snowpark_fn.lit(1.0)))
            result_type = DoubleType()
        case "log2":
            spark_function_name = f"LOG2({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.log(2.0, snowpark_args[0]))
            result_type = DoubleType()
        case "lower" | "lcase":
            result_exp = snowpark_fn.lower(snowpark_args[0])
            result_type = StringType()
        case "lpad":
            # Assume the last argument is missing and set the pad value to a string.
            pad_value = snowpark_fn.lit(" ")
            if len(snowpark_args) == 2:
                spark_function_name = (
                    f"lpad({snowpark_arg_names[0]}, {snowpark_arg_names[1]},  )"
                )
                arg_type = snowpark_typed_args[0]
                # If the first argument is of BinaryType, the pad value is instead b"\x00".
                if isinstance(arg_type.typ, BinaryType):
                    pad_value = snowpark_fn.lit(b"\x00")
            else:
                # If the last argument isn't missing, set the pad value to the last argument.
                pad_value = snowpark_args[2]
            result_exp = snowpark_fn.lpad(snowpark_args[0], snowpark_args[1], pad_value)
            result_type = StringType()
        case "ltrim":
            if len(snowpark_args) == 2:
                # Only possible using SQL
                spark_function_name = f"TRIM(LEADING {snowpark_arg_names[1]} FROM {snowpark_arg_names[0]})"
            result_exp = snowpark_fn.ltrim(*snowpark_args)
            result_type = StringType()
        case "make_date":
            y = snowpark_args[0].cast(LongType())
            m = snowpark_args[1].cast(LongType())
            d = snowpark_args[2].cast(LongType())
            dash = snowpark_fn.lit("-")
            snowpark_function = "to_date" if spark_sql_ansi_enabled else "try_to_date"
            date_str_exp = snowpark_fn.concat(y, dash, m, dash, d)
            result_exp = snowpark_fn.builtin(snowpark_function)(date_str_exp)
            result_type = DateType()
        case "make_timestamp" | "make_timestamp_ltz" | "make_timestamp_ntz":
            y, m, d, h, mins = map(lambda col: col.cast(LongType()), snowpark_args[:5])
            y_abs = snowpark_fn.abs(y)
            s = snowpark_args[5].cast(DoubleType())
            # 'seconds = 60' is valid
            s_shifted = snowpark_fn.when(s == 60, 0).otherwise(s)
            s_floor = snowpark_fn.floor(s)
            nanos = snowpark_fn.round(
                snowpark_fn.round(s - s_floor, 6) * 1_000_000_000
            ).cast(LongType())

            dash = snowpark_fn.lit("-")
            space = snowpark_fn.lit(" ")
            colon = snowpark_fn.lit(":")
            parse_function = (
                "to_timestamp" if spark_sql_ansi_enabled else "try_to_timestamp"
            )
            str_exp = snowpark_fn.concat(
                y_abs, dash, m, dash, d, space, h, colon, mins, colon, s_shifted
            )
            parsed_str_exp = snowpark_fn.builtin(parse_function)(str_exp)

            match function_name:
                case "make_timestamp":
                    make_function_name = "timestamp_tz_from_parts"
                    result_type = TimestampType()
                case "make_timestamp_ltz":
                    make_function_name = "timestamp_ltz_from_parts"
                    result_type = TimestampType(TimestampTimeZone.LTZ)
                case "make_timestamp_ntz":
                    make_function_name = "timestamp_ntz_from_parts"
                    result_type = TimestampType(TimestampTimeZone.NTZ)

            make_timestamp_res = (
                snowpark_fn.timestamp_tz_from_parts(
                    y,
                    m,
                    d,
                    h,
                    mins,
                    s_floor,
                    nanos,
                    snowpark_args[6],
                ).cast(result_type)
                if len(snowpark_args) == 7
                else snowpark_fn.function(make_function_name)(
                    y, m, d, h, mins, s_floor, nanos
                ).cast(result_type)
            )

            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(parsed_str_exp), snowpark_fn.lit(None)
            ).otherwise(make_timestamp_res)
        case "map":
            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            @cached_udf(
                input_types=[ArrayType()],
                return_type=StructType(),
            )
            def _create_map(arg_array):
                if arg_array is None or len(arg_array) % 2 != 0:
                    raise ValueError(
                        "Number of arguments must be even (a list of key-value pairs)."
                    )

                result = {}
                for index in range(0, len(arg_array), 2):
                    key = arg_array[index]
                    result[key] = arg_array[index + 1]

                return result

            key_type = _find_common_type(
                list(map(lambda x: x.typ, snowpark_typed_args[::2]))
            )
            value_type = _find_common_type(
                list(map(lambda x: x.typ, snowpark_typed_args[1::2]))
            )
            if len(snowpark_args) == 0:
                result_exp = snowpark_fn.cast(
                    snowpark_fn.object_construct(), MapType(NullType(), NullType())
                )
                result_type = MapType(NullType(), NullType())
            elif key_type is None or isinstance(key_type, NullType):
                raise SparkRuntimeException(
                    "[NULL_MAP_KEY] Cannot use null as map key."
                )
            else:
                value_type = value_type if value_type else NullType()
                if allow_duplicate_keys or (not isinstance(key_type, StringType)):
                    input_args = snowpark_fn.array_construct(
                        *[snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args]
                    )
                    result_exp = _create_map(input_args)
                else:
                    # please not that spark does not suppot null in the keys but we need to make this spark invompatible change
                    # to support a customer workload because the udf performs 10 times worse than this.
                    input_args = [
                        snowpark_fn.cast(x, StringType())
                        if i % 2 == 0
                        else snowpark_fn.cast(x, VariantType())
                        for i, x in enumerate(snowpark_args)
                    ]
                    result_exp = result_exp = snowpark_fn.call_function(
                        "OBJECT_CONSTRUCT_KEEP_NULL", *input_args
                    )
                result_exp = snowpark_fn.cast(
                    result_exp,
                    MapType(key_type, value_type),
                )
                result_type = MapType(key_type, value_type)
        case "map_concat":
            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            def _map_concat(allow_dups, arg_array):
                new_map = {}
                for m in arg_array:
                    if m is None:
                        # return none if any of the input maps are none
                        return None
                    for key, value in m.items():
                        if key in new_map and not allow_dups:
                            raise ValueError(
                                DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                            )
                        else:
                            new_map[key] = value
                return new_map

            map_concat_udf = cached_udf(
                _map_concat,
                input_types=[BooleanType(), ArrayType()],
                return_type=StructType(),
            )

            key_type = _find_common_type(
                list(map(lambda x: x.typ.key_type, snowpark_typed_args[::2]))
            )
            value_type = _find_common_type(
                list(map(lambda x: x.typ.value_type, snowpark_typed_args[1::2]))
            )

            input_args = [snowpark_fn.cast(arg, StructType()) for arg in snowpark_args]

            result_exp = snowpark_fn.cast(
                map_concat_udf(
                    snowpark_fn.lit(allow_duplicate_keys),
                    snowpark_fn.array_construct(*input_args),
                ),
                MapType(key_type, value_type),
            )
            result_type = MapType(key_type, value_type)
        case "map_contains_key":
            result_exp = snowpark_fn.map_contains_key(*snowpark_args)
            result_type = BooleanType()
        case "map_entries":
            key_type = snowpark_typed_args[0].typ.key_type
            value_type = snowpark_typed_args[0].typ.value_type

            # SNOW-2040715
            def _map_entries(obj: dict):
                if obj is None:
                    raise TypeError(f"Expected MapType but received {obj} instead.")
                return [{"key": key, "value": value} for key, value in obj.items()]

            arg_type = snowpark_typed_args[0].typ
            if not isinstance(arg_type, MapType):
                raise TypeError(
                    f"map_entries requires a MapType argument, got {arg_type}"
                )

            map_entries = snowpark_fn.udf(
                _map_entries,
                return_type=ArrayType(StructType()),
                input_types=[arg_type],
            )
            result_type = ArrayType(
                StructType(
                    [
                        StructField("key", key_type, _is_column=False),
                        StructField("value", value_type, _is_column=False),
                    ]
                )
            )
            result_exp = snowpark_fn.cast(
                map_entries(snowpark_args[0]),
                result_type,
            )
        case "map_from_arrays":
            keys_type = snowpark_typed_args[0].typ
            values_type = snowpark_typed_args[1].typ
            if not isinstance(keys_type, ArrayType) or not isinstance(
                values_type, ArrayType
            ):
                raise TypeError(
                    f"map_from_arrays requires two arguments of type ArrayType, got {keys_type} and {values_type}"
                )
            key_type = keys_type.element_type if keys_type.structured else VariantType()
            value_type = (
                values_type.element_type if values_type.structured else VariantType()
            )

            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            def _map_from_arrays(allow_dups, keys, values):
                if len(keys) != len(values):
                    raise ValueError(
                        "The key array and value array of must have the same length"
                    )

                if not allow_dups and len(set(keys)) != len(keys):
                    seen = set()
                    for key in keys:
                        if key in seen:
                            raise ValueError(
                                DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                            )
                        seen.add(key)
                # will overwrite the last occurrence if there are duplicates.
                return dict(zip(keys, values))

            _map_from_arrays_udf = cached_udf(
                _map_from_arrays,
                return_type=StructType(),
                input_types=[BooleanType(), ArrayType(), ArrayType()],
            )
            result_exp = snowpark_fn.cast(
                _map_from_arrays_udf(
                    snowpark_fn.lit(allow_duplicate_keys),
                    snowpark_fn.cast(snowpark_args[0], ArrayType()),
                    snowpark_fn.cast(snowpark_args[1], ArrayType()),
                ),
                MapType(key_type, value_type),
            )
            result_type = MapType(key_type, value_type)
        case "map_from_entries":
            if not isinstance(snowpark_typed_args[0].typ, ArrayType):
                raise TypeError(
                    f"map_from_entries requires an argument of type ArrayType, got {snowpark_typed_args[0].typ}"
                )

            entry_type = snowpark_typed_args[0].typ.element_type

            match entry_type:
                case None:
                    # workaround for spark sql struct(key, value) - entry_type is None
                    # TODO: can we get correct types once we integrate spark's sql parser?
                    # VariantType is not supported for structured map keys
                    key_type = StringType()
                    value_type = VariantType()
                    # default field names
                    key_field = "col1"
                    value_field = "col2"
                case _ if isinstance(entry_type, StructType) and entry_type.structured:
                    key_type = entry_type.fields[0].datatype
                    value_type = entry_type.fields[1].datatype
                    [key_field, value_field] = entry_type.names
                case _:
                    raise TypeError(
                        f"map_from_entries requires an array of StructType, got array of {entry_type}"
                    )

            last_win_dedup = global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"

            result_exp = snowpark_fn.cast(
                snowpark_fn.function("reduce")(
                    snowpark_args[0],
                    snowpark_fn.object_construct(),
                    snowpark_fn.sql_expr(
                        # value_field is cast to variant because object_insert doesn't allow structured types,
                        # and structured types are not coercible to variant
                        # TODO: allow structured types in object_insert?
                        f"(acc, e) -> object_insert(acc, e:{key_field}, e:{value_field}::variant, {last_win_dedup})"
                    ),
                ),
                MapType(key_type, value_type),
            )
            result_type = MapType(key_type, value_type)
        case "map_keys":
            arg_type = snowpark_typed_args[0].typ
            if not isinstance(arg_type, MapType):
                raise TypeError(f"map_keys requires a MapType argument, got {arg_type}")

            if arg_type.structured:
                result_exp = snowpark_fn.map_keys(snowpark_args[0])
            else:
                # snowpark's map_keys function is not compatible with snowflake's OBJECT type
                result_exp = snowpark_fn.object_keys(snowpark_args[0])
            result_type = ArrayType(arg_type.key_type, contains_null=False)
        case "map_values":
            # TODO: implement in Snowflake/Snowpark
            # technically this could be done with a lateral join, but it's probably not worth the effort
            arg_type = snowpark_typed_args[0].typ
            if not isinstance(arg_type, MapType):
                raise AnalysisException(
                    f"map_values requires a MapType argument, got {arg_type}"
                )

            def _map_values(obj: dict) -> list:
                return list(obj.values())

            map_values = cached_udf(
                _map_values, return_type=ArrayType(), input_types=[StructType()]
            )

            result_exp = snowpark_fn.cast(
                map_values(snowpark_fn.cast(snowpark_args[0], StructType())),
                ArrayType(arg_type.value_type),
            )
            result_type = ArrayType(arg_type.value_type)
        case "mask":
            result_exp, upper_char, lower_char, digit_char, other_char = snowpark_args

            random_tag_suffix = "".join(random.sample(string.ascii_uppercase, 6))
            tags = [
                s + random_tag_suffix
                for s in ["TAGUPPER", "TAGLOWER", "TAGDIGIT", "TAGOTHER"]
            ]
            patterns = ["[A-Z]", "[a-z]", r"\d", "[^A-Z]"]
            replacements = [upper_char, lower_char, digit_char, other_char]

            # To avoid replacement character collisions we need to replace them with unique tags first.
            for tag, pattern, replacement_char in zip(tags, patterns, replacements):
                result_exp = snowpark_fn.when(
                    ~snowpark_fn.is_null(replacement_char),
                    snowpark_fn.regexp_replace(result_exp, pattern, tag),
                ).otherwise(result_exp)

            for tag, replacement_char in zip(tags, replacements):
                result_exp = snowpark_fn.when(
                    ~snowpark_fn.is_null(replacement_char),
                    snowpark_fn.regexp_replace(result_exp, tag, replacement_char),
                ).otherwise(result_exp)
            result_type = StringType()
        case "max":
            result_exp = TypedColumn(
                snowpark_fn.max(snowpark_args[0]),
                lambda: snowpark_typed_args[0].types,
            )
        case "max_by":
            result_exp = TypedColumn(
                snowpark_fn.max_by(*snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "md5":
            result_exp = snowpark_fn.md5(snowpark_args[0])
            result_type = StringType(32)
        case "median":
            result_exp = snowpark_fn.median(snowpark_args[0])
            # TODO SNOW-2034495: can we resolve the result type?
            result_exp = _type_with_typer(result_exp)
        case "min":
            result_exp = TypedColumn(
                snowpark_fn.min(snowpark_args[0]),
                lambda: snowpark_typed_args[0].types,
            )
        case "min_by":
            result_exp = TypedColumn(
                snowpark_fn.min_by(*snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "minute":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.minute(
                    snowpark_fn.builtin("try_to_timestamp")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.minute(
                    snowpark_fn.to_timestamp(snowpark_args[0])
                )
            result_type = LongType()
        case "mode":
            result_exp = TypedColumn(
                snowpark_fn.mode(snowpark_args[0]),
                lambda: snowpark_typed_args[0].types,
            )
        case "monotonically_increasing_id":
            result_exp = snowpark_fn.monotonically_increasing_id()
            result_type = LongType()
        case "month":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.month(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.month(snowpark_fn.to_date(snowpark_args[0]))
            result_type = LongType()
        case "months_between":
            # Pyspark months_between returns a floating point number with a higher precision than Snowpark
            # and has a third optional argument (roundOff: bool = True), which allows to increase the precision even more.
            # The difference is visible after a few decimal places, but in order to have a 100% compatibility, extending the Snowpark's API is required.

            spark_function_name = f"months_between({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, {'true' if len(snowpark_args) == 2 else str(snowpark_arg_names[2]).lower()})"
            result_exp = _try_to_cast(
                "try_to_date",
                snowpark_fn.cast(
                    snowpark_fn.months_between(
                        snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
                        snowpark_fn.cast(snowpark_args[1], get_timestamp_type()),
                    ),
                    DoubleType(),
                ),
                snowpark_args[0],
                snowpark_args[1],
            )
            result_type = DoubleType()
        case "named_struct":
            if snowpark_args is None or len(snowpark_args) % 2 != 0:
                raise ValueError(
                    "Number of arguments must be even (a list of key-value pairs)."
                )
            field_cols = snowpark_typed_args[1::2]
            result_exp = snowpark_fn.object_construct_keep_null(
                *[
                    name_with_col
                    for name, typed_col in zip(snowpark_args[::2], field_cols)
                    for name_with_col in (
                        name,
                        typed_col.column(to_semi_structure=True),
                    )
                ]
            )
            # calculate schema to cast the result to the structured type
            field_names = list(
                map(unwrap_literal, exp.unresolved_function.arguments[::2])
            )
            schema = StructType(
                [
                    StructField(name, col.typ, _is_column=False)
                    for name, col in zip(field_names, field_cols)
                ]
            )
            result_exp = snowpark_fn.cast(result_exp, schema)
            result_type = schema
        case "nanvl":
            # SNOW-1915311: Numeric value 'NAN' is not recognized is thrown in certain
            # scenarios, when equal_nan is used, e.g. in test_normal_functions spark test.
            arg1_is_nan = snowpark_args[0] == snowpark_fn.lit(NAN)
            arg2_is_nan = snowpark_args[1] == snowpark_fn.lit(NAN)

            result_exp = (
                snowpark_fn.when(~arg1_is_nan, snowpark_args[0])
                .when(arg1_is_nan & arg2_is_nan, snowpark_fn.lit(NAN))
                .when(snowpark_fn.is_null(snowpark_args[0]), snowpark_fn.lit(None))
                .when(~arg2_is_nan, snowpark_args[1])
                .otherwise(snowpark_fn.lit(None))
            )
            result_type = DoubleType()
        case "negative" | "unary_minus":
            arg_type = snowpark_typed_args[0].typ
            if function_name == "unary_minus":
                spark_function_name = f"(- {snowpark_arg_names[0]})"
            else:
                spark_function_name = f"negative({snowpark_arg_names[0]})"
            if isinstance(arg_type, _NumericType):
                result_exp = snowpark_fn.negate(snowpark_args[0])
            elif isinstance(arg_type, StringType):
                if spark_sql_ansi_enabled:
                    raise NumberFormatException(
                        f'The value \'{snowpark_args[0]}\' of the type {arg_type} cannot be cast to "DOUBLE" because it is malformed. Correct the value as per the syntax, or change its target type. Use `try_cast` to tolerate malformed input and return NULL instead. If necessary set "spark.sql.ansi.enabled" to "false" to bypass this error.'
                    )
                else:
                    result_exp = snowpark_fn.lit(None)
            elif isinstance(arg_type, NullType):
                result_exp = snowpark_fn.lit(None)
            else:
                raise AnalysisException(
                    f"[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve {spark_function_name} due to data type mismatch: "
                    f'Parameter 1 requires the ("NUMERIC") type, however "{snowpark_arg_names[0]}" has the type "{snowpark_typed_args[0]}".'
                )
            result_type = (
                snowpark_typed_args[0].types
                if isinstance(arg_type, _NumericType)
                else DoubleType()
            )
        case "next_day":
            dates = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
            date = unwrap_literal(exp.unresolved_function.arguments[1])
            if date is None or date.lower() not in dates:
                if spark_sql_ansi_enabled:
                    raise IllegalArgumentException(
                        """Illegal input for day of week. If necessary set "spark.sql.ansi.enabled" to false to bypass this error."""
                    )
                else:
                    result_exp = snowpark_fn.lit(None)
            else:
                result_exp = _try_to_cast(
                    "try_to_date",
                    snowpark_fn.next_day(snowpark_args[0], snowpark_args[1]),
                    snowpark_args[0],
                )
            result_type = DateType()
        case "not":
            spark_function_name = f"(NOT {snowpark_arg_names[0]})"
            result_exp = ~snowpark_args[0]
            result_type = BooleanType()
        case "nth_value":
            args = exp.unresolved_function.arguments
            n = unwrap_literal(args[1])
            ignore_nulls = unwrap_literal(args[2]) if len(args) > 2 else False
            result_exp = TypedColumn(
                snowpark_fn.nth_value(snowpark_args[0], n, ignore_nulls),
                lambda: snowpark_typed_args[0].types,
            )
            spark_function_name = f"nth_value({snowpark_arg_names[0]}, {n}){' ignore nulls' if ignore_nulls else ''}"
        case "ntile":
            result_exp = snowpark_fn.ntile(snowpark_args[0])
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "nullif":
            result_exp = TypedColumn(
                snowpark_fn.call_function("nullif", *snowpark_args),
                lambda: snowpark_typed_args[0].types,
            )
        case "nvl":
            _validate_arity(2)
            result_type = _find_common_type([arg.typ for arg in snowpark_typed_args])
            result_exp = snowpark_fn.nvl(
                *[col.cast(result_type) for col in snowpark_args]
            )
        case "nvl2":
            _validate_arity(3)
            result_type = _find_common_type(
                [arg.typ for arg in snowpark_typed_args[1:]]
            )
            result_exp = snowpark_fn.call_function(
                "nvl2",
                snowpark_args[0],
                *[col.cast(result_type) for col in snowpark_args[1:]],
            )
        case "octet_length":
            result_exp = snowpark_fn.octet_length(snowpark_args[0])
            result_type = LongType()
        case "or":
            spark_function_name = (
                f"({snowpark_arg_names[0]} OR {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_args[0] | snowpark_args[1]
            result_type = BooleanType()
        case "overlay":
            length = snowpark_fn.when(
                snowpark_args[3] < 0, snowpark_fn.length(snowpark_args[1])
            ).otherwise(snowpark_args[3])
            result_exp = snowpark_fn.concat(
                snowpark_fn.substring(snowpark_args[0], 1, snowpark_args[2] - 1),
                snowpark_args[1],
                snowpark_fn.substring(snowpark_args[0], snowpark_args[2] + length),
            )
            result_type = StringType()
        case "parse_url":
            url, part_to_extract = snowpark_args[0], snowpark_args[1]
            key = snowpark_args[2] if len(snowpark_args) > 2 else snowpark_fn.lit(None)

            result_exp = snowpark_fn.call_function("parse_url", url)

            result_exp = (
                snowpark_fn.when(
                    part_to_extract == snowpark_fn.lit("PROTOCOL"),
                    snowpark_fn.get(result_exp, snowpark_fn.lit("scheme")),
                )
                .when(
                    part_to_extract == snowpark_fn.lit("REF"),
                    snowpark_fn.get(result_exp, snowpark_fn.lit("fragment")),
                )
                .when(
                    part_to_extract == snowpark_fn.lit("AUTHORITY"),
                    snowpark_fn.concat_ws(
                        snowpark_fn.lit(":"),
                        snowpark_fn.get(result_exp, snowpark_fn.lit("host")),
                        snowpark_fn.get(result_exp, snowpark_fn.lit("port")),
                    ),
                )
                .when(
                    (part_to_extract == snowpark_fn.lit("QUERY")) & ~key.is_null(),
                    snowpark_fn.get(
                        snowpark_fn.get(result_exp, snowpark_fn.lit("parameters")), key
                    ),
                )
                .otherwise(
                    snowpark_fn.get(result_exp, snowpark_fn.lower(part_to_extract))
                )
            )

            result_exp = snowpark_fn.cast(result_exp, StringType())
            result_type = StringType()
        case "percent_rank":
            result_exp = snowpark_fn.percent_rank()
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "percentile_cont" | "percentiledisc":

            def _check_percentage(exp: expressions_proto.Expression) -> Column:
                perc = unwrap_literal(exp)
                if perc is None:
                    raise AnalysisException("The percentage must not be null.")
                if not 0.0 <= perc <= 1.0:
                    raise AnalysisException(
                        "The percentage must be between [0.0, 1.0]."
                    )
                return snowpark_fn.lit(perc)

            if function_name == "percentiledisc":
                function_name = "percentile_disc"
            result_exp = snowpark_fn.function(function_name)(
                _check_percentage(exp.unresolved_function.arguments[1])
            ).within_group(snowpark_args[0])
            result_exp = TypedColumn(
                snowpark_fn.cast(result_exp, FloatType()), lambda: [DoubleType()]
            )
            spark_function_name = f"{function_name}({unwrap_literal(exp.unresolved_function.arguments[1])}) WITHIN GROUP (ORDER BY {snowpark_arg_names[0]})"
        case "pi":
            spark_function_name = "PI()"
            result_exp = snowpark_fn.lit(math.pi)
            result_type = FloatType()
        case "pmod":
            a, b = snowpark_args
            result_exp = snowpark_fn.when(a < 0, (a % b + b) % b).otherwise(a % b)
            # TODO SNOW-2034495: assign type
            result_exp = _type_with_typer(result_exp)
        case "posexplode" | "posexplode_outer":
            input_type = snowpark_typed_args[0].typ
            is_nullable = function_name == "posexplode_outer"
            if isinstance(input_type, ArrayType):

                class PosExplode:
                    def process(self, arr, function_name):
                        if not arr:
                            if function_name == "posexplode":
                                yield
                            else:
                                yield (None, None)
                        else:
                            yield from enumerate(arr)

                posexplode_udtf = cached_udtf(
                    PosExplode,
                    output_schema=StructType(
                        [
                            StructField(
                                "pos", LongType(), is_nullable, _is_column=False
                            ),
                            StructField(
                                "col", input_type.element_type, True, _is_column=False
                            ),
                        ]
                    ),
                    input_types=[input_type, StringType()],
                )

                spark_col_names = ["pos", "col"]
                result_type = [LongType(), input_type.element_type]
            elif isinstance(input_type, MapType):

                class PosExplode:
                    def process(self, m, function_name):
                        if not m:
                            if function_name == "posexplode":
                                yield
                            else:
                                yield (None, None, None)
                        else:
                            for i, (key, value) in enumerate(m.items()):
                                yield (i, key, value)

                posexplode_udtf = cached_udtf(
                    PosExplode,
                    output_schema=StructType(
                        [
                            StructField(
                                "pos",
                                LongType(),
                                is_nullable,
                                _is_column=False,
                            ),
                            StructField(
                                "key",
                                input_type.key_type,
                                is_nullable,
                                _is_column=False,
                            ),
                            StructField(
                                "value",
                                input_type.value_type,
                                True,
                                _is_column=False,
                            ),
                        ]
                    ),
                    input_types=[input_type, StringType()],
                )

                spark_col_names = ["pos", "key", "value"]
                result_type = [
                    LongType(),
                    input_type.key_type,
                    input_type.value_type,
                ]
            else:
                raise TypeError(
                    f"Data type mismatch: {function_name} requires an array or map input, but got {input_type}."
                )
            result_exp = snowpark_fn.call_table_function(
                posexplode_udtf.name, snowpark_args[0], snowpark_fn.lit(function_name)
            )
        case "position":
            substr, base_str = snowpark_args[0], snowpark_args[1]
            start_pos = (
                snowpark_args[2] if len(snowpark_args) > 2 else snowpark_fn.lit(1)
            )

            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(start_pos), snowpark_fn.lit(0)
            ).otherwise(snowpark_fn.position(substr, base_str, start_pos))
            result_type = LongType()

            if len(snowpark_args) == 2:
                spark_function_name = (
                    f"position({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, 1)"
                )

        case "positive":
            arg_type = snowpark_typed_args[0].typ
            spark_function_name = f"(+ {snowpark_arg_names[0]})"
            if isinstance(arg_type, _NumericType):
                result_exp = snowpark_args[0]
            elif isinstance(arg_type, StringType):
                if spark_sql_ansi_enabled:
                    raise NumberFormatException(
                        f'The value \'{snowpark_args[0]}\' of the type {arg_type} cannot be cast to "DOUBLE" because it is malformed. Correct the value as per the syntax, or change its target type. Use `try_cast` to tolerate malformed input and return NULL instead. If necessary set "spark.sql.ansi.enabled" to "false" to bypass this error.'
                    )
                else:
                    result_exp = snowpark_fn.lit(None)
            elif isinstance(arg_type, NullType):
                result_exp = snowpark_fn.lit(None)
            else:
                raise AnalysisException(
                    f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "(+ {snowpark_arg_names[0]}" due to data type mismatch: '
                    f'Parameter 1 requires the ("NUMERIC") type, however "{snowpark_arg_names[0]}" has the type "{snowpark_typed_args[0]}".'
                )
            result_type = (
                snowpark_typed_args[0].types
                if isinstance(arg_type, _NumericType)
                else DoubleType()
            )

        case "pow":
            result_exp = snowpark_fn.pow(snowpark_args[0], snowpark_args[1])
            result_type = DoubleType()
        case "power":
            spark_function_name = (
                f"POWER({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.pow(snowpark_args[0], snowpark_args[1])
            result_type = DoubleType()
        case "product":
            # Log-Sum-Exp trick
            result_exp = snowpark_fn.exp(
                snowpark_fn.sum(
                    snowpark_fn.when(
                        snowpark_args[0] <= 0, snowpark_fn.lit(None)
                    ).otherwise(snowpark_fn.ln(snowpark_args[0]))
                )
            )
            result_type = DoubleType()
        case "quarter":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.quarter(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.quarter(snowpark_fn.to_date(snowpark_args[0]))
            result_type = LongType()
        case "radians":
            spark_function_name = f"RADIANS({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.radians(*snowpark_args)
            result_type = DoubleType()
        case "raise_error":
            result_type = StringType()
            raise_error = _raise_error_udf_helper(result_type)
            result_exp = raise_error(*snowpark_args)
        case "rand" | "random":
            # Snowpark random() generates a 64 bit signed integer, but pyspark is [0.0, 1.0).
            # TODO: Seems like more validation of the arguments is appropriate.
            args = exp.unresolved_function.arguments
            if len(args) > 0:
                if not (
                    isinstance(snowpark_typed_args[0].typ, IntegerType)
                    or isinstance(snowpark_typed_args[0].typ, NullType)
                ):
                    raise AnalysisException(
                        f"""[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "{spark_function_name}" due to data type mismatch: Parameter 1 requires the ("INT" or "BIGINT") type, however {snowpark_arg_names[0]} has the type "{snowpark_typed_args[0].typ}"""
                    )
                result_exp = snowpark_fn.random(unwrap_literal(args[0]))
            else:
                result_exp = snowpark_fn.random()

            # Adjust from a 64 bit integer to the pyspark range of [0.0, 1.0).
            # The result_exp is a signed int64 number, so the range is [-2**63, 2**63-1]. We add 2**63 (aka subtract
            # MIN_INT64) to shift this number into the range [0, 2**64-1], which is the uint64 range: [0, MAX_UNIT64]
            # However, in the end result, we want the range to exclude 1.0, hence, we divide by MAX_UNIT64 + 1.
            # The float conversion below is necessary, because snowpark python uses int64 for integers, but we are
            # shifting into unit64 and hence are out of the range of int64.
            result_exp = (result_exp - float(MIN_INT64)) / (float(MAX_UINT64) + 1)
            # TODO SNOW-2034495: can we resolve this type?
            # result_type = DecimalType(26, 6)
            result_exp = _type_with_typer(result_exp)
        case "randn":
            args = exp.unresolved_function.arguments

            result_exp = snowpark_fn.function("NORMAL")(
                snowpark_fn.lit(0.0),
                snowpark_fn.lit(1.0),
                (
                    snowpark_fn.random(unwrap_literal(args[0]))
                    if args
                    else snowpark_fn.random()
                ),
            )
            result_type = DoubleType()
        case "rank":
            result_exp = snowpark_fn.rank()
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "regexp_count":
            # Spark counts an empty pattern as length(input) + 1
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), None)
                .when(snowpark_args[1] == "", snowpark_fn.length(snowpark_args[0]) + 1)
                .otherwise(snowpark_fn.regexp_count(snowpark_args[0], snowpark_args[1]))
            )
            result_type = LongType()
        case "regexp_extract":
            # Pyspark returns null for a null input, Snowpark coalesces this to an empty string.
            # We check the input to get the same behaviour.
            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_args[0]), None
            ).otherwise(
                snowpark_fn.regexp_extract(
                    snowpark_args[0], snowpark_args[1], snowpark_args[2]
                )
            )
            result_type = StringType()
        case "regexp_extract_all":
            if len(snowpark_args) == 2:
                idx = snowpark_fn.lit(1)
                spark_function_name = spark_function_name[:-1] + ", 1)"
            else:
                idx = snowpark_args[2]
            # Snowflake's regexp_extract_all has more arguments, so we need to fill out default values
            result_exp = snowpark_fn.cast(
                snowpark_fn.call_function(
                    "regexp_extract_all",
                    snowpark_args[0],
                    snowpark_args[1],
                    snowpark_fn.lit(1),
                    snowpark_fn.lit(1),
                    snowpark_fn.lit("c"),
                    idx,
                ),
                ArrayType(StringType()),
            )
            result_type = ArrayType(StringType())
        case "regexp_instr":
            # Spark seems to ignore the group index argument, so we don't use it here.
            # Spark matches certain patterns to an empty string. We can emulate this with rlike.
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), None)
                .when(
                    (snowpark_args[0] == "")
                    & (snowpark_args[0].rlike(snowpark_args[1])),
                    1,
                )
                .otherwise(
                    snowpark_fn.call_function(
                        "regexp_instr",
                        snowpark_args[0],
                        snowpark_args[1],
                    )
                )
            )
            result_type = LongType()
            # if idx was not specified, it defaults to 0 in the column name
            if len(snowpark_args) == 2:
                spark_function_name = spark_function_name[:-1] + ", 0)"
        case "regexp_replace":
            spark_function_name = spark_function_name[:-1] + ", 1)"
            result_exp = snowpark_fn.regexp_replace(*snowpark_args)
            result_type = StringType()
        case "regexp_substr":
            # in some cases Snowflake returns an empty string instead of null
            # but that also counts as no match, for example regexp_substr('', '$')
            result_exp = result_exp = snowpark_fn.call_function(
                "nullif",
                snowpark_fn.call_function("regexp_substr", *snowpark_args),
                "",
            )
            result_type = StringType()
        case "regr_avgx":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            input_type = snowpark_typed_args[1].typ
            if isinstance(input_type, DecimalType):
                result_type = _bounded_decimal(
                    input_type.precision + 4, input_type.scale + 4
                )
            else:
                result_type = DoubleType()

            result_exp = _resolve_aggregate_exp(
                snowpark_fn.regr_avgx(*updated_args),
                result_type,
            )
        case "regr_avgy":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            input_type = snowpark_typed_args[0].typ
            if isinstance(input_type, DecimalType):
                result_type = _bounded_decimal(
                    input_type.precision + 4, input_type.scale + 4
                )
            else:
                result_type = DoubleType()

            result_exp = _resolve_aggregate_exp(
                snowpark_fn.regr_avgy(*updated_args),
                result_type,
            )
        case "regr_count":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_count(*updated_args)
            result_type = LongType()
        case "regr_intercept":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_intercept(*updated_args)
            result_type = DoubleType()
        case "regr_r2":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_r2(*updated_args)
            result_type = DoubleType()
        case "regr_slope":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_slope(*updated_args)
            result_type = DoubleType()
        case "regr_sxx":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_sxx(*updated_args)
            result_type = DoubleType()
        case "regr_sxy":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_sxy(*updated_args)
            result_type = DoubleType()
        case "regr_syy":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_syy(*updated_args)
            result_type = DoubleType()
        case "repeat":
            result_exp = snowpark_fn.repeat(*snowpark_args)
            result_type = StringType()
        case "replace":
            result_exp = snowpark_fn.replace(*snowpark_args)
            result_type = StringType()
            if len(snowpark_args) == 2:
                spark_function_name = (
                    f"replace({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, )"
                )
        case "reverse":
            match snowpark_typed_args[0].typ:
                case ArrayType():
                    result_exp = snowpark_fn.function("array_reverse")(snowpark_args[0])
                    result_type = snowpark_typed_args[0].typ
                case _:
                    result_exp = snowpark_fn.reverse(snowpark_args[0])
                    result_type = StringType()
        case "right":
            result_exp = snowpark_fn.right(*snowpark_args)
            result_type = StringType()
        case "rint":
            result_exp = snowpark_fn.cast(
                snowpark_fn.round(snowpark_args[0]), DoubleType()
            )
            result_type = DoubleType()
        case "rlike" | "regexp" | "regexp_like":
            # Snowflake's regexp/rlike implicitly anchors the pattern to the beginning and end of the string.
            # Spark matches any substring, so we use regexp_instr to emulate this, except empty inputs,
            # which need to be checked with regexp/rlike.
            # We also handle:
            # - the case where the pattern is an empty string, which Spark treats as .*
            # - the case where the pattern uses embedded flag expressions (such as '(?i)', which Spark treats as case-insensitive)
            begin_flag_pyspark = "(?"
            flag_pyspark_regex_pattern = r"\(\?([a-z]+)\)"
            regex_pattern = (
                snowpark_fn.when(snowpark_args[1] == "", ".*")
                .when(
                    snowpark_args[1].startswith(begin_flag_pyspark),
                    snowpark_fn.regexp_replace(
                        snowpark_args[1], flag_pyspark_regex_pattern
                    ),
                )
                .otherwise(snowpark_args[1])
            )
            regex_params = snowpark_fn.when(
                snowpark_args[1].startswith(begin_flag_pyspark),
                snowpark_fn.array_to_string(
                    snowpark_fn.call_function(
                        "regexp_substr_all",
                        snowpark_args[1],
                        flag_pyspark_regex_pattern,
                        1,
                        1,
                        "e",
                        1,
                    ),
                    snowpark_fn.lit(""),
                ),
            ).otherwise("c")
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), None)
                .when(
                    snowpark_args[0] == "",
                    snowpark_fn.call_function(
                        "rlike", snowpark_args[0], regex_pattern, regex_params
                    ),
                )
                .otherwise(
                    snowpark_fn.call_function(
                        "regexp_instr",
                        snowpark_args[0],
                        regex_pattern,
                        1,
                        1,
                        0,
                        regex_params,
                    )
                    > 0
                )
            )
            result_type = BooleanType()
            spark_function_name = (
                f"{function_name.upper()}({', '.join(snowpark_arg_names)})"
            )
        case "round":
            if len(snowpark_args) == 1:
                spark_function_name = f"{function_name}({snowpark_arg_names[0]}, 0)"
                result_exp = snowpark_fn.round(snowpark_args[0], snowpark_fn.lit(0))
            else:
                result_exp = snowpark_fn.round(
                    snowpark_args[0],
                    snowpark_args[1],
                )
            # TODO SNOW-2034495: can we resolve this without a describe? it can be an integral or decimal depending on the precision
            result_exp = _type_with_typer(result_exp)
        case "row_number":
            result_exp = snowpark_fn.row_number()
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "rpad":
            # Assume the last argument is missing and set the pad value to a string.
            pad_value = snowpark_fn.lit(" ")
            if len(snowpark_args) == 2:
                spark_function_name = (
                    f"rpad({snowpark_arg_names[0]}, {snowpark_arg_names[1]},  )"
                )
                arg_type = snowpark_typed_args[0]
                # If the first argument is of BinaryType, the pad value is instead b"\x00".
                if isinstance(arg_type.typ, BinaryType):
                    pad_value = snowpark_fn.lit(b"\x00")
            else:
                # If the last argument isn't missing, set the pad value to the last argument.
                pad_value = snowpark_args[2]
            result_exp = snowpark_fn.rpad(snowpark_args[0], snowpark_args[1], pad_value)
            result_type = StringType()
        case "rtrim":
            if len(snowpark_args) == 2:
                # Only possible using SQL
                spark_function_name = f"TRIM(TRAILING {snowpark_arg_names[1]} FROM {snowpark_arg_names[0]})"
            result_exp = snowpark_fn.rtrim(*snowpark_args)
            result_type = StringType()
        case "schema_of_csv":
            snowpark_args = [
                typed_arg.column(to_semi_structure=True)
                for typed_arg in snowpark_typed_args
            ]

            @cached_udf(
                return_type=StringType(),
                input_types=[StringType(), StructType()],
            )
            def _schema_of_csv(data: str, options: Optional[dict]):
                from contextlib import suppress

                sep = ","
                if options is not None and isinstance(options, dict):
                    sep = options.get("sep") or sep

                def _get_type(v: str):
                    if v.lower() in ["true", "false"]:
                        return "BOOLEAN"

                    with suppress(Exception):  # int
                        y = int(v)
                        if str(y) == v:
                            if y < -2147483648 or y > 2147483647:
                                return "BIGINT"
                            return "INT"

                    with suppress(Exception):  # double
                        y = float(v)
                        return "DOUBLE"

                    for _format in ["%H:%M", "%H:%M:%S"]:
                        with suppress(Exception):
                            time.strptime(v, _format)
                            return "TIMESTAMP"

                    return "STRING"

                fields = []
                for i, v in enumerate(data.split(sep)):
                    col_name = f"_c{i}"
                    fields.append(f"{col_name}: {_get_type(v)}")

                return f"STRUCT<{', '.join(fields)}>"

            spark_function_name = f"schema_of_csv({snowpark_arg_names[0]})"

            match snowpark_args:
                case [csv_data]:
                    result_exp = _schema_of_csv(csv_data, snowpark_fn.lit(None))
                case [csv_data, options]:
                    result_exp = _schema_of_csv(csv_data, options)
                case _:
                    raise ValueError("Unrecognized from_csv parameters")
            result_type = StringType()
        case "schema_of_json":

            @cached_udf
            def _infer_schema(json_str: str) -> str:
                import json

                def _struct_key(k: str) -> str:
                    escaped = k.replace("`", "``")
                    if escaped.strip() != k:
                        return f"`{escaped}`"
                    return escaped

                def _infer_pyspark_type(value) -> str:
                    if isinstance(value, str):
                        return "STRING"
                    elif isinstance(value, bool):
                        return "BOOLEAN"
                    elif isinstance(value, int):
                        return "BIGINT"
                    elif isinstance(value, float):
                        return "DOUBLE"
                    elif isinstance(value, list):
                        if not value:
                            return "ARRAY<STRING>"
                        element_types = [_infer_pyspark_type(elem) for elem in value]
                        common_type = _find_common_type(element_types)
                        return f"ARRAY<{common_type}>"
                    elif isinstance(value, dict):
                        if not value:
                            return "STRUCT<>"
                        return (
                            "STRUCT<"
                            + ", ".join(
                                f"{_struct_key(k)}: {value_typ}"
                                for k, v in value.items()
                                if k
                                and (value_typ := _infer_pyspark_type(v)) != "STRUCT<>"
                            )
                            + ">"
                        )
                    elif value is None:
                        return "STRING"
                    else:
                        return "STRING"

                def _find_common_type(types: list[str]) -> str:
                    if not types:
                        return "STRING"

                    if all(t == types[0] for t in types):
                        return types[0]

                    type_hierarchy = {
                        "BOOLEAN": 1,
                        "BIGINT": 2,
                        "DOUBLE": 3,
                        "STRING": 4,
                    }

                    if all(t.startswith("ARRAY<") and t.endswith(">") for t in types):
                        element_types = [
                            t[6:-1] for t in types
                        ]  # Remove "ARRAY<" and ">"
                        common_element_type = _find_common_type(element_types)
                        return f"ARRAY<{common_element_type}>"

                    if all(t.startswith("STRUCT<") and t.endswith(">") for t in types):
                        field_types = defaultdict(list)

                        for struct_type in types:
                            # Extract the content between STRUCT< and >
                            fields_str = struct_type[7:-1]

                            if not fields_str:  # Empty struct
                                continue

                            for field in fields_str.split(", "):
                                name, type_str = field.split(": ", 1)
                                field_types[name].append(type_str)

                        common_fields = []
                        for name, field_type_list in field_types.items():
                            common_field_type = _find_common_type(field_type_list)
                            common_fields.append(f"{name}: {common_field_type}")

                        if not common_fields:
                            return "STRUCT<>"

                        return "STRUCT<" + ", ".join(common_fields) + ">"

                    # If we have mixed types (some array, some struct, some primitive)
                    # or multiple primitive types, apply type promotion

                    # First, handle only basic types
                    basic_types = [t for t in types if t in type_hierarchy]
                    if basic_types:
                        max_type = max(
                            basic_types, key=lambda t: type_hierarchy.get(t, 0)
                        )
                        # If we only have basic types, return the promoted type
                        if len(basic_types) == len(types):
                            return max_type

                    # If we have a mix of basic and complex types, or multiple complex types
                    # Default to STRING as it can represent any type
                    return "STRING"

                try:
                    if not json_str.strip():
                        return "STRING"
                    obj = json.loads(json_str)
                    return _infer_pyspark_type(obj)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid JSON: {e}")

            result_exp = _infer_schema(snowpark_args[0])
            result_type = StringType()
        case "sec":
            spark_function_name = f"SEC({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_args[0]), snowpark_fn.lit(NAN)
            ).otherwise(
                snowpark_fn.coalesce(
                    _divnull(snowpark_fn.lit(1.0), snowpark_fn.cos(snowpark_args[0])),
                    snowpark_fn.lit(INFINITY),
                )
            )
            result_type = DoubleType()
        case "second":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.second(
                    snowpark_fn.builtin("try_to_timestamp")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.second(
                    snowpark_fn.to_timestamp(snowpark_args[0])
                )
            result_type = LongType()
        case "sentences":
            sentences_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.SentencesUdf.sentences",
                ["STRING", "STRING", "STRING"],
                "VARIANT",
                packages=["com.snowflake:snowpark:1.15.0"],
            )

            result_exp = snowpark_fn.cast(
                sentences_udf(*snowpark_args), ArrayType(ArrayType(StringType()))
            )
            result_type = ArrayType(ArrayType(StringType()))
        case "sequence":
            result_exp = snowpark_fn.cast(
                snowpark_fn.sequence(*snowpark_args),
                ArrayType(LongType(), contains_null=False),
            )
            result_type = ArrayType(LongType(), contains_null=False)
        case "sha":
            sha_function = snowpark_fn.function("SHA1_HEX")
            result_exp = sha_function(snowpark_args[0])
            result_type = StringType(40)
        case "sha1":
            result_exp = snowpark_fn.sha1(snowpark_args[0])
            result_type = StringType(40)
        case "sha2":
            bit_values = [0, 224, 256, 384, 512]
            num_bits = unwrap_literal(exp.unresolved_function.arguments[1])
            if num_bits is None:
                if spark_sql_ansi_enabled:
                    raise NumberFormatException(
                        f"""[CAST_INVALID_INPUT] The value {snowpark_arg_names[0]} of the type "{snowpark_typed_args[0].typ}" cannot be cast to "INT" because it is malformed. Correct the value as per the syntax, or change its target type."""
                    )
                result_exp = snowpark_fn.lit(None)
                result_type = StringType()
            elif num_bits not in bit_values:
                raise IllegalArgumentException(
                    f"""requirement failed: numBits {num_bits} is not in the permitted values (0, 224, 256, 384, 512)"""
                )
            else:
                # 0 equivalent to 256 in PySpark, but is not allowed in Snowpark
                num_bits = 256 if num_bits == 0 else num_bits

                result_exp = snowpark_fn.sha2(snowpark_args[0], num_bits)
                result_type = StringType(128)
        case "shiftleft":
            result_exp = snowpark_fn.bitshiftleft(snowpark_args[0], snowpark_args[1])
            result_type = LongType()
        case "shiftright":
            result_exp = snowpark_fn.bitshiftright(snowpark_args[0], snowpark_args[1])
            result_type = LongType()
        case "shiftrightunsigned":
            num_bits = unwrap_literal(exp.unresolved_function.arguments[1])
            result_exp = snowpark_fn.bitshiftright(snowpark_args[0], snowpark_args[1])
            result_exp = result_exp.bitwiseAnd(
                snowpark_fn.lit(0xFFFFFFFFFFFFFFFF >> num_bits)
            )
            result_type = LongType()
        case "shuffle":
            arg_type = snowpark_typed_args[0].typ

            @cached_udf(input_types=[ArrayType()], return_type=ArrayType())
            def _shuffle_udf(array: list) -> list:
                import random

                random.shuffle(array)

                return array

            result_exp = snowpark_fn.cast(
                _shuffle_udf(snowpark_fn.cast(snowpark_args[0], ArrayType())),
                arg_type,
            )
            result_type = arg_type
        case "signum" | "sign":
            fn_name = function_name.upper()
            # Somehow, SIGNUM is upper case, but sign is lower case in PySpark.
            if fn_name == "SIGN":
                fn_name = "sign"

            spark_function_name = f"{fn_name}({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] == NAN, snowpark_fn.lit(NAN)
            ).otherwise(
                snowpark_fn.cast(snowpark_fn.sign(snowpark_args[0]), DoubleType())
            )
            result_type = DoubleType()
        case "sin":
            spark_function_name = f"SIN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.sin(snowpark_args[0])
            result_type = DoubleType()
        case "sinh":
            spark_function_name = f"SINH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.sinh(snowpark_args[0])
            result_type = DoubleType()
        case "size":
            v = snowpark_fn.cast(snowpark_args[0], VariantType())
            result_exp = (
                snowpark_fn.when(
                    snowpark_fn.is_array(v),
                    snowpark_fn.array_size(v),
                )
                .when(
                    snowpark_fn.is_object(v),
                    snowpark_fn.array_size(snowpark_fn.object_keys(v)),
                )
                .when(
                    snowpark_fn.is_null(v),
                    snowpark_fn.lit(-1),
                )
                .otherwise(snowpark_fn.lit(None))
            ).alias(f"SIZE({snowpark_args[0]})")
            result_type = LongType()
        case "skewness":
            result_exp = snowpark_fn.skew(snowpark_args[0])
            result_type = DoubleType()
        case "slice":
            spark_index = snowpark_args[1]
            arr_size = snowpark_fn.array_size(snowpark_args[0])
            slice_len = snowpark_args[2]
            result_exp = snowpark_fn.when(
                spark_index < 0,
                snowpark_fn.array_slice(
                    snowpark_args[0],
                    arr_size + spark_index,
                    arr_size + spark_index + slice_len,
                ),
            ).otherwise(
                snowpark_fn.array_slice(
                    snowpark_args[0], spark_index - 1, spark_index + slice_len - 1
                )
            )
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "some":
            result_exp = snowpark_fn.call_function("boolor_agg", snowpark_args[0])
            result_type = BooleanType()
        case "sort_array":
            sort_asc = unwrap_literal(exp.unresolved_function.arguments[1])
            result_exp = snowpark_fn.sort_array(
                snowpark_args[0],
                sort_ascending=sort_asc,
                nulls_first=sort_asc,
            )
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "soundex":
            value = snowpark_args[0]
            regexp_like_fn = snowpark_fn.function("REGEXP_LIKE")

            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(value), snowpark_fn.lit(None))
                .when(
                    snowpark_fn.trim(value) == "", snowpark_fn.lit("")
                )  # When string contains only whitespaces
                .when(
                    regexp_like_fn(value, "^[^a-zA-Z].*"), value
                )  # When string doesn't start with a letter
                .otherwise(snowpark_fn.soundex(snowpark_fn.upper(value)))
            )
            result_type = StringType()
        case "space":
            result_exp = snowpark_fn.builtin("space")(*snowpark_args)
            result_type = StringType()
        case "spark_partition_id":
            result_exp = snowpark_fn.lit(0)
            result_type = LongType()
        case "split":

            @cached_udf
            def _split(
                input: Optional[str], pattern: Optional[str], limit: Optional[int]
            ) -> Optional[list[str]]:
                if input is None or pattern is None:
                    return None

                if limit == 1:
                    return [input]

                import re

                # A default of -1 is passed in PySpark, but RE needs it to be 0 to provide all splits.
                # In PySpark, the limit also indicates the max size of the resulting array, but in RE
                # the remainder is returned as another element.
                maxsplit = limit - 1 if limit > 0 else 0

                split_result = re.split(pattern, input, maxsplit)
                if len(pattern) == 0:
                    # RE.split provides a first and last empty element that is not there in PySpark.
                    split_result = split_result[1 : len(split_result) - 1]

                return split_result

            match snowpark_args:
                case [str_, pattern]:
                    spark_function_name = (
                        f"split({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, -1)"
                    )
                    result_exp = _split(str_, pattern, snowpark_fn.lit(0))
                case [str_, pattern, limit]:  # noqa: F841
                    result_exp = _split(str_, pattern, limit)
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_type = ArrayType(StringType())
        case "split_part":
            result_exp = snowpark_fn.call_function("split_part", *snowpark_args)
            result_type = StringType()
        case "sqrt":
            spark_function_name = f"SQRT({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.sqrt(snowpark_args[0])
            result_type = DoubleType()
        case "startswith":
            result_exp = snowpark_args[0].startswith(snowpark_args[1])
            result_type = BooleanType()
        case "stddev":
            result_exp = snowpark_fn.stddev(snowpark_args[0])
            result_type = DoubleType()
        case "stddev_pop":
            result_exp = snowpark_fn.stddev_pop(snowpark_args[0])
            result_type = DoubleType()
        case "stddev_samp" | "std":
            result_exp = snowpark_fn.stddev_samp(snowpark_args[0])
            result_type = DoubleType()
        case "str_to_map":
            value, pair_delim_, kv_delim_ = snowpark_args

            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            @cached_udf
            def _str_to_map(
                allow_dups: bool,
                s: Optional[str],
                pair_delim: Optional[str],
                kv_delim: Optional[str],
            ) -> Optional[dict]:
                if any(x is None for x in (s, pair_delim, kv_delim)):
                    return None

                if s == "":
                    return {"": None}

                import re

                pairs = list(filter(lambda x: x != "", re.split(pair_delim, s)))

                kv_pairs = [
                    list(filter(lambda x: x != "", re.split(kv_delim, pair)))
                    for pair in pairs
                ]

                result_map = {}

                for key, val in kv_pairs:
                    if key in result_map and not allow_dups:
                        raise ValueError(
                            DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                        )

                    result_map[key] = val

                return result_map

            result_exp = snowpark_fn.cast(
                _str_to_map(
                    snowpark_fn.lit(allow_duplicate_keys), value, pair_delim_, kv_delim_
                ),
                MapType(StringType(), StringType()),
            )
            result_type = MapType(StringType(), StringType())
        case "struct":

            def _f_name(index: int, resolved_name: str) -> str:
                match exp.unresolved_function.arguments[index].WhichOneof("expr_type"):
                    case "alias":
                        # aliases are used for field names in struct schema
                        return exp.unresolved_function.arguments[index].alias.name[0]
                    case "unresolved_attribute":
                        return resolved_name
                    case "unresolved_named_lambda_variable":
                        return exp.unresolved_function.arguments[
                            index
                        ].unresolved_named_lambda_variable.name_parts[0]

                return f"col{index + 1}"

            fields_cols = list(zip(snowpark_arg_names, snowpark_typed_args))
            field_types = [
                StructField(_f_name(idx, name), col.typ, _is_column=False)
                for idx, (name, col) in enumerate(fields_cols)
            ]
            result_exp = snowpark_fn.object_construct_keep_null(
                *[
                    name_with_col
                    for idx, (name, typed_col) in enumerate(fields_cols)
                    for name_with_col in (
                        snowpark_fn.lit(_f_name(idx, name)),
                        typed_col.column(to_semi_structure=True),
                    )
                ]
            )
            result_type = StructType(field_types)
            result_exp = snowpark_fn.cast(result_exp, result_type)
            spark_field_names = ", ".join(
                resolved_name for (resolved_name, _) in fields_cols
            )
            spark_function_name = f"struct({spark_field_names})"
        case "substring" | "substr":
            result_exp = snowpark_fn.substring(*snowpark_args)
            # substring returns a string of a certain length, but it shouldn't matter for us
            result_type = StringType()
        case "substring_index":
            value, delim, count = snowpark_args

            value = snowpark_fn.split(value, delim)
            array_size = snowpark_fn.array_size(value)

            value = (
                snowpark_fn.when(count == 0, snowpark_fn.array_construct())
                .when(
                    count > 0, snowpark_fn.array_slice(value, snowpark_fn.lit(0), count)
                )
                .otherwise(snowpark_fn.array_slice(value, count, array_size))
            )

            result_exp = snowpark_fn.array_to_string(value, delim)
            result_type = StringType()
        case "sum":
            sum_fn = snowpark_fn.sum
            input_type = snowpark_typed_args[0].typ
            if exp.unresolved_function.is_distinct:
                spark_function_name = f"sum(DISTINCT {snowpark_arg_names[0]})"
                sum_fn = snowpark_fn.sum_distinct

            arg = snowpark_args[0]
            if isinstance(input_type, StringType):
                arg = snowpark_fn.cast(arg, DoubleType())

            if isinstance(input_type, DecimalType):
                result_type = _bounded_decimal(
                    input_type.precision + 10, input_type.scale
                )
            elif isinstance(input_type, _IntegralType):
                result_type = LongType()
            else:
                result_type = DoubleType()

            result_exp = _resolve_aggregate_exp(
                sum_fn(arg),
                result_type,
            )
        case "tan":
            spark_function_name = f"TAN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.tan(snowpark_args[0])
            result_type = DoubleType()
        case "tanh":
            spark_function_name = f"TANH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.tanh(snowpark_args[0])
            result_type = DoubleType()
        case "timestamp_add":
            # Added to DataFrame functions in 4.0.0 - but can be called from SQL in 3.5.3.
            spark_function_name = f"timestampadd({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, {snowpark_arg_names[2]})"
            result_exp = snowpark_fn.cast(
                snowpark_fn.dateadd(
                    unwrap_literal(exp.unresolved_function.arguments[0]),
                    snowpark_args[1],
                    snowpark_args[2],
                ),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case "timestamp_diff":
            # Added to DataFrame functions in 4.0.0 - but can be called from SQL in 3.5.3.
            spark_function_name = f"timestampdiff({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, {snowpark_arg_names[2]})"
            result_exp = snowpark_fn.datediff(
                unwrap_literal(exp.unresolved_function.arguments[0]),
                snowpark_args[1],
                snowpark_args[2],
            )
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "timestamp_micros":
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_timestamp(snowpark_args[0], 6),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case "timestamp_millis":
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_timestamp(snowpark_args[0] * 1_000, 6),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case "timestamp_seconds":
            # Spark allows seconds to be fractional. Snowflake does not allow that
            # even though the documentation explicitly says that it does.
            # As a workaround, use integer milliseconds instead of fractional seconds.
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_timestamp(
                    snowpark_fn.cast(snowpark_args[0] * 1_000_000, LongType()), 6
                ),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case "to_char" | "to_varchar":
            # The structure of the Spark format string must match: [MI|S] [$] [0|9|G|,]* [.|D] [0|9]* [$] [PR|MI|S]
            # Note the grammar above was retrieved from an error message from PySpark, but it is not entirely accurate.
            # - "MI", and "S" may only be used once at the beginning or end of the format string.
            # - "$" may only be used once before all digits in the number format (but after "MI" or "S").
            # - There must be a "0" or "9" to both the left and right of a comma (,) or "G".
            # - The format string must not be empty, and ther must be at least one "0", or "9" in the format string.
            # PySpark itself checks the format string for validity before it gets to SAS, so we can make the assumption that all
            # of the above are true.

            # TRANSLATE SPARK FORMAT STRING TO EQUIVALENT SNOWFLAKE FORMAT STRING
            spark_fmt = snowpark_args[1]

            # Snowflake does not support the "PR" format element, we must remove it and add angle brackets if necessary.
            # To do so we must keep track of whether "PR" was used and remove it if it was.
            PR_used = spark_fmt.endswith("PR")
            snowpark_fmt = snowpark_fn.replace(spark_fmt, "PR")

            # Spark does not include negative signs when no explicit sign format literal ("S" or "MI") is present.
            # Snowflake does include negative signs normally, so we need to remove them if not explicitly requested.
            # We also must keep track of whether "MI" or "S" were used and where they were placed.
            MI_at_start = spark_fmt.startswith("MI")
            S_at_start = spark_fmt.startswith("S")
            MI_at_end = spark_fmt.endswith("MI")
            S_at_end = spark_fmt.endswith("S")
            snowpark_fmt = snowpark_fn.replace(snowpark_fmt, "MI")
            snowpark_fmt = snowpark_fn.replace(snowpark_fmt, "S")

            # Snowflake appends the currency symbol after the left-padding spaces, Spark before.
            # We must remove the currency symbol if it was present and add it back after the format string.
            currency_used = snowpark_fmt.startswith("$")
            snowpark_fmt = snowpark_fn.replace(snowpark_fmt, "$")

            # Replace the decimal point with "D" to make regular expressions and replacements easier.
            snowpark_fmt = snowpark_fn.replace(snowpark_fmt, ".", snowpark_fn.lit("D"))

            # Spark always prints trailing 0's after a decimal point, even if the literal used is "9".
            # Snowflake does not print trailing 0's when "9" is used, so must replace them with "0"s.
            decimal_used = snowpark_fmt.contains(snowpark_fn.lit("D"))
            # Handle this by splitting the format string at the decimal point.
            split_by_decimal = snowpark_fn.split(snowpark_fmt, snowpark_fn.lit("D"))
            before_decimal = snowpark_fn.element_at(split_by_decimal, 0)
            after_decimal = snowpark_fn.element_at(split_by_decimal, 1)
            # Some edge cases rely on knowing if there are no digit placeholders before or after the decimal point.
            before_decimal_empty = before_decimal == ""
            after_demical_empty = after_decimal == ""
            # When both 0's and 9's are used as digit placeholders in the integer component of the number format,
            # Spark has different rules for printing depending on whether the "G" or "," is present. We can make
            # our handling more consistent in SAS by replacing all digit placeholders with the first digit we find.
            before_decimal = snowpark_fn.regexp_replace(
                before_decimal,
                "[09]",
                snowpark_fn.regexp_extract(before_decimal, "^(0|9)", 1),
            )
            snowpark_fmt = snowpark_fn.when(
                decimal_used,
                snowpark_fn.concat(
                    before_decimal,
                    snowpark_fn.when(
                        after_demical_empty, snowpark_fn.lit("")
                    ).otherwise(snowpark_fn.lit("D")),
                    snowpark_fn.replace(after_decimal, "9", "0"),
                ),
            ).otherwise(
                # When a number is 0, Spark does not print the digit when the "9" format element is used
                # and is not followed by a decimal point. Snowflake does print the digit.
                # We use the "B" format element to get this behavior with a Snowflake format string.
                snowpark_fn.concat(snowpark_fn.lit("B"), before_decimal)
            )
            # Snowflake by default inserts a space in front of positive numbers when explicit sign format
            # elements are not used. Spark does not, so we have to insert an explicit sign format element,
            # and remove the added sign after.
            snowpark_fmt = snowpark_fn.concat(snowpark_fmt, snowpark_fn.lit("S"))

            # FORMAT THE NUMBER AND POST-PROCESS TO MATCH SPARK
            formatted = snowpark_fn.to_char(
                snowpark_fn.abs(snowpark_args[0]), snowpark_fmt
            )
            # Snowflake will print negative signs by default even if "S" or "MI" are not present.
            # Spark does not, so we apply the absolute value function to the numeric column first,
            # then remove all printed "+" signs due to the "S" format element we added.
            formatted = snowpark_fn.replace(formatted, "+")
            # Add currency symbol back if it was present.
            formatted = snowpark_fn.when(
                currency_used,
                snowpark_fn.concat(snowpark_fn.lit("$"), formatted),
            ).otherwise(formatted)
            # Handle printing signs before or after the number as necessary.
            positive_sign = snowpark_fn.when(
                S_at_start | S_at_end, snowpark_fn.lit("+")
            ).otherwise(snowpark_fn.lit(" "))
            formatted = snowpark_fn.when(
                snowpark_args[0] < 0,
                snowpark_fn.when(
                    MI_at_start | S_at_start,
                    snowpark_fn.concat(snowpark_fn.lit("-"), formatted),
                )
                .when(
                    MI_at_end | S_at_end,
                    snowpark_fn.concat(formatted, snowpark_fn.lit("-")),
                )
                .otherwise(formatted),
            ).otherwise(
                snowpark_fn.when(
                    MI_at_start | S_at_start,
                    snowpark_fn.concat(positive_sign, formatted),
                )
                .when(
                    MI_at_end | S_at_end, snowpark_fn.concat(formatted, positive_sign)
                )
                .otherwise(formatted)
            )
            # Edge case where if the following conditions are satisfied, Spark will print a 0 in
            # front of the decimal point in place of the negative sign.
            formatted = snowpark_fn.when(
                MI_at_start & ~currency_used & before_decimal_empty,
                snowpark_fn.regexp_replace(formatted, r" \.", "0."),
            ).otherwise(formatted)
            # Add angle brackets if the "PR" format element was present as is done in Spark.
            # Additionally, Spark will try to left align all formatted numbers by adding 2
            # spaces after the number if "PR" is used. We must do the same manually.
            formatted = snowpark_fn.when(
                PR_used,
                snowpark_fn.when(
                    snowpark_args[0] < 0,
                    snowpark_fn.concat(
                        snowpark_fn.lit("<"),
                        formatted,
                        snowpark_fn.lit(">"),
                    ),
                ).otherwise(snowpark_fn.concat(formatted, snowpark_fn.lit("  "))),
            ).otherwise(formatted)
            # Handle edge case where if decimal is used but no digit placeholders are used afterwards,
            # Spark adds an extra space after the above symbols. We must do the same.
            result_exp = snowpark_fn.when(
                decimal_used & after_demical_empty,
                snowpark_fn.concat(formatted, snowpark_fn.lit(" ")),
            ).otherwise(formatted)
            result_type = StringType()
        case "to_csv":
            snowpark_args = [
                typed_arg.column(to_semi_structure=True)
                for typed_arg in snowpark_typed_args
            ]

            @cached_udf
            def _to_csv(col: dict, options: Optional[dict]) -> str:
                sep = ","
                if options is not None:
                    if not isinstance(options, dict):
                        raise TypeError(
                            "[INVALID_OPTIONS.NON_MAP_FUNCTION] Invalid options: Must use the `map()` function for options."
                        )

                    sep = options.get("sep") or sep

                    python_to_snowflake_type = {
                        "str": "STRING",
                        "bool": "BOOLEAN",
                        "dict": "OBJECT",
                        "list": "ARRAY",
                    }

                    for k, v in options.items():
                        if not isinstance(k, str) or not isinstance(v, str):
                            k_type = python_to_snowflake_type.get(
                                type(k).__name__, type(k).__name__.upper()
                            )
                            v_type = python_to_snowflake_type.get(
                                type(v).__name__, type(v).__name__.upper()
                            )
                            raise TypeError(
                                f'[INVALID_OPTIONS.NON_STRING_TYPE] Invalid options: A type of keys and values in `map()` must be string, but got "MAP<{k_type}, {v_type}>".'
                            )

                return sep.join([str(val) for key, val in col.items()])

            spark_function_name = f"to_csv({snowpark_arg_names[0]})"

            if len(snowpark_arg_names) > 1 and snowpark_arg_names[1].startswith(
                "named_struct"
            ):
                raise TypeError(
                    "[INVALID_OPTIONS.NON_MAP_FUNCTION] Invalid options: Must use the `map()` function for options."
                )

            match snowpark_args:
                case [csv_data]:
                    result_exp = _to_csv(csv_data, snowpark_fn.lit(None))
                case [csv_data, options]:
                    result_exp = _to_csv(csv_data, options)
                case _:
                    raise ValueError("Unrecognized from_csv parameters")
            result_type = StringType()
        case "to_date":
            if not spark_sql_ansi_enabled:
                function_name = "try_to_date"
            match snowpark_typed_args[0].typ:
                case DateType():
                    result_exp = snowpark_args[0]
                case TimestampType():
                    result_exp = snowpark_fn.to_date(snowpark_args[0])
                case StringType():
                    result_exp = (
                        snowpark_fn.builtin(function_name)(
                            snowpark_args[0],
                            snowpark_fn.lit(
                                map_spark_timestamp_format_expression(
                                    exp.unresolved_function.arguments[1]
                                )
                            ),
                        )
                        if len(snowpark_args) > 1
                        else snowpark_fn.builtin(function_name)(*snowpark_args)
                    )
                case _:
                    raise AnalysisException(
                        f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "to_date({snowpark_arg_names[0]}" due to data type mismatch: Parameter 1 requires the ("STRING" or "DATE" or "TIMESTAMP" or "TIMESTAMP_NTZ") type, however "{snowpark_arg_names[0]}" has the type "{snowpark_typed_args[0]}".'
                    )

            result_type = DateType()
        case "to_json":
            result_exp = snowpark_fn.to_json(snowpark_fn.to_variant(snowpark_args[0]))
            result_type = StringType()
        case "to_number":
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e, _], [val, fmt]):
                    sf_val = e.col
                    match fmt.WhichOneof("expr_type"):
                        case "literal":
                            lit_fmt, _ = get_literal_field_and_name(fmt.literal)
                            if lit_fmt.endswith("PR"):
                                # Remove PR
                                lit_fmt = lit_fmt.replace("PR", "")
                                fmt = lit_fmt
                                # Replace angle brackets with minus sign
                                match val.WhichOneof("expr_type"):
                                    case "literal":
                                        lit_value, _ = get_literal_field_and_name(
                                            val.literal
                                        )
                                        if lit_value.startswith(
                                            "<"
                                        ) and lit_value.endswith(">"):
                                            lit_value = lit_value.replace("<", "-")
                                            lit_value = lit_value.replace(">", "")
                                            sf_val = snowpark_fn.lit(lit_value)

                    sf_fmt = snowpark_fn.lit(map_spark_number_format_expression(fmt))
                    result_exp = snowpark_fn.function("to_number")(
                        sf_val,
                        sf_fmt,
                    )
                case _:
                    result_exp = snowpark_fn.function("to_number")(
                        snowpark_args[0], snowpark_args[1]
                    )
            # TODO SNOW-2034420: determine type
            result_exp = _type_with_typer(result_exp)
        case "to_timestamp":
            if not spark_sql_ansi_enabled:
                function_name = "try_to_timestamp"
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e], _):
                    result_exp = snowpark_fn.when(
                        snowpark_fn.function(function_name)(
                            snowpark_fn.cast(e.col, StringType())
                        ).isNull(),
                        snowpark_fn.lit(None),
                    ).otherwise(snowpark_fn.to_timestamp(e.col))
                case ([e, _], _) if type(e.typ) in (DateType, TimestampType):
                    result_exp = snowpark_fn.when(
                        snowpark_fn.function(function_name)(
                            snowpark_fn.cast(e.col, StringType())
                        ).isNull(),
                        snowpark_fn.lit(None),
                    ).otherwise(snowpark_fn.to_timestamp(e.col))
                case ([e, _], [_, fmt]):
                    result_exp = snowpark_fn.when(
                        snowpark_fn.function(function_name)(
                            snowpark_fn.cast(e.col, StringType()),
                            snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                        ).isNull(),
                        snowpark_fn.lit(None),
                    ).otherwise(
                        snowpark_fn.to_timestamp(
                            e.col,
                            snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                        )
                    )
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = snowpark_fn.cast(
                result_exp, TimestampType(snowpark.types.TimestampTimeZone.NTZ)
            )
            result_type = TimestampType()

        case "to_timestamp_ltz":
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e], _):
                    result_exp = snowpark_fn.builtin("to_timestamp_ltz")(e.col)
                case ([e, _], _) if type(e.typ) in (DateType, TimestampType):
                    result_exp = snowpark_fn.builtin("to_timestamp_ltz")(e.col)
                case ([e, _], [_, fmt]):
                    result_exp = snowpark_fn.builtin("to_timestamp_ltz")(
                        e.col,
                        snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                    )
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = snowpark_fn.cast(
                result_exp, TimestampType(snowpark.types.TimestampTimeZone.LTZ)
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.LTZ)

        case "to_timestamp_ntz":
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e], _):
                    result_exp = snowpark_fn.builtin("to_timestamp_ntz")(e.col)
                case ([e, _], _) if type(e.typ) in (DateType, TimestampType):
                    result_exp = snowpark_fn.builtin("to_timestamp_ntz")(e.col)
                case ([e, _], [_, fmt]):
                    result_exp = snowpark_fn.builtin("to_timestamp_ntz")(
                        e.col,
                        snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                    )
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = snowpark_fn.cast(
                result_exp, TimestampType(snowpark.types.TimestampTimeZone.NTZ)
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.NTZ)

        case "to_unix_timestamp":
            # to_unix_timestamp in PySpark has an optional format string.
            # In Snowpark, the timestamp is not optional.
            # It is observed that the server receives the optional format string if the timestamp is specified,
            # In case of to_unix_timestamp function in SQL it's possible only one argument.
            # so there are either  1 or 2 arguments.
            match exp.unresolved_function.arguments:
                case [_, _] if type(snowpark_typed_args[0].typ) in (
                    DateType,
                    TimestampType,
                ):
                    result_exp = _try_to_cast(
                        "try_to_timestamp",
                        snowpark_fn.unix_timestamp(snowpark_args[0]),
                        snowpark_args[0],
                    )
                case [_, unresolved_format]:
                    snowpark_timestamp = snowpark_args[0]
                    result_exp = _try_to_cast(
                        "try_to_timestamp",
                        snowpark_fn.unix_timestamp(
                            snowpark_timestamp,
                            snowpark_fn.lit(
                                map_spark_timestamp_format_expression(unresolved_format)
                            ),
                        ),
                        snowpark_timestamp,
                    )
                case [_]:
                    spark_function_name = f"to_unix_timestamp({snowpark_arg_names[0]}, {'yyyy-MM-dd HH:mm:ss'})"
                    result_exp = _try_to_cast(
                        "try_to_timestamp",
                        snowpark_fn.unix_timestamp(
                            snowpark_args[0], snowpark_fn.lit("YYYY-MM-DD HH24:MI:SS")
                        ),
                        snowpark_args[0],
                        snowpark_fn.lit("YYYY-MM-DD HH24:MI:SS"),
                    )
                case _:
                    raise SnowparkConnectNotImplementedError(
                        "to_unix_timestamp expected 1 or 2 arguments."
                    )
            result_type = LongType()

        case "to_utc_timestamp":

            @cached_udf
            def map_timezone(short_tz: str) -> str:
                return SPARK_TZ_ABBREVIATIONS_OVERRIDES.get(short_tz, short_tz)

            result_exp = _try_to_cast(
                "try_to_timestamp",
                snowpark_fn.cast(
                    snowpark_fn.to_utc_timestamp(
                        snowpark_args[0], map_timezone(snowpark_args[1])
                    ),
                    TimestampType(snowpark.types.TimestampTimeZone.NTZ),
                ),
                snowpark_args[0],
            )
            result_type = TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case "translate":
            src_alphabet = unwrap_literal(exp.unresolved_function.arguments[1])
            target_alphabet = unwrap_literal(exp.unresolved_function.arguments[2])

            # In Spark the target alphabet is truncated if it's too long, but in Snowpark an exception is thrown.
            if len(target_alphabet) > len(src_alphabet):
                target_alphabet = target_alphabet[: len(src_alphabet)]

            result_exp = snowpark_fn.translate(
                snowpark_args[0],
                snowpark_fn.lit(src_alphabet),
                snowpark_fn.lit(target_alphabet),
            )
            result_type = StringType()
        case "trunc":
            part = unwrap_literal(exp.unresolved_function.arguments[1])
            if part is None:
                result_exp = snowpark_fn.lit(None)
            else:
                result_exp = _try_to_cast(
                    "try_to_date",
                    snowpark_fn.cast(
                        snowpark_fn.date_trunc(
                            part, snowpark_fn.to_timestamp(snowpark_args[0])
                        ),
                        DateType(),
                    ),
                    snowpark_args[0],
                )
            result_type = DateType()
        case "try_add":
            result_exp = _try_arithmetic_helper(snowpark_typed_args, snowpark_args, 0)
            result_exp = _type_with_typer(result_exp)
        case "try_aes_decrypt":
            result_exp = _aes_helper(
                "TRY_DECRYPT",
                snowpark_args[0],
                snowpark_args[1],
                snowpark_args[4],
                snowpark_args[2],
                snowpark_args[3],
            )
            result_type = BinaryType()
        case "try_avg":
            # Snowflake raises an error when a value that cannot be cast into a numeric is passed to AVG. Spark treats these as NULL values and
            # does not throw an error. Additionally, Spark returns NULL when this calculation results in an overflow, whereas Snowflake raises a "TypeError".
            # Matching Spark behavior on both is handled within try_sum_implementation.

            # If we add together all of the numbers and divide by the size of the column we will know if there will be an overflow.
            # However, even the intermediate sum cannot lead to overflow, not just the end result. Therefore, we can just check if the
            # sum of the column will cause an overflow by using the try_sum implementation. Additionally, The AVG calculation can never overflow
            # without the intermediate sum overflowing. Therefore, it is sufficient to rely on intemediate sum overflow and divide after without
            # additional checking.

            match (snowpark_typed_args[0].typ):
                case (DecimalType()):
                    result_exp, result_type = _try_sum_helper(
                        snowpark_typed_args[0].typ,
                        snowpark_args[0],
                        calculating_avg=True,
                    )
                case (_IntegralType()):
                    # Cannot call try_cast on Number type, however, Double can always hold Number type, therefore we can just call cast.
                    # Column must be cast to DoubleType prior to summation to match Spark's behavior. For any non-Decimal type, the overflow limit
                    # matches that of a Double.
                    cleaned = snowpark_fn.cast(snowpark_args[0], DoubleType())
                    result_exp, result_type = _try_sum_helper(
                        DoubleType(), cleaned, calculating_avg=True
                    )
                case (_):
                    # For the column sum to be non null, there must be > 0 non null rows in the input column. Since we only want to count the
                    # rows included in the calculation, we try cast to DoubleType first, as unsuitable values will be nulled out. DecimalType
                    # remains as is and should not be cast to a Double to match Spark behavior.

                    # However, in ANSI mode, we want to throw an error rather than gracefully handling a cast of non-numeric data. Therefore, we call
                    # cast in this case instead of try_cast.
                    if spark_sql_ansi_enabled:
                        cleaned = snowpark_fn.cast(snowpark_args[0], DoubleType())
                    else:
                        cleaned = snowpark_fn.try_cast(snowpark_args[0], DoubleType())
                    result_exp, result_type = _try_sum_helper(
                        DoubleType(), cleaned, calculating_avg=True
                    )
        case "try_divide":
            match (snowpark_typed_args[0].typ, snowpark_typed_args[1].typ):
                case (_IntegralType(), _IntegralType()):
                    # TRY_CAST can never be called between a NUMBER(38, 0) and a DoubleType due to precision loss. Therefore,
                    # we must use CAST instead, which is why this case cannot be combined with the String/Variant case. However,
                    # an IntegerType can always safely cast to a DoubleType, so there is no danger in using CAST.
                    left_double, right_double = snowpark_fn.cast(
                        snowpark_args[0], DoubleType()
                    ), snowpark_fn.cast(snowpark_args[1], DoubleType())
                    result_exp = snowpark_fn.when(
                        snowpark_args[1] == 0, snowpark_fn.lit(None)
                    ).otherwise(left_double / right_double)
                    result_type = DoubleType()
                case (DecimalType(), _IntegralType()) | (
                    _IntegralType(),
                    DecimalType(),
                ) | (DecimalType(), DecimalType()):
                    # compute new precision and scale using correct decimal division rules
                    if isinstance(
                        snowpark_typed_args[0].typ, DecimalType
                    ) and isinstance(snowpark_typed_args[1].typ, DecimalType):
                        s1, p1 = (
                            snowpark_typed_args[0].typ.scale,
                            snowpark_typed_args[0].typ.precision,
                        )
                        s2, p2 = (
                            snowpark_typed_args[1].typ.scale,
                            snowpark_typed_args[1].typ.precision,
                        )
                        # The scale and precision formula that Spark follows for DecimalType
                        # arithmetic operations can be found in the following Spark source
                        # code file:
                        # https://github.com/apache/spark/blob/a584cc48ef63fefb2e035349c8684250f8b936c4/docs/sql-ref-ansi-compliance.md
                        new_scale = max(6, s1 + p2 + 1)
                        new_precision = p1 - s1 + s2 + new_scale

                    elif isinstance(snowpark_typed_args[0].typ, DecimalType):
                        s1, p1 = (
                            snowpark_typed_args[0].typ.scale,
                            snowpark_typed_args[0].typ.precision,
                        )
                        # INT is treated as Decimal(10, 0)
                        new_scale = max(6, s1 + 11)
                        new_precision = p1 - s1 + new_scale

                    else:  # right is DecimalType
                        s2, p2 = (
                            snowpark_typed_args[1].typ.scale,
                            snowpark_typed_args[1].typ.precision,
                        )
                        # INT is treated as Decimal(10, 0)
                        new_scale = max(6, 11 + p2)
                        new_precision = (
                            10 - 0 + s2 + new_scale
                        )  # INT has precision 10, scale 0

                    # apply precision cap
                    if new_precision > 38:
                        new_scale -= new_precision - 38
                        new_precision = 38
                        new_scale = max(new_scale, 6)

                    left_double = snowpark_fn.cast(snowpark_args[0], DoubleType())
                    right_double = snowpark_fn.cast(snowpark_args[1], DoubleType())

                    quotient = snowpark_fn.when(
                        snowpark_args[1] == 0, snowpark_fn.lit(None)
                    ).otherwise(left_double / right_double)
                    quotient = snowpark_fn.cast(quotient, StringType())

                    result_exp = snowpark_fn.try_cast(
                        quotient, DecimalType(new_precision, new_scale)
                    )
                    result_type = DecimalType(new_precision, new_scale)
                case (_NumericType(), _NumericType()):
                    result_exp = snowpark_fn.when(
                        snowpark_args[1] == 0, snowpark_fn.lit(None)
                    ).otherwise(snowpark_args[0] / snowpark_args[1])
                    result_exp = _type_with_typer(result_exp)
                case (StringType(), _) | (_, StringType()) | (VariantType(), _) | (
                    _,
                    VariantType(),
                ):
                    cleaned_left, cleaned_right = snowpark_fn.try_cast(
                        snowpark_args[0], DoubleType()
                    ), snowpark_fn.try_cast(snowpark_args[1], DoubleType())

                    result_exp = snowpark_fn.when(
                        cleaned_right == 0, snowpark_fn.lit(None)
                    ).otherwise(cleaned_left / cleaned_right)
                    result_exp = _type_with_typer(result_exp)
                case (_, _):
                    raise AnalysisException(
                        f"Incompatible types: {snowpark_typed_args[0].typ}, {snowpark_typed_args[1].typ}"
                    )

        case "try_element_at":
            # For structured ArrayType and MapType columns, Snowflake raises an error when an index is out of bounds or a key does not exist.
            # We avoid this error explicitly here by checking the size of the array or the existence of the key regardless of the column type.
            # This is consistent with Spark behaviors over ArrayType and MapType (structured or not in Snowflake).
            match (snowpark_typed_args[0].typ, snowpark_typed_args[1].typ):
                case (ArrayType(), _IntegralType()):
                    array_size = snowpark_fn.array_size(snowpark_args[0])
                    spark_index = snowpark_args[1]

                    # Spark uses 1-based indexing, Snowflake uses 0-based indexing. Spark also allows negative indexing.
                    # Spark Connect raises an error when index == 0.
                    result_exp = (
                        snowpark_fn.when(
                            spark_index == 0,
                            snowpark_fn.lit(
                                "[snowpark_connect::INVALID_INDEX_OF_ZERO] The index 0 is invalid. An index shall be either < 0 or > 0 (the first element has index 1)."
                            ),
                        )
                        .when(
                            (-array_size <= spark_index) & (spark_index < 0),
                            snowpark_fn.get(snowpark_args[0], array_size + spark_index),
                        )
                        .when(
                            (0 < spark_index) & (spark_index <= array_size),
                            snowpark_fn.get(snowpark_args[0], spark_index - 1),
                        )
                        .otherwise(snowpark_fn.lit(None))
                    )
                    result_type = snowpark_typed_args[0].typ.element_type
                case (MapType(), StringType()):
                    result_exp = snowpark_fn.when(
                        snowpark_fn.map_contains_key(
                            snowpark_args[1], snowpark_args[0]
                        ),
                        snowpark_fn.get(snowpark_args[0], snowpark_args[1]),
                    ).otherwise(snowpark_fn.lit(None))
                    result_type = snowpark_typed_args[0].typ.value_type
                case _:
                    # Currently we do not handle VariantType columns as the first argument here.
                    # Spark will not support VariantType until 4.0.0, revisit this when the support is added.
                    raise AnalysisException(
                        f"Expected either (ArrayType, IntegralType) or (MapType, StringType), got {snowpark_typed_args[0].typ}, {snowpark_typed_args[1].typ}."
                    )
        case "try_multiply":
            match (snowpark_typed_args[0].typ, snowpark_typed_args[1].typ):
                case (_IntegralType(), _IntegralType()):
                    min_long = sys.maxsize + 1
                    max_long = sys.maxsize

                    max_value = snowpark_fn.when(
                        ((snowpark_args[0] > 0) & (snowpark_args[1] > 0))
                        | ((snowpark_args[0] < 0) & (snowpark_args[1] < 0)),
                        max_long,
                    ).otherwise(min_long)

                    result_exp = (
                        # Multiplication by 0 must be handled separately, since division by 0 will throw an error.
                        snowpark_fn.when(
                            (snowpark_args[0] == 0) | (snowpark_args[1] == 0),
                            snowpark_fn.lit(0),
                        )
                        # We check for overflow by seeing if max or min divided by the right argument is greater than the
                        # left argument.
                        .when(
                            snowpark_fn.abs(snowpark_args[0])
                            > (max_value / snowpark_fn.abs(snowpark_args[1])),
                            snowpark_fn.lit(None),
                        ).otherwise(snowpark_args[0] * snowpark_args[1])
                    )
                    result_exp = _type_with_typer(result_exp)
                case (DecimalType(), _IntegralType()) | (
                    _IntegralType(),
                    DecimalType(),
                ) | (DecimalType(), DecimalType()):
                    # figure out what precision to use as the overflow amount
                    if isinstance(
                        snowpark_typed_args[0].typ, DecimalType
                    ) and isinstance(snowpark_typed_args[1].typ, DecimalType):
                        new_precision = (
                            snowpark_typed_args[0].typ.precision
                            + snowpark_typed_args[1].typ.precision
                            + 1
                        )
                        new_scale = (
                            snowpark_typed_args[0].typ.scale
                            + snowpark_typed_args[1].typ.scale
                        )
                    elif isinstance(snowpark_typed_args[0].typ, DecimalType):
                        new_precision = snowpark_typed_args[0].typ.precision + 11
                        new_scale = snowpark_typed_args[0].typ.scale
                    else:
                        new_precision = snowpark_typed_args[1].typ.precision + 11
                        new_scale = snowpark_typed_args[1].typ.scale

                    # truncating down appropriately
                    if new_precision > 38:
                        new_precision = 38
                    if new_scale > new_precision:
                        new_scale = new_precision

                    left_double = snowpark_fn.cast(snowpark_args[0], DoubleType())
                    right_double = snowpark_fn.cast(snowpark_args[1], DoubleType())

                    product = left_double * right_double

                    product = snowpark_fn.cast(product, StringType())
                    result_exp = snowpark_fn.try_cast(
                        product, DecimalType(new_precision, new_scale)
                    )
                    result_type = DecimalType(new_precision, new_scale)
                case (_NumericType(), _NumericType()):
                    result_exp = snowpark_args[0] * snowpark_args[1]
                    result_exp = _type_with_typer(result_exp)
                case (StringType(), _) | (_, StringType()) | (VariantType(), _) | (
                    _,
                    VariantType(),
                ):
                    cleaned_left, cleaned_right = snowpark_fn.try_cast(
                        snowpark_args[0], DoubleType()
                    ), snowpark_fn.try_cast(snowpark_args[1], DoubleType())
                    result_exp = cleaned_left * cleaned_right
                    result_exp = _type_with_typer(result_exp)
                case (_, _):
                    raise AnalysisException(
                        f"Incompatible types: {snowpark_typed_args[0].typ}, {snowpark_typed_args[1].typ}"
                    )
        case "try_sum":
            # Snowflake raises an error when a value that cannot be cast into a numeric is passed to SUM. Spark treats these as NULL values and
            # does not throw an error. Additionally, Spark returns NULL when this calculation results in an overflow, whereas Snowflake raises a "TypeError".
            # We avoid these errors explicitly for StringType and VariantType columns by checking the column type and preemptively calling try_cast to a
            # numeric type. Non numerics will be returned as NULL, which is consistent with Spark's behavior as well. For Integral and Decimal types, overflow
            # will be handled manually via UDAF. For Float and Double (which are synonymous), overflow goes to 'inf'/-'inf' which matches Spark's behavior.
            if (
                spark_sql_ansi_enabled
                and not isinstance(snowpark_typed_args[0].typ, DecimalType)
                and not isinstance(snowpark_typed_args[0].typ, _IntegralType)
            ):
                # We want to throw an error on invalid inputs in ANSI mode. Therefore, we should cast to Double prior to passing into _try_sum_helper to
                # trigger error, rather than NULL on non-numeric values in the input column. DecimalType will never have non-numeric types, and also should
                # remain DecimalType. Therefore, we can safely go the alternative path in the DecimalType case.
                casted = snowpark_fn.cast(snowpark_args[0], DoubleType())
                result_exp, result_type = _try_sum_helper(DoubleType(), casted)
            else:
                result_exp, result_type = _try_sum_helper(
                    snowpark_typed_args[0].typ, snowpark_args[0]
                )
        case "try_subtract":
            result_exp = _try_arithmetic_helper(snowpark_typed_args, snowpark_args, 1)
            result_exp = _type_with_typer(result_exp)
        case "try_to_number":
            result_exp = snowpark_fn.function("try_to_number")(
                snowpark_args[0], snowpark_args[1]
            )
            # TODO SNOW-2034420: assign type
            result_exp = _type_with_typer(result_exp)

        case "try_to_timestamp":
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e], _):
                    result_exp = snowpark_fn.builtin("try_to_timestamp")(e.col)
                case ([e, _], _) if type(e.typ) in (DateType, TimestampType):
                    result_exp = snowpark_fn.builtin("try_to_timestamp")(e.col)
                case ([e, _], [_, fmt]):
                    result_exp = snowpark_fn.builtin("try_to_timestamp")(
                        e.col,
                        snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                    )
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = snowpark_fn.cast(result_exp, TimestampType())
            result_type = TimestampType()
        case "typeof":
            col_snowpark_typ = snowpark_typed_args[0].typ
            spark_typ = map_snowpark_to_pyspark_types(col_snowpark_typ)
            result_exp = snowpark_fn.lit(spark_typ.simpleString())
            result_type = StringType()
        case "unbase64":
            base64_decoding_function = snowpark_fn.function("TRY_BASE64_DECODE_BINARY")

            # Compensate for the missing padding and remove spaces, as Spark does. Snowflake would produce a NULL value.
            value = snowpark_fn.replace(snowpark_args[0], " ", "")

            length_mod_4 = snowpark_fn.length(value) % 4

            result_exp = snowpark_fn.when(
                length_mod_4 == 0, base64_decoding_function(value)
            ).otherwise(
                base64_decoding_function(
                    snowpark_fn.concat(
                        value,
                        snowpark_fn.repeat(snowpark_fn.lit("="), 4 - length_mod_4),
                    )
                )
            )
            result_type = BinaryType()
        case "unhex":
            # Non string columns, convert them to string type. This mimics pyspark behavior.
            string_input = snowpark_fn.cast(snowpark_args[0], StringType())

            # Pad odd-length hex strings with leading zero. This mimics pyspark behavior.
            padded_input = snowpark_fn.when(
                snowpark_fn.length(string_input) % 2 == 1,
                snowpark_fn.concat(snowpark_fn.lit("0"), string_input),
            ).otherwise(string_input)

            result_exp = snowpark_fn.function("TRY_HEX_DECODE_BINARY")(padded_input)
            result_type = BinaryType()
        case "unix_date":
            result_exp = snowpark_fn.datediff(
                "day", snowpark_fn.lit("1970-01-01"), snowpark_args[0]
            )
            result_type = IntegerType()
        case "unix_micros":
            result_exp = snowpark_fn.date_part(
                "epoch_microseconds",
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
            )
            result_type = LongType()
        case "unix_millis":
            result_exp = snowpark_fn.date_part(
                "epoch_milliseconds",
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
            )
            result_type = LongType()
        case "unix_seconds":
            result_exp = snowpark_fn.date_part(
                "epoch_seconds",
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
            )
            result_type = LongType()
        case "unix_timestamp":
            # unix_timestamp in PySpark has an optional timestamp and optional format string.
            # In Snowpark, the timestamp is not optional.
            # It is observed that the server receives the optional format string if the timestamp is specified,
            # In case of unix_timestamp function in SQL it's possible only one argument.
            # so there are either 0, 1 or 2 arguments.
            match exp.unresolved_function.arguments:
                case []:
                    spark_function_name = (
                        "unix_timestamp(current_timestamp(), yyyy-MM-dd HH:mm:ss)"
                    )
                    result_exp = snowpark_fn.unix_timestamp(_handle_current_timestamp())
                case [_, _] if type(snowpark_typed_args[0].typ) in (
                    DateType,
                    TimestampType,
                ):
                    result_exp = _try_to_cast(
                        "try_to_timestamp",
                        snowpark_fn.unix_timestamp(snowpark_args[0]),
                        snowpark_args[0],
                    )
                case [_, unresolved_format]:
                    snowpark_timestamp = snowpark_args[0]
                    result_exp = _try_to_cast(
                        "try_to_timestamp",
                        snowpark_fn.unix_timestamp(
                            snowpark_timestamp,
                            snowpark_fn.lit(
                                map_spark_timestamp_format_expression(unresolved_format)
                            ),
                        ),
                        snowpark_args[0],
                    )
                case [_]:
                    spark_function_name = f"unix_timestamp({snowpark_arg_names[0]}, {'yyyy-MM-dd HH:mm:ss'})"
                    result_exp = _try_to_cast(
                        "try_to_timestamp",
                        snowpark_fn.unix_timestamp(
                            snowpark_args[0], snowpark_fn.lit("YYYY-MM-DD HH24:MI:SS")
                        ),
                        snowpark_args[0],
                        snowpark_fn.lit("YYYY-MM-DD HH24:MI:SS"),
                    )
                case _:
                    raise SnowparkConnectNotImplementedError(
                        "unix_timestamp expected 0, 1 or 2 arguments."
                    )
            result_type = LongType()
        case "upper" | "ucase":
            result_exp = snowpark_fn.upper(snowpark_args[0])
            result_type = StringType()
        case "url_decode":

            @cached_udf
            def _url_decode(encoded_url: Optional[str]) -> Optional[str]:
                if encoded_url is None:
                    return None
                try:
                    # Handle both + and %20 encoding for spaces
                    return unquote(encoded_url.replace("+", " "))
                except Exception:
                    return None

            result_exp = _url_decode(snowpark_args[0])
            result_type = StringType()
        case "url_encode":

            @cached_udf
            def _url_encode(url: Optional[str]) -> Optional[str]:
                if url is None:
                    return None
                try:
                    # some tweaks to make it compatible with Spark (and with java.net.URLEncoder)
                    encoded = quote(url, safe="*~")
                    return encoded.replace("~", "%7E").replace("%20", "+")
                except Exception:
                    return None

            result_exp = _url_encode(snowpark_args[0])
            result_type = StringType()

        case "uuid":
            result_exp = snowpark_fn.builtin("UUID_STRING")()
            result_type = StringType()

        case "var_pop":
            result_exp = _resolve_aggregate_exp(
                snowpark_fn.var_pop(snowpark_args[0]), DoubleType()
            )
        case "var_samp" | "variance":
            result_exp = _resolve_aggregate_exp(
                snowpark_fn.var_samp(snowpark_args[0]), DoubleType()
            )
        case "version":
            result_exp = snowpark_fn.lit(get_spark_version())
            result_type = StringType()
        case "weekday":
            arg = snowpark_args[0]
            if isinstance(snowpark_typed_args[0].typ, StringType):
                arg = snowpark_fn.builtin("try_to_date")(snowpark_args[0])

            # dayofweekiso returns 1-7 for Sunday-Saturday, so we subtract 1 to get 0-6 for Monday-Sunday.
            result_exp = snowpark_fn.builtin("dayofweekiso")(
                snowpark_fn.to_date(arg)
            ) - snowpark_fn.lit(1)
            result_type = LongType()
        case "weekofyear":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.weekofyear(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.weekofyear(
                    snowpark_fn.to_date(snowpark_args[0])
                )
            result_type = LongType()
        case "when" | "if":
            name_components = ["CASE"]
            name_components.append("WHEN")
            name_components.append(snowpark_arg_names[0])
            name_components.append("THEN")
            name_components.append(snowpark_arg_names[1])
            result_exp = snowpark_fn.when(snowpark_args[0], snowpark_args[1])
            result_type_indexes = [1]
            for i in range(2, len(snowpark_args), 2):
                if i + 1 >= len(snowpark_args):
                    name_components.append("ELSE")
                    name_components.append(snowpark_arg_names[i])
                    result_exp = result_exp.otherwise(snowpark_args[i])
                    result_type_indexes.append(i)
                else:
                    name_components.append("WHEN")
                    name_components.append(snowpark_arg_names[i])
                    name_components.append("THEN")
                    name_components.append(snowpark_arg_names[i + 1])
                    result_exp = result_exp.when(snowpark_args[i], snowpark_args[i + 1])
                    result_type_indexes.append(i + 1)
            name_components.append("END")
            result_exp = TypedColumn(
                result_exp,
                lambda: [
                    _find_common_type(
                        [snowpark_typed_args[i].typ for i in result_type_indexes]
                    )
                ],
            )
            spark_function_name = " ".join(name_components)
        case "width_bucket":
            width_bucket_fn = snowpark_fn.function("width_bucket")
            v, min_, max_, num_buckets = snowpark_args

            result_exp = (
                snowpark_fn.when(num_buckets <= 0, snowpark_fn.lit(None))
                .when(min_ == max_, snowpark_fn.lit(None))
                .otherwise(width_bucket_fn(v, min_, max_, num_buckets))
            )

            result_type = IntegerType()
        case "window":
            (window_duration, start_time) = _extract_window_args(exp)
            spark_function_name = "window"
            result_exp = snowpark_fn.window(
                snowpark_args[0], window_duration, start_time=start_time
            )
            window_schema = StructType(
                [
                    StructField(
                        '"start"',
                        TimestampType(TimestampTimeZone.LTZ),
                        True,
                        _is_column=False,
                    ),
                    StructField(
                        '"end"',
                        TimestampType(TimestampTimeZone.LTZ),
                        True,
                        _is_column=False,
                    ),
                ],
                structured=STRUCTURED_TYPES_ENABLED,
            )
            result_exp = snowpark_fn.cast(result_exp, window_schema)
            # TODO SNOW-2034495: figure out how to specify the type of a window
            result_exp = _type_with_typer(result_exp)
        case "xpath":
            xpath_list_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.XPathUdfs.xpath_list",
                ["STRING", "STRING"],
                "ARRAY(STRING)",
            )

            result_exp = xpath_list_udf(snowpark_args[0], snowpark_args[1])
            result_type = ArrayType(StringType())
        case "xpath_boolean":
            xpath_boolean_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.XPathUdfs.xpath_boolean",
                ["STRING", "STRING"],
                "BOOLEAN",
            )

            result_exp = xpath_boolean_udf(*snowpark_args)
            result_type = BooleanType()
        case "xpath_double" | "xpath_float" | "xpath_number":
            xpath_number_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.XPathUdfs.xpath_number",
                ["STRING", "STRING"],
                "DOUBLE",
            )

            result_exp = xpath_number_udf(*snowpark_args)
            result_type = DoubleType()
        case "xpath_int" | "xpath_long" | "xpath_short":
            xpath_number_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.XPathUdfs.xpath_number",
                ["STRING", "STRING"],
                "DOUBLE",
            )

            udf_result = xpath_number_udf(*snowpark_args)

            result_exp = snowpark_fn.when(
                snowpark_fn.equal_nan(udf_result), snowpark_fn.lit(0)
            ).otherwise(snowpark_fn.cast(udf_result, LongType()))
            result_type = LongType()
        case "xpath_string":
            xpath_string_udf = register_cached_java_udf(
                "com.snowflake.snowpark_connect.udfs.XPathUdfs.xpath_string",
                ["STRING", "STRING"],
                "STRING",
            )

            result_exp = xpath_string_udf(*snowpark_args)
            result_type = StringType()
        case "xxhash64":
            import snowflake.snowpark_connect.utils.xxhash64 as xxhash64

            xxhash64_src_file = Path(__file__).parent.parent / "utils" / "xxhash64.py"

            # In the notebook environment, the physical file may not be where it's expected, if not found
            # then temporarily create in another location.
            if not xxhash64_src_file.exists():
                xxhash64_src_bytes = inspect.getsource(xxhash64).encode("utf-8")
                sub_dir = (
                    Path(tempfile.gettempdir())
                    / "snowflake"
                    / "snowpark_connect"
                    / "utils"
                )
                xxhash64_src_file = sub_dir / "xxhash64.py"
                # If the file doesn't exist (from a prior run) or it's a different size, then recreate.
                # Otherwise we can use the previously created xxhash64 source file.
                if (
                    not xxhash64_src_file.exists()
                    or xxhash64_src_file.stat().st_size != len(xxhash64_src_bytes)
                ):
                    sub_dir.mkdir(parents=True, exist_ok=True)
                    xxhash64_src_file.write_bytes(xxhash64_src_bytes)

            xxhash_udf_imports = [
                (
                    str(xxhash64_src_file),
                    "snowflake.snowpark_connect.utils.xxhash64",
                )
            ]

            xxhash_udf = partial(
                cached_udf, return_type=LongType(), imports=xxhash_udf_imports
            )

            result_exp = snowpark_fn.lit(DEFAULT_SEED)

            for arg in snowpark_typed_args:
                match arg.typ:
                    case IntegerType() | ShortType() | ByteType() | BooleanType():
                        xxhash64_udf_int = xxhash_udf(
                            xxhash64_int, input_types=[LongType(), LongType()]
                        )

                        result_exp = xxhash64_udf_int(
                            snowpark_fn.cast(arg.col, LongType()), result_exp
                        )
                    case FloatType():
                        xxhash64_udf_float = xxhash_udf(
                            xxhash64_float, input_types=[FloatType(), LongType()]
                        )

                        result_exp = xxhash64_udf_float(arg.col, result_exp)
                    case DoubleType():
                        xxhash64_udf_double = xxhash_udf(
                            xxhash64_double, input_types=[DoubleType(), LongType()]
                        )

                        result_exp = xxhash64_udf_double(arg.col, result_exp)
                    case LongType():
                        xxhash64_udf_long = xxhash_udf(
                            xxhash64_long, input_types=[LongType(), LongType()]
                        )

                        result_exp = xxhash64_udf_long(arg.col, result_exp)
                    case _:
                        xxhash64_udf_str = xxhash_udf(
                            xxhash64_string, input_types=[StringType(), LongType()]
                        )

                        result_exp = xxhash64_udf_str(
                            snowpark_fn.cast(arg.col, StringType()), result_exp
                        )
                result_type = LongType()
        case "year":
            if isinstance(snowpark_typed_args[0].typ, StringType):
                result_exp = snowpark_fn.year(
                    snowpark_fn.builtin("try_to_date")(snowpark_args[0])
                )
            else:
                result_exp = snowpark_fn.year(snowpark_fn.to_date(snowpark_args[0]))
            result_type = LongType()
        case binary_method if binary_method in ("to_binary", "try_to_binary"):
            binary_format = "hex"
            if len(snowpark_args) > 1:
                binary_format = snowpark_args[1]
            result_exp = snowpark_fn.when(
                snowpark_args[0].isNull(), snowpark_fn.lit(None)
            ).otherwise(
                snowpark_fn.function(binary_method)(
                    snowpark_fn.cast(snowpark_args[0], StringType()), binary_format
                ),
            )
            result_type = BinaryType()
        case udf_name if udf_name.lower() in session._udfs:
            # TODO: In Spark, UDFs can override built-in functions in SQL,
            # but not in DataFrame ops.
            udf = session._udfs[udf_name.lower()]
            result_exp = snowpark_fn.call_udf(
                udf.name,
                *(snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args),
            )
            result_type = udf.return_type
        case udtf_name if udtf_name.lower() in session._udtfs:
            udtf, spark_col_names = session._udtfs[udtf_name.lower()]
            result_exp = udtf(
                *(snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args)
            )
            result_type = [f.datatype for f in udtf._output_schema]

        case "luhn_check":

            # https://en.wikipedia.org/wiki/Luhn_algorithm
            @cached_udf(input_types=[StringType()], return_type=BooleanType())
            def _luhn_check(input_number: str) -> bool:
                input_number = input_number.replace(" ", "")
                if not input_number.isdigit():
                    return False

                digits = list(map(int, input_number))

                for i in range(len(digits) - 2, -1, -2):
                    digits[i] *= 2
                    if digits[i] > 9:
                        digits[i] -= 9

                total_sum = sum(digits)
                return total_sum % 10 == 0

            result_exp = _luhn_check(snowpark_args[0])
            result_type = BooleanType()

        case other:
            # TODO: Add more here as we come across them.
            # Unfortunately the scope of function names are not documented in
            # the proto file.
            raise SnowparkConnectNotImplementedError(
                f"Unsupported function name {other}"
            )

    def _to_typed_column(
        res: Column | TypedColumn,
        res_type: DataType | List[DataType] | None,
        function_name: str,
    ) -> TypedColumn:
        if isinstance(res, TypedColumn):
            tc = res
        elif res_type is None:
            # This error indicates the function result lacks type information.
            # Possible ways to properly type a function result (in order of performance):
            # 1. Static type: Assign directly to `result_type` when type is known at resolve time
            # 2. Dynamic type based on function arguments types: Use `snowpark_typed_args` to determine type
            # 3. Use _type_with_typer() as last resort - it calls GS to determine the type
            raise SnowparkConnectNotImplementedError(
                f"Result type of function {function_name} not implemented"
            )
        elif type(res_type) is list:
            tc = TypedColumn(res, lambda: res_type)
        else:
            tc = TypedColumn(res, lambda: [res_type])

        return tc

    spark_col_names = (
        spark_col_names if len(spark_col_names) > 0 else [spark_function_name]
    )
    return spark_col_names, _to_typed_column(result_exp, result_type, function_name)


def _extract_window_args(fn: expressions_proto.Expression) -> (str, str):
    args = fn.unresolved_function.arguments
    match args:
        case [_, _, _]:
            raise SnowparkConnectNotImplementedError(
                "the slide_duration parameter is not supported"
            )
        case [_, window_duration, slide_duration, _] if unwrap_literal(
            window_duration
        ) != unwrap_literal(slide_duration):
            raise SnowparkConnectNotImplementedError(
                "the slide_duration parameter is not supported"
            )
        case [_, window_duration, _, start_time]:
            return unwrap_literal(window_duration), unwrap_literal(start_time)
        case [_, window_duration]:
            return unwrap_literal(window_duration), None


def _handle_current_timestamp():
    result_exp = snowpark_fn.cast(
        snowpark_fn.current_timestamp(),
        get_timestamp_type(),
    )
    return result_exp


def _equivalent_decimal(type):
    match (type):
        case ByteType():
            return DecimalType(3, 0)
        case ShortType():
            return DecimalType(5, 0)
        case IntegerType():
            return DecimalType(10, 0)
        case LongType():
            return DecimalType(20, 0)
    return DecimalType(38, 0)


def _resolve_decimal_and_numeric(type1: DecimalType, type2: _NumericType) -> DataType:
    if isinstance(type2, DecimalType):
        return DecimalType(
            max(type1.precision, type2.precision), max(type1.scale, type2.scale)
        )
    if isinstance(type2, _FractionalType):
        return type2
    int_dec = _equivalent_decimal(type2)
    scale = type1.scale
    precision = max(type1.precision, int_dec.precision + scale)
    return _bounded_decimal(precision, scale)


def _find_common_type(types: list[DataType]) -> DataType | None:
    numeric_priority = {
        DoubleType: 6,
        FloatType: 5,
        LongType: 4,
        IntegerType: 3,
        ShortType: 2,
        ByteType: 1,
    }
    time_priority = {
        TimestampType: 2,
        DateType: 1,
    }
    castable_to_string = [_NumericType, DateType, TimestampType, StringType]

    def _common(type1, type2):
        match (type1, type2):
            case (None, t) | (t, None):
                return t
            case (NullType(), t) | (t, NullType()):
                return t
            case (StringType(), t) | (t, StringType()) if any(
                isinstance(t, castable) for castable in castable_to_string
            ):
                return StringType()
            case (BooleanType(), BooleanType()):
                return BooleanType()
            case (_, _) if isinstance(type1, DecimalType) and isinstance(
                type2, _NumericType
            ):
                return _resolve_decimal_and_numeric(type1, type2)
            case (_, _) if isinstance(type1, _NumericType) and isinstance(
                type2, DecimalType
            ):
                return _resolve_decimal_and_numeric(type2, type1)
            case (_, _) if isinstance(type1, _NumericType) and isinstance(
                type2, _NumericType
            ):
                return max([type1, type2], key=lambda tp: numeric_priority[type(tp)])
            case (_, _) if isinstance(
                type1, tuple(time_priority.keys())
            ) and isinstance(type2, tuple(time_priority.keys())):
                return max([type1, type2], key=lambda tp: time_priority[type(tp)])
            case (ArrayType(), ArrayType()):
                typ = _common(type1.element_type, type2.element_type)
                return ArrayType(typ)
            case (StructType(), StructType()):
                fields1 = type1.fields
                fields2 = type2.fields
                if [field.name for field in fields1] != [
                    field.name for field in fields2
                ]:
                    raise AnalysisException(
                        f"pyspark.errors.exceptions.captured.AnalysisException: [DATATYPE_MISMATCH.DATA_DIFF_TYPES] Cannot resolve expression due to data type mismatch: Input should all be the same type, but it's {type1} or {type2}"
                    )
                fields = []
                for idx, field in enumerate(fields1):
                    typ = _common(field.datatype, fields2[idx].datatype)
                    fields.append(StructField(field.name, typ, _is_column=False))
                return StructType(fields)
            case (MapType(), MapType()):
                key_type = _common(type1.key_type, type2.key_type)
                value_type = _common(type1.value_type, type2.value_type)
                return MapType(key_type, value_type)
            case _:
                raise AnalysisException(
                    f"pyspark.errors.exceptions.captured.AnalysisException: [DATATYPE_MISMATCH.DATA_DIFF_TYPES] Cannot resolve expression due to data type mismatch: Input should all be the same type, but it's {type1} or {type2}"
                )

    types = list(filter(lambda tp: tp is not None, types))
    if not types:
        return None

    return reduce(_common, types)


def _resolve_function_with_lambda(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    from snowflake.snowpark import Session
    from snowflake.snowpark_connect.expression.map_expression import map_expression

    def _resolve_lambda(
        lambda_exp, arg_types: list[DateType], resolve_only_body: bool = False
    ) -> tuple[list[str], TypedColumn]:
        names = [a.name_parts[0] for a in lambda_exp.lambda_function.arguments]
        schema = StructType(
            [
                StructField(name, typ, _is_column=False)
                for name, typ in zip(names, arg_types)
            ]
        )
        artificial_df = Session.get_active_session().create_dataframe([], schema)
        set_schema_getter(artificial_df, lambda: schema)

        with resolving_lambda_function():
            return map_expression(
                lambda_exp.lambda_function.function
                if resolve_only_body
                else lambda_exp,
                column_mapping,
                ExpressionTyper(artificial_df),
            )

    def _get_arr_el_type(tc: TypedColumn):
        match tc.typ:
            case ArrayType() if tc.typ.structured:
                return tc.typ.element_type
            case ArrayType():
                return VariantType()
            case t:
                raise ValueError(f"Expected array, got {t}")

    def _get_map_types(tc: TypedColumn):
        match tc.typ:
            case MapType() if tc.typ.structured:
                return tc.typ.key_type, tc.typ.value_type
            case MapType():
                return VariantType(), VariantType()
            case t:
                raise AnalysisException(
                    f'[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Parameter 1 requires the "MAP" type, however "id" has the type "{t}".'
                )

    def _map_to_array(m: dict) -> Optional[list]:
        # confirm that m is a dict and not a sqlNullWrapper
        if m is None or not hasattr(m, "items"):
            return None
        return [{"key": k, "value": v} for k, v in m.items()]

    def _randomize_lambda_args_names(message: Message, suffix: str | None = None):
        if suffix is None:
            suffix = uuid.uuid4().hex
        for field, value in message.ListFields():
            if (
                field.name == "name_parts"
                and message.DESCRIPTOR.name == "UnresolvedNamedLambdaVariable"
            ):
                modified = [f"{v}_{suffix}" for v in value]
                getattr(message, field.name)[:] = modified
            elif isinstance(value, Message):
                _randomize_lambda_args_names(value, suffix)
            elif field.label == field.LABEL_REPEATED:
                for item in value:
                    if isinstance(item, Message):
                        _randomize_lambda_args_names(item, suffix)

    first_arg = exp.unresolved_function.arguments[0]
    ([arg1_name], arg1_tc) = map_expression(first_arg, column_mapping, typer)
    function_name = exp.unresolved_function.function_name
    result_type = None
    match function_name:
        case "aggregate" | "reduce":
            arr_el_typ = _get_arr_el_type(arg1_tc)
            init_exp = exp.unresolved_function.arguments[1]
            merge_lambda_fn_exp = exp.unresolved_function.arguments[2]
            ([arg2_name], arg2_tc) = map_expression(init_exp, column_mapping, typer)
            ([arg3_name], arg3_tc) = _resolve_lambda(
                merge_lambda_fn_exp, [arg2_tc.typ, arr_el_typ]
            )
            result_exp = snowpark_fn.function("reduce")(
                arg1_tc.col, arg2_tc.col, arg3_tc.col
            )
            result_exp = TypedColumn(result_exp, lambda: arg3_tc.types)
            match exp.unresolved_function.arguments:
                case [_, _, _]:
                    # looks like there is 4th argument in the name (identity function) in native Spark
                    arg4_name = (
                        "lambdafunction(namedlambdavariable(), namedlambdavariable())"
                    )
                case [_, _, _, finish_lambda_fn_exp]:
                    type_of_merge_lamda_body = arg3_tc.typ
                    ([arg4_name], arg4_tc) = _resolve_lambda(
                        finish_lambda_fn_exp, [type_of_merge_lamda_body]
                    )
                    result_exp = snowpark_fn.array_construct(
                        result_exp.column(to_semi_structure=True)
                    )
                    result_exp = snowpark_fn.cast(
                        result_exp,
                        ArrayType(element_type=type_of_merge_lamda_body),
                    )
                    result_exp = snowpark_fn.function("transform")(
                        result_exp, arg4_tc.col
                    )
                    result_type = arg4_tc.typ  # it's type of 'finish' lambda body
                    result_exp = snowpark_fn.get(result_exp, snowpark_fn.lit(0))
                case _:
                    raise SnowparkConnectNotImplementedError(
                        f"{function_name} function requires 3 or 4 arguments"
                    )

            snowpark_arg_names = [
                arg1_name,
                arg2_name,
                arg3_name,
                arg4_name,
            ]

            if not get_is_evaluating_sql():
                # For `reduce` native Spark underneath calls aggregate builtin function, and it leaks in column name (but not in SQL mode)
                function_name = "aggregate"
        case "exists":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_el_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_el_typ])
            result_exp = snowpark_fn.function("filter")(arg1_tc.col, arg2_tc.col)
            result_exp = snowpark_fn.array_size(result_exp) > 0
            result_type = BooleanType()
            snowpark_arg_names = [arg1_name, arg2_name]
        case "filter":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_el_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_el_typ])

            snowpark_arg_names = [arg1_name, arg2_name]
            result_exp = snowpark_fn.function("filter")(arg1_tc.col, arg2_tc.col)
            result_exp = TypedColumn(result_exp, lambda: [ArrayType(arr_el_typ)])
        case "forall":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_el_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_el_typ])
            result_exp = snowpark_fn.function("transform")(arg1_tc.col, arg2_tc.col)
            result_exp = snowpark_fn.function("reduce")(
                result_exp,
                snowpark_fn.lit(True),
                snowpark_fn.sql_expr("(acc, i) -> acc and i"),
            )
            result_type = BooleanType()
            snowpark_arg_names = [arg1_name, arg2_name]
        case "map_filter":
            """
            Implementation of Spark's map_filter with a similar workaround as `zip_with`.
            The input map is converted to an array of structs with fields 'key' and 'value'.
            This array is then filtered and reduced using Snowflake's `filter` and `reduce` functions.
            The input lambda is converted to a single argument Snowflake lambda.
            """

            _map_to_array_udf = cached_udf(
                _map_to_array, input_types=[VariantType()], return_type=ArrayType()
            )
            key_type, val_type = _get_map_types(arg1_tc)

            lambda_exp = exp.unresolved_function.arguments[1]
            # Due to lack of direct equivalent API in Snowflake, we need to transform the lambda expression.
            # Rather than traversing the entire lambda AST, we use string manipulation on the query.
            # We randomize lambda argument names to minimize the risk of accidental replacements in the query.
            _randomize_lambda_args_names(lambda_exp)
            ([lambda_body_name], fn_body) = _resolve_lambda(
                lambda_exp,
                [key_type, val_type],
                resolve_only_body=True,
            )

            l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
            l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]

            analyzer = Session.get_active_session()._analyzer
            fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
            # if the key is a number, we need to cast it
            # otherwise it seems to be treated as a string
            key_exp = (
                "get(x, 'key')::int"
                if isinstance(key_type, _IntegralType)
                else "get(x, 'key')"
            )
            transform_sql = fn_sql.replace(l_arg1, key_exp).replace(
                l_arg2, "strip_null_value(get(x, 'value'))"
            )
            transform_exp = snowpark_fn.sql_expr(f"x -> ({transform_sql})::boolean")
            last_win_dedup = global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            reduce_exp = snowpark_fn.function("reduce")(
                snowpark_fn.function("filter")(
                    _map_to_array_udf(snowpark_fn.cast(arg1_tc.col, VariantType())),
                    transform_exp,
                ),
                snowpark_fn.object_construct(),
                snowpark_fn.sql_expr(
                    # value is cast to variant because object_insert doesn't allow structured types,
                    # and structured types are not coercible to variant
                    # TODO: allow structured types in object_insert?
                    f"(acc, e) -> object_insert(acc, e:key, e:value::variant, {last_win_dedup})"
                ),
            )
            result_type = arg1_tc.typ
            result_exp = snowpark_fn.cast(reduce_exp, result_type)
            snowpark_arg_names = [
                arg1_name,
                f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable())",
            ]
        case "map_zip_with":

            @cached_udf(
                input_types=[VariantType(), VariantType()],
                return_type=ArrayType(),
            )
            def _maps_to_array(m1, m2):
                if (
                    m1 is None
                    or not hasattr(m1, "items")
                    or m2 is None
                    or not hasattr(m2, "items")
                ):
                    return None
                keys = set(m1.keys()) | set(m2.keys())  # Union of keys from both maps
                return [{"k": k, "v1": m1.get(k), "v2": m2.get(k)} for k in keys]

            ([arg2_name], arg2_tc) = map_expression(
                exp.unresolved_function.arguments[1], column_mapping, typer
            )

            key1_type, val1_type = _get_map_types(arg1_tc)
            key2_type, val2_type = _get_map_types(arg2_tc)

            lambda_exp = exp.unresolved_function.arguments[2]
            # Due to lack of direct equivalent API in Snowflake, we need to transform the lambda expression.
            # Rather than traversing the entire lambda AST, we use string manipulation on the query.
            # We randomize lambda argument names to minimize the risk of accidental replacements in the query.
            _randomize_lambda_args_names(lambda_exp)
            ([lambda_body_name], fn_body) = _resolve_lambda(
                lambda_exp,
                [key1_type, val1_type, val2_type],
                resolve_only_body=True,
            )

            key_type = _find_common_type([key1_type, key2_type])
            l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
            l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]
            l_arg3 = lambda_exp.lambda_function.arguments[2].name_parts[0]

            analyzer = Session.get_active_session()._analyzer
            fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
            # if the key is a number, we need to cast it
            # otherwise it seems to be treated as a string
            key_exp = (
                "get(x, 'k')::int"
                if isinstance(key_type, _IntegralType)
                else "get(x, 'k')"
            )
            transform_sql = (
                fn_sql.replace(l_arg1, key_exp)
                .replace(l_arg2, "strip_null_value(get(x, 'v1'))")
                .replace(l_arg3, "strip_null_value(get(x, 'v2'))")
            )

            last_win_dedup = global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            array_of_maps_exp = _maps_to_array(
                snowpark_fn.cast(arg1_tc.col, VariantType()),
                snowpark_fn.cast(arg2_tc.col, VariantType()),
            )
            result_exp = snowpark_fn.function("reduce")(
                array_of_maps_exp,
                snowpark_fn.object_construct(),
                snowpark_fn.sql_expr(
                    f"(acc, x) -> object_insert(acc, {key_exp}, nvl(({transform_sql})::variant, parse_json('null')), {last_win_dedup})"
                ),
            )
            result_type = MapType(key_type, fn_body.typ)
            result_exp = snowpark_fn.cast(result_exp, result_type)
            snowpark_arg_names = [
                arg1_name,
                arg2_name,
                f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable(), namedlambdavariable())",
            ]
        case "transform":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_el_typ = _get_arr_el_type(arg1_tc)
            match lambda_exp.lambda_function.arguments:
                case [_]:
                    ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_el_typ])
                    snowpark_arg_names = [arg1_name, arg2_name]
                    result_exp = snowpark_fn.function("transform")(
                        arg1_tc.col, arg2_tc.col
                    )
                    result_exp = TypedColumn(
                        result_exp, lambda: [ArrayType(arg2_tc.typ)]
                    )
                case [_, _]:

                    @cached_udf(
                        input_types=[ArrayType()],
                        return_type=ArrayType(),
                    )
                    def _with_index(arr: list) -> list:
                        if arr is None:
                            return None
                        return [{"index": i, "element": el} for i, el in enumerate(arr)]

                    # Due to lack of direct equivalent API in Snowflake, we need to transform the lambda expression.
                    # Rather than traversing the entire lambda AST, we use string manipulation on the query.
                    # We randomize lambda argument names to minimize the risk of accidental replacements in the query.
                    _randomize_lambda_args_names(lambda_exp)
                    ([lambda_body_name], fn_body) = _resolve_lambda(
                        lambda_exp,
                        [arr_el_typ, LongType()],
                        resolve_only_body=True,
                    )

                    l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
                    l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]

                    analyzer = Session.get_active_session()._analyzer
                    fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
                    fn_sql_with_replaced_args = fn_sql.replace(
                        l_arg1, "strip_null_value(get(x, 'element'))"
                    ).replace(l_arg2, "get(x, 'index')::int")

                    result_exp = snowpark_fn.function("transform")(
                        _with_index(arg1_tc.column(to_semi_structure=True)),
                        snowpark_fn.sql_expr(f"x -> {fn_sql_with_replaced_args}"),
                    )
                    result_type = ArrayType(fn_body.typ)
                    result_exp = snowpark_fn.cast(result_exp, result_type)
                    snowpark_arg_names = [
                        arg1_name,
                        f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable())",
                    ]
                case _:
                    raise SnowparkConnectNotImplementedError(
                        f"{function_name} function requires lambda function with 1 or 2 arguments"
                    )
        case "transform_keys":
            _map_to_array_udf = cached_udf(
                _map_to_array,
                input_types=[VariantType()],
                return_type=ArrayType(),
                packages=[],
            )
            key_type, val_type = _get_map_types(arg1_tc)

            lambda_exp = exp.unresolved_function.arguments[1]
            # Due to lack of direct equivalent API in Snowflake, we need to transform the lambda expression
            # Rather than traversing the entire lambda AST, we use string manipulation on the query
            # We randomize lambda argument names to minimize the risk of accidental replacements in the query
            _randomize_lambda_args_names(lambda_exp)
            ([lambda_body_name], fn_body) = _resolve_lambda(
                lambda_exp,
                [key_type, val_type],
                resolve_only_body=True,
            )

            l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
            l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]

            analyzer = Session.get_active_session()._analyzer
            fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
            # if the key is a number, we need to cast it
            # otherwise it seems to be treated as a string
            key_exp = (
                "get(x, 'key')::int"
                if isinstance(key_type, _IntegralType)
                else "get(x, 'key')"
            )
            fn_sql_with_replaced_args = fn_sql.replace(l_arg1, key_exp).replace(
                l_arg2, "strip_null_value(get(x, 'value'))"
            )
            last_win_dedup = global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            reduce_exp = snowpark_fn.function("reduce")(
                _map_to_array_udf(snowpark_fn.cast(arg1_tc.col, VariantType())),
                snowpark_fn.object_construct(),
                snowpark_fn.sql_expr(
                    # value is cast to variant because object_insert doesn't allow structured types,
                    # and structured types are not coercible to variant
                    # TODO: allow structured types in object_insert?
                    f"(acc, x) -> object_insert(acc, {fn_sql_with_replaced_args}, x:value::variant, {last_win_dedup})"
                ),
            )
            result_type = MapType(fn_body.typ, val_type)
            result_exp = snowpark_fn.cast(
                reduce_exp,
                result_type,
            )
            snowpark_arg_names = [
                arg1_name,
                f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable())",
            ]

        case "transform_values":
            _map_to_array_udf = cached_udf(
                _map_to_array,
                input_types=[VariantType()],
                return_type=ArrayType(),
                packages=[],
            )
            key_type, val_type = _get_map_types(arg1_tc)

            lambda_exp = exp.unresolved_function.arguments[1]
            # Due to lack of direct equivalent API in Snowflake, we need to transform the lambda expression
            # Rather than traversing the entire lambda AST, we use string manipulation on the query
            # We randomize lambda argument names to minimize the risk of accidental replacements in the query
            _randomize_lambda_args_names(lambda_exp)
            ([lambda_body_name], fn_body) = _resolve_lambda(
                lambda_exp,
                [key_type, val_type],
                resolve_only_body=True,
            )

            l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
            l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]

            analyzer = Session.get_active_session()._analyzer
            fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
            # if the key is a number, we need to cast it
            # otherwise it seems to be treated as a string
            key_exp = (
                "get(x, 'key')::int"
                if isinstance(key_type, _IntegralType)
                else "get(x, 'key')"
            )
            fn_sql_with_replaced_args = fn_sql.replace(l_arg1, key_exp).replace(
                l_arg2, "strip_null_value(get(x, 'value'))"
            )
            last_win_dedup = global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            reduce_exp = snowpark_fn.function("reduce")(
                _map_to_array_udf(snowpark_fn.cast(arg1_tc.col, VariantType())),
                snowpark_fn.object_construct(),
                snowpark_fn.sql_expr(
                    # value is cast to variant because object_insert doesn't allow structured types,
                    # and structured types are not coercible to variant
                    # TODO: allow structured types in object_insert?
                    f"(acc, x) -> object_insert(acc, x:key, nvl(({fn_sql_with_replaced_args})::variant, parse_json('null')), {last_win_dedup})"
                ),
            )
            result_type = MapType(key_type, fn_body.typ)
            result_exp = snowpark_fn.cast(
                reduce_exp,
                result_type,
            )
            snowpark_arg_names = [
                arg1_name,
                f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable())",
            ]

        case "zip_with":
            """
            This impl is a workaround since Snowflake SQL lacks native support of `zip_with`:
             - Use `arrays_zip` to combine two input arrays into a single array of structs with fields $1 and $2
             - Resolve only the body of the lambda function from the 3rd argument (which is a standard `unresolved_function` expression)
             - Convert a resolved expression into raw SQL using the analyzer (this SQL references original lambda args)
             - Replace lambda arg references in SQL with get(x,'$1') and get(x,'$2') accessors
             - Construct a new lambda 'x -> modified_sql'
             - Apply `transform` function to transform the zipped array using that lambda
            """
            arr2 = exp.unresolved_function.arguments[1]
            ([arg2_name], arg2_tc) = map_expression(arr2, column_mapping, typer)

            zip_exp = snowpark_fn.arrays_zip(arg1_tc.col, arg2_tc.col)
            lambda_exp = exp.unresolved_function.arguments[2]
            # Due to lack of direct equivalent API in Snowflake, we need to transform the lambda expression.
            # Rather than traversing the entire lambda AST, we use string manipulation on the query.
            # We randomize lambda argument names to minimize the risk of accidental replacements in the query.
            _randomize_lambda_args_names(lambda_exp)
            ([lambda_body_name], fn_body) = _resolve_lambda(
                lambda_exp,
                [arg1_tc.typ.element_type, arg2_tc.typ.element_type],
                resolve_only_body=True,
            )
            l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
            l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]
            analyzer = Session.get_active_session()._analyzer
            fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
            transform_sql = fn_sql.replace(l_arg1, "get(x, '$1')").replace(
                l_arg2, "get(x, '$2')"
            )
            transform_exp = snowpark_fn.sql_expr(f"x -> {transform_sql}")
            snowpark_arg_names = [
                arg1_name,
                arg2_name,
                f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable())",
            ]
            result_exp = snowpark_fn.function("transform")(zip_exp, transform_exp)
            result_exp = TypedColumn(result_exp, lambda: [ArrayType(fn_body.typ)])
        case other:
            # TODO: Add more here as we come across them.
            raise SnowparkConnectNotImplementedError(
                f"Unsupported function name {other}"
            )

    spark_function_name = f"{function_name}({', '.join(snowpark_arg_names)})"
    if not isinstance(result_exp, TypedColumn):
        tc = TypedColumn(
            result_exp,
            lambda: [result_type]
            if result_type is not None
            else typer.type(result_exp),
        )
    else:
        tc = result_exp
    return [spark_function_name], tc


def _resolve_first_value(exp, snowpark_args):
    """
    Utility method to perform first function.
    """
    args = exp.unresolved_function.arguments
    ignore_nulls = unwrap_literal(args[1]) if len(args) > 1 else False
    return snowpark_fn.first_value(snowpark_args[0], ignore_nulls)


def _resolve_last_value(exp, snowpark_args):
    """
    Utility method to perform last function.
    """
    args = exp.unresolved_function.arguments
    ignore_nulls = unwrap_literal(args[1]) if len(args) > 1 else False
    return snowpark_fn.last_value(snowpark_args[0], ignore_nulls)


def _aes_helper(function_name, value, passphrase, aad, encryption_method, padding):
    """
    Utility method to perform AES encryption and decryption.
    """
    aes_function = snowpark_fn.function(function_name)
    return aes_function(
        value,
        passphrase,
        snowpark_fn.when(
            (encryption_method == snowpark_fn.lit("DEFAULT"))
            | (snowpark_fn.lower(encryption_method) == snowpark_fn.lit("gcm")),
            aad,
        ),
        snowpark_fn.concat(
            snowpark_fn.lit("AES-"),
            snowpark_fn.when(
                encryption_method == snowpark_fn.lit("DEFAULT"), "GCM"
            ).otherwise(encryption_method),
            snowpark_fn.when(
                padding == snowpark_fn.lit("DEFAULT"),
                snowpark_fn.lit(None),
            ).otherwise(snowpark_fn.concat(snowpark_fn.lit("/pad:"), padding)),
        ),
    )


def _bounded_decimal(precision: int, scale: int) -> DecimalType:
    return DecimalType(min(38, precision), min(37, scale))


def _try_to_cast(function_name: str, execute_if_true: Column, *arguments) -> Column:
    # This function tries to cast all of the passed arguments using a given function.
    # This ensures that invalid inputs are handled gracefully by falling back to a default behavior
    # (e.g., returning NULL if ANSI mode is enabled or raising an appropriate error).
    if global_config.spark_sql_ansi_enabled:
        return execute_if_true

    combined_conditions = reduce(
        operator.iand,
        (
            snowpark_fn.builtin(function_name)(
                snowpark_fn.cast(arg, StringType())
            ).isNotNull()
            for arg in arguments
        ),
    )

    return snowpark_fn.when(combined_conditions, execute_if_true).otherwise(
        snowpark_fn.lit(None)
    )


def _try_sum_helper(
    arg_type: DataType, col_name: Column, calculating_avg: bool = False
) -> tuple[Column, DataType]:
    # This function calculates the sum or average of a Snowpark column (`col_name`) based on its
    # data type (`arg_type`) and whether an average is requested (`calculating_avg`).
    #
    # Its main behavioral characteristics are:
    #
    # 1. For Integral and Decimal Types:
    #    - It uses custom User-Defined Aggregate Functions (UDAFs) to compute the sum.
    #    - BEHAVIOR: If an arithmetic overflow occurs during summation for these types,
    #      the function returns `None` (null) for the sum.
    #    - If `calculating_avg` is True (which it will never be for Integral Types):
    #        - If the sum results in `None` (due to overflow), the average is also `None`.
    #        - Otherwise, the average is the (non-overflowed) sum divided by the count of non-null rows.
    #
    # 2. For Floating-Point Types (_FractionalType like Float, Double) or other types
    #    that are try-casted to Double:
    #    - It uses the standard `snowpark_fn.sum()` aggregate function.
    #    - BEHAVIOR: If an overflow occurs, the sum will be `Infinity` or `-Infinity`,
    #      following Snowflake's default behavior for floating-point sums.
    #    - If `calculating_avg` is True, the average is this sum (which could be Infinity)
    #      divided by the count of non-null rows.
    #
    # In essence, this function provides a "try_sum" or "try_avg" behavior, specifically
    # aiming to convert overflows into `None` for exact numeric types (integers, decimals),
    # while letting floating-point overflows behave as they normally would in Snowflake.
    # It returns the resulting aggregate column and its Snowpark DataType.

    match arg_type:
        case (_IntegralType()):

            class TrySumIntegerUDAF:
                def __init__(self) -> None:
                    self.agg_sum = None
                    self.max_int = sys.maxsize
                    self.min_int = -sys.maxsize - 1
                    self.overflowed = False

                @property
                def aggregate_state(self):
                    # overflow will return NaN, null col will return NULL, otherwise the sum
                    return float("nan") if self.overflowed else self.agg_sum

                def accumulate(self, input_num):
                    if not self.overflowed:
                        if input_num is not None:
                            if (
                                self.agg_sum is None
                            ):  # the input sum is non null but the agg is
                                self.agg_sum = input_num
                            elif self.agg_sum > (
                                self.max_int - input_num
                            ) or self.agg_sum < (
                                self.min_int - input_num
                            ):  # neither are null but will cause overflow
                                self.overflowed = True
                            else:
                                self.agg_sum += (
                                    input_num  # neither are null, no overflow
                                )

                def merge(self, other_sum):
                    if not self.overflowed:
                        if other_sum is not float("nan"):  # neither is an overflow
                            if other_sum is None:
                                pass  # agg_sum stays the same, the other sum is empty
                            elif (
                                self.agg_sum is None
                            ):  # other sum isn't none but agg_sum is
                                self.agg_sum = other_sum
                            elif self.agg_sum > (
                                self.max_int - other_sum
                            ) or self.agg_sum < (self.min_int - other_sum):
                                self.overflowed = True
                            else:
                                self.agg_sum += other_sum
                        else:
                            self.overflowed = True  # if we merge two together and one has overflowed, the agg overflows

                def finish(self):
                    return None if self.overflowed else self.agg_sum

            _try_sum_int_udaf = cached_udaf(
                TrySumIntegerUDAF,
                return_type=arg_type,
                input_types=[arg_type],
            )
            # call the udaf
            return _try_sum_int_udaf(col_name), arg_type

            # NOTE: We will never call this function with an IntegerType column and calculating_avg=True. Therefore,
            # we don't need to handle the case where calculating_avg=True here. The caller of this function will handle it.

        case (DecimalType()):

            class TrySumDecimalUDAF:
                def __init__(self) -> None:
                    self.agg_sum = Decimal(0.00)
                    self.max_decimal = Decimal("9" * 38 + "." + "9" * abs(0))
                    self.min_decimal = -self.max_decimal
                    self.overflowed = False

                @property
                def aggregate_state(self):
                    return (
                        float("nan")
                        if self.overflowed
                        else (self.agg_sum, self.max_decimal)
                    )

                def accumulate(self, input_num, precision: int = 38, scale: int = 0):
                    self.max_decimal = Decimal("9" * precision + "." + "9" * abs(scale))
                    self.min_decimal = -self.max_decimal

                    if not self.overflowed:
                        if input_num is not None:
                            if (
                                self.agg_sum is None
                            ):  # the input sum is non null but the agg is
                                self.agg_sum = input_num
                            elif self.agg_sum > (
                                self.max_decimal - input_num
                            ) or self.agg_sum < (
                                self.min_decimal - input_num
                            ):  # neither are null but will cause overflow
                                self.overflowed = True
                            else:
                                self.agg_sum += (
                                    input_num  # neither are null, no overflow
                                )

                def merge(self, other_sum):
                    if not self.overflowed:
                        if other_sum is not float("nan"):  # neither is an overflow
                            self.max_decimal = other_sum[1]
                            self.min_decimal = -self.max_decimal
                            other_sum = other_sum[0]
                            if other_sum is None:
                                pass  # agg_sum stays the same, the other sum is empty
                            elif (
                                self.agg_sum is None
                            ):  # other sum isn't none but agg_sum is
                                self.agg_sum = other_sum
                            elif self.agg_sum > (
                                self.max_decimal - other_sum
                            ) or self.agg_sum < (self.min_decimal - other_sum):
                                self.overflowed = True
                            else:
                                self.agg_sum += other_sum
                    else:
                        self.overflowed = True  # if we merge two together and one has overflowed, the agg overflows

                def finish(self):
                    return None if self.overflowed else self.agg_sum

            _try_sum_decimal_udaf = cached_udaf(
                TrySumDecimalUDAF,
                return_type=DecimalType(
                    arg_type.precision,
                    arg_type.scale,
                ),
                input_types=[
                    DecimalType(
                        arg_type.precision,
                        arg_type.scale,
                    ),
                    IntegerType(),
                    IntegerType(),
                ],
            )

            aggregate_sum = _try_sum_decimal_udaf(
                col_name,
                snowpark_fn.lit(arg_type.precision),
                snowpark_fn.lit(arg_type.scale),
            )
            # if calculating_avg is True, we need to divide the sum by the count of non-null rows
            if calculating_avg:
                new_type = DecimalType(
                    precision=min(38, arg_type.precision + 4),
                    scale=min(38, arg_type.scale + 4),
                )
                if aggregate_sum is snowpark_fn.lit(None):
                    return snowpark_fn.lit(None), new_type
                else:
                    non_null_rows = snowpark_fn.count(col_name)
                    return aggregate_sum / non_null_rows, new_type
            else:
                new_type = DecimalType(
                    precision=min(38, arg_type.precision + 10), scale=arg_type.scale
                )
                return aggregate_sum, new_type

        case (_):
            # If the input column is floating point (double and float are synonymous in Snowflake per
            # the numeric types documentation), we can just let it go through to Snowflake, where overflow
            # matches Spark and goes to inf.
            if not isinstance(arg_type, _FractionalType):
                cleaned = snowpark_fn.try_cast(col_name, DoubleType())
                aggregate_sum = snowpark_fn.sum(cleaned)
            else:
                aggregate_sum = snowpark_fn.sum(col_name)

            # if calculating_avg is True, we need to divide the sum by the count of non-null rows
            if calculating_avg:
                if aggregate_sum is snowpark_fn.lit(None):
                    return snowpark_fn.lit(None), DoubleType()
                else:
                    non_null_rows = snowpark_fn.count(col_name)
                    return aggregate_sum / non_null_rows, DoubleType()
            else:
                return aggregate_sum, DoubleType()


def _try_arithmetic_helper(
    typed_args: List[TypedColumn], snowpark_args: List[Column], operation_type: int
) -> Column:
    # Constructs a Snowpark Column expression for a "try-style" arithmetic operation
    # (addition or subtraction, determined by `operation_type`) between two input columns.
    #
    # Key behavioral characteristics:
    # 1. For **Integral inputs**: Explicitly checks for 64-bit overflow/underflow.
    #    - BEHAVIOR: Returns a NULL literal if the operation would exceed these limits;
    #      otherwise, returns the result of the standard Snowpark `+` or `-`.
    #
    # 2. For **other Numeric types, or String types** (which are first passed to
    #    `_validate_numeric_args` for attempted numeric conversion):
    #    - BEHAVIOR: Applies the standard Snowpark `+` or `-` operator. The outcome of this
    #      (e.g., for float overflow, decimal limits) depends on Snowflake's default
    #      behavior for these standard arithmetic operations on the given types.
    #
    # Arithmetic operations involving **Boolean types** will raise an `AnalysisException`.
    # All other unhandled incompatible type combinations result in a NULL literal.
    # The function returns the resulting Snowpark Column expression.

    match (typed_args[0].typ, typed_args[1].typ):
        case (_IntegralType(), _IntegralType()):
            # For integer addition, overflow errors by default in Snowflake. We need it to return null.
            if operation_type == 0:  # Addition
                result_exp = (
                    snowpark_fn.when(
                        (snowpark_args[0] > 0)
                        & (snowpark_args[1] > 0)
                        & (
                            snowpark_args[0]
                            > snowpark_fn.lit(9223372036854775807) - snowpark_args[1]
                        ),
                        snowpark_fn.lit(None),  # Overflow
                    )
                    .when(
                        (snowpark_args[0] < 0)
                        & (snowpark_args[1] < 0)
                        & (
                            snowpark_args[0]
                            < snowpark_fn.lit(-9223372036854775808) - snowpark_args[1]
                        ),
                        snowpark_fn.lit(None),  # Underflow
                    )
                    .otherwise(snowpark_args[0] + snowpark_args[1])
                )
            else:  # Subtraction
                result_exp = (
                    snowpark_fn.when(
                        (snowpark_args[0] > 0)
                        & (snowpark_args[1] < 0)
                        & (
                            snowpark_args[0]
                            > snowpark_fn.lit(9223372036854775807) + snowpark_args[1]
                        ),
                        snowpark_fn.lit(None),  # Overflow
                    )
                    .when(
                        (snowpark_args[0] < 0)
                        & (snowpark_args[1] > 0)
                        & (
                            snowpark_args[0]
                            < snowpark_fn.lit(-9223372036854775808) + snowpark_args[1]
                        ),
                        snowpark_fn.lit(None),  # Underflow
                    )
                    .otherwise(snowpark_args[0] - snowpark_args[1])
                )
            return result_exp
        case ((DateType(), _) | (_, DateType())):
            arg1, arg2 = typed_args[0].typ, typed_args[1].typ
            # Valid input parameter types for try_add - DateType and _NumericType, _NumericType and DateType.
            # For try_subtract, valid types are DateType, _NumericType and DateType, DateType.
            if operation_type == 0:
                if (
                    isinstance(arg1, DateType) and not isinstance(arg2, _IntegralType)
                ) or (
                    isinstance(arg2, DateType) and not isinstance(arg1, _IntegralType)
                ):
                    raise AnalysisException(
                        '[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "date_add(dt, add)" due to data type mismatch: Parameter 2 requires the ("INT" or "SMALLINT" or "TINYINT") type'
                    )
                return _try_to_cast(
                    "try_to_date",
                    snowpark_fn.cast(snowpark_fn.date_add(*snowpark_args), DateType()),
                    snowpark_args[0],
                )
            else:
                if isinstance(arg1, DateType) and isinstance(arg2, _IntegralType):
                    return _try_to_cast(
                        "try_to_date",
                        snowpark_fn.to_date(
                            snowpark_fn.date_sub(snowpark_args[0], snowpark_args[1])
                        ),
                        snowpark_args[0],
                    )
                elif isinstance(arg1, DateType) and isinstance(arg2, DateType):
                    return snowpark_fn.daydiff(snowpark_args[0], snowpark_args[1])
                else:
                    raise AnalysisException(
                        '[DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve "date_sub(dt, sub)" due to data type mismatch: Parameter 1 requires the "DATE" type and parameter 2 requires the ("INT" or "SMALLINT" or "TINYINT") type'
                    )

        # If either of the inputs is floating point, we can just let it go through to Snowflake, where overflow
        # matches Spark and goes to inf.
        # Note that we already handle the int,int case above, hence it is okay to use the broader _numeric
        # below.
        case (_NumericType(), _NumericType()):
            if operation_type == 0:
                return snowpark_args[0] + snowpark_args[1]
            else:
                return snowpark_args[0] - snowpark_args[1]
        # String cases - try to convert to numeric
        case (
            (StringType(), _NumericType())
            | (_NumericType(), StringType())
            | (
                StringType(),
                StringType(),
            )
        ):
            # It's ok to use _validate_numeric_args here because we already know it will not throw because we
            # are only dealing with string and numeric.
            if operation_type == 0:
                updated_args = _validate_numeric_args(
                    "try_add", typed_args, snowpark_args
                )
                return updated_args[0] + updated_args[1]
            else:
                updated_args = _validate_numeric_args(
                    "try_subtract", typed_args, snowpark_args
                )
                return updated_args[0] - updated_args[1]

        case (BooleanType(), _) | (_, BooleanType()):
            raise AnalysisException(
                f"Incompatible types: {typed_args[0].typ}, {typed_args[1].typ}"
            )
        case _:
            # Return NULL for incompatible types
            return snowpark_fn.lit(None)


def _raise_error_udf_helper(return_type: DataType):
    def _raise_error(message=None):
        raise ValueError(message)

    return cached_udf(_raise_error, return_type=return_type, input_types=[StringType()])


def _divnull(dividend: Column, divisor: Column) -> Column:
    """
    Utility method to perform division with null handling.
    If the divisor is zero, it returns null instead of raising an error.
    Use it instead of snowpark_fn.divnull to avoid performance overhead
    """
    return snowpark_fn.when(divisor == 0, snowpark_fn.lit(None)).otherwise(
        dividend / divisor
    )
