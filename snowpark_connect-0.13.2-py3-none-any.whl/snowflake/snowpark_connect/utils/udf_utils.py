# Note: this class will be loaded in a stored procedure to create a Python UDF with different Python version.
# So its dependencies are restricted to pandas, snowpark, and, pyspark
import inspect
from typing import Iterator

import pandas
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from pyspark.serializers import CloudPickleSerializer

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark.types import DataType, VariantType


class ProcessCommonInlineUserDefinedFunction:
    def __init__(
        self,
        common_inline_user_defined_function: expressions_proto.CommonInlineUserDefinedFunction,
        called_from: str,
        return_type: DataType,
        input_column_names: list[str] | None = None,
        input_types: list | None = None,
        udf_name: str | None = None,
        replace: bool = False,
        udf_packages: str = "",
    ) -> None:
        self._function_name = common_inline_user_defined_function.function_name
        self._is_deterministic = common_inline_user_defined_function.deterministic
        self._arguments = common_inline_user_defined_function.arguments
        self._function_type = common_inline_user_defined_function.WhichOneof("function")
        self._input_types = input_types
        self._udf_name = udf_name
        self._replace = replace
        self._called_from = called_from
        self._input_column_names = input_column_names
        self._udf_packages = udf_packages
        match self._function_type:
            case "python_udf":
                self._return_type = return_type
                self._eval_type = (
                    common_inline_user_defined_function.python_udf.eval_type
                )
                self._command = common_inline_user_defined_function.python_udf.command
                self._python_ver = (
                    common_inline_user_defined_function.python_udf.python_ver
                )
            case _:
                raise ValueError(
                    f"Function type {self._function_type} not supported for common inline user-defined function"
                )

    @property
    def snowpark_udf_args(self):
        if self._column_mapping is not None:
            return self._snowpark_udf_args
        else:
            raise ValueError(
                "Column mapping is not provided, cannot get snowpark udf args"
            )

    @property
    def snowpark_udf_arg_names(self):
        if self._column_mapping is not None:
            return self._snowpark_udf_arg_names
        else:
            raise ValueError(
                "Column mapping is not provided, cannot get snowpark udf arg names"
            )

    def _create_python_udf(self):
        def update_none_input_types():
            if self._input_types is None:
                # If any of the parameters don't have type hint, we use Snowflake Variant type.
                func_signature = inspect.signature(callable_func)
                self._input_types = [VariantType()] * len(func_signature.parameters)

        (
            callable_func,
            pyspark_output_type,
        ) = CloudPickleSerializer().loads(self._command)

        if self._udf_packages:
            packages = [p.strip() for p in self._udf_packages.strip("[]").split(",")]
        else:
            packages = []
        update_none_input_types()

        match self._called_from:
            case "map_map_partitions":
                column_names = self._input_column_names
                eval_type = self._eval_type

                # keep this wrap function small and independent to avoid creating UDF error in sproc
                def wrapped_function(*args):
                    result = callable_func(
                        pandas.DataFrame(iter([list(args)]), columns=column_names)
                    )
                    if eval_type == 207:  # SQL_MAP_ARROW_ITER_UDF
                        if not isinstance(result, Iterator) and not hasattr(
                            result, "__iter__"
                        ):
                            raise RuntimeError(
                                f"snowpark_connect::UDF_RETURN_TYPE Return type of the user-defined function should be "
                                f"iterator of pyarrow.RecordBatch, but is {type(result).__name__}"
                            )
                        import pyarrow as pa

                        for elem in result:
                            if not isinstance(elem, pa.RecordBatch):
                                raise RuntimeError(
                                    f"snowpark_connect::UDF_RETURN_TYPE Return type of the user-defined function should "
                                    f"be iterator of pyarrow.RecordBatch, but is iterator of {type(elem).__name__}"
                                )
                    return result

                udf_function = wrapped_function
                packages += ["pyarrow", "pandas"]
            case _:
                udf_function = callable_func

        return snowpark_fn.udf(
            udf_function,
            return_type=self._return_type,
            input_types=self._input_types,
            name=self._udf_name,
            replace=self._replace,
            packages=packages,
        )

    def create_udf(self):
        match self._function_type:
            case "python_udf":
                return self._create_python_udf()
            case _:
                raise ValueError(
                    f"Function type {self._function_type} not supported for common inline user-defined function"
                )
