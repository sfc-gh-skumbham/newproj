import os
from collections.abc import Sequence
from typing import Any

from snowflake import snowpark
from snowflake.snowpark.exceptions import SnowparkClientException
from snowflake.snowpark.session import _get_active_session
from snowflake.snowpark_connect.constants import DEFAULT_CONNECTION_NAME
from snowflake.snowpark_connect.utils.describe_query_cache import (
    instrument_session_for_describe_cache,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.udf_cache import init_builtin_udf_cache


def _get_current_snowpark_session() -> snowpark.Session | None:
    # TODO: this is a temporary solution to get the current session, it would be better to add a function in snowpark
    try:
        session = _get_active_session()
        # if session._conn._conn.expired:
        #     _remove_session(session)
        #     return self.create()
        return session
    except SnowparkClientException as ex:
        if ex.error_code == "1403":  # No session
            return None
        raise


def configure_snowpark_session(session: snowpark.Session):
    from snowflake.snowpark_connect.config import global_config
    from snowflake.snowpark_connect.utils.telemetry import TelemetryClient

    logger.info(f"Configuring session {session}")

    session._sas_telemetry_client = TelemetryClient(session._conn._conn)
    # custom udfs
    session._udfs = {}
    session._udtfs = {}
    session._sprocs = set()
    # built-in udf cache
    init_builtin_udf_cache(session)

    session.ast_enabled = False
    session.eliminate_numeric_sql_value_cast_enabled = False
    session.reduce_describe_query_enabled = True
    session._join_alias_fix = True
    session.connection.arrow_number_to_decimal_setter = True

    session.sql("ALTER SESSION SET TIMESTAMP_TYPE_MAPPING = TIMESTAMP_LTZ").collect()
    session.sql(
        f"ALTER SESSION SET TIMEZONE = '{global_config.spark_sql_session_timeZone}'"
    ).collect()
    session.sql("ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE=false").collect()

    session.sql(
        "ALTER SESSION SET PYTHON_SNOWPARK_ENABLE_THREAD_SAFE_SESSION = true"
    ).collect()

    # Instrument the snowpark session to use a cache for describe queries.
    instrument_session_for_describe_cache(session)


def _is_running_in_SPCS():
    return (
        os.path.exists("/snowflake/session/token")
        and os.getenv("SNOWFLAKE_ACCOUNT") is not None
        and os.getenv("SNOWFLAKE_HOST") is not None
    )


def _get_session_configs_from_ENV() -> dict[str, Any]:
    session_configs = {
        "account": os.getenv("SNOWFLAKE_ACCOUNT"),
        "protocol": "https",
        "host": os.getenv("SNOWFLAKE_HOST"),
        "port": os.getenv("SNOWFLAKE_PORT", 443),
        "authenticator": "oauth",
        "token_file_path": "/snowflake/session/token",
        "client_session_keep_alive": True,
    }
    return session_configs


def get_or_create_snowpark_session(
    custom_configs: dict | None = None,
) -> snowpark.Session:
    """
    snowpark connect code should use this function to create or get snowpark session
    """
    session_configs = {}
    if _is_running_in_SPCS():
        # Running in SPCS, use environment variables injected by SPCS run time
        # We don't use connections.toml file created by SPCS because of the 0600 permissions issue
        session_configs = _get_session_configs_from_ENV()
    else:
        session_configs["connection_name"] = DEFAULT_CONNECTION_NAME

    if os.getenv("SNOWFLAKE_DATABASE") is not None:
        session_configs["database"] = os.getenv("SNOWFLAKE_DATABASE")

    if os.getenv("SNOWFLAKE_SCHEMA") is not None:
        session_configs["schema"] = os.getenv("SNOWFLAKE_SCHEMA")

    if os.getenv("SNOWFLAKE_WAREHOUSE") is not None:
        session_configs["warehouse"] = os.getenv("SNOWFLAKE_WAREHOUSE")

    # add custom session configs
    if custom_configs:
        session_configs.update(custom_configs)

    old_session = _get_current_snowpark_session()
    new_session = snowpark.Session.builder.configs(session_configs).getOrCreate()
    if old_session is None or old_session.session_id != new_session.session_id:
        # every new session needs to be configured
        configure_snowpark_session(new_session)

    return new_session


def set_query_tags(spark_tags: Sequence[str]) -> None:
    """Sets Snowpark session query_tag value to the tag from the Spark request."""

    if any("," in tag for tag in spark_tags):
        raise ValueError("Tags cannot contain ','.")

    # TODO: Tags might not be set correctly in parallel workloads or multi-threaded code.
    snowpark_session = get_or_create_snowpark_session()
    spark_tags_str = ",".join(sorted(spark_tags)) if spark_tags else None

    if spark_tags_str != snowpark_session.query_tag:
        snowpark_session.query_tag = spark_tags_str
