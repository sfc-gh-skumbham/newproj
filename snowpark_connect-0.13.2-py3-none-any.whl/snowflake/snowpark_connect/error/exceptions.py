class SnowparkConnectException(Exception):
    """Parent class to all SnowparkConnect related exceptions."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)


class MissingDatabase(SnowparkConnectException):
    def __init__(self) -> None:
        super().__init__(
            "No default database found in session",
        )


class MissingSchema(SnowparkConnectException):
    def __init__(self) -> None:
        super().__init__(
            "No default schema found in session",
        )
