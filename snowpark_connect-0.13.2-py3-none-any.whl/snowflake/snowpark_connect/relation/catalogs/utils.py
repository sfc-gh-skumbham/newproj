from snowflake.connector.errors import ProgrammingError
from snowflake.snowpark_connect.relation.catalogs import CATALOGS, SNOWFLAKE_CATALOG
from snowflake.snowpark_connect.relation.catalogs.abstract_spark_catalog import (
    AbstractSparkCatalog,
)
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session

CURRENT_CATALOG = SNOWFLAKE_CATALOG
CURRENT_CATALOG_NAME = "spark_catalog"


def get_current_catalog() -> AbstractSparkCatalog:
    return CURRENT_CATALOG


def set_current_catalog(catalog_name: str | None) -> AbstractSparkCatalog:
    global CURRENT_CATALOG_NAME
    CURRENT_CATALOG_NAME = catalog_name
    if catalog_name in CATALOGS:
        return CATALOGS[catalog_name]

    sf_catalog = get_or_create_snowpark_session().catalog
    try:
        sf_catalog.setCurrentDatabase(catalog_name if catalog_name is not None else "")
        return get_current_catalog()
    except ProgrammingError as e:
        raise Exception(
            f"Catalog '{catalog_name}' plugin class not found: spark.sql.catalog.{catalog_name} is not defined"
        ) from e
