import typing
from itertools import chain

import pandas
import pyspark.sql.connect.proto.common_pb2 as common_proto
import pyspark.sql.connect.proto.types_pb2 as types_proto
from pyspark.errors.exceptions.base import AnalysisException

from snowflake import snowpark
from snowflake.snowpark import functions
from snowflake.snowpark._internal.analyzer.analyzer_utils import (
    quote_name_without_upper_casing,
    unquote_if_quoted,
)
from snowflake.snowpark.types import BooleanType
from snowflake.snowpark_connect import column_name_handler
from snowflake.snowpark_connect.config import auto_uppercase_ddl, global_config
from snowflake.snowpark_connect.relation.catalogs.abstract_spark_catalog import (
    AbstractSparkCatalog,
    _get_current_snowflake_schema,
    _process_multi_layer_database,
    _process_multi_layer_identifier,
)
from snowflake.snowpark_connect.type_mapping import proto_to_snowpark_type
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def _normalize_identifier(identifier: str | None) -> str | None:
    if identifier is None:
        return None
    return identifier.upper() if auto_uppercase_ddl() else identifier


def sf_quote(name: str | None) -> str | None:
    if name is None:
        return None
    return quote_name_without_upper_casing(_normalize_identifier(name))


class SnowflakeCatalog(AbstractSparkCatalog):
    def __init__(self) -> None:
        super().__init__(name="spark_catalog", description=None)

    def listDatabases(
        self,
        pattern: str | None = None,
    ) -> pandas.DataFrame:
        """List all databases accessible in Snowflake with an optional name to filter by."""
        # This pattern is case-sensitive while our SAS implementation is not
        catalog, sf_database, sf_schema = _process_multi_layer_database(pattern)
        sf_schema = sf_schema.replace("*", ".*")
        if catalog is not None and self != catalog:
            raise SnowparkConnectNotImplementedError(
                "Calling into another catalog is not currently supported"
            )
        sp_catalog = get_or_create_snowpark_session().catalog

        dbs = sp_catalog.list_schemas(
            database=sf_quote(sf_database),
            pattern=_normalize_identifier(sf_schema),
        )
        names: list[str] = list()
        catalogs: list[str] = list()
        descriptions: list[str | None] = list()
        locationUris: list[str] = list()
        for db in dbs:
            name = unquote_if_quoted(db.name)
            if name == "INFORMATION_SCHEMA" and global_config._get_config_setting(
                "spark.Catalog.databaseFilterInformationSchema"
            ):
                continue
            names.append(name)
            catalogs.append(self.name)
            descriptions.append(db.comment)
            locationUris.append(f"snowflake://{name}")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "description": descriptions,
                "locationUri": locationUris,
            }
        )

    def getDatabase(
        self,
        spark_dbName: str,
    ) -> pandas.DataFrame:
        """Listing a single database that's accessible in Snowflake."""
        return self.listDatabases(pattern=spark_dbName)

    def databaseExists(
        self,
        spark_dbName: str,
    ) -> pandas.DataFrame:
        """Whether a database with provided name exists in Snowflake."""
        return pandas.DataFrame({"exists": [not self.getDatabase(spark_dbName).empty]})

    def listTables(
        self,
        spark_dbName: str | None = None,
        pattern: str | None = None,
    ) -> pandas.DataFrame:
        """Listing all tables/views accessible in Snowflake, optionally filterable on database, schema, and a pattern for the table names."""
        sp_catalog = get_or_create_snowpark_session().catalog
        if spark_dbName is not None:
            catalog, sf_database, sf_schema = _process_multi_layer_database(
                spark_dbName
            )
            if catalog is not None and self != catalog:
                raise SnowparkConnectNotImplementedError(
                    "Calling into another catalog is not currently supported"
                )
        else:
            catalog = sf_database = sf_schema = None

        tables = sp_catalog.list_tables(
            database=sf_quote(sf_database),
            schema=sf_quote(sf_schema),
            pattern=_normalize_identifier(pattern),
        )
        views = sp_catalog.list_views(
            database=sf_quote(sf_database),
            schema=sf_quote(sf_schema),
            pattern=_normalize_identifier(pattern),
        )
        names: list[str] = list()
        catalogs: list[str] = list()
        namespaces: list[list[str | None]] = list()
        names: list[str] = list()
        descriptions: list[str | None] = list()
        table_types: list[str | None] = list()
        is_temporaries: list[bool] = list()
        for o in chain(tables, views):
            names.append(unquote_if_quoted(o.name))
            catalogs.append(self.name)
            namespaces.append([o.schema_name])
            descriptions.append(o.comment)
            table_types.append(o.kind)
            is_temporaries.append(o.kind == "TEMPORARY")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "namespace": namespaces,
                "description": descriptions,
                "tableType": table_types,
                "isTemporary": is_temporaries,
            }
        )

    def getTable(
        self,
        spark_tableName: str,
    ) -> pandas.DataFrame:
        """Listing a single table/view with provided name that's accessible in Snowflake."""
        sp_catalog = get_or_create_snowpark_session().catalog
        catalog, sf_database, sf_schema, table = _process_multi_layer_identifier(
            spark_tableName
        )
        if catalog is not None and self != catalog:
            raise SnowparkConnectNotImplementedError(
                "Calling into another catalog is not currently supported"
            )
        tables = sp_catalog.list_tables(
            database=sf_quote(sf_database),
            schema=sf_quote(sf_schema),
            pattern=_normalize_identifier(table),
        )
        views = sp_catalog.list_views(
            database=sf_quote(sf_database),
            schema=sf_quote(sf_schema),
            pattern=_normalize_identifier(table),
        )
        names: list[str] = list()
        catalogs: list[str] = list()
        namespaces: list[list[str | None]] = list()
        names: list[str] = list()
        descriptions: list[str | None] = list()
        table_types: list[str | None] = list()
        is_temporaries: list[bool] = list()
        for t in tables:
            names.append(unquote_if_quoted(t.name))
            catalogs.append(self.name)
            namespaces.append([t.schema_name])
            descriptions.append(t.comment)
            table_types.append(t.kind)
            is_temporaries.append(t.kind == "TEMPORARY")
        for v in views:
            names.append(unquote_if_quoted(v.name))
            catalogs.append(self.name)
            namespaces.append([v.schema_name])
            descriptions.append(v.comment)
            table_types.append(v.kind)
            is_temporaries.append(v.kind == "TEMPORARY")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "namespace": namespaces,
                "description": descriptions,
                "tableType": table_types,
                "isTemporary": is_temporaries,
            }
        )

    def tableExists(
        self,
        spark_tableName: str,
        spark_dbName: str | None,
    ) -> pandas.DataFrame:
        """Whether a table/view with provided name exists in Snowflake, optionally filterable with dbName.
        If no database is specified, first try to treat tableName as a multi-layer-namespace identifier
        (or fully qualified name), then try tableName as a normal table name in the current database if necessary.
        Argument dbName is not actually implemented yet while we figure out how to map databases from Spark to Snowflake.
        """
        table_mli = spark_tableName
        if spark_dbName:
            table_mli = f"{spark_dbName}.{table_mli}"
        tables = self.getTable(table_mli)
        return pandas.DataFrame(
            {
                "exists": [not tables.empty],
            }
        )

    def listColumns(
        self,
        spark_tableName: str,
        spark_dbName: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """List all columns in a table/view, optionally database name filter can be provided."""
        sp_catalog = get_or_create_snowpark_session().catalog
        if spark_dbName is None:
            catalog, sf_database, sf_schema, sf_table = _process_multi_layer_identifier(
                spark_tableName
            )
            if catalog is not None and self != catalog:
                raise SnowparkConnectNotImplementedError(
                    "Calling into another catalog is not currently supported"
                )
            columns = sp_catalog.list_columns(
                database=sf_quote(sf_database),
                schema=sf_quote(sf_schema),
                table_name=sf_quote(sf_table),
            )
        else:
            columns = sp_catalog.list_columns(
                schema=sf_quote(spark_dbName),
                table_name=sf_quote(spark_tableName),
            )
        names: list[str] = list()
        descriptions: list[str | None] = list()
        data_types: list[str] = list()
        nullables: list[bool] = list()
        is_partitions: list[bool] = list()
        is_buckets: list[bool] = list()
        for column in columns:
            names.append(unquote_if_quoted(column.name))
            descriptions.append(column.comment)
            data_types.append(column.datatype)
            nullables.append(bool(column.nullable))
            is_partitions.append(False)
            is_buckets.append(False)

        return pandas.DataFrame(
            {
                "name": names,
                "description": descriptions,
                "dataType": data_types,
                "nullable": nullables,
                "isPartition": is_partitions,
                "isBucket": is_buckets,
            }
        )

    def currentDatabase(self) -> pandas.DataFrame:
        """Get the currently used database's name."""
        db_name = _get_current_snowflake_schema()
        assert db_name is not None, "current database could not be confirmed"
        return pandas.DataFrame({"current_database": [unquote_if_quoted(db_name)]})

    def setCurrentDatabase(
        self,
        spark_dbName: str,
    ) -> pandas.DataFrame:
        """Set the currently used database's name."""
        sp_catalog = get_or_create_snowpark_session().catalog
        sp_catalog.setCurrentSchema(sf_quote(spark_dbName))
        return pandas.DataFrame({"current_database": [spark_dbName]})

    def dropGlobalTempView(
        self,
        spark_view_name: str,
    ) -> snowpark.DataFrame:
        session = get_or_create_snowpark_session()
        schema = global_config.spark_sql_globalTempDatabase
        result_df = session.sql(
            "drop view if exists identifier(?)",
            params=[f"{sf_quote(schema)}.{sf_quote(spark_view_name)}"],
        )
        result_df = result_df.select(
            functions.contains('"status"', functions.lit("successfully dropped")).alias(
                "value"
            )
        )
        columns = ["value"]
        return column_name_handler.build_column_map(
            result_df, columns, columns, [BooleanType()]
        )

    def dropTempView(
        self,
        spark_view_name: str,
    ) -> snowpark.DataFrame:
        """Drop the current temporary view."""
        session = get_or_create_snowpark_session()
        result = session.sql(
            "drop view if exists identifier(?)",
            params=[sf_quote(spark_view_name)],
        ).collect()
        view_was_dropped = (
            len(result) == 1 and "successfully dropped" in result[0]["status"]
        )
        result_df = session.createDataFrame([(view_was_dropped,)], schema=["value"])
        columns = ["value"]
        return column_name_handler.build_column_map(
            result_df, columns, columns, [BooleanType()]
        )

    def createTable(
        self,
        tableName: str,
        path: str,
        source: str,
        schema: types_proto.DataType,
        description: str,
        **options: typing.Any,
    ) -> snowpark.DataFrame:
        """Create either an external, or a managed table.

        If path is supplied in which the data for this table exists. When path is specified, an external table is
        created from the data at the given path. Otherwise a managed table is created.

        In case a managed table is being created, schema is required.
        """
        # TODO: support fully-qualified tableName
        if source == "":
            source = global_config.get("spark.sql.sources.default")
        if source not in ("csv", "json", "avro", "parquet", "orc", "xml"):
            raise SnowparkConnectNotImplementedError(
                f"Source '{source}' is not currently supported by Catalog.createTable. "
                "Maybe default value through 'spark.sql.sources.default' should be set."
            )
        session = get_or_create_snowpark_session()
        if path == "":
            # Managed table
            if schema.ByteSize() == 0:
                raise SnowparkConnectNotImplementedError(
                    f"Unable to infer schema for {source.upper()}. It must be specified manually.",
                )
            sp_schema = proto_to_snowpark_type(schema)
            columns = [c.name for c in schema.struct.fields]
            column_types = [f.datatype for f in sp_schema.fields]
            return column_name_handler.build_column_map(
                session.createDataFrame([], sp_schema), columns, columns, column_types
            )
        else:
            # External table
            raise SnowparkConnectNotImplementedError(
                "External table creation is not supported currently."
            )

    def isCached(self, spark_tableName: str) -> pandas.DataFrame:
        """Whether a table is cached by us locally.

        Check whether a table exists and then delegate to the local cache.
        """
        if not self.tableExists(spark_tableName, None).iloc[0, 0]:
            raise AnalysisException(
                f"[TABLE_OR_VIEW_NOT_FOUND] The table or view  `{spark_tableName}` cannot be found."
            )
        return super().isCached(spark_tableName)

    def cacheTable(
        self,
        spark_tableName: str,
        storageLevel: common_proto.StorageLevel | None = None,
    ) -> pandas.DataFrame:
        """Cache a table, or view locally.

        Check whether a table exists and then delegate to the local cache.
        """
        if not self.tableExists(spark_tableName, None).iloc[0, 0]:
            raise AnalysisException(
                f"[TABLE_OR_VIEW_NOT_FOUND] The table or view  `{spark_tableName}` cannot be found."
            )
        return super().cacheTable(spark_tableName, storageLevel)

    def uncacheTable(self, spark_tableName: str) -> pandas.DataFrame:
        """Uncache a table, or view locally.

        Check whether a table exists and then delegate to the local cache.
        """
        if not self.tableExists(spark_tableName, None).iloc[0, 0]:
            raise AnalysisException(
                f"[TABLE_OR_VIEW_NOT_FOUND] The table or view  `{spark_tableName}` cannot be found."
            )
        return super().uncacheTable(spark_tableName)
