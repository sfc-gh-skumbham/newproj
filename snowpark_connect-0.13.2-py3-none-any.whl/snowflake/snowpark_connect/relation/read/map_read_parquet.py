import collections
import os
from collections.abc import Callable

import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark import (
    DataFrame,
    DataFrameReader,
    Session,
    functions as snowpark_fn,
)
from snowflake.snowpark._internal.analyzer import analyzer_utils
from snowflake.snowpark._internal.analyzer.analyzer_utils import (
    quote_name_without_upper_casing,
)
from snowflake.snowpark.types import DataType, DoubleType, IntegerType, StringType
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.config import auto_uppercase_ddl
from snowflake.snowpark_connect.relation.read.map_read import ReaderConfig
from snowflake.snowpark_connect.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_read_parquet(
    rel: relation_proto.Relation,
    schema: str | None,
    session: snowpark.Session,
    paths: list[str],
    options: ReaderConfig,
) -> snowpark.DataFrame:
    """
    Read a Parquet file into a Snowpark DataFrame.

    We leverage the stage that is already created in the map_read function that
    calls this.
    """

    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise SnowparkConnectNotImplementedError(
            "Streaming is not supported for Parquet files."
        )
    else:
        snowpark_options = options.convert_to_snowpark_args()
        assert schema is None, "Read PARQUET does not support user schema"
        assert len(paths) > 0, "Read PARQUET expects at least one path"

        reader = session.read.options(snowpark_options)
        df = _read_parquet(session, reader, paths[0])

        if len(paths) > 1:
            for p in paths[1:]:
                reader._user_schema = None
                df = df.union_all(_read_parquet(session, reader, p))

        renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(
            df, rel.common.plan_id
        )
        return build_column_map(
            renamed_df,
            [analyzer_utils.unquote_if_quoted(c) for c in df.columns],
            snowpark_column_names,
            [f.datatype for f in df.schema.fields],
        )


def _read_parquet(session: Session, reader: DataFrameReader, path: str) -> DataFrame:
    """Reads parquet file(s) and appends partition columns if needed"""

    partitions, inferred_types = _find_unique_partitions(session, path)
    partitions = list(partitions)

    if not partitions:
        return reader.parquet(path)

    df = reader.parquet(os.path.join(path, partitions[0]))
    df = _add_partition_columns(df, partitions[0], inferred_types)

    for partition in partitions[1:]:
        # Parquet does not support user schema - we need to set it to None before reusing the same reader
        reader._user_schema = None
        other_df = reader.parquet(os.path.join(path, partition))
        other_df = _add_partition_columns(other_df, partition, inferred_types)

        df = df.union_all(other_df)

    return df


def _add_partition_columns(
    df: DataFrame, partition: str, inferred_types: dict[str, DataType]
) -> DataFrame:
    """
    Appends partition columns to the DataFrame.
    For example if partition is equal to "ab=cx=1/x=2", the result data frame might look like this:
    | col1 | x | y |
    |--------------|
    | val1 | 1 | 2 |
    | val2 | 1 | 2 |
    | val3 | 1 | 2 |
    """

    new_col_names = []
    new_col_values = []
    for partition_col in partition.split("/"):
        column_name, value = _parse_partition_column(partition_col)

        column_name_quoted = quote_name_without_upper_casing(column_name)
        if auto_uppercase_ddl():
            column_name_quoted = column_name.upper()

        new_col_names.append(column_name_quoted)
        new_col_values.append(
            snowpark_fn.cast(snowpark_fn.lit(value), inferred_types[column_name])
        )

    return df.with_columns(new_col_names, new_col_values)


# TODO: Add telemetry on how many unique parquet partitions are found
def _find_unique_partitions(
    session: Session, stage_path: str
) -> tuple[set[str], dict[str, DataType]]:
    """
    Extracts a set of unique parquet partition columns from a specific stage location and infer their types.

    For example if there are the following paths under the stage_path:
    - <stage_path>/x=a/y=1/file1.parquet
    - <stage_path>/x=1/y=2/file2.parquet
    - <stage_path>/x=2/y=1/file3.parquet

    This function will return {"x=a/y=1", "x=1/y=2", "x=2/y=1"}, {"x": StringType(), "y": IntegerType()}
    """

    unique_partitions = set()
    start_path_segments = len(list(filter(None, stage_path.split("/"))))

    partition_columns_values = collections.defaultdict(set)
    dir_level_to_column_name = {}

    files_on_stage = (
        session.sql(f"LS {stage_path}").select('"name"').to_local_iterator()
    )

    for row in files_on_stage:
        cloud_path: list[str] = row[0].split("://")  # Remove a cloud prefix, e.g. s3://
        file_path = cloud_path[1] if len(cloud_path) == 2 else cloud_path[0]

        path_segments = []
        seen_column_names_in_current_partition = set()

        for dir_level, path_segment in enumerate(
            file_path.split("/")[start_path_segments:-1]
        ):
            if "=" not in path_segment:  # not a partition directory
                if dir_level in dir_level_to_column_name:
                    raise ValueError(
                        f"Conflicting directory structures detected. Suspicious path: {file_path}"
                    )
                break

            col_name, partition_value = _parse_partition_column(path_segment)

            if not col_name:
                raise ValueError(f"Empty partition column name in '{path_segment}'")

            if not partition_value:
                raise ValueError(f"Empty partition value in '{path_segment}'")

            if col_name in seen_column_names_in_current_partition:
                raise ValueError(
                    f"[COLUMN_ALREADY_EXISTS] The column `{col_name}` already exists. Consider to choose another name or rename the existing column."
                )

            seen_column_names_in_current_partition.add(col_name)

            if dir_level not in dir_level_to_column_name:
                dir_level_to_column_name[dir_level] = col_name

            if dir_level_to_column_name[dir_level] != col_name:
                raise ValueError(
                    f"Conflicting partition column names detected {dir_level_to_column_name[dir_level]}"
                )

            partition_columns_values[col_name].add(partition_value)
            path_segments.append(path_segment)

        if path_segments:
            unique_partitions.add("/".join(path_segments))

    partition_column_types = {
        col_name: _infer_partition_column_type(values)
        for col_name, values in partition_columns_values.items()
    }

    return unique_partitions, partition_column_types


def _infer_partition_column_type(values: set[str]) -> DataType:
    def _is_castable(value: str, type_: Callable) -> bool:
        try:
            type_(value)
            return True
        except ValueError:
            return False

    if all(_is_castable(value, int) for value in values):
        return IntegerType()

    if all(_is_castable(value, float) for value in values):
        return DoubleType()

    return StringType()


def _parse_partition_column(name: str) -> tuple[str, str]:
    """Extracts column name and partition value from a path segment."""

    col_name, partition_value = name.split("=", maxsplit=1)

    return col_name, partition_value
