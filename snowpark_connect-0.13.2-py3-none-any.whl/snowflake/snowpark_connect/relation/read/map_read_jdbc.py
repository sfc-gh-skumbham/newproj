import jaydebeapi
import jpype
import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.read.jdbc_read_dbapi import JdbcDataFrameReader
from snowflake.snowpark_connect.relation.read.utils import (
    Connection,
    rename_columns_as_snowflake_standard,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger


def create_connection(jdbc_options: dict[str, str]) -> Connection:
    url = jdbc_options.get("url", None)
    driver = jdbc_options.get("driver", None)
    if driver is None:
        driver = (
            jpype.java.sql.DriverManager.getDriver(url).getClass().getCanonicalName()
        )
    try:
        return jaydebeapi.connect(driver, url, jdbc_options)
    except Exception as e:
        jpype.detachThreadFromJVM()
        raise Exception(f"Error connecting JDBC datasource: {e}")


def close_connection(conn: Connection) -> None:
    if conn is not None:
        conn.close()
    # JVM main thread and SAS Server main thread creates deadlock.
    # jaydebeapi has connect method which calls jpype internally.
    # jpype start JVM if it's not started.
    # Then jpype attach the current thread to the JVM.
    # But jaydebeapi doesn't have any method to detach or shutdown the JVM.
    jpype.detachThreadFromJVM()


def map_read_jdbc(
    rel: relation_proto.Relation,
    session: snowpark.Session,
    options: dict[str, str],
) -> snowpark.DataFrame:
    """
    Read a table data or query data from a JDBC external datasource into a Snowpark DataFrame.
    """

    jdbc_options = options.copy()
    dbtable = options.get("dbtable", None)
    query = options.get("query", None)
    partition_column = options.get("partitionColumn", None)
    lower_bound = options.get("lowerBound", None)
    upper_bound = options.get("upperBound", None)
    num_partitions = options.get("numPartitions", None)
    predicates = rel.read.data_source.predicates

    logger.info(
        f"dbtable={dbtable},query={query},partition_column={partition_column},lower_bound={lower_bound},upper_bound={upper_bound},num_partitions={num_partitions}"
    )
    if num_partitions is not None:
        num_partitions = int(num_partitions)

    if len(dbtable) == 0:
        dbtable = None

    if not dbtable and not query:
        raise ValueError("Include dbtable or query is required option")

    if query is not None and dbtable is not None:
        raise ValueError(
            "Not allowed to specify dbtable and query options at the same time"
        )

    if query is not None and partition_column is not None:
        raise ValueError(
            "Not allowed to specify partitionColumn and query options at the same time"
        )

    try:
        df = JdbcDataFrameReader(session, jdbc_options).jdbc_read_dbapi(
            create_connection,
            close_connection,
            table=dbtable,
            query=query,
            column=partition_column,
            lower_bound=lower_bound,
            upper_bound=upper_bound,
            num_partitions=num_partitions,
            predicates=predicates,
        )
        true_names = list(map(lambda x: unquote_if_quoted(x).lower(), df.columns))
        renamed_df, snowpark_cols = rename_columns_as_snowflake_standard(
            df, rel.common.plan_id
        )
        return build_column_map(
            renamed_df,
            true_names,
            snowpark_cols,
            [f.datatype for f in df.schema.fields],
        )
    except Exception as e:
        raise Exception(f"Error accessing JDBC datasource for read: {e}")
