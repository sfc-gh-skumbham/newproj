import datetime
import decimal
import inspect
from typing import Any, List, Tuple

import pyspark.sql.connect.proto.relations_pb2 as relation_proto
import pyspark.sql.connect.proto.types_pb2 as types_proto
from pyspark.errors.exceptions.base import PySparkTypeError, PythonException
from pyspark.serializers import CloudPickleSerializer

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark.functions import col, parse_json
from snowflake.snowpark.types import ArrayType, MapType, StructType, VariantType
from snowflake.snowpark_connect.column_name_handler import (
    ColumnNameMap,
    build_column_map,
)
from snowflake.snowpark_connect.config import (
    get_boolean_session_config_param,
    global_config,
)
from snowflake.snowpark_connect.expression.map_expression import (
    map_single_column_expression,
)
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import (
    parse_ddl_string,
    proto_to_snowpark_type,
)
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session


def build_expected_types_from_parsed(
    parsed_return: types_proto.DataType,
) -> List[Tuple[str, Any]]:
    """
    Recursively build expected_types from a PySpark StructType schema.
    Each entry is a tuple: (kind, type_marker)
    kind: "scalar", "array", or "struct"
    type_marker: for scalar, a tuple (python_type, marker_dict); for array, (python_type, marker_dict); for struct, dict of fields
    """

    def parse_type_marker(
        typ: types_proto.DataType,
    ) -> Tuple[str, Any]:
        match typ.WhichOneof("kind"):
            case "map":
                key_type = parse_type_marker(typ.map.key_type)
                value_type = parse_type_marker(typ.map.value_type)
                return "scalar", (dict, {"dict": (key_type, value_type)})
            case "array":
                element_type = parse_type_marker(typ.array.element_type)
                return "array", element_type
            case "struct":
                struct_fields = {
                    sf.name: parse_type_marker(sf.data_type) for sf in typ.struct.fields
                }
                return "struct", struct_fields
            case "string":
                return "scalar", (str, "string")
            case "integer" | "short" | "long":
                return "scalar", (int, "int")
            case "float" | "double":
                return "scalar", (float, "float")
            case "boolean":
                return "scalar", (bool, "bool")
            case "date":
                return "scalar", (datetime.date, "date")
            case "timestamp":
                return "scalar", (datetime.datetime, "timestamp")
            case "binary":
                return "scalar", (bytes, "binary")
            case "byte":
                # ByteType in Spark represents an 8-bit signed integer (values from -128 to 127), not a bytes type
                return "scalar", (int, "byte")
            case "decimal":
                # Use Spark's default precision (10) and scale (0) if not specified in the proto
                precision = (
                    typ.decimal.precision if typ.decimal.HasField("precision") else 10
                )
                scale = typ.decimal.scale if typ.decimal.HasField("scale") else 0
                marker = {"type": "decimal", "precision": precision, "scale": scale}
                return "scalar", (decimal.Decimal, marker)
            case _:
                return "scalar", (object, "unknown")

    return [parse_type_marker(field.data_type) for field in parsed_return.struct.fields]


def spark_compatible_udtf_wrapper(
    user_udtf_cls: type, expected_types: list[tuple[str, Any]]
) -> type:
    """
    UDTF Wrapper class to mimic Spark's output type coercion and error handling.
    """

    def _coerce_to_bool(val: object) -> bool | None:
        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            v_str = val.strip().lower()
            if v_str == "true":
                return True
            if v_str == "false":
                return False
        return None

    def _coerce_to_int(val: object) -> int | None:
        if isinstance(val, bool):
            return 1 if val else 0
        if isinstance(val, int):
            return val
        return None

    def _coerce_to_float(val: object) -> float | None:
        if isinstance(val, float):
            return val
        return None

    def _coerce_to_date(val: object) -> datetime.date | None:
        if isinstance(val, datetime.date):
            return val
        if isinstance(val, datetime.datetime):
            return val.date()
        raise AttributeError(f"Invalid date value {val}")

    def _coerce_to_binary(val: object, target_type_name: str = "byte") -> bytes | None:
        if target_type_name == "binary":
            if isinstance(val, (bytes, bytearray)):
                return val
            elif isinstance(val, str):
                return val.encode("utf-8")
            return None

        if target_type_name == "byte":
            if isinstance(val, (bytes, bytearray)):
                return val
            elif isinstance(val, int):
                return str(val).encode("utf-8")

        return None

    def _coerce_to_decimal(val: object) -> decimal.Decimal | None:
        if isinstance(val, decimal.Decimal):
            return val
        return None

    def _coerce_to_py_string(val: object) -> str | None:
        if val is None:
            return None

        # Special handling for dictionaries to match PySpark format
        if isinstance(val, dict):
            # Format dictionaries using "=" instead of ":" for key-value pairs
            dict_items = [f"{k}={v}" for k, v in val.items()]
            return "{" + ", ".join(dict_items) + "}"

        return str(val)

    def _coerce_generic_scalar(
        val: object, target_py_type: type, marker: object = None
    ) -> object | None:
        if val is None:
            return None

        if isinstance(marker, dict) and "dict" in marker:
            # If expected type is a dict but val is not a dict, return None
            if not isinstance(val, dict):
                return None
            key_type_info, value_type_info = marker["dict"]
            return {
                _spark_coerce_value_recursive(
                    k, key_type_info
                ): _spark_coerce_value_recursive(v, value_type_info)
                for k, v in val.items()
            }

        if target_py_type is object:
            return val
        try:
            return target_py_type(val)
        except (ValueError, TypeError):
            return None

    def _coerce_to_timestamp(val: object) -> datetime.datetime | None:
        if isinstance(val, datetime.datetime):
            return val
        raise AttributeError(f"Invalid time stamp value {val}")

    SCALAR_COERCERS = {
        bool: _coerce_to_bool,
        int: _coerce_to_int,
        float: _coerce_to_float,
        datetime.date: _coerce_to_date,
        datetime.datetime: _coerce_to_timestamp,
        bytes: _coerce_to_binary,
        bytearray: _coerce_to_binary,
        decimal.Decimal: _coerce_to_decimal,
        str: _coerce_to_py_string,
    }

    def _spark_coerce_value_recursive(
        val: object, type_info_tuple: tuple[str, object]
    ) -> object | None:
        """
        We will try to coerce the value returned by the user process method to the expected type.
        """
        kind, py_type_or_struct_info = type_info_tuple

        if kind == "scalar":
            target_py_type, marker = py_type_or_struct_info
            coercer = SCALAR_COERCERS.get(target_py_type)
            if coercer:
                if marker == "binary":
                    return coercer(val, marker)
                return coercer(val)
            return _coerce_generic_scalar(val, target_py_type, marker)

        elif kind == "array":
            element_type_info = py_type_or_struct_info
            if not isinstance(val, (list, tuple)):
                return None
            return [_spark_coerce_value_recursive(v, element_type_info) for v in val]

        elif kind == "struct":
            struct_fields_info = py_type_or_struct_info
            if val is None:
                return {fname: None for fname in struct_fields_info}
            coerced_struct = {}
            if isinstance(val, dict):
                for fname, field_type_info in struct_fields_info.items():
                    coerced_struct[fname] = _spark_coerce_value_recursive(
                        val.get(fname), field_type_info
                    )
            elif isinstance(val, (tuple, list)):
                field_names = list(struct_fields_info.keys())
                for i, fname in enumerate(field_names):
                    field_type_info = struct_fields_info[fname]
                    v = val[i] if i < len(val) else None
                    coerced_struct[fname] = _spark_coerce_value_recursive(
                        v, field_type_info
                    )
            else:
                for fname, field_type_info in struct_fields_info.items():
                    v = getattr(val, fname, None)
                    coerced_struct[fname] = _spark_coerce_value_recursive(
                        v, field_type_info
                    )
            return coerced_struct
        else:
            return val

    class WrappedUDTF:
        def __init__(self, *args, **kwargs) -> None:
            try:
                self._user_instance = user_udtf_cls(*args, **kwargs)
                self._user_method = self._user_instance.eval
            except Exception as e:
                raise RuntimeError(
                    f"[UDTF_EXEC_ERROR] User defined table function encountered an error in the '__init__' method: {e}"
                )

        def process(self, *args, **kwargs):
            # Pre-process args and kwargs to convert SqlNullWrapper to None before calling user's eval
            processed_args = [
                None if type(arg).__name__ == "sqlNullWrapper" else arg for arg in args
            ]
            processed_kwargs = {
                k: (None if type(v).__name__ == "sqlNullWrapper" else v)
                for k, v in kwargs.items()
            }

            result_iter = self._user_method(*processed_args, **processed_kwargs)
            if result_iter is None:
                return  # Do not yield anything, so result is []

            for raw_row_tuple in result_iter:
                if raw_row_tuple is None:
                    yield tuple([None] * len(expected_types))
                    continue

                if not isinstance(raw_row_tuple, (tuple, list)):
                    raise TypeError(
                        f"[UDTF_INVALID_OUTPUT_ROW_TYPE] return value should be an iterable object containing tuples, but got {type(raw_row_tuple)}"
                    )

                if len(raw_row_tuple) != len(expected_types):
                    raise RuntimeError(
                        f"[UDTF_RETURN_SCHEMA_MISMATCH] The number of columns in the result does not match the specified schema. Expected {len(expected_types)} columns, but got {len(raw_row_tuple)}"
                    )

                # Check for struct type mismatch
                for i, (val, type_info) in enumerate(
                    zip(raw_row_tuple, expected_types)
                ):
                    kind, type_marker = type_info
                    # If expected type is struct but received a scalar primitive value
                    if (
                        kind == "struct"
                        and not isinstance(val, (dict, list, tuple))
                        and val is not None
                    ):
                        raise RuntimeError(
                            f"[UNEXPECTED_TUPLE_WITH_STRUCT] Expected a struct for column at position {i}, but got a primitive value of type {type(val)}"
                        )

                coerced_row_list = [None] * len(expected_types)
                for i, (val, type_info) in enumerate(
                    zip(raw_row_tuple, expected_types)
                ):
                    coerced_row_list[i] = _spark_coerce_value_recursive(val, type_info)

                yield tuple(coerced_row_list)

        def end_partition(self, *args, **kwargs):
            if hasattr(self._user_instance, "terminate") and callable(
                self._user_instance.terminate
            ):
                return self._user_instance.terminate(*args, **kwargs)

    return WrappedUDTF


def spark_compatible_udtf_wrapper_with_arrow(
    user_udtf_cls: type, expected_types: list[tuple[str, Any]]
) -> type:
    import pyarrow as pa

    def _python_type_to_arrow_type_impl(
        type_info_tuple: tuple[str, Any]
    ) -> pa.DataType:
        kind, type_marker = type_info_tuple
        if kind == "scalar":
            target_py_type, marker_val = type_marker
            if marker_val == "byte" and target_py_type is int:
                return pa.int8()
            elif target_py_type is str:
                return pa.string()
            elif target_py_type is bool:
                return pa.bool_()
            elif target_py_type is int:
                return pa.int64()
            elif target_py_type is float:
                return pa.float64()
            elif target_py_type is bytes:
                return pa.binary()
            elif target_py_type is bytearray:
                return pa.binary()
            elif target_py_type is decimal.Decimal:
                if isinstance(marker_val, dict) and marker_val.get("type") == "decimal":
                    precision = marker_val.get("precision", 10)
                    scale = marker_val.get("scale", 0)
                    return pa.decimal128(precision, scale)
                else:
                    return pa.decimal128(38, 18)
            elif target_py_type is datetime.date:
                return pa.date32()
            elif target_py_type is datetime.datetime:
                return pa.timestamp("us", tz=None)
            elif isinstance(marker_val, dict) and "dict" in marker_val:
                key_info, value_info = marker_val["dict"]
                key_type = _python_type_to_arrow_type_impl(key_info)
                value_type = _python_type_to_arrow_type_impl(value_info)
                return pa.map_(key_type, value_type)
            else:
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Unsupported Python scalar type for Arrow conversion: {target_py_type}"
                )
        elif kind == "array":
            element_type_info = type_marker
            element_arrow_type = _python_type_to_arrow_type_impl(element_type_info)
            return pa.list_(element_arrow_type)
        elif kind == "struct":
            struct_fields_info = type_marker
            if not isinstance(struct_fields_info, dict):
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Invalid struct definition for Arrow: expected dict, got {type(struct_fields_info)}"
                )
            fields = []
            for field_name, field_type_info in struct_fields_info.items():
                field_arrow_type = _python_type_to_arrow_type_impl(field_type_info)
                fields.append(pa.field(field_name, field_arrow_type))
            return pa.struct(fields)
        else:
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Unsupported data kind for Arrow conversion: {kind}"
            )

    def _convert_to_arrow_value(
        obj: Any, arrow_type: pa.DataType, parent_container_type: str | None = None
    ) -> Any:
        if obj is None:
            return None

        if pa.types.is_list(arrow_type):
            if isinstance(obj, dict):
                # When dict is provided for array type, extract keys
                return [
                    _convert_to_arrow_value(k, arrow_type.value_type, "array")
                    for k in obj.keys()
                ]
            if isinstance(obj, str):
                # When string is provided for array type, split into characters
                return [
                    _convert_to_arrow_value(char, arrow_type.value_type, "array")
                    for char in obj
                ]
            if not isinstance(obj, (list, tuple)):
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Expected list or tuple for Arrow array type, got {type(obj).__name__}"
                )
            element_type = arrow_type.value_type
            return [_convert_to_arrow_value(e, element_type, "array") for e in obj]

        if pa.types.is_map(arrow_type):
            if not isinstance(obj, dict):
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Expected dict for Arrow map type, got {type(obj).__name__}"
                )
            key_type = arrow_type.key_type
            value_type = arrow_type.item_type
            return {
                _convert_to_arrow_value(k, key_type): _convert_to_arrow_value(
                    v, value_type
                )
                for k, v in obj.items()
            }

        if pa.types.is_struct(arrow_type):
            names = [field.name for field in arrow_type]
            field_arrow_types = [field.type for field in arrow_type]

            if isinstance(obj, dict):
                output_struct_dict = {}
                for i, name in enumerate(names):
                    field_type = field_arrow_types[i]
                    output_struct_dict[name] = _convert_to_arrow_value(
                        obj.get(name), field_type, "struct"
                    )
                return output_struct_dict
            else:
                # If the UDTF yields a list/tuple (or anything not a dict) for a struct column, it's an error.
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Expected a dictionary for Arrow struct type column, but got {type(obj).__name__}"
                )

        # Check if a scalar type is expected and if obj is a collection; if so, error out.
        # This must be after handling list, map, struct which are collections themselves.
        if not (
            pa.types.is_list(arrow_type)
            or pa.types.is_map(arrow_type)
            or pa.types.is_struct(arrow_type)
        ):
            if isinstance(obj, (list, tuple, dict)):
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert Python collection type {type(obj).__name__} to scalar Arrow type {arrow_type}"
                )

        if pa.types.is_boolean(arrow_type):
            if isinstance(obj, bool):
                return obj
            # For array elements, allow conversion from numbers
            if parent_container_type == "array" and isinstance(obj, (int, float)):
                return bool(obj)
            # Only convert numbers 0 and 1 to boolean for non-array contexts
            if isinstance(obj, (int, float)):
                if obj == 0:
                    return False
                elif obj == 1:
                    return True
                raise TypeError(
                    f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {obj} to Arrow boolean"
                )
            if isinstance(obj, str):
                v_str = obj.strip().lower()
                if v_str == "true":
                    return True
                if v_str == "false":
                    return False
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow boolean"
            )

        if pa.types.is_integer(arrow_type):
            if isinstance(obj, bool):
                return int(obj)
            if isinstance(obj, int):
                return obj
            if isinstance(obj, float):
                return int(obj)
            if isinstance(obj, str):
                try:
                    return int(obj)
                except ValueError:
                    pass
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow integer"
            )

        if pa.types.is_floating(arrow_type):
            if isinstance(obj, (int, float)):
                return float(obj)
            if isinstance(obj, str):
                try:
                    return float(obj)
                except ValueError:
                    pass
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow float"
            )

        if pa.types.is_string(arrow_type):
            # For array elements and struct fields, allow conversion from numeric types
            if parent_container_type in ["array", "struct"] and isinstance(
                obj, (int, float, bool)
            ):
                return str(obj)
            if isinstance(obj, str):
                return obj
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow string"
            )

        if pa.types.is_binary(arrow_type) or pa.types.is_fixed_size_binary(arrow_type):
            if isinstance(obj, (bytes, bytearray)):
                return bytes(obj)
            if isinstance(obj, str):
                return bytearray(obj.encode("utf-8"))
            if isinstance(obj, int):
                return bytearray([obj])
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow binary"
            )

        if pa.types.is_date(arrow_type):
            if isinstance(obj, datetime.date):
                return obj
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow date. Expected datetime.date."
            )

        if pa.types.is_timestamp(arrow_type):
            if isinstance(obj, datetime.datetime):
                return obj
            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow timestamp. Expected datetime.datetime."
            )

        if pa.types.is_decimal(arrow_type):
            if isinstance(obj, decimal.Decimal):
                return obj
            if isinstance(obj, int):
                return decimal.Decimal(obj)
            if isinstance(obj, str):
                try:
                    return decimal.Decimal(obj)
                except decimal.InvalidOperation:
                    pass

            raise TypeError(
                f"[UDTF_ARROW_TYPE_CAST_ERROR] Cannot convert {type(obj).__name__} to Arrow decimal. Expected decimal.Decimal or compatible int/str."
            )

        raise TypeError(
            f"[UDTF_ARROW_TYPE_CAST_ERROR] Unsupported type conversion for {type(obj).__name__} to Arrow type {arrow_type}"
        )

    class WrappedUDTF:
        def __init__(self, *args, **kwargs) -> None:
            try:
                self._user_instance = user_udtf_cls(*args, **kwargs)
                self._user_method = self._user_instance.eval
            except Exception as e:
                raise RuntimeError(
                    f"[UDTF_EXEC_ERROR] User defined table function encountered an error in the '__init__' method: {e}"
                )

        def process(self, *args, **kwargs):
            # Pre-process args and kwargs to convert SqlNullWrapper to None before calling user's eval
            processed_args = [
                None if type(arg).__name__ == "sqlNullWrapper" else arg for arg in args
            ]
            processed_kwargs = {
                k: (None if type(v).__name__ == "sqlNullWrapper" else v)
                for k, v in kwargs.items()
            }

            result_iter = self._user_method(*processed_args, **processed_kwargs)
            if result_iter is None:
                return  # Do not yield anything, so result is []

            for raw_row_output in result_iter:
                if not isinstance(raw_row_output, (tuple,)):
                    if len(expected_types) == 1:
                        raw_row_tuple = (raw_row_output,)
                    else:  # If multiple output columns expected, but not a tuple, this is a mismatch
                        raise ValueError(
                            f"[UDTF_RETURN_SCHEMA_MISMATCH] Expected a tuple of length {len(expected_types)} for multiple output columns, but got {type(raw_row_output).__name__}"
                        )
                else:
                    raw_row_tuple = raw_row_output

                if len(raw_row_tuple) != len(expected_types):
                    raise ValueError(
                        f"[UDTF_RETURN_SCHEMA_MISMATCH] The number of columns in the result does not match the specified schema. Expected {len(expected_types)} columns, but got {len(raw_row_tuple)}"
                    )

                coerced_row_list = [None] * len(expected_types)
                for i, (val, type_info) in enumerate(
                    zip(raw_row_tuple, expected_types)
                ):
                    arrow_type = _python_type_to_arrow_type_impl(type_info)
                    coerced_row_list[i] = _convert_to_arrow_value(val, arrow_type)

                yield tuple(coerced_row_list)

        def end_partition(self, *args, **kwargs):
            if hasattr(self._user_instance, "terminate") and callable(
                self._user_instance.terminate
            ):
                return self._user_instance.terminate(*args, **kwargs)

    return WrappedUDTF


def convert_maptype_to_variant(schema: StructType) -> StructType:
    """
    Recursively convert all MapType fields in a StructType (or ArrayType of StructType) to VariantType.
    """
    if isinstance(schema, StructType):
        for field in schema.fields:
            if isinstance(field.datatype, MapType):
                field.datatype = VariantType()
            elif isinstance(field.datatype, StructType):
                convert_maptype_to_variant(field.datatype)
            elif isinstance(field.datatype, ArrayType):
                # If array of struct/map, recurse
                if isinstance(field.datatype.element_type, MapType):
                    field.datatype.element_type = VariantType()
                elif isinstance(field.datatype.element_type, StructType):
                    convert_maptype_to_variant(field.datatype.element_type)
    return schema


def udtf_helper(udtf_proto: relation_proto.CommonInlineUserDefinedTableFunction):
    udtf = udtf_proto.python_udtf
    callable_func = CloudPickleSerializer().loads(udtf.command)
    parsed_return = udtf.return_type
    try:
        if udtf.return_type.HasField("unparsed"):
            parsed_return = parse_ddl_string(udtf.return_type.unparsed.data_type_string)
    except ValueError as e:
        raise PythonException(
            f"[UDTF_ARROW_TYPE_CAST_ERROR] Error parsing UDTF return type DDL: {e}"
        )
    original_output_schema = proto_to_snowpark_type(parsed_return)

    output_schema = proto_to_snowpark_type(parsed_return)
    # Snowflake UDTF does not support MapType, so we convert it to VariantType.
    output_schema = convert_maptype_to_variant(output_schema)
    func_signature = inspect.signature(callable_func.eval)
    if global_config.get("snowpark.connect.udf.packages", "") != "":
        packages = [
            p.strip()
            for p in global_config.get("snowpark.connect.udf.packages")
            .strip("[]")
            .split(",")
        ]
    else:
        packages = []
    # Set all input types to VariantType regardless of type hints so that we can pass all arguments as VariantType.
    # Otherwise, we will run into issues with type mismatches. This only applies for UDTF registration.
    # We subtract one here since UDTF functions are class methods and always have "self" as the first parameter.
    input_types = [VariantType()] * (len(func_signature.parameters) - 1)

    if is_arrow_enabled_in_udtf():
        expected_types = build_expected_types_from_parsed(parsed_return)
        callable_func = spark_compatible_udtf_wrapper_with_arrow(
            callable_func, expected_types
        )
    elif is_spark_compatible_udtf_mode_enabled():
        expected_types = build_expected_types_from_parsed(parsed_return)
        callable_func = spark_compatible_udtf_wrapper(callable_func, expected_types)
    else:
        callable_func.process = callable_func.eval
        if hasattr(callable_func, "terminate"):
            callable_func.end_partition = callable_func.terminate

    if not isinstance(output_schema, StructType):
        raise PySparkTypeError(
            f"Invalid Python user-defined table function return type. Expect a struct type, but got {parsed_return}"
        )
    spark_column_names = [f.name for f in parsed_return.struct.fields]

    return (
        callable_func,
        output_schema,
        input_types,
        udtf_proto.function_name,
        packages,
        func_signature,
        spark_column_names,
        original_output_schema,
    )


def register_udtf(
    udtf_proto: relation_proto.CommonInlineUserDefinedTableFunction,
) -> snowpark.udtf.UserDefinedTableFunction:
    match udtf_proto.WhichOneof("function"):
        case "python_udtf":
            session = get_or_create_snowpark_session()
            (
                callable_func,
                output_schema,
                input_types,
                function_name,
                packages,
                _,
                spark_column_names,
                _,
            ) = udtf_helper(udtf_proto)

            # Include pyarrow in packages when using Arrow-enabled UDTF
            current_packages = packages
            if is_arrow_enabled_in_udtf() and "pyarrow" not in current_packages:
                current_packages += ["pyarrow"]

            udtf = session.udtf.register(
                handler=callable_func,
                output_schema=output_schema,
                input_types=input_types,
                replace=True,
                packages=current_packages,
            )
            session._udtfs[function_name.lower()] = (udtf, spark_column_names)
            return udtf
        case _:
            raise ValueError(f"Not python udtf {udtf_proto.function}")


def is_spark_compatible_udtf_mode_enabled() -> bool:
    return get_boolean_session_config_param("snowpark.connect.udtf.compatibility_mode")


def is_arrow_enabled_in_udtf() -> bool:  # REINSTATED
    """Check if Arrow is enabled for UDTFs"""
    return get_boolean_session_config_param(
        "spark.sql.execution.pythonUDTF.arrow.enabled"
    )


def map_common_inline_user_defined_table_function(
    rel: relation_proto.CommonInlineUserDefinedTableFunction,
) -> snowpark.DataFrame:
    session = get_or_create_snowpark_session()

    match rel.WhichOneof("function"):
        case "python_udtf":
            (
                callable_func,
                output_schema,
                input_types,
                function_name,
                packages,
                func_signature,
                spark_column_names,
                original_output_schema,
            ) = udtf_helper(rel)

            # Check if the number of arguments provided matches the function signature
            expected_arg_count = len(func_signature.parameters) - 1  # Skip self
            actual_arg_count = len(rel.arguments)

            # Missing arguments
            if actual_arg_count < expected_arg_count:
                param_names = list(func_signature.parameters.keys())[1:]  # Skip self
                missing_params = param_names[actual_arg_count:]
                missing_param_str = ", ".join(f"'{p}'" for p in missing_params)

                raise PythonException(
                    f"eval() missing {len(missing_params)} required positional argument: {missing_param_str}"
                )
            # Too many arguments
            elif actual_arg_count > expected_arg_count:
                total_expected = expected_arg_count + 1  # Add 1 for self
                total_given = actual_arg_count + 1  # Add 1 for self

                raise PythonException(
                    f"eval() takes {total_expected} positional arguments but {total_given} were given"
                )

            column_map = ColumnNameMap([], [])
            snowpark_udtf_args = []
            for arg_exp in rel.arguments:
                (_, snowpark_udtf_arg_tc) = map_single_column_expression(
                    arg_exp, column_map, ExpressionTyper.dummy_typer(session)
                )
                snowpark_udtf_arg = snowpark_udtf_arg_tc.col
                snowpark_udtf_args.append(snowpark_udtf_arg)

            current_packages = packages
            if is_arrow_enabled_in_udtf():
                # Always include pyarrow in packages when using Arrow-enabled UDTF
                if "pyarrow" not in current_packages:
                    current_packages += ["pyarrow"]

            snowpark_udtf = snowpark_fn.udtf(
                handler=callable_func,
                output_schema=output_schema,
                input_types=input_types,
                name=function_name,
                replace=True,
                packages=current_packages,
            )
            df = session.table_function(
                snowpark_udtf(*[arg.cast(VariantType()) for arg in snowpark_udtf_args])
            )

            original_types = {}
            for field in original_output_schema.fields:
                original_types[field.name] = field.datatype

            snowpark_column_types = []
            # Replace JSON strings with Python dicts for map columns
            for field in output_schema.fields:
                if isinstance(field.datatype, VariantType):
                    col_name = field.name
                    if col_name in original_types and isinstance(
                        original_types[col_name], MapType
                    ):
                        original_map_type = original_types[col_name]
                        parsed_col = parse_json(col(col_name))
                        df = df.with_column(
                            col_name, parsed_col.cast(original_map_type)
                        )
                        snowpark_column_types.append(original_map_type)
                    else:
                        df = df.with_column(col_name, parse_json(col(col_name)))
                        snowpark_column_types.append(field.datatype)
                else:
                    snowpark_column_types.append(field.datatype)

            snowpark_columns = [f.name for f in output_schema.fields]

            return build_column_map(
                df,
                spark_column_names,
                snowpark_column_names=snowpark_columns,
                snowpark_column_types=snowpark_column_types,
            )
        case _:
            raise ValueError(f"Not python udtf {rel.python_udtf}")
