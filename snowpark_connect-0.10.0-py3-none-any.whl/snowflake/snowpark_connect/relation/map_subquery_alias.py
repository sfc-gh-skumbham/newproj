import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.utils.context import get_alias_map


def map_alias(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Returns an aliased dataframe in which the columns can now be referenced to using col(<df alias>, <column name>).
    """
    alias: str = rel.subquery_alias.alias
    input_df: snowpark.DataFrame = map_relation(rel.subquery_alias.input)
    input_df._alias = alias
    get_alias_map()[alias] = input_df
    return input_df
