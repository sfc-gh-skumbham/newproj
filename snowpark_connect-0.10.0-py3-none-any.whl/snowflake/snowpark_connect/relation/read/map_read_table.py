import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer.analyzer_utils import (
    quote_name_without_upper_casing,
    unquote_if_quoted,
)
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)
from snowflake.snowpark_connect.utils.attribute_handling import (
    auto_uppercase_dml,
    split_fully_qualified_spark_name,
)
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def post_process_df(df: snowpark.DataFrame, plan_id: int) -> snowpark.DataFrame:
    true_names = list(map(lambda x: unquote_if_quoted(x).lower(), df.columns))
    renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(
        df, plan_id
    )
    return build_column_map(
        renamed_df,
        true_names,
        snowpark_column_names,
        [f.datatype for f in df.schema.fields],
    )


def get_table_from_name(
    table_name: str, session: snowpark.Session, plan_id: int
) -> snowpark.DataFrame:
    snowpark_name = ".".join(
        quote_name_without_upper_casing(part)
        for part in split_fully_qualified_spark_name(table_name)
    )

    if auto_uppercase_dml():
        snowpark_name = snowpark_name.upper()

    df = session.read.table(snowpark_name)
    return post_process_df(df, plan_id)


def get_table_from_query(
    query: str, session: snowpark.Session, plan_id: int
) -> snowpark.DataFrame:
    df = session.sql(query)
    return post_process_df(df, plan_id)


def map_read_table(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Read a table into a Snowpark DataFrame.
    """
    session: snowpark.Session = get_or_create_snowpark_session()
    if rel.read.HasField("named_table"):
        table_identifier = rel.read.named_table.unparsed_identifier
    elif (
        rel.read.data_source.HasField("format")
        and rel.read.data_source.format.lower() == "iceberg"
    ):
        if len(rel.read.data_source.paths) != 1:
            raise SnowparkConnectNotImplementedError(
                f"Unexpected paths: {rel.read.data_source.paths}"
            )
        table_identifier = rel.read.data_source.paths[0]
    else:
        raise ValueError("The relation must have a table identifier.")
    return get_table_from_name(table_identifier, session, rel.common.plan_id)
