import struct

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark.types import (
    BinaryType,
    BooleanType,
    DateType,
    DoubleType,
    LongType,
    NullType,
    StringType,
    StructType,
    TimestampTimeZone,
    TimestampType,
    _FractionalType,
    _IntegralType,
    _NumericType,
)
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.expression.map_unresolved_function import (
    SYMBOL_FUNCTIONS,
)
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import (
    map_type_string_to_snowpark_type,
    proto_to_snowpark_type,
)
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import (
    get_is_evaluating_sql,
    is_function_argument_being_resolved,
)
from snowflake.snowpark_connect.utils.udf_cache import cached_udf


def map_cast(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    """
    Map a cast expression to a Snowpark expression.
    """

    from snowflake.snowpark_connect.expression.map_expression import (
        map_single_column_expression,
    )

    spark_sql_ansi_enabled = global_config.spark_sql_ansi_enabled

    match exp.cast.WhichOneof("cast_to_type"):
        case "type":
            to_type = proto_to_snowpark_type(exp.cast.type)
        case "type_str":
            to_type = map_type_string_to_snowpark_type(exp.cast.type_str)
        case _:
            raise ValueError("No type to cast to")

    from_exp = exp.cast.expr
    new_name, typed_column = map_single_column_expression(
        from_exp, column_mapping, typer
    )

    match from_exp.WhichOneof("expr_type"):
        case "unresolved_attribute" if not is_function_argument_being_resolved():
            col_name = new_name
        case "literal" if not is_function_argument_being_resolved() and get_is_evaluating_sql():
            col_name = new_name
        case "unresolved_function" if from_exp.unresolved_function.function_name in SYMBOL_FUNCTIONS:
            col_name = new_name
        case _:
            to_type_str = to_type.typeName().upper()
            to_type_str = to_type_str.replace("INTEGER", "INT")
            col_name = f"CAST({new_name} AS {to_type_str})"

    from_type = typed_column.typ
    col = typed_column.col
    match (from_type, to_type):
        case (_, _) if (from_type == to_type):
            result_exp = col
        case (NullType(), _):
            result_exp = col.cast(to_type)
        case (StructType(), _) if from_type.structured:
            result_exp = col.cast(to_type, rename_fields=True)

        # date and timestamp
        case (TimestampType(), _) if isinstance(to_type, _NumericType):
            epoch_s = snowpark_fn.date_part("epoch_seconds", col)
            result_exp = epoch_s.cast(to_type)
        case (TimestampType(), BooleanType()):
            timestamp_0L = snowpark_fn.to_timestamp(snowpark_fn.lit(0))
            result_exp = snowpark_fn.when(
                col.is_not_null(),
                col
                != timestamp_0L,  # 0L timestamp is mapped to False, other values are mapped to True
            ).otherwise(snowpark_fn.lit(None))
        case (TimestampType(), DateType()):
            result_exp = snowpark_fn.to_date(col)
        case (DateType(), TimestampType()):
            result_exp = snowpark_fn.to_timestamp(col)
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (TimestampType(), TimestampType()):
            result_exp = col
        case (_, TimestampType()) if isinstance(from_type, _NumericType):
            microseconds = col * snowpark_fn.lit(1000000)
            result_exp = snowpark_fn.when(
                col < 0, snowpark_fn.ceil(microseconds)
            ).otherwise(snowpark_fn.floor(microseconds))
            result_exp = result_exp.cast(LongType())
            result_exp = snowpark_fn.to_timestamp(
                result_exp, snowpark_fn.lit(6)
            )  # microseconds precision
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (_, TimestampType()) if isinstance(from_type, BooleanType):
            result_exp = snowpark_fn.to_timestamp(
                col.cast(LongType()), snowpark_fn.lit(6)
            )  # microseconds precision
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (_, TimestampType()):
            result_exp = snowpark_fn.function("try_to_timestamp")(col)
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (DateType(), _) if isinstance(to_type, (_NumericType, BooleanType)):
            result_exp = snowpark_fn.cast(snowpark_fn.lit(None), to_type)
        case (_, DateType()):
            result_exp = snowpark_fn.function("try_to_date")(col)

        # boolean
        case (BooleanType(), _) if isinstance(to_type, _NumericType):
            result_exp = col.cast(LongType()).cast(to_type)
        case (_, BooleanType()) if isinstance(from_type, _NumericType):
            result_exp = col.cast(LongType()).cast(to_type)

        # binary
        case (StringType(), BinaryType()):
            result_exp = snowpark_fn.to_binary(col, "UTF-8")
        case (LongType(), BinaryType()):

            @cached_udf
            def _long_to_binary(n: int) -> bytes:
                if n is None:
                    return None
                return struct.pack(">q", n)

            result_exp = _long_to_binary(col)
        case (_, BinaryType()):
            result_exp = snowpark_fn.try_to_binary(col)
        case (BinaryType(), StringType()):
            result_exp = snowpark_fn.to_varchar(col, "UTF-8")

        # numeric
        case (_, _) if isinstance(from_type, _FractionalType) and isinstance(
            to_type, _IntegralType
        ):
            result_exp = snowpark_fn.when(col < 0, snowpark_fn.ceil(col)).otherwise(
                snowpark_fn.floor(col)
            )
            result_exp = result_exp.cast(to_type)
        case (StringType(), _) if (isinstance(to_type, _IntegralType)):
            if spark_sql_ansi_enabled:
                result_exp = snowpark_fn.cast(col, DoubleType())
            else:
                result_exp = snowpark_fn.try_cast(col, DoubleType())
            result_exp = snowpark_fn.when(
                result_exp < 0, snowpark_fn.ceil(result_exp)
            ).otherwise(snowpark_fn.floor(result_exp))
            result_exp = result_exp.cast(to_type)
        case (StringType(), _):
            if spark_sql_ansi_enabled:
                result_exp = snowpark_fn.cast(col, to_type)
            else:
                result_exp = snowpark_fn.try_cast(col, to_type)

        case _:
            result_exp = snowpark_fn.cast(col, to_type)

    return [col_name], TypedColumn(result_exp, lambda: [to_type])
