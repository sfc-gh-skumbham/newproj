from typing import Iterator

import pandas

import snowflake.snowpark.functions as snowpark_fn


class CreateUdfInputs:
    def __init__(self, called_from, eval_type, **kwargs) -> None:
        # Required attributes
        self.called_from = called_from
        self.eval_type = eval_type

        # Optional attributes (can be passed as keyword arguments)
        match called_from:
            case "map_partitions":
                self.output_dtype = kwargs.get("output_dtype", None)
                self.input_types = kwargs.get("input_types", None)
                self.udf_function = kwargs.get("udf_function", None)
                self.column_names = kwargs.get("column_names", None)
            case (_):
                raise ValueError(f"Called from unknown location {called_from}")


def create_udf(create_udf_inputs):
    class PythonEvalType:
        NON_UDF = 0

        SQL_BATCHED_UDF = 100
        SQL_ARROW_BATCHED_UDF = 101

        SQL_SCALAR_PANDAS_UDF = 200
        SQL_GROUPED_MAP_PANDAS_UDF = 201
        SQL_GROUPED_AGG_PANDAS_UDF = 202
        SQL_WINDOW_AGG_PANDAS_UDF = 203
        SQL_SCALAR_PANDAS_ITER_UDF = 204
        SQL_MAP_PANDAS_ITER_UDF = 205
        SQL_COGROUPED_MAP_PANDAS_UDF = 206
        SQL_MAP_ARROW_ITER_UDF = 207
        SQL_GROUPED_MAP_PANDAS_UDF_WITH_STATE = 208

        SQL_TABLE_UDF = 300
        SQL_ARROW_TABLE_UDF = 301

    def check_map_arrow_iter_udf(result):
        if not isinstance(result, Iterator) and not hasattr(result, "__iter__"):
            raise RuntimeError(
                f"snowpark_connect::UDF_RETURN_TYPE Return type of the user-defined function should be iterator of pyarrow.RecordBatch, but is {type(result).__name__}"
            )

        import pyarrow as pa

        for elem in result:
            if not isinstance(elem, pa.RecordBatch):
                raise RuntimeError(
                    f"snowpark_connect::UDF_RETURN_TYPE Return type of the user-defined function should be iterator of pyarrow.RecordBatch, but is iterator of {type(elem).__name__}"
                )
        return

    def check_return_type(result, eval_type: int):
        match eval_type:
            case PythonEvalType.SQL_MAP_ARROW_ITER_UDF:
                check_map_arrow_iter_udf(result)
            # TODO do not throw error on unknown eval type until all the eval types are handeled
            case (_):
                return

    match create_udf_inputs.called_from:
        case "map_partitions":
            column_names = create_udf_inputs.column_names
            udf_function = create_udf_inputs.udf_function
            eval_type = create_udf_inputs.eval_type

            def wrapped_function(*args):
                result = udf_function(
                    pandas.DataFrame(iter([list(args)]), columns=column_names)
                )
                check_return_type(result, eval_type)
                return result

            return snowpark_fn.udf(
                wrapped_function,
                return_type=create_udf_inputs.output_dtype,
                input_types=create_udf_inputs.input_types,
                name="spark_map_partitions_udf",
                replace=True,
                packages=[
                    "py4j==0.10.9.7",
                    "numpy",
                    "pandas",
                    "filelock",
                    "typing-extensions >=4.8.0",
                    "sympy",
                    "networkx",
                    "jinja2",
                    "fsspec",
                    "pytorch",
                    "pyarrow",
                    "snowflake-snowpark-python",
                ],
            )
        case (_):
            raise ValueError(
                f"Called from unknown location {create_udf_inputs.called_from}"
            )
