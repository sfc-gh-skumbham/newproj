#!/usr/bin/env python

"""The utility file for running spark-submit cluster mode.
"""

import argparse
import logging
import os
import random
import string
import tempfile
import textwrap
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Callable

import yaml

from snowflake import snowpark
from snowflake.connector.config_manager import CONFIG_MANAGER
from snowflake.snowpark_connect.constants import DEFAULT_CONNECTION_NAME

current_dir = os.path.dirname(os.path.abspath(__file__))

SPCS_SPEC_FILE = "spcs_spec.yaml"
USE_SYSTEM_IMAGE_REGISTRY = False
REQUIRED_CONFIGS = [
    "account",
    "user",
    "password",
    "role",
    "host",
    "warehouse",
    "database",
    "schema",
    "compute_pool",
    "spcs_host",
    "spcs_repo_name",
]

logger = logging.getLogger("snowflake_spark_submit")
logger.setLevel(logging.DEBUG)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - [Thread %(thread)d] - %(message)s"
)
console_handler.setFormatter(formatter)

# Display the logs to the console
logger.addHandler(console_handler)


def generate_random_name(
    length: int = 8,
    prefix: str = "",
    suffix: str = "",
    choices: Sequence[str] = string.ascii_lowercase,
) -> str:
    """Our convenience function to generate random string for object names.
    Args:
        length: How many random characters to choose from choices.
            length would be at least 6 for avoiding collision
        prefix: Prefix to add to random string generated.
        suffix: Suffix to add to random string generated.
        choices: A generator of things to choose from.
    """
    random_part = "".join([random.choice(choices) for _ in range(length)]) + str(
        time.time_ns()
    )

    return "".join([prefix, random_part, suffix])


class JobRunner:
    def __init__(
        self,
        args: argparse.Namespace,
        generate_spark_cmd: Callable[[argparse.Namespace], list[str]],
    ) -> None:
        # TODO: do we want to do accountadmin work inside snowpark-submit? Or we want it to be a prerequisite (we can provide
        #  a script to set up it easier)?

        # for now, I'm not gonna do accountadmin work here. Just manually prepared it and hard coded the non-accountadmin
        # creds for PoC

        self.args = args
        self.generate_spark_cmd = generate_spark_cmd
        self.client_app_language = "scala"  # default to scala
        assert (
            DEFAULT_CONNECTION_NAME in CONFIG_MANAGER["connections"]
        ), f"{DEFAULT_CONNECTION_NAME} needs to be configured."
        configs = CONFIG_MANAGER["connections"][DEFAULT_CONNECTION_NAME]
        # TODO: allow passing below configs in as args instead of requiring them to be in config file
        for config in REQUIRED_CONFIGS:
            setattr(self, config, str(configs[config]) if config in configs else None)

        # configs for local testing
        # self.account = "fake-sf-account"
        # self.user = "fake-sf-user"
        # self.password = "fake-sf-password"
        # self.role = "fake-spcs-role"
        # self.host = "fake.snowflakecomputing.com"
        # self.warehouse = "fake_warehouse"
        # self.database = "fake_spcs_db"
        # self.schema = "fake_spcs_schema"
        # self.compute_pool = "fake_spcs_compute_pool"
        # self.spcs_host = "fake-sf-region-registry.snowflakecomputing.com"
        # self.spcs_repo_name = "fake_spcs_repository_name"

        # spcs configs will be outdated after we switch to system image registry
        self.spcs_repo_path = f"/{self.database}/{self.schema}/{self.spcs_repo_name}"
        self.spcs_repo = self.spcs_host + self.spcs_repo_path

        # TODO: allow passing in through arguments
        for config in REQUIRED_CONFIGS:
            assert getattr(self, config, None), f"{config} needs to be configured."

        self._snowpark_session: snowpark.Session = snowpark.Session.builder.configs(
            {
                "protocol": "https",
                "host": self.host,
                "port": 443,
                "account": self.account,
                "user": self.user,
                "password": self.password,
                "warehouse": self.warehouse,
                "role": self.role,
                "database": self.database,
                "schema": self.schema,
            }
        ).create()

        self.docker_working_dir = "/app/"
        self.temp_stage_mount_dir = "/app/client-src/"

    def prepare_snowpark_connect_image(self, image_name: str, docker_file_path: str):
        # TODO: for unknown reason, this is flaky that, when image is changed, it can't successfully cache / build / upload sometimes.
        import docker

        snowpark_connect_image = f"{self.spcs_repo}/{image_name}:latest"

        logger.debug("start building %s image", snowpark_connect_image)
        # docker build --rm --platform linux/amd64 -t <repository_url>/<image_name> .
        docker_client = docker.APIClient()
        docker_logs = docker_client.build(
            path=docker_file_path,
            tag=snowpark_connect_image,
            rm=True,
            platform="linux/amd64",
            decode=True,
        )

        for chunk in docker_logs:
            if "stream" in chunk:
                logger.debug(chunk["stream"].rstrip())  # mimic Docker CLI
            elif "errorDetail" in chunk:
                logger.error(chunk["errorDetail"]["message"])

        logger.debug("logging in to docker registry")
        # docker login <registry_hostname> -u <username>
        docker_logs = docker_client.login(
            username=self.user, password=self.password, registry=self.spcs_host
        )
        logger.debug(docker_logs)

        logger.debug("uploading %s image to docker registry", image_name)
        # docker push <repository_url>/<image_name>
        docker_logs = docker_client.push(
            snowpark_connect_image,
            stream=True,
            decode=True,
        )

        for line in docker_logs:
            if "status" in line:
                logger.debug(line["status"])
            elif "error" in line:
                logger.error(line["error"])

    def prepare_spcs_spec(
        self,
        temp_stage_name: str,
        client_src_zip_file_path: str,
        server_image_name: str = "snowpark-connect-server",
        client_image_name: str = "snowpark-connect-client",
        service_name: str = "snowpark_connect_job_service",
    ):
        # TODO: more options can be added
        #  resources (CPU, memory etc.)
        #  secrets
        #  volumes (@stagename)
        #  logExporters
        #  metricConfig
        #  serviceRoles
        logger.debug("start preparing spcs_spec")
        spcs_spec_template = os.path.join(current_dir, "spcs_spec.template.yaml")
        with open(spcs_spec_template) as f:
            spcs_spec = yaml.safe_load(f)

        # TODO: when change to global registry, we need to change the image path to the global one
        # snowpark connect server container
        server_container = spcs_spec["spec"]["container"][0]
        if USE_SYSTEM_IMAGE_REGISTRY:
            server_container[
                "image"
            ] = "/snowflake/images/snowflake_images/spark_connect_for_snowpark_server:0.0.1-alpha"
        else:
            server_container["image"] = (
                self.spcs_repo_path + f"/{server_image_name}:latest"
            )
        server_container["env"]["SNOWFLAKE_WAREHOUSE"] = self.warehouse

        # snowpark connect client container
        client_container = spcs_spec["spec"]["container"][1]
        if USE_SYSTEM_IMAGE_REGISTRY:
            raise NotImplementedError(
                "client images are not available in system image registry yet"
            )
        else:
            client_container["image"] = (
                self.spcs_repo_path + f"/{client_image_name}:latest"
            )
        client_container["env"]["SERVICE_NAME"] = service_name
        client_container["args"] = [
            " ".join(self.generate_spark_cmd(self.args)),
            client_src_zip_file_path,
        ]

        spcs_spec["spec"]["volumes"][0]["source"] = f"@{temp_stage_name}"
        spcs_spec_yaml = yaml.dump(spcs_spec, default_flow_style=False)
        logger.debug(spcs_spec_yaml)
        # TODO: add spec.logExporters
        return spcs_spec_yaml

    def upload_client_files(self, temp_stage_name):
        file_path = Path(self.args.filename)
        self.args.filename = self.docker_working_dir + file_path.name
        files_for_zip = [file_path]

        # TODO: support non-local files
        if self.client_app_language == "scala":
            if self.args.jars:
                jar_paths = [Path(jar) for jar in self.args.jars.split(",")]
                files_for_zip.extend(jar_paths)
                jar_paths_in_container = [
                    self.docker_working_dir + jar_path.name for jar_path in jar_paths
                ]
                # adjust --jars argument
                self.args.jars = ",".join(jar_paths_in_container)
        elif self.client_app_language == "python":
            if self.args.py_files:
                py_file_paths = [
                    Path(py_file) for py_file in self.args.py_files.split(",")
                ]
                files_for_zip.extend(py_file_paths)
                py_file_paths_in_container = [
                    self.docker_working_dir + py_file_path.name
                    for py_file_path in py_file_paths
                ]
                # adjust --py-files argument
                self.args.py_files = ",".join(py_file_paths_in_container)

        import zipfile

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            zip_file_name = (
                generate_random_name(prefix="snowpark_submit_files_") + ".zip"
            )
            zip_file_path = tmp_path / zip_file_name
            with zipfile.ZipFile(zip_file_path, "w") as zipf:
                for file in files_for_zip:
                    logger.debug(f"zipping file {file.name}")
                    zipf.write(file, arcname=file.name)

            logger.debug(
                f"Created archive {zip_file_path} for uploading the client src file and other dependencies."
            )

            # Upload the archive
            upload_zip_sql = f"PUT file://{zip_file_path.resolve()} @{temp_stage_name} AUTO_COMPRESS=FALSE OVERWRITE=TRUE;"
            self._snowpark_session.sql(upload_zip_sql).collect()
            logger.debug(
                f"Uploaded the archive {zip_file_path} to the temporary stage {temp_stage_name}."
            )

        stage_content = self._snowpark_session.sql(f"ls @{temp_stage_name}").collect()
        logger.debug(stage_content)
        return self.temp_stage_mount_dir + zip_file_name

    def _add_class_paths(self, jar_paths: list[str]):
        if self.args.driver_class_path is None:
            self.args.driver_class_path = ":".join(jar_paths)
        else:
            self.args.driver_class_path = ":".join(
                [jar_paths] + [self.args.driver_class_path]
            )
        logger.debug("driver_class_path: %s", self.args.driver_class_path)

    def run(self):
        # TODO: required deps - pyyaml.
        # TODO: currently this experiment app supports only scala 2.12 and spark 3.5.3. We need a way for customer to specify which version of scala and spark to use.
        # TODO: support following arguments
        #  external access integrations
        #  log level
        #  trace level
        #  metrics level
        #  snowflake secrets
        #  session parameters - db, schema, warehouse etc.
        # TODO: better way of terminating the job service, e.g. heartbeat

        # step 1, prepare docker images, and push to registry. One is provided by us for sas server, another one is user's application
        # image
        server_image_name = "snowpark-connect-server"
        if self.args.filename.endswith(".jar"):
            self.client_app_language = "scala"
            # spark-connect-client-jvm_2.12-3.5.3.jar is copied in the docker image.
            self._add_class_paths(
                ["/app/spark_lib/spark-connect-client-jvm_2.12-3.5.3.jar"]
            )
        elif self.args.filename.endswith(".py"):
            self.client_app_language = "python"
        else:
            raise ValueError(
                f"Only .jar and .py files are supported now. {self.args.filename} is provided."
            )

        client_image_name = f"snowpark-connect-client-{self.client_app_language}"

        # TODO: temporarily disabled for local testing. Removing this before release.
        # self.prepare_snowpark_connect_image(
        #     server_image_name, f"{current_dir}/docker/snowpark-connect-server"
        # )
        # self.prepare_snowpark_connect_image(
        #     client_image_name,
        #     f"{current_dir}/docker/snowpark-connect-client/{self.client_app_language}",
        # )

        # step 2, upload client files to stage
        temp_stage_name = self.create_temp_stage_for_upload()
        client_src_zip_file_path = self.upload_client_files(temp_stage_name)

        # step 3, prepare SPCS specs
        # TODO: consider accepting user input service name (also need to avoid conflict)
        service_name = generate_random_name(
            prefix="snowpark_connect_job_service_"
        ).upper()
        logger.debug("service_name: %s", service_name)

        spcs_spec_yaml = self.prepare_spcs_spec(
            temp_stage_name=temp_stage_name,
            client_src_zip_file_path=client_src_zip_file_path,
            server_image_name=server_image_name,
            client_image_name=client_image_name,
            service_name=service_name,
        )

        # step 4, spins up SPCS clusters
        logger.debug("Start running SPCS job service %s", service_name)

        execute_spcs_sql = f"""
EXECUTE JOB SERVICE
    IN COMPUTE POOL {self.compute_pool}
    NAME={service_name}
    ASYNC = TRUE
    FROM SPECIFICATION $$
{textwrap.indent(spcs_spec_yaml, ' ' * 4)}
    $$
        """
        # TODO: consider supporting COMMENT in JOB SERVICE
        logger.debug(execute_spcs_sql)
        self._snowpark_session.sql(f"drop service if exists {service_name}").collect()
        try:
            res = self._snowpark_session.sql(execute_spcs_sql).collect()
            logger.debug(res)
            logger.debug(
                "Job service %s has been submitted and running asynchorously in SPCS. The service will be automatically dropped when finish. Please find logs in event table.",
                service_name,
            )
        except Exception as e:
            logger.error(e)
        finally:
            # SQLs to extract logs from event table. The SYSTEM$GET_SERVICE_LOGS function is not available after service is dropped.
            # And SPCS team is working on an easy function to extract logs from event table. ETA early May.
            log_line = f"""
            SHOW PARAMETERS LIKE 'EVENT_TABLE' IN ACCOUNT;
            select *
            from <event table from above query result>
            where RESOURCE_ATTRIBUTES['snow.service.type'] = 'Job'
            and RESOURCE_ATTRIBUTES['snow.service.container.name'] = 'client' -- or 'server' for server log
            and RESOURCE_ATTRIBUTES['snow.service.name'] = '{service_name}'
            and timestamp > dateadd('minute', -10, current_timestamp()) -- adjust timestamp for your case
            order by timestamp
            ;
            """
            logger.info("To fetch logs, run the following SQLs: %s", log_line)

        self._snowpark_session.close()

        return 0

    def create_temp_stage_for_upload(self):
        # Create a temporary stage for uploading files
        temp_stage_name = generate_random_name(prefix="sf_spark_submit_temp_stage_")

        # currently azure only supports SNOWFLAKE_SSE encryption type. aws supports both SNOWFLAKE_FULL/SSE
        create_stage_sql = f"CREATE OR REPLACE TEMPORARY STAGE {temp_stage_name} ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE') DIRECTORY = ( ENABLE = true );"
        self._snowpark_session.sql(create_stage_sql).collect()

        return temp_stage_name
