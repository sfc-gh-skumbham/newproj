import base64
import uuid
from urllib.parse import urlparse

import pyspark.sql.connect.proto.base_pb2 as proto_base

import snowflake.connector


class GsProxy:
    def __init__(self, gs_endpoint: str) -> None:
        # Use "http://snowflake.dev.local:53400".
        parsed_url = urlparse(gs_endpoint)
        self.protocol = parsed_url.scheme
        self.host = parsed_url.hostname
        self.port = parsed_url.port or "53400"
        self.account = "SNOWFLAKE_ALIAS"
        self.username = "admin"
        self.password = "test"
        self.warehouse = "TESTWH"
        self.database = "TESTDB"
        self.schema = "PUBLIC"

    def execute_plan(
        self, req: str | proto_base.ExecutePlanRequest
    ) -> proto_base.ExecutePlanResponse:
        if isinstance(req, str):
            encoded = req
        else:
            data = req.SerializeToString()
            encoded = base64.b64encode(data).decode("utf-8")
        print(self._post("ExecutePlan", encoded))  # noqa: T201
        return None  # TODO

    def _post(self, method, ast):
        request_id = str(uuid.uuid4())
        request = {
            "dataframeAst": ast,
            "warehouse": self.warehouse,
            "database": self.database,
            "schema": self.schema,
            "asyncExec": False,
            "requestId": request_id,
        }
        with snowflake.connector.connect(
            host=self.host,
            port=self.port,
            protocol=self.protocol,
            account=self.account,
            user=self.username,
            password=self.password,
            warehouse=self.warehouse,
            database=self.database,
            schema=self.schema,
        ) as conn:
            return conn.rest.request(
                f"/queries/v1/query-request?requestId={request_id}&method={method}",
                body=request,
            )
