import atexit
import logging
import os
import pathlib
import socket
import tempfile
import threading
import urllib.parse
from concurrent import futures
from typing import Any, Callable, Dict, List, Optional, Tuple

import grpc
import jpype
import pandas
import pyspark
import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.base_pb2_grpc as proto_base_grpc
import pyspark.sql.connect.proto.common_pb2 as common_proto
import pyspark.sql.connect.proto.types_pb2 as types_proto
from grpc_status import rpc_status
from pyspark import StorageLevel
from pyspark.errors import PySparkValueError
from pyspark.sql.connect.client.core import ChannelBuilder
from pyspark.sql.connect.session import SparkConf, SparkSession

import snowflake.snowpark_connect.proto.control_pb2_grpc as control_grpc
from snowflake import snowpark
from snowflake.snowpark_connect.analyze_plan.map_tree_string import map_tree_string
from snowflake.snowpark_connect.config import init_snowpark_session, route_config_proto
from snowflake.snowpark_connect.constants import (
    DEFAULT_CONNECTION_NAME,
    SERVER_SIDE_SESSION_ID,
)
from snowflake.snowpark_connect.control_server import ControlServicer
from snowflake.snowpark_connect.error.error_utils import build_grpc_error_response
from snowflake.snowpark_connect.execute_plan.map_execution_command import (
    map_execution_command,
)
from snowflake.snowpark_connect.execute_plan.map_execution_root import (
    map_execution_root,
)
from snowflake.snowpark_connect.execute_plan.utils import is_streaming
from snowflake.snowpark_connect.gs_proxy import GsProxy
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.relation.utils import get_semantic_string
from snowflake.snowpark_connect.type_mapping import (
    parse_ddl_string,
    snowpark_to_proto_type,
)
from snowflake.snowpark_connect.utils.cache import (
    df_cache_map_pop,
    df_cache_map_put_if_absent,
)
from snowflake.snowpark_connect.utils.context import (
    clear_context_data,
    set_session_id,
    set_spark_version,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import (
    log_waring_once_storage_level,
    logger,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
    TelemetryClient,
)
from snowflake.snowpark_connect.utils.xxhash64 import xxhash64_string

# https://github.com/apache/spark/blob/v3.5.3/connector/connect/common/src/main/scala/org/apache/spark/sql/connect/common/config/ConnectCommon.scala#L21
_SPARK_CONNECT_GRPC_MAX_MESSAGE_SIZE = 128 * 1024 * 1024


class SnowflakeConnectServicer(proto_base_grpc.SparkConnectServiceServicer):
    def __init__(
        self,
        log_request_fn: Optional[Callable[[bytearray], None]] = None,
        gs_endpoint: Optional[str] = None,
    ) -> None:
        self.log_request_fn = log_request_fn
        if gs_endpoint is None:
            self.gs_proxy = None
        else:
            self.gs_proxy = GsProxy(gs_endpoint)
            # TODO: This code will be removed after the initial round of testing.
            res = self.gs_proxy.execute_plan(
                "CiQ2NDlmYjNiZS00YzBmLTRkMTQtOTgyNS1jYTQxYzlhODljMzYSDQoLYXp3aWVnaW5jZXcawAYKvQYKAxC7IKIBtAYKrQYKAxC6INoFpAYKoQYKAxC1IFqZBgrIBP/////YAAAAEAAAAAAACgAMAAYABQAIAAoAAAAAAQQADAAAAAgACAAAAAQACAAAAAQAAAADAAAAcAAAADAAAAAEAAAArP///wAAAQUQAAAAGAAAAAQAAAAAAAAAAQAAAGMAAAAEAAQABAAAANT///8AAAEDEAAAABgAAAAEAAAAAAAAAAEAAABiAAYACAAGAAYAAAAAAAIAEAAUAAgABgAHAAwAAAAQABAAAAAAAAECEAAAABwAAAAEAAAAAAAAAAEAAABhAAAACAAMAAgABwAIAAAAAAAAAUAAAAAAAAAA//////gAAAAUAAAAAAAAAAwAFgAGAAUACAAMAAwAAAAAAwQAGAAAAGAAAAAAAAAAAAAKABgADAAEAAgACgAAAIwAAAAQAAAAAwAAAAAAAAAAAAAABwAAAAAAAAAAAAAAAQAAAAAAAAAIAAAAAAAAABgAAAAAAAAAIAAAAAAAAAABAAAAAAAAACgAAAAAAAAAGAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAQAAAAAAAAAFAAAAAAAAAACQAAAAAAAAAAAAAAAwAAAAMAAAAAAAAAAQAAAAAAAAADAAAAAAAAAAEAAAAAAAAAAwAAAAAAAAAAAAAAAAAAAAMAAAAAAAAAAQAAAAAAAAACAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAFEAAAAAAAwAAAAYAAAAJAAAAZm9vYmFyYmF6AAAAAAAAAP////8AAAAAEssBeyJmaWVsZHMiOlt7Im1ldGFkYXRhIjp7fSwibmFtZSI6ImEiLCJudWxsYWJsZSI6dHJ1ZSwidHlwZSI6ImxvbmcifSx7Im1ldGFkYXRhIjp7fSwibmFtZSI6ImIiLCJudWxsYWJsZSI6dHJ1ZSwidHlwZSI6ImRvdWJsZSJ9LHsibWV0YWRhdGEiOnt9LCJuYW1lIjoiYyIsIm51bGxhYmxlIjp0cnVlLCJ0eXBlIjoic3RyaW5nIn1dLCJ0eXBlIjoic3RydWN0In0QFBgUIjlfU1BBUktfQ09OTkVDVF9QWVRIT04gc3BhcmsvMy41LjMgb3MvZGFyd2luIHB5dGhvbi8zLjExLjUqBAoCCAEyJDExMGM0ZDUwLTBiZTAtNDk2Mi1iYTQ3LWM4NzRhZjI1YjliNg=="
            )
            print(f">> {res}")  # noqa: T201
            import sys

            sys.exit()

    def ExecutePlan(self, request: proto_base.ExecutePlanRequest, context):
        """Executes a request that contains the query and returns a stream of [[Response]].

        It is guaranteed that there is at least one ARROW batch returned even if the result set is empty.
        """
        logger.info("ExecutePlan")
        if self.log_request_fn is not None:
            self.log_request_fn(request.SerializeToString())
        if self.gs_proxy is not None:
            return self.gs_proxy.execute_plan(request)
        # TODO: remove session id context when we host this in Snowflake server
        # set the thread-local context of session id
        clear_context_data()
        set_session_id(request.session_id)
        set_spark_version(request.client_type)
        result = []
        streaming_relation = False
        while True:
            try:
                match request.plan.WhichOneof("op_type"):
                    case "root":
                        logger.info("ROOT")
                        result += map_execution_root(request)
                    case "command":
                        logger.info("COMMAND")
                        command_result = map_execution_command(request)
                        if command_result is not None:
                            result.append(command_result)
            except Exception as e:
                import traceback

                traceback.print_exc()
                rich_status = build_grpc_error_response(e)
                context.abort_with_status(rpc_status.to_status(rich_status))

            if not (is_streaming(request.plan.root) or streaming_relation):
                return iter(
                    result
                    + [
                        proto_base.ExecutePlanResponse(
                            session_id=request.session_id,
                            operation_id=SERVER_SIDE_SESSION_ID,
                            result_complete=proto_base.ExecutePlanResponse.ResultComplete(),
                        ),
                    ]
                )

    def AnalyzePlan(self, request: proto_base.AnalyzePlanRequest, context):
        """Analyzes a query and returns a [[AnalyzeResponse]] containing metadata about the query."""
        logger.info(f"AnalyzePlan: {request.WhichOneof('analyze')}")
        if self.log_request_fn is not None:
            self.log_request_fn(request.SerializeToString())
        try:
            # TODO: remove session id context when we host this in Snowflake server
            # set the thread-local context of session id
            clear_context_data()
            set_session_id(request.session_id)
            set_spark_version(request.client_type)
            match request.WhichOneof("analyze"):
                case "schema":
                    snowpark_df = map_relation(request.schema.plan.root)
                    snowpark_schema: snowpark.types.StructType = snowpark_df.schema
                    schema = proto_base.AnalyzePlanResponse.Schema(
                        schema=types_proto.DataType(
                            **snowpark_to_proto_type(
                                snowpark_schema, snowpark_df._column_map, snowpark_df
                            )
                        )
                    )
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        schema=schema,
                    )
                case "tree_string":
                    return map_tree_string(request)
                case "is_local":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        is_local=proto_base.AnalyzePlanResponse.IsLocal(is_local=False),
                    )
                case "ddl_parse":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        ddl_parse=proto_base.AnalyzePlanResponse.DDLParse(
                            parsed=parse_ddl_string(request.ddl_parse.ddl_string)
                        ),
                    )
                case "get_storage_level":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        get_storage_level=proto_base.AnalyzePlanResponse.GetStorageLevel(
                            storage_level=common_proto.StorageLevel(
                                use_disk=True, use_memory=True
                            )
                        ),
                    )
                case "persist":
                    plan_id = request.persist.relation.common.plan_id
                    # cache the plan if it is not already in the map

                    df_cache_map_put_if_absent(
                        (request.session_id, plan_id),
                        lambda: map_relation(request.persist.relation),
                        materialize=True,
                    )

                    storage_level = request.persist.storage_level
                    if storage_level != StorageLevel.DISK_ONLY:
                        log_waring_once_storage_level(storage_level)

                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        persist=proto_base.AnalyzePlanResponse.Persist(),
                    )
                case "unpersist":
                    plan_id = request.persist.relation.common.plan_id
                    # unpersist the cached plan
                    df_cache_map_pop((request.session_id, plan_id))

                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        unpersist=proto_base.AnalyzePlanResponse.Unpersist(),
                    )
                case "explain":
                    # Snowflake only exposes simplified execution plans, similar to Spark's optimized logical plans.
                    # Snowpark provides the execution plan IFF the dataframe maps to a single query.
                    # TODO: Do we need to return a Spark-like plan?
                    snowpark_df = map_relation(request.explain.plan.root)
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        explain=proto_base.AnalyzePlanResponse.Explain(
                            explain_string=snowpark_df._explain_string()
                        ),
                    )
                case "spark_version":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        spark_version=proto_base.AnalyzePlanResponse.SparkVersion(
                            version="3.5.3"
                        ),
                    )
                case "same_semantics":
                    target_queries_hash = xxhash64_string(
                        get_semantic_string(request.same_semantics.target_plan.root)
                    )
                    other_queries_hash = xxhash64_string(
                        get_semantic_string(request.same_semantics.other_plan.root)
                    )
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        same_semantics=proto_base.AnalyzePlanResponse.SameSemantics(
                            result=target_queries_hash == other_queries_hash
                        ),
                    )
                case "semantic_hash":
                    queries_str = get_semantic_string(request.semantic_hash.plan.root)
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        semantic_hash=proto_base.AnalyzePlanResponse.SemanticHash(
                            result=xxhash64_string(queries_str)
                            & 0x7FFFFFFF  # need a 32 bit int here.
                        ),
                    )
                case "is_streaming":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        is_streaming=proto_base.AnalyzePlanResponse.IsStreaming(
                            is_streaming=False
                        ),
                    )
                case _:
                    raise SnowparkConnectNotImplementedError(
                        f"ANALYZE PLAN NOT IMPLEMENTED:\n{request}"
                    )
        except Exception as e:
            import traceback

            traceback.print_exc()
            rich_status = build_grpc_error_response(e)
            context.abort_with_status(rpc_status.to_status(rich_status))

    @staticmethod
    def Config(
        request: proto_base.ConfigRequest,
        context,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        """Update or fetch the configurations and returns a [[ConfigResponse]] containing the result."""
        logger.info("Config")
        return route_config_proto(request, snowpark.Session.builder.getOrCreate())

    def AddArtifacts(self, request_iterator, context):
        """Add artifacts to the session and returns a [[AddArtifactsResponse]] containing metadata about
        the added artifacts.
        """
        logger.info("AddArtifacts")
        raise SnowparkConnectNotImplementedError(
            f"ADD ARTIFACTS NOT IMPLEMENTED:\n{request_iterator}"
        )

    def ArtifactStatus(self, request, context):
        """Check statuses of artifacts in the session and returns them in a [[ArtifactStatusesResponse]]"""
        logger.info("ArtifactStatus")
        raise SnowparkConnectNotImplementedError(
            f"ARTIFACT STATUS NOT IMPLEMENTED:\n{request}"
        )

    def Interrupt(self, request, context):
        """Interrupts running executions"""
        logger.info("Interrupt")
        raise SnowparkConnectNotImplementedError(
            f"INTERRUPT NOT IMPLEMENTED:\n{request}"
        )

    def ReattachExecute(self, request: proto_base.ReattachExecuteRequest, context):
        """Reattach to an existing reattachable execution.
        The ExecutePlan must have been started with ReattachOptions.reattachable=true.
        If the ExecutePlanResponse stream ends without a ResultComplete message, there is more to
        continue. If there is a ResultComplete, the client should use ReleaseExecute with
        """
        logger.info("ReattachExecute")
        raise SnowparkConnectNotImplementedError(
            "Spark client has detached, please resubmit request. In a future version, the server will be support the reattach."
        )

    def ReleaseExecute(self, request: proto_base.ReleaseExecuteRequest, context):
        """Release an reattachable execution, or parts thereof.
        The ExecutePlan must have been started with ReattachOptions.reattachable=true.
        Non reattachable executions are released automatically and immediately after the ExecutePlan
        RPC and ReleaseExecute may not be used.
        """
        logger.info("ReleaseExecute")
        return proto_base.ReleaseExecuteResponse(
            session_id=request.session_id,
            operation_id=SERVER_SIDE_SESSION_ID,
        )

    # TODO: These are required in Spark 4.x.
    # def ReleaseSession(self, request, context):
    #     """Release a session.
    #     All the executions in the session will be released. Any further requests for the session with
    #     that session_id for the given user_id will fail. If the session didn't exist or was already
    #     released, this is a noop.
    #     """
    #     logger.info("ReleaseSession")
    #     return super().ReleaseSession(request, context)
    #
    # def FetchErrorDetails(self, request, context):
    #     """FetchErrorDetails retrieves the matched exception with details based on a provided error id."""
    #     logger.info("FetchErrorDetails")
    #     return super().FetchErrorDetails(request, context)


_server_running: threading.Event = threading.Event()
_server_url: Optional[str] = None
_client_url: Optional[str] = None
_server_error: bool = False


def _stop_server(stop_event: threading.Event, server: grpc.Server):
    stop_event.wait()
    server.stop(0)
    logger.info("server stop sent")


def _serve(
    stop_event: Optional[threading.Event] = None,
    session: Optional[snowpark.Session] = None,
    gs_endpoint: Optional[str] = None,
):
    global _server_running, _server_error
    # TODO: factor out the Snowflake connection code.
    try:
        config_snowpark()
        if session is None:
            session = (
                snowpark.Session.builder.config(
                    "connection_name", DEFAULT_CONNECTION_NAME
                )
                .config("eliminate_numeric_sql_value_cast_enabled", False)
                .config("arrow_number_to_decimal", True)
                .create()
            )
        session._sas_telemetry_client = TelemetryClient(session._conn._conn)
        session._udfs = {}
        session._udtfs = {}
        # TODO: Remove this when SNOW-1906574 is resolved
        session.cte_optimization_enabled = False
        session.reduce_describe_query_enabled = True
        session._join_alias_fix = True
        init_snowpark_session(session)
        setup_pandas_timestamp_monkey_patch()
        server_options = [
            ("grpc.max_receive_message_length", _SPARK_CONNECT_GRPC_MAX_MESSAGE_SIZE),
        ]
        server = grpc.server(
            futures.ThreadPoolExecutor(max_workers=10), options=server_options
        )
        control_servicer = ControlServicer(session)
        proto_base_grpc.add_SparkConnectServiceServicer_to_server(
            SnowflakeConnectServicer(
                control_servicer.log_spark_connect_batch, gs_endpoint
            ),
            server,
        )
        control_grpc.add_ControlServiceServicer_to_server(control_servicer, server)
        server_url = get_server_url()
        server.add_insecure_port(server_url)
        server.start()
        logger.info(f"Snowpark Connect session started on {server_url}")
        _server_running.set()
        session._sas_telemetry_client.send_server_started_telemetry()
        if stop_event is not None:
            # start a background thread to listen for stop event and terminate the server
            threading.Thread(
                target=_stop_server, args=(stop_event, server), daemon=True
            ).start()
        server.wait_for_termination()
    except Exception as e:
        _server_error = True
        _server_running.set()  # unblock any client sessions
        logger.error(e, exc_info=True)
        if "Invalid connection_name 'spark-connect', known ones are " in str(e):
            logger.error(
                "Ensure 'spark-connect' connection config has been set correctly in connections.toml."
            )


def _set_remote_url(remote_url: str):
    global _server_url, _client_url
    if remote_url.startswith("sc://"):
        _client_url = remote_url[5:]
        _server_url = _client_url.split("/")[0]
    elif remote_url.startswith("unix:/"):
        _client_url = remote_url
        _server_url = remote_url.split("/;")[0]
    else:
        raise RuntimeError(f"Invalid Snowpark Connect URL: {remote_url}")


def _set_server_tcp_port(server_port: int):
    global _server_url, _client_url
    _server_url = f"[::]:{server_port}"
    _client_url = f"sc://localhost:{server_port}"


def _is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("localhost", port)) == 0


def _set_server_unix_domain_socket(path: str):
    global _server_url, _client_url
    _server_url = f"unix:{path}"
    _client_url = f"unix:{path}"


def get_server_url() -> str:
    global _server_url
    if not _server_url:
        raise RuntimeError("Server URL not set")
    return _server_url


def get_client_url() -> str:
    global _client_url
    if not _client_url:
        raise RuntimeError("Client URL not set")
    return _client_url


def _make_unix_domain_socket() -> str:
    parent_dir = tempfile.mkdtemp()
    server_path = os.path.join(parent_dir, "snowflake_sas_grpc.sock")
    atexit.register(_cleanup_unix_domain_socket, server_path)
    return server_path


def _cleanup_unix_domain_socket(server_path: str) -> None:
    parent_dir = os.path.dirname(server_path)
    if os.path.exists(server_path):
        os.remove(server_path)
    if os.path.exists(parent_dir):
        os.rmdir(parent_dir)


class UnixDomainSocketChannelBuilder(ChannelBuilder):
    """
    Spark Connect gRPC channel builder for Unix domain sockets
    """

    def __init__(self, channelOptions: Optional[List[Tuple[str, Any]]] = None) -> None:
        url: str = get_client_url()
        if url[:6] != "unix:/" or len(url) < 7:
            raise PySparkValueError(
                error_class="INVALID_CONNECT_URL",
                message_parameters={
                    "detail": "The URL must start with 'unix://'. Please update the URL to follow the correct format, e.g., 'unix://unix_domain_socket_path'.",
                },
            )

        # Rewrite the URL to use http as the scheme so that we can leverage
        # Python's built-in parser to parse URL parameters
        fake_url = "http://" + url[6:]
        self.url = urllib.parse.urlparse(fake_url)
        self.params: Dict[str, str] = {}
        self._extract_attributes()

        # Now parse the real unix domain socket URL
        self.url = urllib.parse.urlparse(url)

        GRPC_DEFAULT_OPTIONS = [
            ("grpc.max_send_message_length", _SPARK_CONNECT_GRPC_MAX_MESSAGE_SIZE),
            ("grpc.max_receive_message_length", _SPARK_CONNECT_GRPC_MAX_MESSAGE_SIZE),
        ]

        if channelOptions is None:
            self._channel_options = GRPC_DEFAULT_OPTIONS
        else:
            self._channel_options = GRPC_DEFAULT_OPTIONS + channelOptions

    @property
    def endpoint(self) -> str:
        return f"{self.url.scheme}:{self.url.path}"

    def toChannel(self) -> grpc.Channel:
        return grpc.insecure_channel(self.endpoint, options=self._channel_options)


def config_snowpark() -> None:
    """
    Some snowpark configs required by SAS.
    """

    # Enable structType. Require snowpark 1.27.0 or snowpark main branch after commit 888cec55c4
    import snowflake.snowpark.context as context

    context._use_structured_type_semantics = True
    context._is_snowpark_connect_compatible_mode = True


def setup_pandas_timestamp_monkey_patch():
    """
    Monkey patch pandas.Timestamp.astimezone to safely invoke astimezone with no arguments.
    The pandas implementation of astimezone fails when invoked with no arguments, but Python's
    datetime.datetime object can accept no arguments.

    As pyspark's dataframe.collect() internally calls astimezone().replace(tzinfo=None) with no arguments,
    Sas's dataframe.collect() with timestamp values is broken. This monkey patch
    will help us navigate through that edge-case by explicitly passing tz=None to the astimezone method.
    """
    original_astimezone = pandas.Timestamp.astimezone

    def safe_astimezone(self, *args):
        if not args:
            return original_astimezone(self, tz=None)
        return original_astimezone(self, *args)

    pandas.Timestamp.astimezone = safe_astimezone


def start_jvm():
    # The JVM is used to run the Spark parser and JDBC drivers,
    # so needs to be configured to support both.

    # JDBC driver .jars are added using the CLASSPATH env var.
    # We then add the Spark parser jars (that are shipped with pyspark)
    # by appending them to the default classpath.

    # Since we need to control JVM's parameters, fail immediately
    # if the JVM has already been started elsewhere.
    if jpype.isJVMStarted():
        raise RuntimeError(
            "JVM must not be running when starting the Spark Connect server"
        )

    pyspark_jars = pathlib.Path(pyspark.__file__).parent / "jars"
    spark_parser_deps = [
        "antlr4-*.jar",
        "commons-*.jar",
        "hadoop-client-api-*.jar",
        "jackson-*.jar",
        "json4s-*.jar",
        "kryo-shaded-*.jar",
        "log4j-*.jar",
        "paranamer-*.jar",
        "scala-*.jar",
        "slf4j-*.jar",
        "spark-*.jar",
    ]
    for dep in spark_parser_deps:
        for path in pyspark_jars.glob(dep):
            jpype.addClassPath(path)

    # TODO: Should remove convertStrings, but it breaks the JDBC code.
    jpype.startJVM(convertStrings=True)


def start_session(
    is_daemon: bool = True,
    remote_url: Optional[str] = None,
    tcp_port: Optional[int] = None,
    unix_domain_socket: Optional[str] = None,
    stop_event: threading.Event = None,
    snowpark_session: Optional[snowpark.Session] = None,
    gs_endpoint: Optional[str] = None,
) -> threading.Thread | None:
    """
    Starts Spark Connect server connected to Snowflake. No-op if the Server is already running.

    Parameters:
        is_daemon (bool): Should run the server as daemon or not. use True to automatically shut the Spark connect
                          server down when the main program (or test) finishes. use False to start the server in a
                          stand-alone, long-running mode.
        remote_url (Optional[str]): sc:// URL on which to start the Spark Connect server. This option is incompatible with the tcp_port
                                    and unix_domain_socket parameters.
        tcp_port (Optional[int]): TCP port on which to start the Spark Connect server. This option is incompatible with
                                  the remote_url and unix_domain_socket parameters.
        unix_domain_socket (Optional[str]): Path to the unix domain socket on which to start the Spark Connect server.
                                            This option is incompatible with the remote_url and tcp_port parameters.
        stop_event (Optional[threading.Event]): Stop the SAS server when stop_event.set() is called.
                                                Only works when is_daemon=True.
        snowpark_session: A Snowpark session to use for this connection; currently the only applicable use of this is to
                          pass in the session created by the stored proc environment.
        gs_endpoint: If supplied, specifies the REST endpoint to forward queries to. This is used in the early stages
                     of testing the server-side functionality. To be deprecated when the real Spark Connect endpoint is
                     implemented.
    """
    if os.environ.get("SPARK_ENV_LOADED"):
        raise RuntimeError(
            "Snowpark Connect cannot be run inside of a Spark environment"
        )

    global _server_running
    if _server_running.is_set():
        url = get_client_url()
        logger.warning(f"Snowpark Connect session is already running at {url}")
        return
    if len(list(filter(None, [remote_url, tcp_port, unix_domain_socket]))) > 1:
        raise RuntimeError(
            "Can only set at most one of remote_url, tcp_port, and unix_domain_socket"
        )
    # Suppress Snowpark warnings by default since they are not relevant to users.
    snowpark_logger = logging.getLogger("snowflake.snowpark")
    snowpark_logger.setLevel(logging.ERROR)
    if remote_url:
        _set_remote_url(remote_url)
    elif tcp_port:
        # Verify the port is currently free.
        if _is_port_in_use(tcp_port):
            raise RuntimeError(f"TCP port {tcp_port} is already in use")
        _set_server_tcp_port(tcp_port)
    else:
        if not unix_domain_socket:
            # If neither are specified, create ephemeral unique unix domain socket.
            unix_domain_socket = _make_unix_domain_socket()
        _set_server_unix_domain_socket(unix_domain_socket)

    if not gs_endpoint:
        start_jvm()

    if is_daemon:
        arguments = (stop_event, snowpark_session, gs_endpoint)
        # `daemon=True` ensures the server thread exits when script finishes.
        server_thread = threading.Thread(target=_serve, args=arguments, daemon=True)
        server_thread.start()
        _server_running.wait()
        if _server_error:
            raise RuntimeError("Snowpark Connect session failed to start")
        return server_thread
    else:
        # Launch in the foreground.
        _serve(session=snowpark_session, gs_endpoint=gs_endpoint)

    # Wait for server to start.


def get_session(url: Optional[str] = None, conf: SparkConf = None) -> SparkSession:
    """
    Returns spark connect session

    Parameters:
        url (Optional[str]): Spark connect server URL. Uses default server URL if none is provided.

    Returns:
        A new spark connect session

    Raises:
        RuntimeError: If Spark Connect server is not started.
    """
    global _server_error
    if not url:
        url = get_client_url()

    if url.startswith("unix:/"):
        b = SparkSession.builder.channelBuilder(UnixDomainSocketChannelBuilder())
    else:
        b = SparkSession.builder.remote(url)

    if conf is not None:
        b.config(conf)

    return b.getOrCreate()
