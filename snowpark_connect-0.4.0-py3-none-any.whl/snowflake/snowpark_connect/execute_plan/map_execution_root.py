import pandas
import pyspark.sql.connect.proto.base_pb2 as proto_base

from snowflake import snowpark
from snowflake.snowpark_connect.constants import SERVER_SIDE_SESSION_ID
from snowflake.snowpark_connect.execute_plan.utils import (
    arrow_table_to_arrow_bytes,
    pandas_to_arrow_batches_bytes,
)
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.type_mapping import snowpark_to_proto_type


def map_execution_root(
    request: proto_base.ExecutePlanRequest,
) -> list[proto_base.ExecutePlanResponse]:
    result_df: snowpark.DataFrame | pandas.DataFrame = map_relation(request.plan.root)
    if isinstance(result_df, snowpark.DataFrame):
        snowpark_schema = result_df.schema
        schema = snowpark_to_proto_type(
            snowpark_schema, result_df._column_map, result_df
        )

        arrow_table = result_df.to_arrow()
        row_count = arrow_table.num_rows
        if arrow_table.num_rows == 0:
            # empty result needs special processing
            pandas_df = result_df.to_pandas()
            data_bytes = pandas_to_arrow_batches_bytes(pandas_df)
        else:
            data_bytes = arrow_table_to_arrow_bytes(arrow_table, snowpark_schema)
    else:
        pandas_df = result_df
        data_bytes = pandas_to_arrow_batches_bytes(pandas_df)
        row_count = len(pandas_df)
        schema = None
    return [
        proto_base.ExecutePlanResponse(
            session_id=request.session_id,
            operation_id=SERVER_SIDE_SESSION_ID,
            arrow_batch=proto_base.ExecutePlanResponse.ArrowBatch(
                row_count=row_count,
                data=data_bytes,
            ),
            schema=schema,
        ),
    ]
