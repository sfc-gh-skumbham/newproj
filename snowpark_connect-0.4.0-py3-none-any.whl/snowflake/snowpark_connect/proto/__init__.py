# N.B. The generated protobuf code uses a local import, which breaks without this.

import os
import sys

sys.path.append(os.path.abspath(os.path.dirname(__file__)))
