import datetime
from collections import defaultdict

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark import Session
from snowflake.snowpark.column import Column
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.expression import (
    map_udf,
    map_unresolved_attribute as map_att,
    map_unresolved_function as map_func,
    map_window_function as map_window_func,
)
from snowflake.snowpark_connect.expression.literal import get_literal_field_and_name
from snowflake.snowpark_connect.expression.map_cast import map_cast
from snowflake.snowpark_connect.expression.map_sql_expression import map_sql_expr
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import map_simple_types
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import (
    gen_sql_plan_id,
    is_function_argument_being_resolved,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_alias(
    alias: expressions_proto.Expression.Alias,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    """
    Map an alias expression to a Snowpark expression.

    Args:
        alias (expressions_proto.Expression.Alias): The alias expression to map.
    """
    if len(list(alias.name)) != 1:
        expression_name = map_single_column_expression(
            alias.expr, column_mapping, typer
        )[0]
        raise ValueError(
            f"Found the unresolved operator: 'Project [{expression_name} AS ({', '.join(list(alias.name))})]'"
        )
    name, col = map_single_column_expression(alias.expr, column_mapping, typer)
    col_name = alias.name[0]
    if is_function_argument_being_resolved():
        # Function arguments need to be quoted if they contain spaces and require syntax 'expr AS alias' instead of 'alias'
        col_name = (
            f"`{col_name.replace('`', '``')}`"
            if any(char.isspace() or char == "`" for char in col_name)
            else col_name
        )
        col_name = f"{name} AS {col_name}"
    # Spark passes a list for alias name, but it is unclear why since alias
    # can only take a single argument.
    # We need to make sure that the aliased snowpark column has a unique name, so
    # gen_sql_plan_id is used to suffix the alias.
    # TODO: do we need to push down the actual plan_id?
    return col_name, col.alias(f"{alias.name[0]}-{gen_sql_plan_id()}")


def map_single_column_expression(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    col_names, typed_col = map_expression(exp, column_mapping, typer)
    assert (
        len(col_names) == 1
    ), f"Expected exactly single column expression, got {len(col_names)}"
    return col_names[0], typed_col


def map_expression(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    """
    Map an expression to a Snowpark expression.

    Args:
        exp (expressions_proto.Expression): The expression to map.
        column_mapping (ColumnNameMapper): The mapping from column names to Snowpark
            column objects.
    """

    expr_type = exp.WhichOneof("expr_type")
    match expr_type:
        case "alias":
            col_name, col = map_alias(exp.alias, column_mapping, typer)
            return [col_name], col
        case "call_function":
            new_expression = expressions_proto.Expression(
                unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                    function_name=exp.call_function.function_name,
                    arguments=exp.call_function.arguments,
                )
            )
            return map_func.map_unresolved_function(
                new_expression, column_mapping, typer
            )
        case "cast":
            return map_cast(exp, column_mapping, typer)
        case "common_inline_user_defined_function":
            name, col = map_udf.map_common_inline_user_defined_udf(
                exp, column_mapping, typer
            )
            return [name], col
        case "expression_string":
            return map_sql_expr(exp, column_mapping, typer)
        case "lambda_function":
            lambda_name, lambda_body = map_single_column_expression(
                exp.lambda_function.function, column_mapping, typer
            )
            args = [a.name_parts[0] for a in exp.lambda_function.arguments]
            args_str = ", ".join(args)
            analyzer = Session.get_active_session()._analyzer
            body_str = analyzer.analyze(lambda_body.col._expression, defaultdict())
            result_exp = snowpark_fn.sql_expr(f"({args_str}) -> {body_str}")
            args_name = ", ".join(["namedlambdavariable()"] * len(args))
            return (
                [f"lambdafunction({lambda_name}, {args_name})"],
                TypedColumn(
                    result_exp,
                    lambda: typer.type(result_exp),
                ),
            )
        case "literal":
            lit_value, lit_name = get_literal_field_and_name(exp.literal)
            lit_type_str = str(exp.literal.WhichOneof("literal_type"))
            # this is a hack until we would have an interval type supported in snowflake, for now
            # this will use the interval expression instead of literal expression to solve this usecase.
            if isinstance(lit_value, datetime.timedelta):
                return [lit_name], TypedColumn(
                    snowpark_fn.make_interval(
                        days=lit_value.days,
                        seconds=lit_value.seconds,
                        microseconds=lit_value.microseconds,
                    ),
                    lambda: [map_simple_types(lit_type_str)],
                )
            return [lit_name], TypedColumn(
                snowpark_fn.lit(lit_value), lambda: [map_simple_types(lit_type_str)]
            )
        case "sort_order":
            child_name, child_column = map_single_column_expression(
                exp.sort_order.child, column_mapping, typer
            )
            match exp.sort_order.direction:
                case (
                    exp.sort_order.SORT_DIRECTION_UNSPECIFIED
                    | exp.sort_order.SORT_DIRECTION_ASCENDING
                ):
                    if exp.sort_order.null_ordering == exp.sort_order.SORT_NULLS_LAST:
                        return [child_name], snowpark_fn.asc_nulls_last(child_column)
                    else:
                        # If nulls are not specified or null_ordering is FIRST in the sort order, Spark defaults to nulls
                        # first in the case of ascending sort order.
                        return [child_name], snowpark_fn.asc_nulls_first(child_column)
                case exp.sort_order.SORT_DIRECTION_DESCENDING:
                    if exp.sort_order.null_ordering == exp.sort_order.SORT_NULLS_FIRST:
                        return [child_name], snowpark_fn.desc_nulls_first(child_column)
                    else:
                        # If nulls are not specified or null_ordering is LAST in the sort order, Spark defaults to nulls
                        # last in the case of descending sort order.
                        return [child_name], snowpark_fn.desc_nulls_last(child_column)
                case _:
                    raise ValueError(
                        f"Invalid sort direction {exp.sort_order.direction}"
                    )
        case "unresolved_attribute":
            col_name, col = map_att.map_unresolved_attribute(exp, column_mapping, typer)
            return [col_name], col
        case "unresolved_extract_value":
            child_name, child_typed_column = map_single_column_expression(
                exp.unresolved_extract_value.child, column_mapping, typer
            )
            extract_name, extract_typed_column = map_single_column_expression(
                exp.unresolved_extract_value.extraction,
                column_mapping,
                typer,
            )
            spark_function_name = f"{child_name}[{extract_name}]"
            result_exp = child_typed_column.col.getItem(
                Column._to_expr(extract_typed_column.col).value
            )
            return [spark_function_name], TypedColumn(
                result_exp, lambda: typer.type(result_exp)
            )
        case "unresolved_function":
            return map_func.map_unresolved_function(exp, column_mapping, typer)
        case "unresolved_named_lambda_variable":
            lv_name = exp.unresolved_named_lambda_variable.name_parts[0]
            col = snowpark_fn.col(lv_name)
            return ["namedlambdavariable()"], TypedColumn(col, lambda: typer.type(col))
        case "unresolved_regex":
            p = exp.unresolved_regex.col_name
            pattern_str = p[1:-1] if p.startswith("`") and p.endswith("`") else p

            mapping = column_mapping.spark_to_snowpark_for_pattern(pattern_str)
            spark_cols, snowpark_cols = (
                [spark_name for spark_name, _ in mapping],
                [snowpark_name for _, snowpark_name in mapping],
            )

            col_expr = snowpark_fn.sql_expr(", ".join(snowpark_cols))
            return (
                spark_cols,
                TypedColumn(col_expr, lambda: typer.type(col_expr))
                if snowpark_cols
                else TypedColumn.empty(),
            )
        case "unresolved_star":
            result_exp = snowpark_fn.col("*", _is_qualified_name=True)
            return ["*"], TypedColumn(result_exp, lambda: typer.type(result_exp))
        case "window":
            col_name, col = map_window_func.map_window_function(
                exp, column_mapping, typer
            )
            return [col_name], col
        case _:
            raise SnowparkConnectNotImplementedError(
                f"Unsupported expression type {expr_type}"
            )
