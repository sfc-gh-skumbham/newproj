import re
from typing import Tuple

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark._internal.utils import quote_name
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import get_alias_map, get_plan_id_map

SPARK_QUOTED = re.compile("^(`.*`)$", re.DOTALL)


def is_spark_quoted(name: str) -> bool:
    """
    Check if the name is already quoted.
    """
    return SPARK_QUOTED.match(name) is not None


def split_fully_qualified_spark_name(qualified_name: str) -> list[str]:
    """
    Splits a fully qualified Spark identifier into its component parts.

    A dot (.) is used as a delimiter only when occurring outside a quoted segment.
    A quoted segment is wrapped in single backticks. Inside a quoted segment,
    any occurrence of two consecutive backticks is treated as a literal backtick.
    After splitting, any token that was quoted is unescaped:
      - The external backticks are removed.
      - Any double backticks are replaced with a single backtick.

    Examples:
      "a.b.c"
         -> ["a", "b", "c"]

      "`a.somethinh.b`.b.c"
         -> ["a.somethinh.b", "b", "c"]

      "`a$b`.`b#c`.d.e.f.g.h.as"
         -> ["a$b", "b#c", "d", "e", "f", "g", "h", "as"]

      "`a.b.c`"
         -> ["a.b.c"]

      "`a``b``c.d.e`"
         -> ["a`b`c", "d", "e"]

      "asdfasd" -> ["asdfasd"]
    """
    if qualified_name == "``":
        # corner case where empty string is denoted by an empty string. We cannot have emtpy string
        # in fully qualified name.
        return [""]

    parts = []
    token_chars = []
    in_quotes = False
    i = 0
    n = len(qualified_name)

    while i < n:
        ch = qualified_name[i]
        if ch == "`":
            # If current char is a backtick:
            if i + 1 < n and qualified_name[i + 1] == "`":
                # If next char is also a backtick, unescape the backtick character by replacing `` with `.
                token_chars.append("`")
                i += 2
                continue
            else:
                # Toggle the in_quotes state and skip backtick in the token.
                in_quotes = not in_quotes
                i += 1
        elif ch == "." and not in_quotes:
            # Dot encountered outside of quotes: finish the current token.
            parts.append("".join(token_chars))
            token_chars = []
            i += 1
        else:
            token_chars.append(ch)
            i += 1

    if token_chars:
        parts.append("".join(token_chars))

    return parts


def map_unresolved_attribute(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    attr_name = exp.unresolved_attribute.unparsed_identifier
    name_parts = split_fully_qualified_spark_name(attr_name)
    attr_name = ".".join(name_parts)

    assert len(name_parts) > 0, f"Unable to parse input attribute: {attr_name}"

    if exp.unresolved_attribute.HasField("plan_id"):
        target_df = get_plan_id_map(exp.unresolved_attribute.plan_id)
        typer = ExpressionTyper(target_df)
        assert (
            target_df is not None
        ), f"resolving an attribute of a unresolved dataframe {exp.unresolved_attribute.plan_id}"
        snowpark_name = (
            target_df._column_map.get_snowpark_column_name_from_spark_column_name(
                name_parts[0]
            )
        )
        if len(name_parts) > 1:
            parent_chain = ".".join(name_parts[:-1])
            snowpark_name = f"{parent_chain}.{snowpark_name}"
        col = target_df.col(snowpark_name)
    else:
        snowpark_name = column_mapping.get_snowpark_column_name_from_spark_column_name(
            name_parts[0], allow_non_exists=True
        )
        if snowpark_name is None:
            # check for alias
            (alias_name, col_name) = _parse_spark_column_alias(attr_name)
            if col_name is not None and alias_name in get_alias_map():
                alias_df = get_alias_map()[alias_name]
                typer = ExpressionTyper(alias_df)
                snowpark_name = alias_df._column_map.get_snowpark_column_name_from_spark_column_name(
                    col_name
                )
                col = alias_df.col(snowpark_name)
                return col_name, TypedColumn(col, lambda: typer.type(col))
            # Column does not exist. Pass in dummy column name for lazy error throwing.
            snowpark_name = attr_name

        if len(name_parts) > 1:
            # Add the quotes to match the snowpark schema. We added them to escape special character in the child names.
            child_chain = ".".join([quote_name(name, True) for name in name_parts[1:]])
            snowpark_name = f"""{snowpark_name}.{child_chain}"""
            col = snowpark_fn.col(
                snowpark_name,
                _is_qualified_name=True,
            )
        else:
            col = snowpark_fn.col(snowpark_name)

    return (attr_name, TypedColumn(col, lambda: typer.type(col)))


def _parse_spark_column_alias(attr_name: str) -> Tuple[str, str | None]:
    """Parse df_alias.col to (df_alias, col)"""
    # TODO: properly handle alias and column names that contains ` and .
    res = attr_name.split(".")
    if len(res) == 1:
        return res[0], None
    return res[0], res[1]
