import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.expression.literal import get_literal_field_and_name
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import temporary_window_expression

# SQL functions that support ROWS BETWEEN but not RANGE BETWEEN.
ROWS_ONLY_FUNCTIONS = frozenset(
    ["first", "first_value", "last", "last_value", "nth_value"]
)


def map_window_function(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    from snowflake.snowpark_connect.expression.map_expression import (
        map_single_column_expression,
    )

    with temporary_window_expression(typer):

        def parse_frame_boundary(
            boundary: expressions_proto.Expression.Window.WindowFrame.FrameBoundary,
            is_upper: bool,
        ) -> tuple[str, int]:
            if boundary.HasField("current_row"):
                return "CURRENT ROW", snowpark.Window.CURRENT_ROW
            elif boundary.HasField("unbounded"):
                if is_upper:
                    return "UNBOUNDED FOLLOWING", snowpark.Window.UNBOUNDED_FOLLOWING
                else:
                    return "UNBOUNDED PRECEDING", snowpark.Window.UNBOUNDED_PRECEDING
            elif boundary.HasField("value"):
                # the expression has to be literal of int in the case of rows_between or range_betwen
                literal, _ = get_literal_field_and_name(boundary.value.literal)
                return f"{literal} FOLLOWING", literal

        function_name, window_func = map_single_column_expression(
            exp.window.window_function, column_mapping, typer
        )
        partitions = [
            map_single_column_expression(p, column_mapping, typer)[1].col
            for p in exp.window.partition_spec
        ]

        orders = []
        orderby_name = ["ORDER BY "]
        for order in exp.window.order_spec:
            order_col_name, (order_exp, _) = map_single_column_expression(
                order.child, column_mapping, typer
            )
            orderby_name.append(order_col_name)
            match order.direction:
                case expressions_proto.Expression.SortOrder.SortDirection.SORT_DIRECTION_ASCENDING:
                    orderby_name.append(" ASC ")
                    match order.null_ordering:
                        case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_FIRST:
                            orderby_name.append("NULLS FIRST")
                            orders.append(order_exp.asc_nulls_first())
                        case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_LAST:
                            orderby_name.append("NULLS LAST")
                            orders.append(order_exp.asc_nulls_last())
                        case _:
                            orders.append(order_exp.asc())
                case expressions_proto.Expression.SortOrder.SortDirection.SORT_DIRECTION_DESCENDING:
                    orderby_name.append(" DESC ")
                    match order.null_ordering:
                        case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_FIRST:
                            orderby_name.append("NULLS FIRST")
                            orders.append(order_exp.desc_nulls_first())
                        case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_LAST:
                            orderby_name.append("NULLS LAST")
                            orders.append(order_exp.desc_nulls_last())
                        case _:
                            orders.append(order_exp.desc())
                case _:
                    # When order direction is not specified, nulls first/last is ignored, because
                    # there is no order_exp.nulls_first() / order_exp.nulls_last()
                    orders.append(order_exp)
            orderby_name.append(", ")

        window_df = snowpark.Window
        if len(partitions) > 0:
            window_df = window_df.partitionBy(partitions)
        if len(orders) > 0:
            window_df = window_df.orderBy(orders)

        frame_name = []
        match exp.window.frame_spec.frame_type:
            case expressions_proto.Expression.Window.WindowFrame.FrameType.FRAME_TYPE_ROW:
                frame_name.append("ROWS BETWEEN")
                lower_name, lower = parse_frame_boundary(
                    exp.window.frame_spec.lower, is_upper=False
                )
                upper_name, upper = parse_frame_boundary(
                    exp.window.frame_spec.upper, is_upper=True
                )

                is_unbounded = (
                    lower == snowpark.Window.UNBOUNDED_PRECEDING
                    and upper == snowpark.Window.UNBOUNDED_FOLLOWING
                )
                if not orders and is_unbounded:
                    window_df = window_df.orderBy(
                        column_mapping.get_snowpark_columns()[0]
                    )

                window_df = window_df.rows_between(lower, upper)
                frame_name.append(f"{lower_name} AND {upper_name}")
            case expressions_proto.Expression.Window.WindowFrame.FrameType.FRAME_TYPE_RANGE:
                frame_name.append("RANGE BETWEEN")
                lower_name, lower = parse_frame_boundary(
                    exp.window.frame_spec.lower, is_upper=False
                )
                upper_name, upper = parse_frame_boundary(
                    exp.window.frame_spec.upper, is_upper=True
                )

                is_unbounded = (
                    lower == snowpark.Window.UNBOUNDED_PRECEDING
                    and upper == snowpark.Window.UNBOUNDED_FOLLOWING
                )
                if not orders and is_unbounded:
                    window_df = window_df.orderBy(
                        column_mapping.get_snowpark_columns()[0]
                    )

                window_df = window_df.range_between(lower, upper)
                frame_name.append(f"{lower_name} AND {upper_name}")
            case _:
                if orders:
                    # Work around functions that support ROWS BETWEEN but not RANGE BETWEEN:
                    # for current row or unbounded limits there should be no difference.
                    if (
                        exp.window.window_function.unresolved_function.function_name
                        in ROWS_ONLY_FUNCTIONS
                    ):
                        window_df = window_df.rows_between(
                            snowpark.Window.UNBOUNDED_PRECEDING,
                            snowpark.Window.CURRENT_ROW,
                        )
                    else:
                        window_df = window_df.range_between(
                            snowpark.Window.UNBOUNDED_PRECEDING,
                            snowpark.Window.CURRENT_ROW,
                        )
                    frame_name.append(
                        "RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW"
                    )
                else:
                    window_df = window_df.orderBy(
                        column_mapping.get_snowpark_columns()[0]
                    ).rows_between(
                        snowpark.Window.UNBOUNDED_PRECEDING,
                        snowpark.Window.UNBOUNDED_FOLLOWING,
                    )
                    frame_name.append(
                        "ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING"
                    )

        spark_col_name = f"{function_name} OVER ({''.join(orderby_name[:-1])} {' '.join(frame_name)})"
        result_exp = window_func.col.over(window_df)
        return spark_col_name, TypedColumn(result_exp, lambda: typer.type(result_exp))
