import re
from contextlib import contextmanager
from contextvars import ContextVar
from functools import cache

import jpype
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.types_pb2 as types_proto
from pyspark.errors.exceptions.base import AnalysisException

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import (
    get_sql_named_arg,
    get_sql_plan,
    get_sql_pos_arg,
    get_sql_relation,
    push_sql_scope,
    stash_sql_relation,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)

from .typer import ExpressionTyper

DECIMAL_RE = re.compile(r"decimal\((\d+), *(\d+)\)")


# Even though expressions can contain relations - e.g., "1 + (SELECT 2)" -
# there's no expression_proto.Expression that can contain a relation_proto.Relation.
#
# As a workaround, we:
# - stash the relation into a ContextVar
# - return an ExpressionString with invalid SQL that has an index of the relation
# - have map_sql_expr operate in two modes: either parse the SQL, or process the stashed relation
#
# The _executing_mapped_sql ContextVar determines the behavior of map_sql_expr:
# - False: "normal" mode - maps the SQL expression into a protobuf, then calls map_expression on it
# - True: called (recursively) from map_expression above, or from map_relation; it calls
#     map_relation on the stashed relation, gets the resulting SQL, and returns it as an expression
_executing_mapped_sql = ContextVar[bool]("_executing_mapped_sql", default=False)


@contextmanager
def executing_mapped_sql():
    assert not _executing_mapped_sql.get()
    _executing_mapped_sql.set(True)
    yield
    _executing_mapped_sql.set(False)


@cache
def sql_parser():
    return jpype.JClass("org.apache.spark.sql.execution.SparkSqlParser")()


@cache
def _as_java_list():
    return jpype.JClass("scala.collection.JavaConverters").seqAsJavaList


def as_java_list(obj):
    return _as_java_list()(obj)


def map_sql_expr(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    """
    Map Spark SQL to a Snowpark expression.
    """
    from snowflake.snowpark_connect.expression.map_expression import map_expression
    from snowflake.snowpark_connect.relation.map_relation import map_relation

    sql = exp.expression_string.expression

    if _executing_mapped_sql.get():
        # Process the stashed relation.
        assert sql.startswith("#")
        parts = sql.split("#")
        query_idx = int(parts[1])
        subquery_type = parts[2] if len(parts) > 2 else None
        rel = get_sql_relation(query_idx)
        df = map_relation(rel)

        queries = df.queries["queries"]
        if len(queries) != 1:
            raise SnowparkConnectNotImplementedError(
                f"Unexpected number of queries: {len(queries)}"
            )
        match subquery_type:
            case "exists":
                expr_str = f"(exists ({queries[0]}))"
            case _:
                expr_str = f"({queries[0]})"
        result_exp = snowpark_fn.expr(expr_str)

        return ["scalarsubquery()"], TypedColumn(
            result_exp, lambda: typer.type(result_exp)
        )
    else:
        # Parse the SQL.
        logical_plan = sql_parser().parseExpression(sql)

        with push_sql_scope():
            proto = map_logical_plan_expression(logical_plan)

        with executing_mapped_sql():
            return map_expression(proto, column_mapping, typer)


SPARK_OP_TO_PROTO = {
    "Add": "+",
    "Subtract": "-",
    "Multiply": "*",
    "Divide": "/",
    "Remainder": "%",
    "Subtract": "-",
    "UnaryMinus": "negative",
    "LessThan": "<",
    "GreaterThan": ">",
    "LessThanOrEqual": "<=",
    "GreaterThanOrEqual": ">=",
    "EqualTo": "==",
    "EqualNullSafe": "<=>",
    "BitwiseAnd": "&",
    "BitwiseOr": "|",
    "BitwiseXor": "^",
    "BitwiseNot": "~",
    "Not": "not",
    "And": "and",
    "Or": "or",
    "Concat": "concat",
    "In": "in",
    "IsNull": "isnull",
    "IsNotNull": "isnotnull",
}

SPARK_CAST_TO_PROTO = {
    "boolean": types_proto.DataType(boolean=types_proto.DataType.Boolean()),
    "int": types_proto.DataType(integer=types_proto.DataType.Integer()),
    "smallint": types_proto.DataType(integer=types_proto.DataType.Integer()),
    "bigint": types_proto.DataType(long=types_proto.DataType.Long()),
    "float": types_proto.DataType(float=types_proto.DataType.Float()),
    "double": types_proto.DataType(double=types_proto.DataType.Double()),
    "string": types_proto.DataType(string=types_proto.DataType.String()),
    "decimal": types_proto.DataType(
        decimal=types_proto.DataType.Decimal(scale=10, precision=0)
    ),
    "date": types_proto.DataType(date=types_proto.DataType.Date()),
    "timestamp": types_proto.DataType(timestamp=types_proto.DataType.Timestamp()),
}

SPARK_SORT_DIRECTION_TO_PROTO = {
    "Ascending": expressions_proto.Expression.SortOrder.SORT_DIRECTION_ASCENDING,
    "Descending": expressions_proto.Expression.SortOrder.SORT_DIRECTION_DESCENDING,
}

SPARK_SORT_NULL_ORDERING_TO_PROTO = {
    "NullsFirst": expressions_proto.Expression.SortOrder.SORT_NULLS_FIRST,
    "NullsLast": expressions_proto.Expression.SortOrder.SORT_NULLS_LAST,
}


def escape_spark_quoted(name: str) -> str:
    double_ticks = name.replace("`", "``")
    return f"`{double_ticks}`"


def map_logical_plan_expression(exp) -> expressions_proto.Expression:
    from snowflake.snowpark_connect.relation.map_sql import map_logical_plan_relation

    match str(exp.nodeName()):
        case "Alias":
            proto = expressions_proto.Expression(
                alias=expressions_proto.Expression.Alias(
                    expr=map_logical_plan_expression(exp.child()),
                    name=[str(exp.name())],
                )
            )
        case "CaseWhen":
            # exp has a .branches() method that gives us conditions and results
            # in a more structured format - however, we would need to flatten them, anyway,
            # so just use .children()
            proto = expressions_proto.Expression(
                unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                    function_name="when",
                    arguments=[
                        map_logical_plan_expression(e)
                        for e in as_java_list(exp.children())
                    ],
                )
            )
        case "Cast":
            proto = expressions_proto.Expression(
                cast=expressions_proto.Expression.Cast(
                    expr=map_logical_plan_expression(exp.child()),
                    type=None,
                    type_str=str(exp.dataType().typeName()),
                )
            )
        case "CreateNamedStruct":
            arg_exprs = [
                arg
                for k_v in zip(
                    as_java_list(exp.nameExprs()), as_java_list(exp.valExprs())
                )
                for arg in k_v
            ]
            proto = expressions_proto.Expression(
                unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                    function_name="named_struct",
                    arguments=[map_logical_plan_expression(e) for e in arg_exprs],
                )
            )
        case "Exists":
            assert not _executing_mapped_sql.get()
            rel_proto = map_logical_plan_relation(exp.plan())
            idx = stash_sql_relation(rel_proto)

            proto = expressions_proto.Expression(
                expression_string=expressions_proto.Expression.ExpressionString(
                    expression=f"#{idx}#exists"
                )
            )
        # TODO: direct protobuf support requires spark 4.0.0
        #
        #     proto = expressions_proto.Expression(
        #         subquery_expression=expressions_proto.Expression.SubqueryExpression(
        #             rel_proto.common.plan_id,
        #             subquery_type=expressions_proto.Expression.SubqueryExpression.SUBQUERY_TYPE_EXISTS,
        #         )
        #     )
        case "InSubquery":
            values = list(as_java_list(exp.values()))
            if len(values) != 1:
                raise SnowparkConnectNotImplementedError("Unexpected subquery")

            proto = expressions_proto.Expression(
                unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                    function_name="in",
                    arguments=[
                        map_logical_plan_expression(values[0]),
                        map_logical_plan_expression(exp.query()),
                    ],
                )
            )
        case "LambdaFunction":
            arguments = [
                map_logical_plan_expression(arg).unresolved_named_lambda_variable
                for arg in as_java_list(exp.arguments())
            ]
            proto = expressions_proto.Expression(
                lambda_function=expressions_proto.Expression.LambdaFunction(
                    function=map_logical_plan_expression(exp.function()),
                    arguments=arguments,
                )
            )
        case "Like" | "ILike":
            proto = expressions_proto.Expression(
                unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                    function_name=str(exp.nodeName()).lower(),
                    arguments=[
                        map_logical_plan_expression(e)
                        for e in as_java_list(exp.children())
                    ],
                )
            )
        case "Literal":
            type_name = str(exp.dataType().typeName())
            type_value = exp.value()

            if type_name == "string":
                type_value = str(type_value)
            elif type_name == "void":
                type_name = "null"
                type_value = types_proto.DataType()
            elif type_name == "binary":
                type_value = bytes(type_value)
            elif type_name.startswith("interval "):
                type_name = "day_time_interval"  # TODO
            elif m := DECIMAL_RE.fullmatch(type_name):
                type_name = "decimal"
                type_value = expressions_proto.Expression.Literal.Decimal(
                    value=str(type_value),
                    precision=int(m.group(1)),
                    scale=int(m.group(2)),
                )

            proto = expressions_proto.Expression(
                literal=expressions_proto.Expression.Literal(
                    **{
                        type_name: type_value,
                    }
                )
            )
        case "ListQuery":
            assert not _executing_mapped_sql.get()
            rel_proto = map_logical_plan_relation(exp.plan())
            idx = stash_sql_relation(rel_proto)

            proto = expressions_proto.Expression(
                expression_string=expressions_proto.Expression.ExpressionString(
                    expression=f"#{idx}"
                )
            )
        case "NamedParameter":
            name = str(exp.name())
            value = get_sql_named_arg(name)
            if not value.HasField("literal_type"):
                raise AnalysisException(f"Found an unbound parameter {name!r}")
            proto = expressions_proto.Expression(literal=value)
        case "PosParameter":
            pos = exp.pos()
            try:
                value = get_sql_pos_arg(pos)
            except KeyError:
                raise AnalysisException(f"Found an unbound parameter at position {pos}")
            proto = expressions_proto.Expression(literal=value)
        case "ScalarSubquery":
            assert not _executing_mapped_sql.get()
            rel_proto = map_logical_plan_relation(exp.plan())
            idx = stash_sql_relation(rel_proto)

            proto = expressions_proto.Expression(
                expression_string=expressions_proto.Expression.ExpressionString(
                    expression=f"#{idx}"
                )
            )
        case "SortOrder":
            direction = SPARK_SORT_DIRECTION_TO_PROTO[str(exp.direction())]
            null_ordering = SPARK_SORT_NULL_ORDERING_TO_PROTO[str(exp.nullOrdering())]
            proto = expressions_proto.Expression(
                sort_order=expressions_proto.Expression.SortOrder(
                    child=map_logical_plan_expression(exp.child()),
                    direction=direction,
                    null_ordering=null_ordering,
                )
            )
        case "UnresolvedAlias":
            proto = map_logical_plan_expression(exp.child())
        case "UnresolvedAttribute":
            *parents, name = as_java_list(exp.nameParts())
            plan_id = None
            is_fully_qualified_name = False
            if parents:
                parent_name = ".".join(str(p) for p in parents)
                plan_id = get_sql_plan(parent_name)
                # If no plan_id exists, treat the column name as fully qualified by its parent.
                if plan_id is None:
                    # There's a difference in how Spark sql and dataframe operation passes backticks in column names.
                    # Spark sql un-escapes the backticks instead of passing the raw string. This
                    # logic is to escape backticks again to make it consistent with regular spark functions.
                    parent_chain = ".".join(escape_spark_quoted(p) for p in parents)
                    name = f"{parent_chain}.{escape_spark_quoted(name)}"
                    is_fully_qualified_name = True

            if not is_fully_qualified_name:
                # There's a difference in how Spark sql and dataframe operation passes backticks in column names.
                # Spark sql un-escapes the backticks instead of passing the raw string. This
                # logic is to escape backticks again to make it consistent with regular spark functions.
                name = escape_spark_quoted(name)

            proto = expressions_proto.Expression(
                unresolved_attribute=expressions_proto.Expression.UnresolvedAttribute(
                    unparsed_identifier=str(name),
                    plan_id=plan_id,
                ),
            )
        case "UnresolvedExtractValue":
            proto = expressions_proto.Expression(
                unresolved_extract_value=expressions_proto.Expression.UnresolvedExtractValue(
                    child=map_logical_plan_expression(exp.child()),
                    extraction=map_logical_plan_expression(exp.extraction()),
                )
            )
        case "UnresolvedFunction":
            func_name = ".".join(
                str(part) for part in as_java_list(exp.nameParts())
            ).lower()
            args = [
                map_logical_plan_expression(arg)
                for arg in as_java_list(exp.arguments())
            ]

            if (typ := SPARK_CAST_TO_PROTO.get(func_name)) is not None:
                proto = expressions_proto.Expression(
                    cast=expressions_proto.Expression.Cast(
                        expr=args[0],
                        type=typ,
                    )
                )
            else:
                if func_name == "log" and len(args) == 1:
                    args = [
                        expressions_proto.Expression(
                            unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                                function_name="e",
                                arguments=[],
                            )
                        ),
                        args[0],
                    ]
                elif func_name == "months_between" and len(args) == 2:
                    args = [
                        args[0],
                        args[1],
                        expressions_proto.Expression(
                            literal=expressions_proto.Expression.Literal(
                                boolean=True,
                            )
                        ),
                    ]
                elif func_name == "round" and len(args) == 1:
                    args = [
                        args[0],
                        expressions_proto.Expression(
                            literal=expressions_proto.Expression.Literal(
                                integer=0,
                            )
                        ),
                    ]
                elif func_name == "if":
                    func_name = "when"

                proto = expressions_proto.Expression(
                    unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                        function_name=func_name,
                        arguments=args,
                        is_distinct=exp.isDistinct(),
                    )
                )
        case "UnresolvedNamedLambdaVariable":
            proto = expressions_proto.Expression(
                unresolved_named_lambda_variable=expressions_proto.Expression.UnresolvedNamedLambdaVariable(
                    name_parts=[str(part) for part in as_java_list(exp.nameParts())],
                )
            )
        case "UnresolvedStar":
            proto = expressions_proto.Expression(
                unresolved_star=expressions_proto.Expression.UnresolvedStar(
                    unparsed_target=str(exp.target()),
                )
            )
        case op if (proto_func := SPARK_OP_TO_PROTO.get(op)) is not None:
            proto = expressions_proto.Expression(
                unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                    function_name=proto_func,
                    arguments=[
                        map_logical_plan_expression(arg)
                        for arg in as_java_list(exp.children())
                    ],
                )
            )
        case other:
            raise SnowparkConnectNotImplementedError(f"Not implemented: {other}")

    return proto
