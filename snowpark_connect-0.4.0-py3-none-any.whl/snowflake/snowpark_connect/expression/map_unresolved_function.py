import math
import pathlib
import random
import string
import time
from collections import defaultdict
from functools import partial, reduce
from typing import Optional
from urllib.parse import quote, unquote

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from lxml import etree
from pyspark.errors.exceptions.base import AnalysisException
from pyspark.sql.types import _parse_datatype_json_string

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark import Column, Session
from snowflake.snowpark._internal.analyzer.unary_expression import Alias
from snowflake.snowpark.types import (
    ArrayType,
    BinaryType,
    BooleanType,
    ByteType,
    DataType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    MapType,
    NullType,
    ShortType,
    StringType,
    StructField,
    StructType,
    TimestampTimeZone,
    TimestampType,
    VariantType,
    _IntegralType,
    _NumericType,
)
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.constants import (
    DUPLICATE_KEY_FOUND_ERROR_TEMPLATE,
    SPARK_TZ_ABBREVIATIONS_OVERRIDES,
)
from snowflake.snowpark_connect.expression.literal import get_literal_field_and_name
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import (
    map_pyspark_types_to_snowpark_types,
    map_spark_number_format_expression,
    map_spark_timestamp_format_expression,
    parse_ddl_string,
)
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import (
    get_spark_version,
    resolving_fun_args,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)
from snowflake.snowpark_connect.utils.xxhash64 import (
    DEFAULT_SEED,
    xxhash64_double,
    xxhash64_float,
    xxhash64_int,
    xxhash64_long,
    xxhash64_string,
)

MAX_UINT64 = 2**64 - 1
MIN_INT64 = -(2**63)
SYMBOL_FUNCTIONS = {"<", ">", "<=", ">=", "!=", "+", "-", "*", "/", "%"}
NAN, INFINITY = float("nan"), float("inf")


def _validate_numeric_args(
    function_name: str, typed_args: list, snowpark_args: list
) -> list:
    """Validates that the first two arguments are numeric types. Follows spark and casts strings to double.

    Args:
        function_name: Name of the function being validated (for error message)
        typed_args: List of TypedColumn arguments to check
        snowpark_args: List of Column objects that may be modified

    Returns:
        Modified snowpark_args with string columns cast to DoubleType

    Raises:
        TypeError: If arguments cannot be converted to numeric types
    """
    if len(typed_args) < 2:
        raise ValueError(f"{function_name} requires at least 2 arguments")

    modified_args = list(snowpark_args)

    # Looping so that we can adjust for fewer/more arguments in the future if needed.
    for i in range(2):
        arg_type = typed_args[i].typ

        match arg_type:
            case _NumericType():
                continue
            case StringType():
                # Cast strings to doubles following Spark
                # https://github.com/apache/spark/blob/master/sql/catalyst/src/main/scala/org/apache/spark/sql/catalyst/analysis/TypeCoercion.scala#L204
                modified_args[i] = snowpark_fn.try_cast(snowpark_args[i], DoubleType())
            case _:
                raise TypeError(
                    f"Data type mismatch: {function_name} requires numeric types, but got {typed_args[0].typ} and {typed_args[1].typ}."
                )

    return modified_args


# TODO: fix tz_convert taking 2 positional arguments
# TODO: (this isn't the direct cause but some of the parameters cause the bug)
def get_timestamp_type():
    match global_config["spark.sql.timestampType"]:
        case "TIMESTAMP_LTZ":
            timestamp_type = TimestampType(TimestampTimeZone.LTZ)
        case "TIMESTAMP_NTZ":
            timestamp_type = TimestampType(TimestampTimeZone.NTZ)
        case "TIMESTAMP_TZ":
            timestamp_type = TimestampType(TimestampTimeZone.TZ)
        case _:
            timestamp_type = TimestampType(TimestampTimeZone.DEFAULT)
    return timestamp_type


def unwrap_literal(exp: expressions_proto.Expression):
    """Workaround for Snowpark functions generating invalid SQL when used with fn.lit (SNOW-1871954)"""
    return get_literal_field_and_name(exp.literal)[0]


def _coerce_for_equality(
    left: TypedColumn, right: TypedColumn
) -> tuple[Column, Column]:
    if left.typ == right.typ:
        return left.col, right.col

    # To avoid handling both (A, B) and (B, A), swap them in the second case, then swap back at the end.
    if type(left.typ).__name__ > type(right.typ).__name__:
        left, right = right, left
        swap = True
    else:
        swap = False

    left_col = left.col
    right_col = right.col

    match (left.typ, right.typ):
        case (BooleanType(), IntegerType()):
            left_col = left_col.cast(IntegerType())
        case (BooleanType(), LongType()):
            left_col = left_col.cast(LongType())
        case (BooleanType(), FloatType()):
            left_col = left_col.cast(IntegerType()).cast(FloatType())
        case (BooleanType(), DoubleType()):
            left_col = left_col.cast(IntegerType()).cast(DoubleType())
        case (BooleanType(), StringType()):
            right_col = right_col.try_cast(BooleanType())
        case (IntegerType(), StringType()):
            right_col = right_col.try_cast(IntegerType())
        case (LongType(), StringType()):
            right_col = right_col.try_cast(LongType())
        case (FloatType(), StringType()):
            right_col = right_col.try_cast(FloatType())
        case (DoubleType(), StringType()):
            right_col = right_col.try_cast(DoubleType())
        case (DecimalType(), StringType()):
            right_col = right_col.try_cast(DoubleType())

    if swap:
        return right_col, left_col
    else:
        return left_col, right_col


def map_unresolved_function(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    from snowflake.snowpark_connect.expression.map_expression import map_expression

    session = Session.get_active_session()

    args_types = list(
        map(lambda a: a.WhichOneof("expr_type"), exp.unresolved_function.arguments)
    )
    # Functions that accept lambda parameters are handled separately to keep the resolution of other functions simple.
    # Lambda parameter types often depend on the types of other arguments passed to the function.
    if "lambda_function" in args_types:
        return _resolve_function_with_lambda(exp, column_mapping, typer)

    def _resolve_args_expressions(exp: expressions_proto.Expression):
        def _resolve_fn_arg(exp):
            with resolving_fun_args():
                return map_expression(exp, column_mapping, typer)

        def _unalias_column(tc: TypedColumn) -> TypedColumn:
            # This is required to avoid SQL compilation errors when aliases are used inside subexpressions.
            # We unwrap such aliases and use a child expression for snowpark's evaluation.
            if hasattr(tc.col, "_expression"):
                col_exp = tc.col._expression
                if isinstance(col_exp, Alias):
                    return TypedColumn(Column(col_exp.child), lambda: tc.types)
            return tc

        resolved = [_resolve_fn_arg(arg) for arg in exp.unresolved_function.arguments]
        resolved_without_alias = [
            (names, _unalias_column(tc)) for names, tc in resolved
        ]
        not_empty = list(filter(lambda x: not x[1].is_empty(), resolved_without_alias))
        return zip(*not_empty) if not_empty else ([], [])

    snowpark_arg_names, snowpark_typed_args = (
        _resolve_args_expressions(exp)
        if len(exp.unresolved_function.arguments) > 0
        else ([], [])
    )
    snowpark_arg_names = [n for names in snowpark_arg_names for n in names]
    snowpark_args = [arg.col for arg in snowpark_typed_args]

    # default function name
    spark_function_name = (
        f"({snowpark_arg_names[0]} {exp.unresolved_function.function_name} {snowpark_arg_names[1]})"
        if exp.unresolved_function.function_name in SYMBOL_FUNCTIONS
        else f"{exp.unresolved_function.function_name}({', '.join(snowpark_arg_names)})"
    )
    spark_col_names = []

    function_name = exp.unresolved_function.function_name
    match function_name:
        case "!=":
            result_exp = snowpark_args[0] != snowpark_args[1]
        case "%":
            result_exp = snowpark_args[0] % snowpark_args[1]
        case "*":
            result_exp = snowpark_args[0] * snowpark_args[1]
        case "+":
            result_exp = snowpark_args[0] + snowpark_args[1]
        case "-":
            result_exp = snowpark_args[0] - snowpark_args[1]
        case "/":
            if isinstance(
                snowpark_typed_args[0].typ, (IntegerType, LongType, ShortType)
            ) and isinstance(
                snowpark_typed_args[1].typ, (IntegerType, LongType, ShortType)
            ):
                #  Check if both arguments are integer types. Snowpark performs integer division, and precision is lost.
                #  Cast to double and perform division
                result_exp = snowpark_fn.divnull(
                    snowpark_args[0].cast(DoubleType()),
                    snowpark_args[1].cast(DoubleType()),
                )
            else:
                # Perform division directly
                result_exp = snowpark_fn.divnull(snowpark_args[0], snowpark_args[1])
        case "~":
            result_exp = snowpark_fn.bitnot(snowpark_args[0])
            spark_function_name = f"~{snowpark_arg_names[0]}"
        case "<":
            result_exp = snowpark_args[0] < snowpark_args[1]
        case "<=":
            result_exp = snowpark_args[0] <= snowpark_args[1]
        case "<=>":
            # eqNullSafe
            rarg_name = snowpark_arg_names[1]
            typ = snowpark_typed_args[1].typ
            if typ == DoubleType() or typ == FloatType():
                if rarg_name == "nan":
                    rarg_name = "NaN"

            spark_function_name = f"({snowpark_arg_names[0]} <=> {rarg_name})"
            left, right = _coerce_for_equality(
                snowpark_typed_args[0], snowpark_typed_args[1]
            )
            result_exp = left.eqNullSafe(right)
        case "==":
            spark_function_name = f"({snowpark_arg_names[0]} = {snowpark_arg_names[1]})"
            left, right = _coerce_for_equality(
                snowpark_typed_args[0], snowpark_typed_args[1]
            )
            result_exp = left == right
        case ">":
            result_exp = snowpark_args[0] > snowpark_args[1]
        case ">=":
            result_exp = snowpark_args[0] >= snowpark_args[1]
        case "&":
            spark_function_name = f"({snowpark_arg_names[0]} & {snowpark_arg_names[1]})"
            result_exp = snowpark_args[0].bitwiseAnd(snowpark_args[1])
        case "|":
            spark_function_name = f"({snowpark_arg_names[0]} | {snowpark_arg_names[1]})"
            result_exp = snowpark_args[0].bitwiseOR(snowpark_args[1])
        case "^":
            spark_function_name = f"({snowpark_arg_names[0]} ^ {snowpark_arg_names[1]})"
            result_exp = snowpark_args[0].bitwiseXOR(snowpark_args[1])
        case "abs":
            result_exp = snowpark_fn.abs(snowpark_args[0])
        case "acos":
            spark_function_name = f"ACOS({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                (snowpark_args[0] < -1) | (snowpark_args[0] > 1), NAN
            ).otherwise(snowpark_fn.acos(snowpark_args[0]))
        case "acosh":
            spark_function_name = f"ACOSH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when((snowpark_args[0] < 1), NAN).otherwise(
                snowpark_fn.acosh(snowpark_args[0])
            )
        case "add_months":
            result_exp = snowpark_fn.add_months(
                snowpark_fn.to_date(snowpark_args[0]), snowpark_args[1]
            )
        case "aes_decrypt":
            result_exp = _aes_helper(
                "DECRYPT",
                snowpark_args[0],
                snowpark_args[1],
                snowpark_args[4],
                snowpark_args[2],
                snowpark_args[3],
            )
        case "aes_encrypt":
            result_exp = _aes_helper(
                "ENCRYPT",
                snowpark_args[0],
                snowpark_args[1],
                snowpark_args[5],
                snowpark_args[2],
                snowpark_args[3],
            )
        case "and":
            spark_function_name = (
                f"({snowpark_arg_names[0]} AND {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_args[0] & snowpark_args[1]
        case "any_value":
            # SNOW-1955766: Support ignore null parameter
            result_exp = snowpark_fn.any_value(*snowpark_args)
        case "approx_count_distinct":
            result_exp = snowpark_fn.approx_count_distinct(snowpark_args[0])
        case "approx_percentile" | "percentile_approx":
            # SNOW-1955784: Support accuracy parameter

            # Even though the Spark function accepts a Column for percentage, it will fail unless it's a literal.
            # Therefore, we can do error checking right here.
            def _check_percentage(exp: expressions_proto.Expression) -> Column:
                perc = unwrap_literal(exp)
                if not 0.0 <= perc <= 1.0:
                    raise AnalysisException("percentage must be between [0.0, 1.0]")
                return snowpark_fn.lit(perc)

            if isinstance(snowpark_typed_args[1].typ, ArrayType):
                # Snowpark doesn't accept a list of percentile values.
                # This is a workaround to fetch percentile arguments and invoke the snowpark_fn.approx_percentile serially.
                array_func = exp.unresolved_function.arguments[1].unresolved_function
                assert array_func.function_name == "array", array_func

                result_exp = snowpark_fn.array_construct(
                    *[
                        snowpark_fn.approx_percentile(
                            snowpark_args[0], _check_percentage(arg)
                        )
                        for arg in array_func.arguments
                    ]
                )
            else:
                result_exp = snowpark_fn.approx_percentile(
                    snowpark_args[0],
                    _check_percentage(exp.unresolved_function.arguments[1]),
                )
        case "array":
            result_exp = snowpark_fn.array_construct(
                *[
                    typed_arg.column(to_semi_structure=True)
                    for typed_arg in snowpark_typed_args
                ]
            )
            arg_types = [t for tc in snowpark_typed_args for t in tc.types]
            element_type = _find_common_type(arg_types)
            result_exp = snowpark_fn.cast(result_exp, ArrayType(element_type))
        case "array_append":
            result_exp = snowpark_fn.array_append(snowpark_args[0], snowpark_args[1])
        case "array_compact":
            result_exp = snowpark_fn.array_compact(snowpark_args[0])
        case "array_contains":
            array_type = snowpark_typed_args[0].typ
            if not isinstance(array_type, ArrayType):
                raise AnalysisException(
                    f"Expected argument '{snowpark_arg_names[0]}' to have an ArrayType."
                )

            value = (
                snowpark_fn.cast(snowpark_args[1], array_type.element_type)
                if array_type.structured
                else snowpark_fn.to_variant(snowpark_args[1])
            )

            result_exp = snowpark_fn.array_contains(value, snowpark_args[0])
        case "array_distinct":
            result_exp = snowpark_fn.array_distinct(snowpark_args[0])
        case "array_except":
            result_exp = snowpark_fn.array_except(*snowpark_args)
        case "array_insert":
            data = snowpark_args[0]
            spark_index = snowpark_args[1]
            el = snowpark_args[2]

            snow_index = (
                snowpark_fn.when(
                    spark_index < (snowpark_fn.array_size(data) * snowpark_fn.lit(-1)),
                    spark_index + 1,
                )
                .when(spark_index < 0, snowpark_fn.array_size(data) + spark_index + 1)
                # Trigger an exception by using a string instead of an integer.
                .when(spark_index == 0, snowpark_fn.lit("index 0 is invalid"))
                .otherwise(spark_index - 1)
            )

            result_exp = snowpark_fn.array_insert(data, snow_index, el)
        case "array_intersect":
            result_exp = snowpark_fn.array_intersection(*snowpark_args)
        case "array_join":
            match snowpark_args:
                case [data, delimiter]:
                    data = snowpark_fn.cast(data, VariantType())
                    data = snowpark_fn.function("filter")(
                        data, snowpark_fn.sql_expr("x -> x IS NOT NULL")
                    )
                    result_exp = snowpark_fn.array_to_string(data, delimiter)
                case [data, delimiter, _]:
                    null_replacement = unwrap_literal(
                        exp.unresolved_function.arguments[2]
                    )
                    data = snowpark_fn.cast(data, VariantType())
                    data = snowpark_fn.function("transform")(
                        data,
                        snowpark_fn.sql_expr(f"x -> IFNULL(x,'{null_replacement}')"),
                    )
                    result_exp = snowpark_fn.array_to_string(data, delimiter)
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
        case "array_max":
            result_exp = snowpark_fn.array_max(snowpark_args[0])
        case "array_min":
            result_exp = snowpark_fn.array_min(snowpark_args[0])
        case "array_position":
            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_args[0])
                | snowpark_fn.is_null(snowpark_args[1]),
                snowpark_fn.lit(None),
            ).otherwise(
                snowpark_fn.coalesce(
                    snowpark_fn.array_position(snowpark_args[1], snowpark_args[0]),
                    snowpark_fn.lit(-1),
                )
                + 1
            )
        case "array_prepend":
            result_exp = snowpark_fn.array_prepend(snowpark_args[0], snowpark_args[1])
        case "array_remove":
            array_type = snowpark_typed_args[0].typ
            assert isinstance(
                array_type, ArrayType
            ), f"Expected argument '{snowpark_arg_names[0]}' to have an ArrayType."
            result_exp = snowpark_fn.array_remove(snowpark_args[0], snowpark_args[1])
            if array_type.structured and array_type.element_type is not None:
                result_exp = snowpark_fn.cast(result_exp, array_type)
        case "array_repeat":

            @snowpark_fn.udf(
                return_type=ArrayType(snowpark_typed_args[0].typ),
                input_types=[snowpark_typed_args[0].typ, IntegerType()],
            )
            def _array_repeat(col, count):
                return [col] * count

            result_exp = _array_repeat(snowpark_args[0], snowpark_args[1])
        case "array_size" | "cardinality":
            array_type = snowpark_typed_args[0].typ
            if not isinstance(array_type, ArrayType):
                raise AnalysisException(
                    f"Expected argument '{snowpark_arg_names[0]}' to have an ArrayType."
                )
            result_exp = snowpark_fn.array_size(*snowpark_args)
        case "array_sort":
            result_exp = snowpark_fn.array_sort(*snowpark_args)
        case "array_union":
            result_exp = snowpark_fn.array_distinct(
                snowpark_fn.array_cat(*snowpark_args)
            )
        case "arrays_overlap":
            array1, array2 = snowpark_args

            array1_is_not_empty = snowpark_fn.array_size(array1) > 0
            array2_is_not_empty = snowpark_fn.array_size(array2) > 0

            array1_contains_nulls = snowpark_fn.array_contains(
                snowpark_fn.lit(None), array1
            )
            array2_contains_nulls = snowpark_fn.array_contains(
                snowpark_fn.lit(None), array2
            )

            filter_function = snowpark_fn.function("FILTER")
            is_not_null_filter = snowpark_fn.sql_expr("x -> x IS NOT NULL")

            array1_no_nulls = filter_function(array1, is_not_null_filter)
            array2_no_nulls = filter_function(array2, is_not_null_filter)

            arrays_overlap = snowpark_fn.arrays_overlap(
                array1_no_nulls, array2_no_nulls
            )

            result_exp = (
                snowpark_fn.when(
                    arrays_overlap == snowpark_fn.lit(True), arrays_overlap
                )
                .when(
                    array1_is_not_empty
                    & array2_is_not_empty
                    & (array1_contains_nulls | array2_contains_nulls),
                    snowpark_fn.lit(None),
                )
                .otherwise(snowpark_fn.lit(False))
            )
        case "arrays_zip":
            result_exp = snowpark_fn.arrays_zip(*snowpark_args)
        case "asc":
            result_exp = snowpark_fn.asc(snowpark_args[0])
        case "ascii":
            # Snowflake's ascii function doesn't match PySpark's however the unicode function does.
            unicode_function = snowpark_fn.function("unicode")
            result_exp = unicode_function(snowpark_args[0])
        case "asin":
            spark_function_name = f"ASIN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                (snowpark_args[0] < -1) | (snowpark_args[0] > 1), NAN
            ).otherwise(snowpark_fn.asin(snowpark_args[0]))
        case "asinh":
            spark_function_name = f"ASINH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.asinh(snowpark_args[0])
        case "assert_true":

            @snowpark_fn.udf(
                input_types=[BooleanType(), StringType()],
                return_type=NullType(),
            )
            def _assert_true(expr, message=None):
                if not expr:
                    raise ValueError(message)

            result_exp = _assert_true(*snowpark_args)
        case "atan":
            spark_function_name = f"ATAN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.atan(snowpark_args[0])
        case "atan2":
            spark_function_name = (
                f"ATAN2({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.atan2(snowpark_args[0], snowpark_args[1])
        case "atanh":
            spark_function_name = f"ATANH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                (snowpark_args[0] < -1) | (snowpark_args[0] > 1), NAN
            ).otherwise(snowpark_fn.atanh(snowpark_args[0]))
        case "avg":
            result_exp = snowpark_fn.avg(snowpark_args[0])
        case "base64":
            base64_encoding_function = snowpark_fn.function("base64_encode")
            result_exp = base64_encoding_function(snowpark_args[0])
        case "bin":

            @snowpark_fn.udf(
                input_types=[snowpark_typed_args[0].typ], return_type=StringType()
            )
            def _to_bin_udf(val):
                try:
                    val = int(val)
                except (ValueError, TypeError):
                    return None

                return format(val if val >= 0 else (1 << 64) + val, "b")

            result_exp = _to_bin_udf(snowpark_args[0])
        case "bit_and":
            bit_and_agg_function = snowpark_fn.function("BITAND_AGG")
            result_exp = bit_and_agg_function(snowpark_args[0])
        case "bit_count":

            @snowpark_fn.udf(
                input_types=[snowpark_typed_args[0].typ], return_type=IntegerType()
            )
            def _bit_count_udf(val):
                try:
                    val = val.bit_count()
                except (ValueError, TypeError):
                    return None

                return val

            result_exp = _bit_count_udf(snowpark_args[0])
        case "bit_get" | "getbit":
            bit_get_function = snowpark_fn.function("GETBIT")
            result_exp = bit_get_function(*snowpark_args)
        case "bit_length":
            bit_length_function = snowpark_fn.function("bit_length")
            result_exp = bit_length_function(snowpark_args[0])
        case "bit_or":
            bit_or_agg_function = snowpark_fn.function("BITOR_AGG")
            result_exp = bit_or_agg_function(snowpark_args[0])
        case "bit_xor":
            bit_xor_agg_function = snowpark_fn.function("BITXOR_AGG")
            result_exp = bit_xor_agg_function(snowpark_args[0])
        case "bitmap_bit_position":
            result_exp = snowpark_fn.bitmap_bit_position(snowpark_args[0])
        case "bitmap_bucket_number":
            result_exp = snowpark_fn.bitmap_bucket_number(snowpark_args[0])
        case "bool_and" | "every":
            bool_and_agg_function = snowpark_fn.function("booland_agg")
            result_exp = bool_and_agg_function(*snowpark_args)
        case "bool_or":
            bool_or_agg_function = snowpark_fn.function("boolor_agg")
            result_exp = bool_or_agg_function(*snowpark_args)
        case "bround":
            scale = (
                unwrap_literal(exp.unresolved_function.arguments[1])
                if len(snowpark_args) > 1
                else 0
            )

            match snowpark_typed_args[0].typ:
                case DecimalType():
                    result_exp = snowpark_fn.bround(
                        snowpark_args[0], snowpark_fn.lit(scale)
                    )
                case _:
                    # TODO: Snowflake's bround only supports decimal, not floating point types.
                    # If fixing this in Snowflake takes some time, we should change to use a UDF here for float.
                    # For now, this is just an approximation by casting to Decimal and casting back.
                    scale_for_decimal = 0 if scale < 0 else min(scale + 2, 38)
                    result_exp = snowpark_fn.cast(
                        snowpark_fn.bround(
                            snowpark_fn.to_decimal(
                                snowpark_args[0], 38, scale_for_decimal
                            ),
                            snowpark_fn.lit(scale),
                        ),
                        snowpark_typed_args[0].typ,
                    )
        case "btrim":
            result_exp = snowpark_fn.trim(*snowpark_args)
        case "cbrt":
            spark_function_name = f"CBRT({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] < 0,
                -snowpark_fn.pow(-snowpark_args[0], snowpark_fn.lit(1 / 3)),
            ).otherwise(snowpark_fn.pow(snowpark_args[0], snowpark_fn.lit(1 / 3)))
        case "ceil" | "ceiling":
            # Somehow, CEIL is upper case, but ceiling is lower case in PySpark.
            fn_name = (
                function_name.upper() if function_name == "ceil" else function_name
            )
            spark_function_name = f"{fn_name}({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cast(
                snowpark_fn.ceil(snowpark_args[0]), LongType()
            )
        case "coalesce":
            result_exp = snowpark_fn.coalesce(*snowpark_args)
        case "col":
            result_exp = snowpark_fn.col(*snowpark_args)
        case "collect_list" | "array_agg":
            # TODO: SNOW-1967177 - Support structured types in array_agg
            result_exp = snowpark_fn.cast(
                snowpark_fn.array_agg(
                    snowpark_typed_args[0].column(to_semi_structure=True)
                ),
                ArrayType(snowpark_typed_args[0].typ),
            )
            spark_function_name = f"collect_list({snowpark_arg_names[0]})"
        case "collect_set":
            # Convert to a semi-structured type. TODO SNOW-1953065 - Support structured types in array_unique_agg.
            result_exp = snowpark_fn.cast(
                snowpark_fn.array_unique_agg(
                    snowpark_typed_args[0].column(to_semi_structure=True)
                ),
                ArrayType(snowpark_typed_args[0].typ),
            )
        case "column":
            result_exp = snowpark_fn.column(*snowpark_args)
        case "concat":
            result_exp = snowpark_fn.concat(*snowpark_args)
        case "concat_ws":
            delimiter = unwrap_literal(exp.unresolved_function.arguments[0])
            result_exp = snowpark_fn._concat_ws_ignore_nulls(
                delimiter, *snowpark_args[1:]
            )
        case "contains":
            result_exp = snowpark_args[0].contains(snowpark_args[1])
        case "conv":

            @snowpark_fn.udf(
                input_types=[
                    snowpark_typed_args[0].typ,
                    snowpark_typed_args[1].typ,
                    snowpark_typed_args[2].typ,
                ],
                return_type=StringType(),
            )
            def _to_conv_udf(val, from_base, to_base):
                try:
                    if val is None:
                        return None
                    num = int(str(val), base=from_base)
                    if num == 0:
                        return "0"
                    is_negative = num < 0
                    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    result = ""
                    num = abs(num)
                    while num > 0:
                        result = digits[num % to_base] + result
                        num //= to_base
                    return "-" + result if is_negative else result
                except (ValueError, TypeError):
                    return "0"

            result_exp = _to_conv_udf(
                snowpark_args[0], snowpark_args[1], snowpark_args[2]
            )
        case "corr":
            col1_type = snowpark_typed_args[0].typ
            col2_type = snowpark_typed_args[1].typ
            if not isinstance(col1_type, _NumericType) or not isinstance(
                col2_type, _NumericType
            ):
                result_exp = snowpark_fn.corr(
                    snowpark_fn.lit(None), snowpark_fn.lit(None)
                )
            else:
                result_exp = snowpark_fn.corr(*snowpark_args)
        case "cos":
            spark_function_name = f"COS({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cos(snowpark_args[0])
        case "cosh":
            spark_function_name = f"COSH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cosh(snowpark_args[0])
        case "cot":
            spark_function_name = f"COT({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.function("cot")(snowpark_args[0])
        case "count":
            if exp.unresolved_function.is_distinct:
                result_exp = snowpark_fn.count_distinct(*snowpark_args)
                spark_function_name = spark_function_name.replace(
                    "count(", "count(DISTINCT ", 1
                )
            else:
                result_exp = snowpark_fn.count(*snowpark_args)
        case "count_if":
            result_exp = snowpark_fn.call_function("COUNT_IF", snowpark_args[0])
        case "covar_pop":
            col1_type = snowpark_typed_args[0].typ
            col2_type = snowpark_typed_args[1].typ
            if not isinstance(col1_type, _NumericType) or not isinstance(
                col2_type, _NumericType
            ):
                raise TypeError(
                    f"Data type mismatch: covar_pop requires numeric types, "
                    f"but got {col1_type} and {col2_type}."
                )
            result_exp = snowpark_fn.covar_pop(snowpark_args[0], snowpark_args[1])
        case "covar_samp":
            col1_type = snowpark_typed_args[0].typ
            col2_type = snowpark_typed_args[1].typ
            if not isinstance(col1_type, _NumericType) or not isinstance(
                col2_type, _NumericType
            ):
                raise TypeError(
                    f"Data type mismatch: covar_samp requires numeric types, "
                    f"but got {col1_type} and {col2_type}."
                )
            result_exp = snowpark_fn.covar_samp(snowpark_args[0], snowpark_args[1])
        case "csc":
            spark_function_name = f"CSC({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.coalesce(
                snowpark_fn.divnull(1.0, snowpark_fn.sin(snowpark_args[0])),
                snowpark_fn.lit(INFINITY),
            )
        case "cume_dist":
            result_exp = snowpark_fn.cume_dist()
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "current_database":
            result_exp = snowpark_fn.current_database()
        case "current_date":
            result_exp = snowpark_fn.current_date()
        case "current_timestamp":
            result_exp = snowpark_fn.cast(
                snowpark_fn.current_timestamp(),
                # TODO: fix tz_convert 2 position arguments bug
                # get_timestamp_type(),
                TimestampType(TimestampTimeZone.NTZ),
            )
        case "current_user" | "user":
            result_exp = snowpark_fn.current_user()
        case "date_add":
            result_exp = snowpark_fn.cast(
                snowpark_fn.date_add(*snowpark_args), DateType()
            )
        case "date_diff":
            result_exp = snowpark_fn.datediff("day", snowpark_args[1], snowpark_args[0])
        case "date_format":
            assert (
                len(exp.unresolved_function.arguments) == 2
            ), "date_format takes 2 arguments"
            result_exp = snowpark_fn.date_format(
                snowpark_args[0],
                snowpark_fn.lit(
                    map_spark_timestamp_format_expression(
                        exp.unresolved_function.arguments[1]
                    )
                ),
            )
        case "date_from_unix_date":
            result_exp = snowpark_fn.date_add(
                snowpark_fn.to_date(snowpark_fn.lit("1970-01-01")), snowpark_args[0]
            )
        case "date_sub":
            result_exp = snowpark_fn.to_date(
                snowpark_fn.date_sub(snowpark_args[0], snowpark_args[1])
            )
        case "date_trunc":
            part = unwrap_literal(exp.unresolved_function.arguments[0])
            result_exp = snowpark_fn.cast(
                snowpark_fn.date_trunc(
                    part, snowpark_fn.to_timestamp(snowpark_args[1])
                ),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "datediff":
            result_exp = snowpark_fn.datediff("day", snowpark_args[1], snowpark_args[0])
        case "dayofmonth":
            result_exp = snowpark_fn.dayofmonth(snowpark_fn.to_date(snowpark_args[0]))
        case "dayofweek":
            result_exp = snowpark_fn.dayofweek(
                snowpark_fn.to_date(snowpark_args[0])
            ) + snowpark_fn.lit(1)
        case "dayofyear":
            result_exp = snowpark_fn.dayofyear(snowpark_fn.to_date(snowpark_args[0]))
        case "decode":
            match snowpark_typed_args[0].typ:
                case BinaryType():
                    decode_udf = snowpark_fn.udf(
                        lambda s, f: (
                            s.decode(f) if s is not None and f is not None else None
                        ),
                        input_types=[BinaryType(), StringType()],
                        return_type=StringType(),
                    )

                    result_exp = decode_udf(*snowpark_args)
                case _:
                    result_exp = snowpark_fn.cast(snowpark_args[0], StringType())
        case "degrees":
            spark_function_name = f"DEGREES({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.degrees(snowpark_args[0])
        case "dense_rank":
            result_exp = snowpark_fn.dense_rank()
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "desc":
            result_exp = snowpark_fn.desc(snowpark_args[0])
        case "e":
            spark_function_name = "E()"
            result_exp = snowpark_fn.lit(math.e)
        case "element_at":
            spark_index = snowpark_args[1]
            data = snowpark_typed_args[0].col
            typ = snowpark_typed_args[0].typ
            match typ:
                case ArrayType():
                    result_exp = snowpark_fn.when(
                        spark_index < 0,
                        snowpark_fn.element_at(
                            data,
                            snowpark_fn.array_size(data) + spark_index,
                        ),
                    ).otherwise(snowpark_fn.element_at(data, spark_index - 1))
                case MapType():
                    result_exp = snowpark_fn.element_at(data, spark_index)
                case _:
                    raise SnowparkConnectNotImplementedError(
                        f"Unsupported type {typ} for element_at function"
                    )
        case "elt":
            n = snowpark_args[0]

            spark_sql_ansi_enabled = global_config.spark_sql_ansi_enabled == "true"

            values = snowpark_fn.array_construct(*snowpark_args[1:])

            if spark_sql_ansi_enabled:

                @snowpark_fn.udf
                def _raise_out_of_bounds_error(n: int) -> str:
                    raise ValueError(
                        f"ArrayIndexOutOfBoundsException: {n} is not within the input bounds."
                    )

                values_size = snowpark_fn.lit(len(snowpark_args) - 1)

                result_exp = (
                    snowpark_fn.when(snowpark_fn.is_null(n), snowpark_fn.lit(None))
                    .when(
                        (snowpark_fn.lit(1) <= n) & (n <= values_size),
                        snowpark_fn.get(
                            values, snowpark_fn.nvl(n - 1, snowpark_fn.lit(0))
                        ),
                    )
                    .otherwise(_raise_out_of_bounds_error(n))
                )
            else:
                result_exp = snowpark_fn.when(
                    snowpark_fn.is_null(n), snowpark_fn.lit(None)
                ).otherwise(
                    snowpark_fn.get(values, snowpark_fn.nvl(n - 1, snowpark_fn.lit(0)))
                )

            result_exp = snowpark_fn.cast(result_exp, StringType())
        case "encode":
            encode_udf = snowpark_fn.udf(
                lambda s, f: s.encode(f) if s is not None and f is not None else None,
                input_types=[StringType(), StringType()],
                return_type=BinaryType(),
            )

            result_exp = encode_udf(*snowpark_args)
        case "endswith":
            result_exp = snowpark_args[0].endswith(snowpark_args[1])
        case "equal_null":
            result_exp = snowpark_fn.equal_null(*snowpark_args)
        case "exp":
            spark_function_name = f"EXP({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.exp(*snowpark_args)
        case "explode":
            result_exp = snowpark_fn.explode(snowpark_args[0])
            match snowpark_typed_args[0].typ:
                case ArrayType():
                    spark_col_names = ["col"]
                case _:
                    spark_col_names = ["key", "value"]
        case "explode_outer":
            result_exp = snowpark_fn.explode_outer(snowpark_args[0])
            match snowpark_typed_args[0].typ:
                case ArrayType():
                    spark_col_names = ["col"]
                case _:
                    spark_col_names = ["key", "value"]
        case "expm1":
            spark_function_name = f"EXPM1({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.exp(*snowpark_args) - 1
        case "factorial":
            result_exp = snowpark_fn.factorial(*snowpark_args)
        case "find_in_set":
            element_sep = snowpark_fn.lit(",")
            array = snowpark_fn.cast(
                snowpark_fn.split(snowpark_args[1], element_sep),
                ArrayType(StringType()),
            )

            result_exp = snowpark_fn.when(
                snowpark_fn.contains(snowpark_args[0], snowpark_fn.lit(",")),
                snowpark_fn.lit(None),
            ).otherwise(snowpark_fn.array_position(snowpark_args[0], array))

            any_arg_is_null = snowpark_args[0].is_null() | snowpark_args[1].is_null()

            result_exp = snowpark_fn.when(
                any_arg_is_null, snowpark_fn.lit(None)
            ).otherwise(
                snowpark_fn.call_function(
                    "nvl2", result_exp, result_exp + 1, snowpark_fn.lit(0)
                )
            )
        case "first":
            if not typer.is_window_enabled:
                # If first not used in window expression, it should act as aggregate function.
                # According to PySpark docs, ignore_nulls can be a Column - but it doesn't make sense and doesn't work.
                # So assume it's a literal.
                ignore_nulls = unwrap_literal(exp.unresolved_function.arguments[1])

                class FirstUDAF:
                    def __init__(self) -> None:
                        self._value = None
                        self._done = False

                    @property
                    def aggregate_state(self):
                        return self._value

                    def accumulate(self, input_value):
                        if not (self._done or (ignore_nulls and input_value is None)):
                            self._value = input_value
                            self._done = True

                    def merge(self, other_value):
                        if not (self._done or (ignore_nulls and other_value is None)):
                            self._value = other_value
                            self._done = True

                    def finish(self):
                        return self._value

                _first_udaf = snowpark_fn.udaf(
                    FirstUDAF,
                    return_type=snowpark_typed_args[0].typ,
                    input_types=[snowpark_typed_args[0].typ],
                )

                result_exp = _first_udaf(snowpark_args[0])
            else:
                result_exp = _resolve_first_value(exp, snowpark_args)
        case "first_value":
            result_exp = _resolve_first_value(exp, snowpark_args)
        case "flatten":
            # SNOW-1890247 - Update this when SQL provides a structured version of flatten
            result_exp = snowpark_fn.cast(
                snowpark_fn.array_flatten(
                    snowpark_fn.cast(snowpark_args[0], VariantType())
                ),
                snowpark_typed_args[0].typ.element_type,
            )
        case "floor":
            spark_function_name = f"FLOOR({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cast(
                snowpark_fn.floor(snowpark_args[0]), LongType()
            )
        case "format_number":
            col, scale = snowpark_args
            col_type = snowpark_typed_args[0].typ

            if not isinstance(col_type, _NumericType):
                raise TypeError(
                    f'Data type mismatch: Parameter 1 of format_number requires  the "NUMERIC" type, however was {col_type}.'
                )

            @snowpark_fn.udf
            def format_number_udf(x: Optional[str], d: int) -> str:
                if x is None:
                    return None

                import decimal

                num = decimal.Decimal(x)

                return "NaN" if num.is_nan() else f"{num:,.{d}f}"

            result_exp = snowpark_fn.when(
                scale < 0,
                snowpark_fn.lit(None),
            ).otherwise(format_number_udf(snowpark_fn.cast(col, StringType()), scale))
        case "format_string" | "printf":

            @snowpark_fn.udf
            def _format_string(fmt: str, args: list) -> Optional[str]:
                mapped_args = map(lambda x: "null" if x is None else x, args)

                try:
                    return fmt % tuple(mapped_args)
                except TypeError:
                    return None

            result_exp = _format_string(
                snowpark_args[0], snowpark_fn.array_construct(*snowpark_args[1:])
            )
        case "from_csv":
            snowpark_args = [
                typed_arg.column(to_semi_structure=True)
                for typed_arg in snowpark_typed_args
            ]
            first_arg_typ = typer.type(snowpark_args[0])[0]

            @snowpark_fn.udf(
                return_type=MapType(),
                input_types=[first_arg_typ, StringType(), MapType()],
            )
            def _from_csv(csv_data: str, schema: str, options: Optional[dict]):
                max_chars_per_column = -1
                sep = ","
                if options is not None and isinstance(options, dict):
                    max_chars_per_column = options.get(
                        "maxCharsPerColumn", max_chars_per_column
                    )
                    max_chars_per_column = int(max_chars_per_column)
                    sep = options.get("sep", sep)

                csv_data = csv_data.split(sep)
                schemas = schema.split(",")
                assert len(csv_data) == len(
                    schemas
                ), "length of data and schema mismatch"

                def _parse_one_schema(sc):
                    parts = [i for i in sc.split(" ") if len(i) != 0]
                    assert len(parts) == 2, f"{sc} is not a valid schema"
                    return parts[0], parts[1]

                results = {}
                for i in range(len(csv_data)):
                    alias, datatype = _parse_one_schema(schemas[i])
                    results[alias] = csv_data[i]
                    if (
                        max_chars_per_column != -1
                        and len(str(csv_data[i])) > max_chars_per_column
                    ):
                        raise ValueError(
                            f"Max chars per column exceeded {max_chars_per_column}: {str(csv_data[i])}"
                        )

                return results

            spark_function_name = f"from_csv({snowpark_arg_names[0]})"
            ddl_schema = parse_ddl_string(snowpark_arg_names[1], True)

            match snowpark_args:
                case [csv_data, schemas]:
                    csv_result = _from_csv(csv_data, schemas, snowpark_fn.lit(None))
                case [csv_data, schemas, options]:
                    csv_result = _from_csv(csv_data, schemas, options)
                case _:
                    raise ValueError("Unrecognized from_csv parameters")

            result_exp = snowpark_fn.cast(csv_result, ddl_schema)
        case "from_json":
            # TODO: support options.
            spark_function_name = f"from_json({snowpark_arg_names[0]})"
            lit_schema = unwrap_literal(exp.unresolved_function.arguments[1])

            try:
                spark_schema = _parse_datatype_json_string(lit_schema)
                snowpark_schema = map_pyspark_types_to_snowpark_types(spark_schema)
            except ValueError as e:
                # it's valid to fall into here in some cases, so only logger.debug not logger.error
                logger.debug("Failed to parse datatype json string: %s", e)
                snowpark_schema = lit_schema

            result_exp = snowpark_fn.cast(
                snowpark_fn.parse_json(snowpark_args[0]), snowpark_schema
            )
        case "from_unixtime":
            assert (
                len(exp.unresolved_function.arguments) == 2
            ), "from_unixtime takes 2 arguments"
            result_exp = snowpark_fn.to_char(
                snowpark_fn.to_timestamp(snowpark_args[0]),
                map_spark_timestamp_format_expression(
                    exp.unresolved_function.arguments[1]
                ),
            )
        case "from_utc_timestamp":
            map_from_spark_tz = snowpark_fn.udf(
                lambda tz: SPARK_TZ_ABBREVIATIONS_OVERRIDES.get(tz, tz),
                input_types=[snowpark.types.StringType()],
                return_type=snowpark.types.StringType(),
            )

            target_tz = map_from_spark_tz(snowpark_args[1])
            result_exp = snowpark_fn.from_utc_timestamp(snowpark_args[0], target_tz)
        case "get":
            if exp.unresolved_function.arguments[1].HasField("literal"):
                index = unwrap_literal(exp.unresolved_function.arguments[1])
                if index < 0:
                    result_exp = snowpark_fn.lit(None)
                else:
                    result_exp = snowpark_fn.get(*snowpark_args)
            else:
                result_exp = snowpark_fn.when(
                    snowpark_args[1] < 0,
                    snowpark_fn.lit(None),
                ).otherwise(snowpark_fn.get(*snowpark_args))
        case "get_json_object":
            json_str = snowpark_args[0]
            json_path = unwrap_literal(exp.unresolved_function.arguments[1])

            # Snowflake JSON paths do not start with '$.', which is required in Spark
            if json_path.startswith("$."):
                json_path = json_path[2:]

            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_fn.check_json(json_str)),
                snowpark_fn.json_extract_path_text(
                    json_str, snowpark_fn.lit(json_path)
                ),
            ).otherwise(snowpark_fn.lit(None))
        case "greatest":
            result_exp = snowpark_fn.greatest(*snowpark_args)
        case "hash":
            # TODO: See the spark-compatibility-issues.md explanation, this is quite different from Spark.
            result_exp = snowpark_fn.hash(*snowpark_args)
        case "hex":
            data = snowpark_fn.cast(snowpark_args[0], VariantType())

            # We need as many 'X' as there are digits. The longest possible 'long' type has 16 digits.
            format_string = "FMXXXXXXXXXXXXXXXX"

            # Hex supports string, binary, integer/long.
            # We can use TO_CHAR for numbers and HEX_ENCODE for string and binary
            result_exp = (
                snowpark_fn.when(
                    snowpark_fn.is_integer(data),
                    snowpark_fn.to_char(
                        # The cast to integer is done because to_char in snowflake doesn't take
                        # two arguments for certain other types.
                        snowpark_fn.cast(data, IntegerType()),
                        format_string,
                    ),
                )
                .when(
                    snowpark_fn.is_double(data),
                    snowpark_fn.to_char(
                        # While float/double aren't officially supported in the spark documentation, they work.
                        # They are treated as integer, but after floor.
                        snowpark_fn.cast(snowpark_fn.floor(data), IntegerType()),
                        format_string,
                    ),
                )
                .otherwise(snowpark_fn.function("HEX_ENCODE")(*snowpark_args))
            )
        case "hll_sketch_agg":
            # Snowflake implements HLL differently than Spark, but the value of hll_sketch_estimate should be accurate.
            result_exp = snowpark_fn.call_function("hll_accumulate", snowpark_args[0])
        case "hll_sketch_estimate":
            result_exp = snowpark_fn.call_function("hll_estimate", snowpark_args[0])
        case "hll_union_agg":
            result_exp = snowpark_fn.call_function("hll_combine", snowpark_args[0])
        case "hour":
            result_exp = snowpark_fn.hour(snowpark_fn.to_timestamp(snowpark_args[0]))
        case "hypot":
            spark_function_name = (
                f"HYPOT({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.sqrt(
                snowpark_args[0] * snowpark_args[0]
                + snowpark_args[1] * snowpark_args[1]
            )
        case "ifnull":
            result_exp = snowpark_fn.ifnull(*snowpark_args)
        case "ilike":
            # Snowpark is not supporting ilike, so using Snowflake builtin function
            ilike = snowpark_fn.builtin("ilike")
            result_exp = ilike(snowpark_args[0], snowpark_args[1])
        case "in":
            spark_function_name = (
                f"({snowpark_arg_names[0]} IN ({', '.join(snowpark_arg_names[1:])}))"
            )
            result_exp = snowpark_args[0].in_(snowpark_args[1:])
        case "initcap":
            result_exp = snowpark_fn.initcap(snowpark_args[0], snowpark_fn.lit(" "))
        case "input_file_name":
            # TODO: Use METADATA$FILENAME to get an actual file name, but this requires a refactor, because this is not possible straightaway here.
            raise SnowparkConnectNotImplementedError(
                "input_file_name is not yet supported."
            )
        case "instr":
            result_exp = snowpark_fn.charindex(snowpark_args[1], snowpark_args[0])
        case "isnan":
            result_exp = snowpark_fn.equal_nan(snowpark_args[0])
        case "isnotnull":
            spark_function_name = f"({snowpark_arg_names[0]} IS NOT NULL)"
            result_exp = snowpark_args[0].isNotNull()
        case "isnull":
            spark_function_name = f"({snowpark_arg_names[0]} IS NULL)"
            result_exp = snowpark_args[0].isNull()
        case "json_array_length":
            arr_exp = snowpark_fn.function("TRY_PARSE_JSON")(snowpark_args[0])
            result_exp = snowpark_fn.array_size(arr_exp)
        case "json_object_keys":
            obj_exp = snowpark_fn.function("TRY_PARSE_JSON")(
                snowpark_args[0], snowpark_fn.lit("d")
            )
            result_exp = snowpark_fn.object_keys(obj_exp).cast(
                ArrayType(StringType(), True)
            )
            result_exp = snowpark_fn.when(
                snowpark_fn.is_object(obj_exp),
                result_exp,
            ).otherwise(snowpark_fn.lit(None))
        case "json_tuple":
            analyzer = Session.get_active_session()._analyzer
            json = snowpark_fn.function("TRY_PARSE_JSON")(
                snowpark_args[0], snowpark_fn.lit("d")
            )
            fields = exp.unresolved_function.arguments[1:]
            fields = [unwrap_literal(f) for f in fields]
            fields = [
                snowpark_fn.to_json(snowpark_fn.get(json, snowpark_fn.lit(f)))
                for f in fields
            ]
            fields = [analyzer.analyze(f._expression, defaultdict()) for f in fields]
            result_exp = snowpark_fn.sql_expr(", ".join(fields))
            spark_col_names = [f"c{i}" for i in range(len(fields))]
        case "kurtosis":
            result_exp = snowpark_fn.kurtosis(snowpark_args[0])
        case "lag":
            offset = unwrap_literal(exp.unresolved_function.arguments[1])
            default = snowpark_args[2] if len(snowpark_args) > 2 else None
            result_exp = snowpark_fn.lag(snowpark_args[0], offset, default)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "last":
            if not typer.is_window_enabled:
                # If last function is not used in window expression, it should act as aggregate function.
                # According to PySpark docs, ignore_nulls can be a Column - but it doesn't make sense and doesn't work.
                # So assume it's a literal.
                ignore_nulls = unwrap_literal(exp.unresolved_function.arguments[1])

                class LastUDAF:
                    def __init__(self) -> None:
                        self._value = None

                    @property
                    def aggregate_state(self):
                        return self._value

                    def accumulate(self, input_value):
                        if not (ignore_nulls and input_value is None):
                            self._value = input_value

                    def merge(self, other_value):
                        if not (ignore_nulls and other_value is None):
                            self._value = other_value

                    def finish(self):
                        return self._value

                _last_udaf = snowpark_fn.udaf(
                    LastUDAF,
                    return_type=snowpark_typed_args[0].typ,
                    input_types=[snowpark_typed_args[0].typ],
                )

                result_exp = _last_udaf(snowpark_args[0])
            else:
                # when used in window function it should act as last_vale
                result_exp = _resolve_last_value(exp, snowpark_args)
        case "last_value":
            result_exp = _resolve_last_value(exp, snowpark_args)
        case "lead":
            offset = unwrap_literal(exp.unresolved_function.arguments[1])
            default = snowpark_args[2] if len(snowpark_args) > 2 else None
            result_exp = snowpark_fn.lead(snowpark_args[0], offset, default)
            result_exp = TypedColumn(result_exp, lambda: snowpark_typed_args[0].types)
        case "least":
            result_exp = snowpark_fn.function("LEAST_IGNORE_NULLS")(*snowpark_args)
        case "left":
            result_exp = snowpark_fn.left(*snowpark_args)
        case "length" | "char_length" | "character_length":
            if exp.unresolved_function.arguments[0].HasField("literal"):
                # Only update the name if it has the literal field.
                # If it doesn't, it means it's binary data.
                arg_value = repr(unwrap_literal(exp.unresolved_function.arguments[0]))
                # repr is used to display proper column names when newlines or tabs are included in the string
                # However, this breaks with the usage of nested emojis.
                arg_value = arg_value[1:-1] if arg_value != "None" else "NULL"
                spark_function_name = (
                    f"{exp.unresolved_function.function_name}({arg_value})"
                )
            result_exp = snowpark_fn.length(snowpark_args[0])
        case "levenshtein":
            match snowpark_args:
                case [arg1, arg2]:
                    result_exp = snowpark_fn.editdistance(arg1, arg2)
                case [arg1, arg2, _]:
                    max_distance = unwrap_literal(exp.unresolved_function.arguments[2])

                    if max_distance >= 0:
                        # snowpark implementation
                        # a maximum distance can be specified. If the distance exceeds this value, the computation halts and returns the maximum distance.
                        # we are passing max_distance + 1 to make it compatible to spark
                        result_exp = snowpark_fn.editdistance(
                            arg1, arg2, max_distance + 1
                        )
                        result_exp = snowpark_fn.when(
                            result_exp >= max_distance + 1, snowpark_fn.lit(-1)
                        ).otherwise(result_exp)
                    else:
                        result_exp = snowpark_fn.when(
                            snowpark_fn.is_null(arg1) | snowpark_fn.is_null(arg2),
                            snowpark_fn.lit(None),
                        ).otherwise(snowpark_fn.lit(-1))
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
        case "like":
            result_exp = snowpark_args[0].like(snowpark_args[1])
        case "ln":
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.ln(snowpark_args[0]))
        case "localtimestamp":
            result_exp = snowpark_fn.builtin("localtimestamp")()
        case "locate":
            substr = unwrap_literal(exp.unresolved_function.arguments[0])
            value = snowpark_args[1]
            start_pos = unwrap_literal(exp.unresolved_function.arguments[2])

            if start_pos > 0:
                result_exp = snowpark_fn.locate(substr, value, start_pos)
            else:
                result_exp = snowpark_fn.when(
                    snowpark_fn.is_null(value),
                    snowpark_fn.lit(None),
                ).otherwise(snowpark_fn.lit(0))
        case "log":
            spark_function_name = (
                f"LOG({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.when(
                snowpark_args[0] == 1,
                snowpark_fn.when(snowpark_args[1] == 1, NAN).otherwise(INFINITY),
            ).otherwise(
                snowpark_fn.when(
                    snowpark_args[1] <= 0, snowpark_fn.lit(None)
                ).otherwise(snowpark_fn.log(snowpark_args[0], snowpark_args[1]))
            )
        case "log10":
            spark_function_name = f"LOG10({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.log(10.0, snowpark_args[0]))
        case "log1p":
            spark_function_name = f"LOG1P({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.ln(snowpark_args[0] + snowpark_fn.lit(1.0)))
        case "log2":
            spark_function_name = f"LOG2({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] <= 0, snowpark_fn.lit(None)
            ).otherwise(snowpark_fn.log(2.0, snowpark_args[0]))
        case "lower" | "lcase":
            result_exp = snowpark_fn.lower(snowpark_args[0])
        case "lpad":
            result_exp = snowpark_fn.lpad(*snowpark_args)
        case "ltrim":
            result_exp = snowpark_fn.ltrim(snowpark_args[0])
        case "make_date":

            @snowpark_fn.udf(
                input_types=[IntegerType(), IntegerType(), IntegerType()],
                return_type=DateType(),
            )
            def _make_date(year, month, day):
                import logging
                from datetime import datetime

                logging.basicConfig(level=logging.INFO)
                try:
                    if year < 0:
                        error_message = f"Invalid year: {year}. Year cannot be negative"
                        logging.error(error_message)
                        raise ValueError(error_message)
                    date = datetime(year, month, day)
                    return date
                except (ValueError, TypeError) as err:
                    logging.error(f"Error creating date: {err}")
                    return None

            result_exp = _make_date(
                snowpark_fn.cast(snowpark_args[0], IntegerType()),
                snowpark_fn.cast(snowpark_args[1], IntegerType()),
                snowpark_fn.cast(snowpark_args[2], IntegerType()),
            )
        case "map":
            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            def _create_map(*args):
                if args is None or len(args) % 2 != 0:
                    raise ValueError(
                        "Number of arguments must be even (a list of key-value pairs)."
                    )

                result = {}
                for index in range(0, len(args), 2):
                    key = args[index]
                    if not allow_duplicate_keys and key in result:
                        raise ValueError(
                            DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                        )
                    result[key] = args[index + 1]

                return result

            input_types = [tc.typ for tc in snowpark_typed_args]
            input_args = [arg.col for arg in snowpark_typed_args]
            create_map_udf = snowpark_fn.udf(
                _create_map,
                input_types=input_types,
                return_type=MapType(),
            )
            result_exp = create_map_udf(input_args)
            key_types = list(map(lambda x: x.typ, snowpark_typed_args[::2]))
            value_types = list(map(lambda x: x.typ, snowpark_typed_args[1::2]))

            result_exp = snowpark_fn.cast(
                result_exp,
                MapType(_find_common_type(key_types), _find_common_type(value_types)),
            )
        case "map_concat":
            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            def _map_concat(*args):
                new_map = {}
                for m in args:
                    for key, value in m.items():
                        if key in new_map and not allow_duplicate_keys:
                            raise ValueError(
                                DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                            )
                        else:
                            new_map[key] = value
                return new_map

            key_types = list(map(lambda x: x.typ.key_type, snowpark_typed_args[::2]))
            value_types = list(
                map(lambda x: x.typ.value_type, snowpark_typed_args[1::2])
            )
            input_types = [tc.typ for tc in snowpark_typed_args]
            input_args = [arg.col for arg in snowpark_typed_args]

            map_concat_udf = snowpark_fn.udf(
                _map_concat,
                input_types=input_types,
                return_type=MapType(),
            )
            result_exp = snowpark_fn.cast(
                map_concat_udf(input_args),
                MapType(_find_common_type(key_types), _find_common_type(value_types)),
            )
        case "map_contains_key":
            result_exp = snowpark_fn.map_contains_key(*snowpark_args)
        case "map_from_arrays":
            keys_type = snowpark_typed_args[0].typ
            values_type = snowpark_typed_args[1].typ
            if not isinstance(keys_type, ArrayType) or not isinstance(
                values_type, ArrayType
            ):
                raise TypeError(
                    f"map_from_arrays requires two arguments of type ArrayType, got {keys_type} and {values_type}"
                )
            key_type = keys_type.element_type if keys_type.structured else VariantType()
            value_type = (
                values_type.element_type if values_type.structured else VariantType()
            )

            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            def _map_from_arrays(keys, values):
                if len(keys) != len(values):
                    raise ValueError(
                        "The key array and value array of must have the same length"
                    )

                if not allow_duplicate_keys and len(set(keys)) != len(keys):
                    seen = set()
                    for key in keys:
                        if key in seen:
                            raise ValueError(
                                DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                            )
                        seen.add(key)
                # will overwrite the last occurance if there are duplicates.
                return dict(zip(keys, values))

            _map_from_arrays_udf = snowpark_fn.udf(
                _map_from_arrays,
                return_type=MapType(),
                input_types=[keys_type, values_type],
            )
            result_exp = snowpark_fn.cast(
                _map_from_arrays_udf(*snowpark_args), MapType(key_type, value_type)
            )
        case "map_from_entries":
            if not isinstance(snowpark_typed_args[0].typ, ArrayType):
                raise TypeError(
                    f"map_from_entries requires an argument of type ArrayType, got {snowpark_typed_args[0].typ}"
                )

            entry_type = snowpark_typed_args[0].typ.element_type

            match entry_type:
                case None:
                    # workaround for spark sql struct(key, value) - entry_type is None
                    # TODO: can we get correct types once we integrate spark's sql parser?
                    # VariantType is not supported for structured map keys
                    key_type = StringType()
                    value_type = VariantType()
                    # default field names
                    key_field = "col1"
                    value_field = "col2"
                case _ if isinstance(entry_type, StructType) and entry_type.structured:
                    key_type = entry_type.fields[0].datatype
                    value_type = entry_type.fields[1].datatype
                    [key_field, value_field] = entry_type.names
                case _:
                    raise TypeError(
                        f"map_from_entries requires an array of StructType, got array of {entry_type}"
                    )

            last_win_dedup = global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"

            result_exp = snowpark_fn.cast(
                snowpark_fn.function("reduce")(
                    snowpark_args[0],
                    snowpark_fn.object_construct(),
                    snowpark_fn.sql_expr(
                        # value_field is cast to variant because object_insert doesn't allow structured types,
                        # and structured types are not coercible to variant
                        # TODO: allow structured types in object_insert?
                        f"(acc, e) -> object_insert(acc, e:{key_field}, e:{value_field}::variant, {last_win_dedup})"
                    ),
                ),
                MapType(key_type, value_type),
            )
        case "map_keys":
            arg_type = snowpark_typed_args[0].typ
            if not isinstance(arg_type, MapType):
                raise TypeError(f"map_keys requires a MapType argument, got {arg_type}")

            if arg_type.structured:
                result_exp = snowpark_fn.map_keys(snowpark_args[0])
            else:
                # snowpark's map_keys function is not compatible with snowflake's OBJECT type
                result_exp = snowpark_fn.object_keys(snowpark_args[0])
        case "map_values":
            # TODO: implement in Snowflake/Snowpark
            # technically this could be done with a lateral join, but it's probably not worth the effort
            def _map_values(obj: dict) -> list:
                return list(obj.values())

            arg_type = snowpark_typed_args[0].typ
            if not isinstance(arg_type, MapType):
                raise TypeError(
                    f"map_values requires a MapType argument, got {arg_type}"
                )

            map_values = snowpark_fn.udf(
                _map_values,
                return_type=ArrayType(arg_type.value_type),
                input_types=[arg_type],
            )

            result_exp = map_values(snowpark_args[0])
        case "mask":
            result_exp, upper_char, lower_char, digit_char, other_char = snowpark_args

            random_tag_suffix = "".join(random.sample(string.ascii_uppercase, 6))
            tags = [
                s + random_tag_suffix
                for s in ["TAGUPPER", "TAGLOWER", "TAGDIGIT", "TAGOTHER"]
            ]
            patterns = ["[A-Z]", "[a-z]", r"\d", "[^A-Z]"]
            replacements = [upper_char, lower_char, digit_char, other_char]

            # To avoid replacement character collisions we need to replace them with unique tags first.
            for tag, pattern, replacement_char in zip(tags, patterns, replacements):
                result_exp = snowpark_fn.when(
                    ~snowpark_fn.is_null(replacement_char),
                    snowpark_fn.regexp_replace(result_exp, pattern, tag),
                ).otherwise(result_exp)

            for tag, replacement_char in zip(tags, replacements):
                result_exp = snowpark_fn.when(
                    ~snowpark_fn.is_null(replacement_char),
                    snowpark_fn.regexp_replace(result_exp, tag, replacement_char),
                ).otherwise(result_exp)
        case "max":
            result_exp = snowpark_fn.max(snowpark_args[0])
        case "max_by":
            result_exp = snowpark_fn.max_by(*snowpark_args)
        case "md5":
            result_exp = snowpark_fn.md5(snowpark_args[0])
        case "mean":
            result_exp = snowpark_fn.avg(snowpark_args[0])
        case "median":
            result_exp = snowpark_fn.median(snowpark_args[0])
        case "min":
            result_exp = snowpark_fn.min(snowpark_args[0])
        case "min_by":
            result_exp = snowpark_fn.min_by(*snowpark_args)
        case "minute":
            result_exp = snowpark_fn.minute(snowpark_fn.to_timestamp(snowpark_args[0]))
        case "mode":
            result_exp = snowpark_fn.mode(snowpark_args[0])
        case "monotonically_increasing_id":
            result_exp = snowpark_fn.monotonically_increasing_id()
        case "month":
            result_exp = snowpark_fn.month(snowpark_fn.to_date(snowpark_args[0]))
        case "months_between":
            # Pyspark months_between returns a floating point number with a higher precision than Snowpark
            # and has a third optional argument (roundOff: bool = True), which allows to increase the precision even more.
            # The difference is visible after a few decimal places, but in order to have a 100% compatibility, extending the Snowpark's API is required.

            spark_function_name = f"months_between({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, {str(snowpark_arg_names[2]).lower()})"
            result_exp = snowpark_fn.months_between(
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
                snowpark_fn.cast(snowpark_args[1], get_timestamp_type()),
            )
        case "named_struct":
            if snowpark_args is None or len(snowpark_args) % 2 != 0:
                raise ValueError(
                    "Number of arguments must be even (a list of key-value pairs)."
                )
            field_cols = snowpark_typed_args[1::2]
            result_exp = snowpark_fn.object_construct_keep_null(
                *[
                    name_with_col
                    for name, typed_col in zip(snowpark_args[::2], field_cols)
                    for name_with_col in (
                        name,
                        typed_col.column(to_semi_structure=True),
                    )
                ]
            )
            # calculate schema to cast the result to the structured type
            field_names = list(
                map(unwrap_literal, exp.unresolved_function.arguments[::2])
            )
            schema = StructType(
                [
                    StructField(name, col.typ)
                    for name, col in zip(field_names, field_cols)
                ]
            )
            result_exp = snowpark_fn.cast(result_exp, schema)
        case "nanvl":
            # SNOW-1915311: Numeric value 'NAN' is not recognized is thrown in certain
            # scenarios, when equal_nan is used, e.g. in test_normal_functions spark test.
            arg1_is_nan = snowpark_args[0] == snowpark_fn.lit(NAN)
            arg2_is_nan = snowpark_args[1] == snowpark_fn.lit(NAN)

            result_exp = (
                snowpark_fn.when(~arg1_is_nan, snowpark_args[0])
                .when(arg1_is_nan & arg2_is_nan, snowpark_fn.lit(NAN))
                .when(snowpark_fn.is_null(snowpark_args[0]), snowpark_fn.lit(None))
                .when(~arg2_is_nan, snowpark_args[1])
                .otherwise(snowpark_fn.lit(None))
            )
        case "negative":
            result_exp = snowpark_fn.negate(snowpark_args[0])
        case "next_day":
            result_exp = snowpark_fn.next_day(snowpark_args[0], snowpark_args[1])
        case "not":
            spark_function_name = f"(NOT {snowpark_arg_names[0]})"
            result_exp = ~snowpark_args[0]
        case "nth_value":
            args = exp.unresolved_function.arguments
            n = unwrap_literal(args[1])
            ignore_nulls = unwrap_literal(args[2]) if len(args) > 2 else False
            result_exp = snowpark_fn.nth_value(snowpark_args[0], n, ignore_nulls)
        case "ntile":
            result_exp = snowpark_fn.ntile(snowpark_args[0])
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "nullif":
            result_exp = snowpark_fn.call_function("nullif", *snowpark_args)
        case "nvl":
            result_exp = snowpark_fn.nvl(*snowpark_args)
        case "nvl2":
            result_exp = snowpark_fn.call_function("nvl2", *snowpark_args)
        case "octet_length":
            result_exp = snowpark_fn.octet_length(snowpark_args[0])
        case "or":
            spark_function_name = (
                f"({snowpark_arg_names[0]} OR {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_args[0] | snowpark_args[1]
        case "overlay":
            length = snowpark_fn.when(
                snowpark_args[3] < 0, snowpark_fn.length(snowpark_args[1])
            ).otherwise(snowpark_args[3])
            result_exp = snowpark_fn.concat(
                snowpark_fn.substring(snowpark_args[0], 1, snowpark_args[2] - 1),
                snowpark_args[1],
                snowpark_fn.substring(snowpark_args[0], snowpark_args[2] + length),
            )
        case "parse_url":
            url, part_to_extract = snowpark_args[0], snowpark_args[1]
            key = snowpark_args[2] if len(snowpark_args) > 2 else snowpark_fn.lit(None)

            result_exp = snowpark_fn.call_function("parse_url", url)

            result_exp = (
                snowpark_fn.when(
                    part_to_extract == snowpark_fn.lit("PROTOCOL"),
                    snowpark_fn.get(result_exp, snowpark_fn.lit("scheme")),
                )
                .when(
                    part_to_extract == snowpark_fn.lit("REF"),
                    snowpark_fn.get(result_exp, snowpark_fn.lit("fragment")),
                )
                .when(
                    part_to_extract == snowpark_fn.lit("AUTHORITY"),
                    snowpark_fn.concat_ws(
                        snowpark_fn.lit(":"),
                        snowpark_fn.get(result_exp, snowpark_fn.lit("host")),
                        snowpark_fn.get(result_exp, snowpark_fn.lit("port")),
                    ),
                )
                .when(
                    (part_to_extract == snowpark_fn.lit("QUERY")) & ~key.is_null(),
                    snowpark_fn.get(
                        snowpark_fn.get(result_exp, snowpark_fn.lit("parameters")), key
                    ),
                )
                .otherwise(
                    snowpark_fn.get(result_exp, snowpark_fn.lower(part_to_extract))
                )
            )

            result_exp = snowpark_fn.cast(result_exp, StringType())
        case "percent_rank":
            result_exp = snowpark_fn.percent_rank()
            result_exp = TypedColumn(result_exp, lambda: [DoubleType()])
        case "pi":
            spark_function_name = "PI()"
            result_exp = snowpark_fn.lit(math.pi)
        case "pmod":
            a, b = snowpark_args
            result_exp = snowpark_fn.when(a < 0, (a % b + b) % b).otherwise(a % b)
        case "posexplode" | "posexplode_outer":
            input_types = [tc.typ for tc in snowpark_typed_args]
            is_nullable = function_name == "posexplode_outer"
            if isinstance(input_types[0], ArrayType):

                @snowpark_fn.udtf(
                    name="pos_explode",
                    replace=True,
                    output_schema=StructType(
                        [
                            StructField(
                                "pos",
                                IntegerType(),
                                is_nullable,
                            ),
                            StructField("col", input_types[0].element_type, True),
                        ]
                    ),
                    input_types=[*input_types, StringType()],
                )
                class PosExplode:
                    def process(self, arr, function_name):
                        if not arr:
                            if function_name == "posexplode":
                                yield
                            else:
                                yield (None, None)
                        else:
                            yield from enumerate(arr)

                spark_col_names = ["pos", "col"]
            elif isinstance(input_types[0], MapType):
                key_types = list(map(lambda x: x.typ.key_type, snowpark_typed_args))
                value_types = list(map(lambda x: x.typ.value_type, snowpark_typed_args))

                @snowpark_fn.udtf(
                    name="pos_explode",
                    replace=True,
                    output_schema=StructType(
                        [
                            StructField(
                                "pos",
                                IntegerType(),
                                is_nullable,
                            ),
                            StructField(
                                "key",
                                _find_common_type(key_types),
                                is_nullable,
                            ),
                            StructField("value", _find_common_type(value_types), True),
                        ]
                    ),
                    input_types=[*input_types, StringType()],
                )
                class PosExplode:
                    def process(self, m, function_name):
                        if not m:
                            if function_name == "posexplode":
                                yield
                            else:
                                yield (None, None, None)
                        else:
                            for i, (key, value) in enumerate(m.items()):
                                yield (i, key, value)

                spark_col_names = ["pos", "key", "value"]
            else:
                raise TypeError(
                    f"Data type mismatch: {function_name} requires an array or map input, but got {input_types[0]}."
                )
            result_exp = snowpark_fn.call_table_function(
                "pos_explode", snowpark_args[0], snowpark_fn.lit(function_name)
            )
        case "position":
            substr, base_str = snowpark_args[0], snowpark_args[1]
            start_pos = (
                snowpark_args[2] if len(snowpark_args) > 2 else snowpark_fn.lit(1)
            )

            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(start_pos), snowpark_fn.lit(0)
            ).otherwise(snowpark_fn.position(substr, base_str, start_pos))

            if len(snowpark_args) == 2:
                spark_function_name = (
                    f"position({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, 1)"
                )

        case "positive":
            arg_type = snowpark_typed_args[0].typ
            if not isinstance(arg_type, _NumericType):
                raise TypeError(
                    f"Data type mismatch: positive requires numeric input, but got {arg_type}."
                )
            spark_function_name = f"(+ {snowpark_arg_names[0]})"
            result_exp = snowpark_args[0]
        case "pow":
            result_exp = snowpark_fn.pow(snowpark_args[0], snowpark_args[1])
        case "power":
            spark_function_name = (
                f"POWER({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.pow(snowpark_args[0], snowpark_args[1])
        case "product":
            # Log-Sum-Exp trick
            result_exp = snowpark_fn.exp(
                snowpark_fn.sum(
                    snowpark_fn.when(
                        snowpark_args[0] <= 0, snowpark_fn.lit(None)
                    ).otherwise(snowpark_fn.ln(snowpark_args[0]))
                )
            )
        case "quarter":
            result_exp = snowpark_fn.quarter(snowpark_fn.to_date(snowpark_args[0]))
        case "radians":
            spark_function_name = f"RADIANS({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.radians(*snowpark_args)
        case "raise_error":

            @snowpark_fn.udf(
                input_types=[StringType()],
                return_type=NullType(),
            )
            def _raise_error(message=None):
                raise ValueError(message)

            result_exp = _raise_error(*snowpark_args)
        case "rand":
            # Snowpark random() generates a 64 bit signed integer, but pyspark is [0.0, 1.0).
            # TODO: Seems like more validation of the arguments is appropriate.
            args = exp.unresolved_function.arguments
            if len(args) > 0:
                result_exp = snowpark_fn.random(unwrap_literal(args[0]))
            else:
                result_exp = snowpark_fn.random()

            # Adjust from a 64 bit integer to the pyspark range of [0.0, 1.0).
            # The result_exp is a signed int64 number, so the range is [-2**63, 2**63-1]. We add 2**63 (aka subtract
            # MIN_INT64) to shift this number into the range [0, 2**64-1], which is the uint64 range: [0, MAX_UNIT64]
            # However, in the end result, we want the range to exclude 1.0, hence, we divide by MAX_UNIT64 + 1.
            # The float conversion below is necessary, because snowpark python uses int64 for integers, but we are
            # shifting into unit64 and hence are out of the range of int64.
            result_exp = (result_exp - float(MIN_INT64)) / (float(MAX_UINT64) + 1)
        case "randn":
            args = exp.unresolved_function.arguments

            result_exp = snowpark_fn.function("NORMAL")(
                snowpark_fn.lit(0.0),
                snowpark_fn.lit(1.0),
                (
                    snowpark_fn.random(unwrap_literal(args[0]))
                    if args
                    else snowpark_fn.random()
                ),
            )
        case "rank":
            result_exp = snowpark_fn.rank()
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "regexp_count":
            # Spark counts an empty pattern as length(input) + 1
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), None)
                .when(snowpark_args[1] == "", snowpark_fn.length(snowpark_args[0]) + 1)
                .otherwise(snowpark_fn.regexp_count(snowpark_args[0], snowpark_args[1]))
            )
        case "regexp_extract":
            # Pyspark returns null for a null input, Snowpark coalesces this to an empty string.
            # We check the input to get the same behaviour.
            result_exp = snowpark_fn.when(
                snowpark_fn.is_null(snowpark_args[0]), None
            ).otherwise(
                snowpark_fn.regexp_extract(
                    snowpark_args[0], snowpark_args[1], snowpark_args[2]
                )
            )
        case "regexp_extract_all":
            if len(snowpark_args) == 2:
                idx = snowpark_fn.lit(1)
                spark_function_name = spark_function_name[:-1] + ", 1)"
            else:
                idx = snowpark_args[2]
            # Snowflake's regexp_extract_all has more arguments, so we need to fill out default values
            result_exp = snowpark_fn.cast(
                snowpark_fn.call_function(
                    "regexp_extract_all",
                    snowpark_args[0],
                    snowpark_args[1],
                    snowpark_fn.lit(1),
                    snowpark_fn.lit(1),
                    snowpark_fn.lit("c"),
                    idx,
                ),
                ArrayType(StringType(), True),
            )
        case "regexp_instr":
            # Spark seems to ignore the group index argument, so we don't use it here.
            # Spark matches certain patterns to an empty string. We can emulate this with rlike.
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), None)
                .when(
                    (snowpark_args[0] == "")
                    & (snowpark_args[0].rlike(snowpark_args[1])),
                    1,
                )
                .otherwise(
                    snowpark_fn.call_function(
                        "regexp_instr",
                        snowpark_args[0],
                        snowpark_args[1],
                    )
                )
            )
            # if idx was not specified, it defaults to 0 in the column name
            if len(snowpark_args) == 2:
                spark_function_name = spark_function_name[:-1] + ", 0)"
        case "regexp_replace":
            spark_function_name = spark_function_name[:-1] + ", 1)"
            result_exp = snowpark_fn.regexp_replace(*snowpark_args)
        case "regexp_substr":
            # in some cases Snowflake returns an empty string instead of null
            # but that also counts as no match, for example regexp_substr('', '$')
            result_exp = result_exp = snowpark_fn.call_function(
                "nullif",
                snowpark_fn.call_function("regexp_substr", *snowpark_args),
                "",
            )
        case "regr_avgx":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_avgx(*updated_args)
        case "regr_avgy":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_avgy(*updated_args)
        case "regr_count":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_count(*updated_args)
        case "regr_intercept":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_intercept(*updated_args)
        case "regr_r2":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_r2(*updated_args)
        case "regr_slope":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_slope(*updated_args)
        case "regr_sxx":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_sxx(*updated_args)
        case "regr_sxy":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_sxy(*updated_args)
        case "regr_syy":
            updated_args = _validate_numeric_args(
                function_name, snowpark_typed_args, snowpark_args
            )
            result_exp = snowpark_fn.regr_syy(*updated_args)
        case "repeat":
            result_exp = snowpark_fn.repeat(*snowpark_args)
        case "replace":
            result_exp = snowpark_fn.replace(*snowpark_args)

            if len(snowpark_args) == 2:
                spark_function_name = (
                    f"replace({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, )"
                )
        case "reverse":
            match snowpark_typed_args[0].typ:
                case ArrayType():
                    result_exp = snowpark_fn.function("array_reverse")(snowpark_args[0])
                case _:
                    result_exp = snowpark_fn.reverse(snowpark_args[0])
        case "right":
            result_exp = snowpark_fn.right(*snowpark_args)
        case "rint":
            result_exp = snowpark_fn.cast(
                snowpark_fn.round(snowpark_args[0]), DoubleType()
            )
        case "rlike" | "regexp" | "regexp_like":
            # Snowflake's regexp/rlike implicitly anchors the pattern to the beginning and end of the string.
            # Spark matches any substring, so we use regexp_instr to emulate this, except empty inputs,
            # which need to be checked with regexp/rlike.
            # We also handle the case where the pattern is an empty string, which Spark seems to treat as .*
            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(snowpark_args[0]), None)
                .when(snowpark_args[0] == "", snowpark_args[0].rlike(snowpark_args[1]))
                .otherwise(
                    snowpark_fn.call_function(
                        "regexp_instr",
                        snowpark_args[0],
                        snowpark_fn.when(snowpark_args[1] == "", ".*").otherwise(
                            snowpark_args[1]
                        ),
                    )
                    > 0
                )
            )
            spark_function_name = (
                f"{function_name.upper()}({', '.join(snowpark_arg_names)})"
            )
        case "round":
            result_exp = snowpark_fn.round(snowpark_args[0], snowpark_args[1])
        case "row_number":
            result_exp = snowpark_fn.row_number()
            result_exp = TypedColumn(result_exp, lambda: [LongType()])
        case "rpad":
            result_exp = snowpark_fn.rpad(*snowpark_args)
        case "rtrim":
            result_exp = snowpark_fn.rtrim(snowpark_args[0])
        case "schema_of_csv":
            snowpark_args = [
                typed_arg.column(to_semi_structure=True)
                for typed_arg in snowpark_typed_args
            ]
            first_arg_typ = typer.type(snowpark_args[0])[0]

            @snowpark_fn.udf(
                return_type=StringType(),
                input_types=[first_arg_typ, MapType()],
            )
            def _schema_of_csv(data: str, options: Optional[dict]):
                from contextlib import suppress

                sep = ","
                if options is not None and isinstance(options, dict):
                    sep = options.get("sep") or sep

                def _get_type(v: str):
                    if v.lower() in ["true", "false"]:
                        return "BOOLEAN"

                    with suppress(Exception):  # int
                        y = int(v)
                        if str(y) == v:
                            if y < -2147483648 or y > 2147483647:
                                return "BIGINT"
                            return "INT"

                    with suppress(Exception):  # double
                        y = float(v)
                        return "DOUBLE"

                    for _format in ["%H:%M", "%H:%M:%S"]:
                        with suppress(Exception):
                            time.strptime(v, _format)
                            return "TIMESTAMP"

                    return "STRING"

                fields = []
                for i, v in enumerate(data.split(sep)):
                    col_name = f"_c{i}"
                    fields.append(f"{col_name}: {_get_type(v)}")

                return f"STRUCT<{', '.join(fields)}>"

            spark_function_name = f"schema_of_csv({snowpark_arg_names[0]})"

            match snowpark_args:
                case [csv_data]:
                    result_exp = _schema_of_csv(csv_data, snowpark_fn.lit(None))
                case [csv_data, options]:
                    result_exp = _schema_of_csv(csv_data, options)
                case _:
                    raise ValueError("Unrecognized from_csv parameters")
        case "sec":
            spark_function_name = f"SEC({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.coalesce(
                snowpark_fn.divnull(1.0, snowpark_fn.cos(snowpark_args[0])),
                snowpark_fn.lit(INFINITY),
            )
        case "second":
            result_exp = snowpark_fn.second(snowpark_fn.to_timestamp(snowpark_args[0]))
        case "sentences":

            @snowpark_fn.udf
            def _sentences(text: Optional[str]) -> Optional[list[list[str]]]:
                if text is None:
                    return None

                import re

                word_sep = r"[:,;@\s]+|-{2,}"
                sentence_sep = r"[!?.]+(?:\s|$)"

                sentences = [
                    list(
                        map(
                            lambda s: s.strip("-"),
                            filter(None, re.split(word_sep, sentence)),
                        )
                    )
                    for sentence in re.split(sentence_sep, text)
                ]

                res = list(filter(None, sentences))
                return res if len(res) > 0 or len(text) == 0 else [[]]

            result_exp = _sentences(snowpark_args[0])
        case "sequence":
            result_exp = snowpark_fn.sequence(*snowpark_args)
        case "sha":
            sha_function = snowpark_fn.function("SHA1_HEX")
            result_exp = sha_function(snowpark_args[0])
        case "sha1":
            result_exp = snowpark_fn.sha1(snowpark_args[0])
        case "sha2":
            num_bits = unwrap_literal(exp.unresolved_function.arguments[1])

            # 0 equivalent to 256 in PySpark, but is not allowed in Snowpark
            num_bits = 256 if num_bits == 0 else num_bits

            result_exp = snowpark_fn.sha2(snowpark_args[0], num_bits)
        case "shiftleft":
            result_exp = snowpark_fn.bitshiftleft(snowpark_args[0], snowpark_args[1])
        case "shiftright":
            result_exp = snowpark_fn.bitshiftright(snowpark_args[0], snowpark_args[1])
        case "shiftrightunsigned":
            num_bits = unwrap_literal(exp.unresolved_function.arguments[1])
            result_exp = snowpark_fn.bitshiftright(snowpark_args[0], snowpark_args[1])
            result_exp = result_exp.bitwiseAnd(
                snowpark_fn.lit(0xFFFFFFFFFFFFFFFF >> num_bits)
            )
        case "shuffle":
            arg_type = snowpark_typed_args[0].typ

            @snowpark_fn.udf(input_types=[arg_type], return_type=arg_type)
            def _shuffle_udf(array: list) -> list:
                import random

                random.shuffle(array)

                return array

            result_exp = _shuffle_udf(snowpark_args[0])
        case "signum" | "sign":
            fn_name = function_name.upper()
            # Somehow, SIGNUM is upper case, but sign is lower case in PySpark.
            if fn_name == "SIGN":
                fn_name = "sign"

            spark_function_name = f"{fn_name}({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.when(
                snowpark_args[0] == NAN, snowpark_fn.lit(NAN)
            ).otherwise(
                snowpark_fn.cast(snowpark_fn.sign(snowpark_args[0]), DoubleType())
            )
        case "sin":
            spark_function_name = f"SIN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.sin(snowpark_args[0])
        case "sinh":
            spark_function_name = f"SINH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.sinh(snowpark_args[0])
        case "size":
            v = snowpark_fn.cast(snowpark_args[0], VariantType())
            result_exp = (
                snowpark_fn.when(
                    snowpark_fn.is_array(v),
                    snowpark_fn.array_size(v),
                )
                .when(
                    snowpark_fn.is_object(v),
                    snowpark_fn.array_size(snowpark_fn.object_keys(v)),
                )
                .when(
                    snowpark_fn.is_null(v),
                    snowpark_fn.lit(-1),
                )
                .otherwise(snowpark_fn.lit(None))
            ).alias(f"SIZE({snowpark_args[0]})")
        case "skewness":
            result_exp = snowpark_fn.skew(snowpark_args[0])
        case "slice":
            spark_index = snowpark_args[1]
            arr_size = snowpark_fn.array_size(snowpark_args[0])
            slice_len = snowpark_args[2]
            result_exp = snowpark_fn.when(
                spark_index < 0,
                snowpark_fn.array_slice(
                    snowpark_args[0],
                    arr_size + spark_index,
                    arr_size + spark_index + slice_len,
                ),
            ).otherwise(
                snowpark_fn.array_slice(
                    snowpark_args[0], spark_index - 1, spark_index + slice_len - 1
                )
            )
        case "sort_array":
            sort_asc = unwrap_literal(exp.unresolved_function.arguments[1])
            result_exp = snowpark_fn.sort_array(
                snowpark_args[0],
                sort_ascending=sort_asc,
                nulls_first=sort_asc,
            )
        case "soundex":
            value = snowpark_args[0]
            regexp_like_fn = snowpark_fn.function("REGEXP_LIKE")

            result_exp = (
                snowpark_fn.when(snowpark_fn.is_null(value), snowpark_fn.lit(None))
                .when(
                    snowpark_fn.trim(value) == "", snowpark_fn.lit("")
                )  # When string contains only whitespaces
                .when(
                    regexp_like_fn(value, "^[^a-zA-Z].*"), value
                )  # When string doesn't start with a letter
                .otherwise(snowpark_fn.soundex(snowpark_fn.upper(value)))
            )
        case "spark_partition_id":
            result_exp = snowpark_fn.lit(0)
        case "split":

            @snowpark_fn.udf
            def _split(
                input: Optional[str], pattern: Optional[str], limit: Optional[int]
            ) -> Optional[list[str]]:
                if input is None or pattern is None:
                    return None

                if limit == 1:
                    return [input]

                import re

                # A default of -1 is passed in PySpark, but RE needs it to be 0 to provide all splits.
                # In PySpark, the limit also indicates the max size of the resulting array, but in RE
                # the remainder is returned as another element.
                maxsplit = limit - 1 if limit > 0 else 0

                split_result = re.split(pattern, input, maxsplit)
                if len(pattern) == 0:
                    # RE.split provides a first and last empty element that is not there in PySpark.
                    split_result = split_result[1 : len(split_result) - 1]

                return split_result

            match snowpark_args:
                case [str_, pattern]:
                    spark_function_name = (
                        f"split({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, -1)"
                    )
                    result_exp = _split(str_, pattern, snowpark_fn.lit(0))
                case [str_, pattern, limit]:  # noqa: F841
                    result_exp = _split(str_, pattern, limit)
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
        case "split_part":
            result_exp = snowpark_fn.call_function("split_part", *snowpark_args)
        case "sqrt":
            spark_function_name = f"SQRT({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.sqrt(snowpark_args[0])
        case "startswith":
            result_exp = snowpark_args[0].startswith(snowpark_args[1])
        case "stddev":
            result_exp = snowpark_fn.stddev(snowpark_args[0])
        case "stddev_pop":
            result_exp = snowpark_fn.stddev_pop(snowpark_args[0])
        case "stddev_samp" | "std":
            result_exp = snowpark_fn.stddev_samp(snowpark_args[0])
        case "str_to_map":
            value, pair_delim_, kv_delim_ = snowpark_args

            allow_duplicate_keys = (
                global_config.spark_sql_mapKeyDedupPolicy == "LAST_WIN"
            )

            @snowpark_fn.udf
            def _str_to_map(
                s: Optional[str], pair_delim: Optional[str], kv_delim: Optional[str]
            ) -> Optional[dict]:
                if any(x is None for x in (s, pair_delim, kv_delim)):
                    return None

                if s == "":
                    return {"": None}

                import re

                pairs = list(filter(lambda x: x != "", re.split(pair_delim, s)))

                kv_pairs = [
                    list(filter(lambda x: x != "", re.split(kv_delim, pair)))
                    for pair in pairs
                ]

                result_map = {}

                for key, val in kv_pairs:
                    if key in result_map and not allow_duplicate_keys:
                        raise ValueError(
                            DUPLICATE_KEY_FOUND_ERROR_TEMPLATE.format(key=key)
                        )

                    result_map[key] = val

                return result_map

            result_exp = snowpark_fn.cast(
                _str_to_map(value, pair_delim_, kv_delim_),
                MapType(StringType(), StringType()),
            )
        case "struct":

            def _f_name(index: int, resolved_name: str) -> str:
                match exp.unresolved_function.arguments[index].WhichOneof("expr_type"):
                    case "alias":
                        # aliases are used for field names in struct schema
                        return exp.unresolved_function.arguments[index].alias.name[0]
                    case "unresolved_attribute":
                        return resolved_name
                    case "unresolved_named_lambda_variable":
                        return exp.unresolved_function.arguments[
                            index
                        ].unresolved_named_lambda_variable.name_parts[0]

                return f"col{index + 1}"

            fields_cols = list(zip(snowpark_arg_names, snowpark_typed_args))
            field_types = [
                StructField(_f_name(idx, name), col.typ)
                for idx, (name, col) in enumerate(fields_cols)
            ]
            result_exp = snowpark_fn.object_construct_keep_null(
                *[
                    name_with_col
                    for idx, (name, typed_col) in enumerate(fields_cols)
                    for name_with_col in (
                        snowpark_fn.lit(_f_name(idx, name)),
                        typed_col.column(to_semi_structure=True),
                    )
                ]
            )
            result_exp = snowpark_fn.cast(result_exp, StructType(field_types))
            spark_field_names = ", ".join(
                resolved_name for (resolved_name, _) in fields_cols
            )
            spark_function_name = f"struct({spark_field_names})"
        case "substring" | "substr":
            result_exp = snowpark_fn.substring(*snowpark_args)
        case "substring_index":
            value, delim, count = snowpark_args

            value = snowpark_fn.split(value, delim)
            array_size = snowpark_fn.array_size(value)

            value = (
                snowpark_fn.when(count == 0, snowpark_fn.array_construct())
                .when(
                    count > 0, snowpark_fn.array_slice(value, snowpark_fn.lit(0), count)
                )
                .otherwise(snowpark_fn.array_slice(value, count, array_size))
            )

            result_exp = snowpark_fn.array_to_string(value, delim)
        case "sum":
            if exp.unresolved_function.is_distinct:
                spark_function_name = f"sum(DISTINCT {snowpark_arg_names[0]})"
                result_exp = snowpark_fn.sum_distinct(snowpark_args[0])
            else:
                result_exp = snowpark_fn.sum(snowpark_args[0])
        case "tan":
            spark_function_name = f"TAN({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.tan(snowpark_args[0])
        case "tanh":
            spark_function_name = f"TANH({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.tanh(snowpark_args[0])
        case "timestamp_micros":
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_timestamp(snowpark_args[0], 6),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "timestamp_millis":
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_timestamp(snowpark_args[0] * 1_000, 6),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "timestamp_seconds":
            # Spark allows seconds to be fractional. Snowflake does not allow that
            # even though the documentation explicitly says that it does.
            # As a workaround, use integer milliseconds instead of fractional seconds.
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_timestamp(
                    snowpark_fn.cast(snowpark_args[0] * 1_000_000, LongType()), 6
                ),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "to_csv":
            snowpark_args = [
                typed_arg.column(to_semi_structure=True)
                for typed_arg in snowpark_typed_args
            ]
            first_arg_typ = typer.type(snowpark_args[0])[0]

            @snowpark_fn.udf(
                return_type=StringType(),
                input_types=[first_arg_typ, MapType()],
            )
            def _to_csv(col: str, options: Optional[dict]):
                sep = ","
                if options is not None and isinstance(options, dict):
                    sep = options.get("sep") or sep
                return sep.join([str(val) for key, val in col.items()])

            spark_function_name = f"to_csv({snowpark_arg_names[0]})"

            match snowpark_args:
                case [csv_data]:
                    result_exp = _to_csv(csv_data, snowpark_fn.lit(None))
                case [csv_data, options]:
                    result_exp = _to_csv(csv_data, options)
                case _:
                    raise ValueError("Unrecognized from_csv parameters")
        case "to_date":
            match snowpark_typed_args[0].typ:
                case DateType():
                    result_exp = snowpark_args[0]
                case TimestampType():
                    result_exp = snowpark_fn.to_date(snowpark_args[0])
                case _:
                    result_exp = (
                        snowpark_fn.to_date(
                            snowpark_args[0],
                            snowpark_fn.lit(
                                map_spark_timestamp_format_expression(
                                    exp.unresolved_function.arguments[1]
                                )
                            ),
                        )
                        if len(snowpark_args) > 1
                        else snowpark_fn.to_date(*snowpark_args)
                    )
        case "to_json":
            result_exp = snowpark_fn.to_json(snowpark_fn.to_variant(snowpark_args[0]))
        case "to_number":
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e, _], [val, fmt]):
                    sf_val = e.col
                    match fmt.WhichOneof("expr_type"):
                        case "literal":
                            lit_fmt, _ = get_literal_field_and_name(fmt.literal)
                            if lit_fmt.endswith("PR"):
                                # Remove PR
                                lit_fmt = lit_fmt.replace("PR", "")
                                fmt = lit_fmt
                                # Replace angle brackets with minus sign
                                match val.WhichOneof("expr_type"):
                                    case "literal":
                                        lit_value, _ = get_literal_field_and_name(
                                            val.literal
                                        )
                                        if lit_value.startswith(
                                            "<"
                                        ) and lit_value.endswith(">"):
                                            lit_value = lit_value.replace("<", "-")
                                            lit_value = lit_value.replace(">", "")
                                            sf_val = snowpark_fn.lit(lit_value)

                    sf_fmt = snowpark_fn.lit(map_spark_number_format_expression(fmt))
                    result_exp = snowpark_fn.function("to_number")(
                        sf_val,
                        sf_fmt,
                    )
                case _:
                    result_exp = snowpark_fn.function("to_number")(
                        snowpark_args[0], snowpark_args[1]
                    )
        case "to_timestamp":
            match (snowpark_typed_args, exp.unresolved_function.arguments):
                case ([e], _):
                    result_exp = snowpark_fn.to_timestamp(e.col)
                case ([e, _], _) if type(e.typ) in (DateType, TimestampType):
                    result_exp = snowpark_fn.to_timestamp(e.col)
                case ([e, _], [_, fmt]):
                    result_exp = snowpark_fn.to_timestamp(
                        e.col,
                        snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                    )
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = snowpark_fn.cast(
                result_exp, TimestampType(snowpark.types.TimestampTimeZone.NTZ)
            )
        case "to_utc_timestamp":

            @snowpark_fn.udf(
                input_types=[snowpark_typed_args[0].typ], return_type=StringType()
            )
            def map_timezone(short_tz):
                return SPARK_TZ_ABBREVIATIONS_OVERRIDES.get(short_tz, short_tz)

            result_exp = snowpark_fn.cast(
                snowpark_fn.to_utc_timestamp(
                    snowpark_args[0], map_timezone(snowpark_args[1])
                ),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "translate":
            src_alphabet = unwrap_literal(exp.unresolved_function.arguments[1])
            target_alphabet = unwrap_literal(exp.unresolved_function.arguments[2])

            # In Spark the target alphabet is truncated if it's too long, but in Snowpark an exception is thrown.
            if len(target_alphabet) > len(src_alphabet):
                target_alphabet = target_alphabet[: len(src_alphabet)]

            result_exp = snowpark_fn.translate(
                snowpark_args[0],
                snowpark_fn.lit(src_alphabet),
                snowpark_fn.lit(target_alphabet),
            )
        case "trim":
            result_exp = snowpark_fn.trim(snowpark_args[0])
        case "trunc":
            part = unwrap_literal(exp.unresolved_function.arguments[1])
            result_exp = snowpark_fn.cast(
                snowpark_fn.date_trunc(
                    part, snowpark_fn.to_timestamp(snowpark_args[0])
                ),
                DateType(),
            )
        case "try_add":
            match (snowpark_typed_args[0].typ, snowpark_typed_args[1].typ):
                case (_IntegralType(), _IntegralType()):
                    # For integer addition, overflow errors by default in Snowflake. We need it to return null.
                    result_exp = (
                        snowpark_fn.when(
                            (snowpark_args[0] > 0)
                            & (snowpark_args[1] > 0)
                            & (
                                snowpark_args[0]
                                > snowpark_fn.lit(9223372036854775807)
                                - snowpark_args[1]
                            ),
                            snowpark_fn.lit(None),  # Overflow
                        )
                        .when(
                            (snowpark_args[0] < 0)
                            & (snowpark_args[1] < 0)
                            & (
                                snowpark_args[0]
                                < snowpark_fn.lit(-9223372036854775808)
                                - snowpark_args[1]
                            ),
                            snowpark_fn.lit(None),  # Underflow
                        )
                        .otherwise(snowpark_args[0] + snowpark_args[1])
                    )

                # If either of the inputs is floating point, we can just let it go through to Snowflake, where overflow
                # matches Spark and goes to inf.
                # Note that we already handle the int,int case above, hence it is okay to use the broader _numeric
                # below.
                case (_NumericType(), _NumericType()):
                    result_exp = snowpark_args[0] + snowpark_args[1]

                # String cases - try to convert to numeric
                case (StringType(), _NumericType()) | (_NumericType(), StringType()) | (
                    StringType(),
                    StringType(),
                ):
                    # Its ok to use _validate_numeric_args here because we already know it will not throw because we
                    # are only dealing with string and numeric.
                    updated_args = _validate_numeric_args(
                        "try_add", snowpark_typed_args, snowpark_args
                    )
                    result_exp = updated_args[0] + updated_args[1]

                case (BooleanType(), _) | (_, BooleanType()):
                    raise AnalysisException(
                        f"Incompatible types: {snowpark_typed_args[0].typ}, {snowpark_typed_args[1].typ}"
                    )

                case _:
                    # Return NULL for incompatible types
                    result_exp = snowpark_fn.lit(None)
        case "try_aes_decrypt":
            result_exp = _aes_helper(
                "TRY_DECRYPT",
                snowpark_args[0],
                snowpark_args[1],
                snowpark_args[4],
                snowpark_args[2],
                snowpark_args[3],
            )
        case "try_to_number":
            result_exp = snowpark_fn.function("try_to_number")(
                snowpark_args[0], snowpark_args[1]
            )
        case "unbase64":
            base64_decoding_function = snowpark_fn.function("TRY_BASE64_DECODE_BINARY")

            # Compensate for the missing padding and remove spaces, as Spark does. Snowflake would produce a NULL value.
            value = snowpark_fn.replace(snowpark_args[0], " ", "")

            length_mod_4 = snowpark_fn.length(value) % 4

            result_exp = snowpark_fn.when(
                length_mod_4 == 0, base64_decoding_function(value)
            ).otherwise(
                base64_decoding_function(
                    snowpark_fn.concat(
                        value,
                        snowpark_fn.repeat(snowpark_fn.lit("="), 4 - length_mod_4),
                    )
                )
            )
        case "unhex":
            unhex_function = snowpark_fn.function("TRY_HEX_DECODE_BINARY")
            result_exp = unhex_function(snowpark_args[0])
        case "unix_micros":
            result_exp = snowpark_fn.date_part(
                "epoch_microseconds",
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
            )
        case "unix_millis":
            result_exp = snowpark_fn.date_part(
                "epoch_milliseconds",
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
            )
        case "unix_seconds":
            result_exp = snowpark_fn.date_part(
                "epoch_seconds",
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
            )
        case "unix_timestamp":
            # unix_timestamp in PySpark has an optional timestamp and optional format string.
            # In Snowpark, the timestamp is not optional.
            # It is observed that the server receives the optional format string if the timestamp is specified,
            # In case of unix_timestamp function in SQL it's possible only one argument.
            # so there are either 0, 1 or 2 arguments.
            match exp.unresolved_function.arguments:
                case []:
                    spark_function_name = (
                        "unix_timestamp(current_timestamp(), yyyy-MM-dd HH:mm:ss)"
                    )
                    result_exp = snowpark_fn.unix_timestamp(_handle_current_timestamp())
                case [_, _] if type(snowpark_typed_args[0].typ) in (
                    DateType,
                    TimestampType,
                ):
                    result_exp = snowpark_fn.unix_timestamp(snowpark_args[0])
                case [_, unresolved_format]:
                    snowpark_timestamp = snowpark_args[0]
                    result_exp = snowpark_fn.unix_timestamp(
                        snowpark_timestamp,
                        snowpark_fn.lit(
                            map_spark_timestamp_format_expression(unresolved_format)
                        ),
                    )
                case [_]:
                    result_exp = snowpark_fn.unix_timestamp(
                        snowpark_args[0], "yyyy-MM-dd HH:mm:ss"
                    )
                case _:
                    raise SnowparkConnectNotImplementedError(
                        "unix_timestamp expected 0, 1 or 2 arguments."
                    )
        case "upper" | "ucase":
            result_exp = snowpark_fn.upper(snowpark_args[0])
        case "url_decode":

            @snowpark_fn.udf
            def _url_decode(encoded_url: Optional[str]) -> Optional[str]:
                if encoded_url is None:
                    return None
                try:
                    # Handle both + and %20 encoding for spaces
                    return unquote(encoded_url.replace("+", " "))
                except Exception:
                    return None

            result_exp = _url_decode(snowpark_args[0])
        case "url_encode":

            @snowpark_fn.udf
            def _url_encode(url: Optional[str]) -> Optional[str]:
                if url is None:
                    return None
                try:
                    # some tweaks to make it compatible with Spark (and with java.net.URLEncoder)
                    encoded = quote(url, safe="*~")
                    return encoded.replace("~", "%7E").replace("%20", "+")
                except Exception:
                    return None

            result_exp = _url_encode(snowpark_args[0])
        case "var_pop":
            result_exp = snowpark_fn.var_pop(snowpark_args[0])
        case "var_samp" | "variance":
            result_exp = snowpark_fn.var_samp(snowpark_args[0])
        case "version":
            result_exp = snowpark_fn.lit(get_spark_version())
        case "weekday":
            result_exp = snowpark_fn.dayofweek(snowpark_args[0])
        case "weekofyear":
            result_exp = snowpark_fn.weekofyear(snowpark_fn.to_date(snowpark_args[0]))
        case "when":
            name_components = ["CASE"]
            name_components.append("WHEN")
            name_components.append(snowpark_arg_names[0])
            name_components.append("THEN")
            name_components.append(snowpark_arg_names[1])
            result_exp = snowpark_fn.when(snowpark_args[0], snowpark_args[1])
            for i in range(2, len(snowpark_args), 2):
                if i + 1 >= len(snowpark_args):
                    name_components.append("ELSE")
                    name_components.append(snowpark_arg_names[i])
                    result_exp = result_exp.otherwise(snowpark_args[i])
                else:
                    name_components.append("WHEN")
                    name_components.append(snowpark_arg_names[i])
                    name_components.append("THEN")
                    name_components.append(snowpark_arg_names[i + 1])
                    result_exp = result_exp.when(snowpark_args[i], snowpark_args[i + 1])
            name_components.append("END")
            spark_function_name = " ".join(name_components)
        case "window":
            (window_duration, start_time) = _extract_window_args(exp)
            spark_function_name = "window"
            result_exp = snowpark_fn.window(
                snowpark_args[0], window_duration, start_time=start_time
            )
        case "xpath":

            @snowpark_fn.udf(packages=["lxml"])
            def _xpath(xml: Optional[str], xpath: Optional[str]) -> Optional[list[str]]:
                if xml is None or xpath is None:
                    return None
                root = etree.fromstring(xml)
                return [
                    None if isinstance(result, etree._Element) else str(result)
                    for result in root.xpath(xpath)
                ]

            result_exp = _xpath(snowpark_args[0], snowpark_args[1])
        case "xpath_boolean":

            @snowpark_fn.udf(packages=["lxml"])
            def _xpath_boolean(
                xml: Optional[str], xpath: Optional[str]
            ) -> Optional[bool]:
                if xml is None or xpath is None:
                    return None
                root = etree.fromstring(xml)
                return bool(root.xpath(xpath))

            result_exp = _xpath_boolean(snowpark_args[0], snowpark_args[1])
        case "xpath_double" | "xpath_float" | "xpath_number":

            @snowpark_fn.udf(packages=["lxml"])
            def _xpath_double(
                xml: Optional[str], xpath: Optional[str]
            ) -> Optional[float]:
                if xml is None or xpath is None:
                    return None

                root = etree.fromstring(xml)
                result = root.xpath(f"number({xpath})")
                return float(result) if not math.isnan(result) else float("nan")

            result_exp = _xpath_double(snowpark_args[0], snowpark_args[1])
        case "xpath_int" | "xpath_long" | "xpath_short":

            @snowpark_fn.udf(packages=["lxml"])
            def _xpath_int(xml: Optional[str], xpath: Optional[str]) -> Optional[int]:
                if xml is None or xpath is None:
                    return None
                root = etree.fromstring(xml)
                result = root.xpath(f"number({xpath})")
                return int(result) if not math.isnan(result) else 0

            result_exp = _xpath_int(snowpark_args[0], snowpark_args[1])
        case "xpath_string":

            @snowpark_fn.udf(packages=["lxml"])
            def _xpath_string(
                xml: Optional[str], xpath: Optional[str]
            ) -> Optional[str]:
                if xml is None or xpath is None:
                    return None
                root = etree.fromstring(xml)
                result = root.xpath(f"string({xpath})")
                return str(result) if result else ""

            result_exp = _xpath_string(snowpark_args[0], snowpark_args[1])
        case "xxhash64":
            xxhash_udf_imports = [
                (
                    str(pathlib.Path(__file__).parent.parent / "utils" / "xxhash64.py"),
                    "snowflake.snowpark_connect.utils.xxhash64",
                )
            ]

            xxhash_udf = partial(
                snowpark_fn.udf, return_type=LongType(), imports=xxhash_udf_imports
            )

            result_exp = snowpark_fn.lit(DEFAULT_SEED)

            for arg in snowpark_typed_args:
                match arg.typ:
                    case IntegerType() | ShortType() | ByteType() | BooleanType():
                        xxhash64_udf_int = xxhash_udf(
                            xxhash64_int, input_types=[IntegerType(), LongType()]
                        )

                        result_exp = xxhash64_udf_int(
                            snowpark_fn.cast(arg.col, IntegerType()), result_exp
                        )
                    case FloatType():
                        xxhash64_udf_float = xxhash_udf(
                            xxhash64_float, input_types=[FloatType(), LongType()]
                        )

                        result_exp = xxhash64_udf_float(arg.col, result_exp)
                    case DoubleType():
                        xxhash64_udf_double = xxhash_udf(
                            xxhash64_double, input_types=[DoubleType(), LongType()]
                        )

                        result_exp = xxhash64_udf_double(arg.col, result_exp)
                    case LongType():
                        xxhash64_udf_long = xxhash_udf(
                            xxhash64_long, input_types=[LongType(), LongType()]
                        )

                        result_exp = xxhash64_udf_long(arg.col, result_exp)
                    case _:
                        xxhash64_udf_str = xxhash_udf(
                            xxhash64_string, input_types=[StringType(), LongType()]
                        )

                        result_exp = xxhash64_udf_str(
                            snowpark_fn.cast(arg.col, StringType()), result_exp
                        )
        case "year":
            result_exp = snowpark_fn.year(snowpark_fn.to_date(snowpark_args[0]))
        case binary_method if binary_method in ("to_binary", "try_to_binary"):
            binary_format = "hex"
            if len(snowpark_args) > 1:
                binary_format = snowpark_args[1]
            result_exp = snowpark_fn.function(binary_method)(
                snowpark_args[0], binary_format
            )
        case udf_name if udf_name.lower() in session._udfs:
            # TODO: In Spark, UDFs can override built-in functions in SQL,
            # but not in DataFrame ops.
            result_exp = session._udfs[udf_name.lower()](
                *(snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args)
            )
        case udtf_name if udtf_name.lower() in session._udtfs:
            udtf, spark_col_names = session._udtfs[udtf_name.lower()]
            result_exp = udtf(
                *(snowpark_fn.cast(arg, VariantType()) for arg in snowpark_args)
            )
        case other:
            # TODO: Add more here as we come across them.
            # Unfortunately the scope of function names are not documented in
            # the proto file.
            raise SnowparkConnectNotImplementedError(
                f"Unsupported function name {other}"
            )

    def _to_typed_column(res: Column | TypedColumn) -> TypedColumn:
        if isinstance(res, TypedColumn):
            return res
        return TypedColumn(res, lambda: typer.type(result_exp))

    spark_col_names = (
        spark_col_names if len(spark_col_names) > 0 else [spark_function_name]
    )
    return spark_col_names, _to_typed_column(result_exp)


def _extract_window_args(fn: expressions_proto.Expression) -> (str, str):
    args = fn.unresolved_function.arguments
    match args:
        case [_, _, _]:
            raise SnowparkConnectNotImplementedError(
                "the slide_duration parameter is not supported"
            )
        case [_, window_duration, slide_duration, _] if unwrap_literal(
            window_duration
        ) != unwrap_literal(slide_duration):
            raise SnowparkConnectNotImplementedError(
                "the slide_duration parameter is not supported"
            )
        case [_, window_duration, _, start_time]:
            return unwrap_literal(window_duration), unwrap_literal(start_time)
        case [_, window_duration]:
            return unwrap_literal(window_duration), None


def _handle_current_timestamp():
    result_exp = snowpark_fn.cast(
        snowpark_fn.current_timestamp(),
        # TODO: fix tz_convert 2 position arguments bug
        # get_timestamp_type(),
        TimestampType(TimestampTimeZone.NTZ),
    )
    return result_exp


def _find_common_type(types: list[DataType]) -> DataType | None:
    numeric_priority = {
        DecimalType: 5,
        DoubleType: 4,
        FloatType: 3,
        LongType: 2,
        IntegerType: 1,
    }
    time_priority = {
        TimestampType: 2,
        DateType: 1,
    }
    castable_to_string = [_NumericType, DateType, TimestampType, StringType]

    def _common(type1, type2):
        match (type1, type2):
            case (None, t) | (t, None):
                return t
            case (NullType(), t) | (t, NullType()):
                return t
            case (StringType(), t) | (t, StringType()) if any(
                isinstance(t, castable) for castable in castable_to_string
            ):
                return StringType()
            case (BooleanType(), BooleanType()):
                return BooleanType()
            case (_, _) if isinstance(type1, _NumericType) and isinstance(
                type2, _NumericType
            ):
                return max([type1, type2], key=lambda tp: numeric_priority[type(tp)])
            case (_, _) if isinstance(
                type1, tuple(time_priority.keys())
            ) and isinstance(type2, tuple(time_priority.keys())):
                return max([type1, type2], key=lambda tp: time_priority[type(tp)])
            case (ArrayType(), ArrayType()):
                typ = _common(type1.element_type, type2.element_type)
                return ArrayType(typ)
            case (StructType(), StructType()):
                fields1 = type1.fields
                fields2 = type2.fields
                if [field.name for field in fields1] != [
                    field.name for field in fields2
                ]:
                    raise TypeError(
                        f"Incompatible types (struct fields do not match): {type1}, {type2}"
                    )
                fields = []
                for idx, field in enumerate(fields1):
                    typ = _common(field.datatype, fields2[idx].datatype)
                    fields.append(StructField(field.name, typ))
                return StructType(fields)
            case (MapType(), MapType()):
                key_type = _common(type1.key_type, type2.key_type)
                value_type = _common(type1.value_type, type2.value_type)
                return MapType(key_type, value_type)
            case _:
                raise TypeError(f"Incompatible types: {type1}, {type2}")

    types = list(filter(lambda tp: tp is not None, types))
    if not types:
        return None

    return reduce(_common, types)


def _resolve_function_with_lambda(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    from snowflake.snowpark import Session
    from snowflake.snowpark_connect.expression.map_expression import map_expression

    def _resolve_lambda(
        lambda_exp, arg_types: list[DateType], resolve_only_body: bool = False
    ) -> tuple[list[str], TypedColumn]:
        names = [a.name_parts[0] for a in lambda_exp.lambda_function.arguments]
        schema = StructType(
            [StructField(name, typ) for name, typ in zip(names, arg_types)]
        )
        artificial_df = Session.get_active_session().create_dataframe([], schema)

        return map_expression(
            lambda_exp.lambda_function.function if resolve_only_body else lambda_exp,
            column_mapping,
            ExpressionTyper(artificial_df),
        )

    def _get_arr_el_type(tc: TypedColumn):
        match tc.typ:
            case ArrayType() if tc.typ.structured:
                return tc.typ.element_type
            case ArrayType():
                return VariantType()
            case t:
                raise ValueError(f"Expected array, got {t}")

    first_arg = exp.unresolved_function.arguments[0]
    ([arg1_name], arg1_tc) = map_expression(first_arg, column_mapping, typer)
    function_name = exp.unresolved_function.function_name
    match function_name:
        case "aggregate" | "reduce":
            match exp.unresolved_function.arguments:
                case [_, init_exp, lambda_exp]:
                    arr_typ = _get_arr_el_type(arg1_tc)
                    ([arg2_name], arg2_tc) = map_expression(
                        init_exp, column_mapping, typer
                    )
                    ([arg3_name], arg3_tc) = _resolve_lambda(
                        lambda_exp, [arg2_tc.typ, arr_typ]
                    )
                    result_exp = snowpark_fn.function("reduce")(
                        arg1_tc.col, arg2_tc.col, arg3_tc.col
                    )
                case _:
                    raise SnowparkConnectNotImplementedError(
                        f"{function_name} function with 'finish' argument is not supported"
                    )
            # looks like 4th argument is identity function in native Spark
            snowpark_arg_names = [
                arg1_name,
                arg2_name,
                arg3_name,
                "lambdafunction(namedlambdavariable(), namedlambdavariable())",
            ]
            # For `reduce` native Spark underneath calls aggregate builtin function, and it leaks in column name
            function_name = "aggregate"
        case "exists":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_typ])
            result_exp = snowpark_fn.function("transform")(arg1_tc.col, arg2_tc.col)
            result_exp = snowpark_fn.function("reduce")(
                result_exp,
                snowpark_fn.lit(False),
                snowpark_fn.sql_expr("(acc, i) -> acc or i"),
            )
            snowpark_arg_names = [arg1_name, arg2_name]
        case "filter":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_typ])

            snowpark_arg_names = [arg1_name, arg2_name]
            result_exp = snowpark_fn.function("filter")(arg1_tc.col, arg2_tc.col)
        case "forall":
            lambda_exp = exp.unresolved_function.arguments[1]
            arr_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_typ])
            result_exp = snowpark_fn.function("transform")(arg1_tc.col, arg2_tc.col)
            result_exp = snowpark_fn.function("reduce")(
                result_exp,
                snowpark_fn.lit(True),
                snowpark_fn.sql_expr("(acc, i) -> acc and i"),
            )
            snowpark_arg_names = [arg1_name, arg2_name]
        case "transform":
            lambda_exp = exp.unresolved_function.arguments[1]
            lambda_args_count = len(lambda_exp.lambda_function.arguments)
            if lambda_args_count == 2:
                # todo: extend api in Snowflake SQL to support binary transformation functions
                raise SnowparkConnectNotImplementedError(
                    "Binary transformation functions are not supported"
                )
            arr_typ = _get_arr_el_type(arg1_tc)
            ([arg2_name], arg2_tc) = _resolve_lambda(lambda_exp, [arr_typ])
            snowpark_arg_names = [arg1_name, arg2_name]
            result_exp = snowpark_fn.function("transform")(arg1_tc.col, arg2_tc.col)

        case "zip_with":
            """
            This impl is a workaround since Snowflake SQL lacks native support of `zip_with`:
             - Use `arrays_zip` to combine two input arrays into a single array of structs with fields $1 and $2
             - Resolve only the body of the lambda function from the 3rd argument (which is a standard `unresolved_function` expression)
             - Convert a resolved expression into raw SQL using the analyzer (this SQL references original lambda args)
             - Replace lambda arg references in SQL with get(x,'$1') and get(x,'$2') accessors
             - Construct a new lambda 'x -> modified_sql'
             - Apply `transform` function to transform the zipped array using that lambda
            """
            arr2 = exp.unresolved_function.arguments[1]
            ([arg2_name], arg2_tc) = map_expression(arr2, column_mapping, typer)

            zip_exp = snowpark_fn.arrays_zip(arg1_tc.col, arg2_tc.col)
            lambda_exp = exp.unresolved_function.arguments[2]

            ([lambda_body_name], fn_body) = _resolve_lambda(
                lambda_exp,
                [arg1_tc.typ.element_type, arg2_tc.typ.element_type],
                resolve_only_body=True,
            )

            l_arg1 = lambda_exp.lambda_function.arguments[0].name_parts[0]
            l_arg2 = lambda_exp.lambda_function.arguments[1].name_parts[0]

            analyzer = Session.get_active_session()._analyzer
            fn_sql = analyzer.analyze(fn_body.col._expression, defaultdict())
            transform_sql = fn_sql.replace(
                f'"{l_arg1.upper()}"', "get(x, '$1')"
            ).replace(f'"{l_arg2.upper()}"', "get(x, '$2')")
            transform_exp = snowpark_fn.sql_expr(f"x -> {transform_sql}")
            snowpark_arg_names = [
                arg1_name,
                arg2_name,
                f"lambdafunction({lambda_body_name}, namedlambdavariable(), namedlambdavariable())",
            ]
            result_exp = snowpark_fn.function("transform")(zip_exp, transform_exp)

        case other:
            # TODO: Add more here as we come across them.
            raise SnowparkConnectNotImplementedError(
                f"Unsupported function name {other}"
            )

    spark_function_name = f"{function_name}({', '.join(snowpark_arg_names)})"
    return [spark_function_name], TypedColumn(
        result_exp, lambda: typer.type(result_exp)
    )


def _resolve_first_value(exp, snowpark_args):
    """
    Utility method to perform first function.
    """
    args = exp.unresolved_function.arguments
    ignore_nulls = unwrap_literal(args[1]) if len(args) > 1 else False
    return snowpark_fn.first_value(snowpark_args[0], ignore_nulls)


def _resolve_last_value(exp, snowpark_args):
    """
    Utility method to perform last function.
    """
    args = exp.unresolved_function.arguments
    ignore_nulls = unwrap_literal(args[1]) if len(args) > 1 else False
    return snowpark_fn.last_value(snowpark_args[0], ignore_nulls)


def _aes_helper(function_name, value, passphrase, aad, encryption_method, padding):
    """
    Utility method to perform AES encryption and decryption.
    """
    aes_function = snowpark_fn.function(function_name)
    return aes_function(
        value,
        passphrase,
        snowpark_fn.when(
            (encryption_method == snowpark_fn.lit("DEFAULT"))
            | (snowpark_fn.lower(encryption_method) == snowpark_fn.lit("gcm")),
            aad,
        ),
        snowpark_fn.concat(
            snowpark_fn.lit("AES-"),
            snowpark_fn.when(
                encryption_method == snowpark_fn.lit("DEFAULT"), "GCM"
            ).otherwise(encryption_method),
            snowpark_fn.when(
                padding == snowpark_fn.lit("DEFAULT"),
                snowpark_fn.lit(None),
            ).otherwise(snowpark_fn.concat(snowpark_fn.lit("/pad:"), padding)),
        ),
    )
