import inspect
from types import ModuleType
from typing import Callable

import pyspark.sql.connect.proto.commands_pb2 as commands_proto
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from pyspark.serializers import CloudPickleSerializer

from snowflake import snowpark
from snowflake.snowpark.types import VariantType
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import proto_to_snowpark_type
from snowflake.snowpark_connect.typed_column import TypedColumn


def infer_udf_dependencies(func: Callable) -> dict[str, ModuleType]:
    """Try to infer required packages. Doesn't guarantee 100% correctness."""

    func_code = func.__code__
    # names in the global scope
    global_names = func.__globals__
    # names accessed in func (potential module references)
    code_names = func_code.co_names

    return [
        global_names[name]
        for name in code_names
        if name in global_names
        and isinstance(global_names[name], ModuleType)
        and (
            global_names[name].__file__
            and "site-packages" in global_names[name].__file__
        )
    ]


def register_udf(udf_proto: commands_proto) -> snowpark.udf.UserDefinedFunction:
    match udf_proto.WhichOneof("function"):
        case "python_udf":
            udf = udf_proto.python_udf
            callable_func, pyspark_output_type = CloudPickleSerializer().loads(
                udf.command
            )
            # If any of the parameters don't have type hint, we use Snowflake Variant type.
            func_signature = inspect.signature(callable_func)
            input_types = [VariantType()] * len(func_signature.parameters)

            modules = infer_udf_dependencies(callable_func)
            packages = [module.__name__ for module in modules]
            snowpark_type = proto_to_snowpark_type(udf.output_type)
            session = snowpark.Session.builder.getOrCreate()

            udf = session.udf.register(
                func=callable_func,
                return_type=snowpark_type,
                input_types=input_types,
                replace=True,
                packages=packages,
            )
            session._udfs[udf_proto.function_name.lower()] = udf
            return udf
        case _:
            raise ValueError(f"Not python udf {udf_proto.function}")


def map_common_inline_user_defined_udf(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    from snowflake.snowpark_connect.expression.map_expression import (
        map_single_column_expression,
    )

    exp_udf = exp.common_inline_user_defined_function
    match exp_udf.WhichOneof("function"):
        case "python_udf":
            udf = exp_udf.python_udf
            (
                callable_func,
                pyspark_output_type,
            ) = CloudPickleSerializer().loads(udf.command)

            modules = infer_udf_dependencies(callable_func)
            packages = [module.__name__ for module in modules]

            # TODO: client provided python version in python_udf.python_ver, which helps to know what
            #  CloudPickleSerializer to use? In the future, we probably don't want to unpack and pack func in sas layer,
            #  which requires modifying Snowpark.
            snowpark_udf_args = []
            snowpark_udf_arg_names = []
            for arg_exp in exp_udf.arguments:
                snowpark_udf_arg_name, snowpark_udf_arg = map_single_column_expression(
                    arg_exp, column_mapping, typer
                )
                snowpark_udf_arg = snowpark_udf_arg.col
                snowpark_udf_args.append(snowpark_udf_arg)
                snowpark_udf_arg_names.append(snowpark_udf_arg_name)

            input_types = []
            for udf_arg in snowpark_udf_args:
                input_types.extend(typer.type(udf_arg))

            # TODO: if inferred packages is incorrect, how to make session level packages a fallback?
            # Both udf and pandas_udf can use the same snowpark.udf api.
            snowpark_type = proto_to_snowpark_type(udf.output_type)
            snowpark_udf = snowpark.functions.udf(
                func=callable_func,
                return_type=snowpark_type,
                input_types=input_types,
                replace=True,
                packages=packages,
            )

            return (
                f"{exp_udf.function_name}({', '.join(snowpark_udf_arg_names)})",
                TypedColumn(snowpark_udf(*snowpark_udf_args), lambda: [snowpark_type]),
            )
        case _:
            raise ValueError(
                f"Not python udf {exp.common_inline_user_defined_function.function}"
            )
