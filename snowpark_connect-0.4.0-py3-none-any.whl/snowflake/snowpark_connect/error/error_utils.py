"""
Spark error references:
https://github.com/apache/spark/blob/master/docs/sql-error-conditions.md
https://github.com/apache/spark/tree/master/sql/catalyst/src/main/scala/org/apache/spark/sql/errors
https://github.com/apache/spark/blob/master/common/utils/src/main/resources/error/error-conditions.json
"""

import json
import pathlib
import traceback

from google.protobuf import any_pb2
from google.rpc import code_pb2, error_details_pb2, status_pb2
from pyspark.errors.error_classes import ERROR_CLASSES_MAP
from pyspark.errors.exceptions.base import (
    AnalysisException,
    IllegalArgumentException,
    ParseException,
    PySparkException,
)

from snowflake.snowpark.exceptions import SnowparkClientException, SnowparkSQLException
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.error.error_mapping import ERROR_MAPPINGS_JSON

# The JSON string in error_mapping.py is a copy of https://github.com/apache/spark/blob/master/common/utils/src/main/resources/error/error-conditions.json.
# The file doesn't have to be synced with spark latest main. Just update it when required.
current_dir = pathlib.Path(__file__).parent.resolve()
ERROR_CLASSES_MAP.update(json.loads(ERROR_MAPPINGS_JSON))

SPARK_PYTHON_TO_JAVA_EXCEPTION = {
    AnalysisException: "org.apache.spark.sql.AnalysisException",
    ParseException: "org.apache.spark.sql.catalyst.parser.ParseException",
    IllegalArgumentException: "java.lang.IllegalArgumentException",
}


def build_grpc_error_response(ex: Exception) -> status_pb2.Status:
    include_stack_trace = (
        global_config.get("spark.sql.pyspark.jvmStacktrace.enabled")
        if hasattr(global_config, "spark.sql.pyspark.jvmStacktrace.enabled")
        else False
    )

    if isinstance(ex, SnowparkClientException):
        # exceptions thrown from snowpark
        spark_java_classes = []
        match ex:
            case SnowparkSQLException():
                if ex.sql_error_code == 100357:
                    # UDF returned an error
                    spark_java_classes.append("org.apache.spark.SparkRuntimeException")
                elif ex.sql_error_code in (904, 1039, 1044):
                    # Data type mismatch
                    spark_java_classes.append("org.apache.spark.sql.AnalysisException")
                else:
                    # not all SnowparkSQLException correspond to QueryExecutionException. E.g., table or view not found is
                    # AnalysisException. We can gradually build a mapping if we want. The first naive version just maps
                    # to QueryExecutionException.
                    spark_java_classes.append(
                        "org.apache.spark.sql.execution.QueryExecutionException"
                    )
            case SnowparkClientException():
                # catch all
                pass

        metadata = {"classes": json.dumps(spark_java_classes)}
        if include_stack_trace:
            metadata["stackTrace"] = "".join(
                traceback.TracebackException.from_exception(ex).format()
            )
        error_info = error_details_pb2.ErrorInfo(
            reason=ex.__class__.__name__,
            domain="snowflake.snowpark",
            metadata=metadata,
        )
    elif isinstance(ex, PySparkException):
        # pyspark exceptions thrown in sas layer
        classes = type(ex).__mro__
        spark_java_classes = [
            SPARK_PYTHON_TO_JAVA_EXCEPTION[clazz]
            for clazz in classes
            if clazz in SPARK_PYTHON_TO_JAVA_EXCEPTION
        ]
        metadata = {"classes": json.dumps(spark_java_classes)}
        if include_stack_trace:
            metadata["stackTrace"] = "".join(
                traceback.TracebackException.from_exception(ex).format()
            )

        error_info = error_details_pb2.ErrorInfo(
            reason=ex.__class__.__name__,
            domain="org.apache.spark",
            metadata=metadata,
        )
    else:
        # unexpected exception types
        error_info = error_details_pb2.ErrorInfo(
            reason=ex.__class__.__name__,
            domain="snowflake.sas",
        )

    detail = any_pb2.Any()
    detail.Pack(error_info)

    rich_status = status_pb2.Status(
        code=code_pb2.INTERNAL, message=str(ex), details=[detail]
    )
    return rich_status


class SparkException:
    """
    This class is used to mock exceptions created by PySpark / Spark backend in SAS layer.
    """

    @staticmethod
    def unpivot_requires_value_columns():
        return AnalysisException(
            error_class="UNPIVOT_REQUIRES_VALUE_COLUMNS", message_parameters={}
        )

    @staticmethod
    def unpivot_value_data_type_mismatch(types: str):
        return AnalysisException(
            error_class="UNPIVOT_VALUE_DATA_TYPE_MISMATCH",
            message_parameters={"types": types},
        )

    @staticmethod
    def implicit_cartesian_product(join_type: str):
        return AnalysisException(
            error_class="_LEGACY_ERROR_TEMP_1211",
            message_parameters={"joinType": join_type, "leftPlan": "leftPlan"},
        )
