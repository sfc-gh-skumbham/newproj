import cloudpickle as pkl
import pyspark.sql.connect.proto.relations_pb2 as relation_proto

import snowflake.snowpark.functions as snowpark_fn
import snowflake.snowpark.types as snowpark_types
import snowflake.snowpark_connect.proto.snowflake_rdd_pb2 as snowflake_proto
from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.map_relation import map_relation


def map_extension(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    The Extension relation type contains any extensions we use for adding new
    functionality to Spark Connect.

    The extension will require new protobuf messages to be defined in the
    snowflake_connect_server/proto directory.

    Currently, this is used for an RDD proof of concept.
    """
    rdd = snowflake_proto.Rdd()
    rel.extension.Unpack(rdd)
    input_df: snowpark.DataFrame = map_relation(rdd.map.input)

    column_name = "_RDD_"
    if len(input_df.columns) > 1:
        input_df = input_df.select(
            snowpark_fn.array_construct(*input_df.columns).as_(column_name)
        )
        input_type = snowpark_types.ArrayType(snowpark_types.IntegerType())
        return_type = snowpark_types.ArrayType(snowpark_types.IntegerType())
    else:
        input_df = input_df.rename(input_df.columns[0], column_name)
        input_type = snowpark_types.VariantType()
        return_type = snowpark_types.VariantType()
    func = snowpark_fn.udf(
        pkl.loads(rdd.map.func),
        return_type=return_type,
        input_types=[input_type],
        name="my_udf",
        replace=True,
    )
    result = input_df.select(func(column_name).as_(column_name))
    return build_column_map(result, [column_name], [column_name])
