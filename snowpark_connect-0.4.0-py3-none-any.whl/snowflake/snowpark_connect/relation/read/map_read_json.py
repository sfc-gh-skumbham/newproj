import re

import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer import analyzer_utils
from snowflake.snowpark.functions import any_value, col, parse_json, strip_null_value
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.read.map_read import JsonReaderConfig
from snowflake.snowpark_connect.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def read_json_file(reader: snowpark.DataFrameReader, path: str) -> snowpark.DataFrame:
    contents = reader.json(path).rename({"$1": "raw_json"})
    parsed = contents.select(parse_json(contents["raw_json"]).as_("parsed_json"))
    flattened = parsed.join_table_function("flatten", parsed["parsed_json"]).select(
        ["SEQ", "KEY", strip_null_value("VALUE").alias("value")]
    )
    cols = [c[0] for c in flattened.group_by("key").agg(any_value("key")).collect()]
    cols_alias = [col(f"'{c}'").alias(f'"{c}"') for c in cols]
    df = flattened.pivot("key").min("value").order_by("SEQ").select(cols_alias)
    return df


def map_read_json(
    rel: relation_proto.Relation,
    schema: snowpark.types.StructType | None,
    session: snowpark.Session,
    paths: list[str],
    options: JsonReaderConfig,
) -> snowpark.DataFrame:
    """
    Read a JSON file into a Snowpark DataFrame.

    [JSON lines](http://jsonlines.org/) file format is supported.

    We leverage the stage that is already created in the map_read function that
    calls this.
    """

    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise SnowparkConnectNotImplementedError(
            "Streaming is not supported for JSON files."
        )
    else:
        snowpark_options = options.convert_to_snowpark_args()
        if schema is None:
            reader = session.read.options(snowpark_options)
        else:
            reader = session.read.options(snowpark_options).schema(schema)
        df = read_json_file(reader=reader, path=paths[0])
        if len(paths) > 1:
            # TODO: figure out if this is what Spark does.
            for p in paths[1:]:
                df = df.union_all(read_json_file(reader=reader, path=p))

        def subtract_one(match):
            """Spark column names are 0 indexed, Snowpark is 1 indexed."""
            return f"_c{str(int(match.group(2)) - 1)}"

        spark_column_names = [
            analyzer_utils.unquote_if_quoted(
                re.sub(r"(^\"c)(\d+)(\"$)", subtract_one, c)
            )
            for c in df.columns
        ]
        renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(
            df, rel.common.plan_id
        )
        return build_column_map(renamed_df, spark_column_names, snowpark_column_names)
