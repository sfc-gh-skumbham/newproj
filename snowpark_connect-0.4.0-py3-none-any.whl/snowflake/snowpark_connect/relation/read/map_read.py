import json
import os

import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark_connect.relation.io_utils import is_cloud_path
from snowflake.snowpark_connect.relation.read.map_read_table import map_read_table
from snowflake.snowpark_connect.relation.read.reader_config import (
    CsvReaderConfig,
    JsonReaderConfig,
    ReaderConfig,
)
from snowflake.snowpark_connect.relation.stage_locator import get_paths_from_stage
from snowflake.snowpark_connect.type_mapping import map_json_schema_to_snowpark
from snowflake.snowpark_connect.utils.cache import df_cache_map_put_if_absent
from snowflake.snowpark_connect.utils.context import get_session_id
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_read(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Read a file into a Snowpark DataFrame.

    Currently, the supported read formats are `csv`, `json` and `parquet`.
    """
    match rel.read.WhichOneof("read_type"):
        case "named_table":
            return map_read_table(rel)

        case "data_source":
            if rel.read.data_source.HasField("format"):
                format = rel.read.data_source.format
            else:
                # TODO: This should come from the config `spark.sql.sources.default`
                format = None

            if format is not None and format.lower() == "iceberg":
                return map_read_table(rel)

            if rel.read.data_source.schema == "":
                schema = None
            else:
                try:
                    parsed_schema = json.loads(rel.read.data_source.schema)
                except json.JSONDecodeError:
                    # It's a DDL-formatted string. e.g. "a INT, b DOUBLE"
                    parsed_schema = {"fields": [], "type": "struct"}
                    for field in rel.read.data_source.schema.split(","):
                        name_and_type = field.split()
                        assert (
                            len(name_and_type) == 2
                        ), f"Schema's definition {name_and_type} is invalid"
                        parsed_schema["fields"].append(
                            {
                                "name": name_and_type[0],
                                "nullable": True,
                                "type": name_and_type[1],
                            }
                        )
                schema = map_json_schema_to_snowpark(parsed_schema)
            options = dict(rel.read.data_source.options)
            session: snowpark.Session = snowpark.Session.builder.getOrCreate()
            if len(rel.read.data_source.paths) > 0:
                paths = get_paths_from_stage(
                    list(rel.read.data_source.paths),
                    session,
                )

                upload_files_if_needed(paths, list(rel.read.data_source.paths), session)

                match format:
                    case "csv":
                        from snowflake.snowpark_connect.relation.read.map_read_csv import (
                            map_read_csv,
                        )

                        result = map_read_csv(
                            rel, schema, session, paths, CsvReaderConfig(options)
                        )
                    case "json":
                        from snowflake.snowpark_connect.relation.read.map_read_json import (
                            map_read_json,
                        )

                        result = map_read_json(
                            rel, schema, session, paths, JsonReaderConfig(options)
                        )
                    case "parquet":
                        from snowflake.snowpark_connect.relation.read.map_read_parquet import (
                            map_read_parquet,
                        )

                        result = map_read_parquet(
                            rel, schema, session, paths, ReaderConfig(options)
                        )
                    case _:
                        raise SnowparkConnectNotImplementedError(
                            f"Unsupported format: {format}"
                        )
            else:
                match format:
                    case "socket":
                        from snowflake.snowpark_connect.relation.read.map_read_socket import (
                            map_read_socket,
                        )

                        return map_read_socket(rel, session, options)

                    case "jdbc":
                        from snowflake.snowpark_connect.relation.read.map_read_jdbc import (
                            map_read_jdbc,
                        )

                        return map_read_jdbc(rel, session, options)

                    case other:
                        raise SnowparkConnectNotImplementedError(
                            f"UNSUPPORTED FORMAT {other} WITH NO PATH"
                        )
        case other:
            # TODO: Empty data source
            raise SnowparkConnectNotImplementedError(f"Unsupported read type: {other}")

    return df_cache_map_put_if_absent(
        (get_session_id(), rel.common.plan_id), lambda: result, materialize=True
    )


def upload_files_if_needed(
    target_paths, source_paths, session: snowpark.Session
) -> None:
    n = len(source_paths)
    assert n == len(target_paths), "Source and target paths must have same length"
    for i in range(n):
        if is_cloud_path(source_paths[i]):
            continue

        # Upload local files
        # since local files are the source of truth
        # any existing files should be overwritten in the target prefix
        if os.path.isdir(source_paths[i]):
            # overwrite=True will not remove all stale files in the target prefix
            session.sql(f"REMOVE {target_paths[i]}/").collect()
            session.file.put(
                os.path.join(source_paths[i], "*"),
                f"{target_paths[i]}/",
                auto_compress=False,
            )
        else:
            session.file.put(
                source_paths[i], target_paths[i], auto_compress=False, overwrite=True
            )
