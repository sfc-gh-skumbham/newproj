import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)


def map_read_table(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Read a table into a Snowpark DataFrame.
    """
    session: snowpark.Session = snowpark.Session.builder.getOrCreate()

    if rel.read.HasField("named_table"):
        table_identifier = rel.read.named_table.unparsed_identifier
    elif (
        rel.read.data_source.HasField("format")
        and rel.read.data_source.format.lower() == "iceberg"
    ):
        table_identifier = rel.read.data_source.paths
    else:
        raise ValueError("The relation must have a table identifier.")

    df = session.read.table(table_identifier)
    true_names = list(map(lambda x: unquote_if_quoted(x).lower(), df.columns))
    renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(
        df, rel.common.plan_id
    )
    return build_column_map(renamed_df, true_names, snowpark_column_names)
