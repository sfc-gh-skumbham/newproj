import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from pyspark.errors.exceptions.base import IllegalArgumentException

import snowflake.snowpark_connect.relation.utils as utils
from snowflake import snowpark
from snowflake.snowpark_connect.expression.literal import get_literal_field_and_name
from snowflake.snowpark_connect.expression.map_expression import (
    map_single_column_expression,
)
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_deduplicate(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Deduplicate a DataFrame based on a Relation's deduplicate.

    The deduplicate is a list of columns that is applied to the DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.deduplicate.input)
    # TODO: Handle `within_watermark` field
    if (
        rel.deduplicate.HasField("all_columns_as_keys")
        and rel.deduplicate.all_columns_as_keys
    ):
        result: snowpark.DataFrame = input_df.drop_duplicates()
    else:
        result: snowpark.DataFrame = input_df.drop_duplicates(
            *input_df._column_map.get_snowpark_column_names_from_spark_column_names(
                list(rel.deduplicate.column_names)
            )
        )
    result._column_map = input_df._column_map
    return result


def map_dropna(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Drop NA values from the input DataFrame.


    """
    input_df: snowpark.DataFrame = map_relation(rel.drop_na.input)
    if rel.drop_na.HasField("min_non_nulls"):
        thresh = rel.drop_na.min_non_nulls
        how = "all"
    else:
        thresh = None
        how = "any"
    if len(rel.drop_na.cols) > 0:
        columns: list[str] = [
            # Use the mapping to get the Snowpark internal column name
            # TODO: Verify the behavior of duplicate column names with dropna
            input_df._column_map.get_snowpark_column_name_from_spark_column_name(c)
            for c in rel.drop_na.cols
        ]
        result: snowpark.DataFrame = input_df.dropna(
            how=how, subset=columns, thresh=thresh
        )
    else:
        result: snowpark.DataFrame = input_df.dropna(how=how, thresh=thresh)
    result._column_map = input_df._column_map
    return result


def map_fillna(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Fill NA values in the DataFrame.

    The `fill_value` is a scalar value that will be used to replace NaN values.
    """
    input_df: snowpark.DataFrame = map_relation(rel.fill_na.input)
    if len(rel.fill_na.cols) > 0:
        columns: list[str] = [
            input_df._column_map.get_snowpark_column_name_from_spark_column_name(c)
            for c in rel.fill_na.cols
        ]
        values = [get_literal_field_and_name(v)[0] for v in rel.fill_na.values]
        if len(values) == 1:
            # This happens when the client uses the `subset` parameter.
            values = values * len(columns)
        assert len(columns) == len(
            values
        ), "FILLNA: number of columns and values must match"
        result = input_df.fillna(dict(zip(columns, values)), include_decimal=True)
    else:
        assert len(rel.fill_na.values) == 1
        proto_value: expressions_proto.Expression.Literal = rel.fill_na.values[0]
        fill_value = get_literal_field_and_name(proto_value)[0]
        # Spark will cast floats to integers if the column is an integer type.
        # Snowpark doesn't, so we have to help it.
        if isinstance(fill_value, float):
            fill_value: dict[str, float | int] = {
                field.name: (
                    fill_value
                    if not isinstance(
                        field.datatype,
                        (snowpark.types.IntegerType, snowpark.types.LongType),
                    )
                    else int(fill_value)
                )
                for field in input_df.schema.fields
            }
        result = input_df.fillna(fill_value, include_decimal=True)
    result._column_map = input_df._column_map
    return result


def map_union(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Union two DataFrames together.

    The two DataFrames must have the same schema.
    """
    left_df: snowpark.DataFrame = map_relation(rel.set_op.left_input)
    right_df: snowpark.DataFrame = map_relation(rel.set_op.right_input)

    # Save the column names so that we can restore them after the union.
    left_df_columns = left_df.columns

    result: snowpark.DataFrame = None

    if rel.set_op.by_name:
        # To use unionByName, we need to have the same column names.
        # We rename the columns back to their originals using the map
        left_column_map = left_df._column_map
        right_column_map = right_df._column_map

        for column in right_df.columns:
            right_df = right_df.withColumnRenamed(
                column,
                right_column_map.get_spark_column_name_from_snowpark_column_name(
                    column
                ),
            )

        for column in left_df.columns:
            left_df = left_df.withColumnRenamed(
                column,
                left_column_map.get_spark_column_name_from_snowpark_column_name(column),
            )

        result = left_df.unionByName(right_df)

        for i in range(len(left_df_columns)):
            result = result.withColumnRenamed(result.columns[i], left_df_columns[i])

        result._column_map = left_column_map
    elif rel.set_op.is_all:
        result = left_df.unionAll(right_df)
        result._column_map = left_df._column_map
    else:
        result = left_df.union(right_df)
        result._column_map = left_df._column_map

    return result


def map_intersect(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Return a new DataFrame containing rows in both DataFrames:

    1. If set_op.is_all is True, this method is implementing ```intersectAll```
        while preserving duplicates.

    2. If set_op.is_all is False, this method is implementing ```intersect```
        while removing duplicates.

    Examples
    --------
    >>> df1 = spark.createDataFrame([("a", 1), ("a", 1), ("a", 1), ("a", 2), ("b",  3), ("c", 4)], ["C1", "C2"]))
    >>> df2 = spark.createDataFrame([("a", 1), ("a", 1), ("b", 3)], ["C1", "C2"])
    >>> df1.intersect(df2).show()

    +---+---+
    | C1| C2|
    +---+---+
    |  a|  1|
    |  b|  3|
    +---+---+

    >>> df1.intersectAll(df2).show()

    +---+---+
    | C1| C2|
    +---+---+
    |  a|  1|
    |  a|  1|
    |  b|  3|
    +---+---+
    """
    left_df: snowpark.DataFrame = map_relation(rel.set_op.left_input)
    right_df: snowpark.DataFrame = map_relation(rel.set_op.right_input)

    if rel.set_op.is_all:
        left_df_with_row_number = utils.get_df_with_partition_row_number(
            left_df, rel.set_op.left_input.common.plan_id, "left_row_number"
        )
        right_df_with_row_number = utils.get_df_with_partition_row_number(
            right_df, rel.set_op.right_input.common.plan_id, "right_row_number"
        )

        result: snowpark.DataFrame = left_df_with_row_number.intersect(
            right_df_with_row_number
        ).select(*left_df._column_map.get_snowpark_columns())
    else:
        result: snowpark.DataFrame = left_df.intersect(right_df)

    # the result df keeps the column map of the original left_df
    result._column_map = left_df._column_map
    return result


def map_except(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Return a new DataFrame containing rows in the left DataFrame but not in the right DataFrame.

    1. If set_op.is_all is True, this method is implementing ```exceptAll```
        while preserving duplicates.

    2. If set_op.is_all is False, this method is implementing ```subtract```
        while removing duplicates.

    Examples
    --------
    >>> df1 = spark.createDataFrame([("a", 1), ("a", 1), ("a", 1), ("a", 2), ("b",  3), ("c", 4)], ["C1", "C2"]))
    >>> df2 = spark.createDataFrame([("a", 1), ("a", 1), ("b", 3)], ["C1", "C2"])
    >>> df1.subtract(df2).show()

    +---+---+
    | C1| C2|
    +---+---+
    |  a|  2|
    |  c|  4|
    +---+---+

    >>> df1.exceptAll(df2).show()

    +---+---+
    | C1| C2|
    +---+---+
    |  a|  1|
    |  a|  1|
    |  a|  2|
    |  c|  4|
    +---+---+
    """
    left_df: snowpark.DataFrame = map_relation(rel.set_op.left_input)
    right_df: snowpark.DataFrame = map_relation(rel.set_op.right_input)

    if rel.set_op.is_all:
        # Snowflake except removes all duplicated rows. In order to handle the case,
        # we add a partition row number column to the df to make duplicated rows unique to
        # avoid the duplicated rows to be removed.
        # For example, with the following left_df and right_df
        # +---+---+                               +---+---+
        # | C1| C2|                               | C1| C2|
        # +---+---+                               +---+---+
        # |  a|  1|                               |  a|  1|
        # |  a|  1|                               |  a|  2|
        # |  a|  2|                               +---+---+
        # |  c|  4|
        # +---+---+
        # we will do
        # +---+---+------------+                    +---+---+------------+
        # | C1| C2| ROW_NUMBER |     EXCEPT         | C1| C2| ROW_NUMBER |
        # +---+---+------------+                    +---+---+------------+
        # |  a|  1|         0  |                    |  a|  1|         0  |
        # |  a|  1|         1  |                    |  a|  2|         0  |
        # |  a|  2|         0  |                    +---+---+------------+
        # |  c|  4|         0  |
        # +---+---+------------+
        # at the end we will do a select to exclude the row number column
        left_df_with_row_number = utils.get_df_with_partition_row_number(
            left_df, rel.set_op.left_input.common.plan_id, "left_row_number"
        )
        right_df_with_row_number = utils.get_df_with_partition_row_number(
            right_df, rel.set_op.right_input.common.plan_id, "right_row_number"
        )

        # Perform except use left_df_with_row_number and right_df_with_row_number,
        # and drop the row number column after except.
        result_df = left_df_with_row_number.except_(right_df_with_row_number).select(
            *left_df._column_map.get_snowpark_columns()
        )
    else:
        result_df = left_df.except_(right_df)

    # the result df keeps the column map of the original left_df
    result_df._column_map = left_df._column_map

    return result_df


def map_filter(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Filter a DataFrame based on a Relation's filter.

    The filter is a SQL expression that is applied to the DataFrame.
    """
    input_df = map_relation(rel.filter.input)
    typer = ExpressionTyper(input_df)
    _, condition = map_single_column_expression(
        rel.filter.condition, input_df._column_map, typer
    )
    result = input_df.filter(condition.col)
    result._column_map = input_df._column_map
    return result


def map_limit(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Limit a DataFrame based on a Relation's limit.

    The limit is an integer that is applied to the DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.limit.input)
    result: snowpark.DataFrame = input_df.limit(rel.limit.limit)
    result._column_map = input_df._column_map
    return result


def map_offset(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Offset a DataFrame based on a Relation's offset.

    The offset is an integer that is applied to the DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.offset.input)
    # TODO: This is a terrible way to have to do this, but Snowpark does not
    # support offset without limit.
    result: snowpark.DataFrame = input_df.limit(
        input_df.count(), offset=rel.offset.offset
    )
    result._column_map = input_df._column_map
    return result


def map_replace(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Replace values in the DataFrame.

    The `replace_map` is a dictionary of column names to a dictionary of
    values to replace. The values in the dictionary are the values to replace
    and the keys are the values to replace them with.
    """
    input_df: snowpark.DataFrame = map_relation(rel.replace.input)
    # note that seems like spark connect always send number values as double in rel.replace.replacements.
    to_replace = [
        get_literal_field_and_name(i.old_value)[0] for i in rel.replace.replacements
    ]
    values = [
        get_literal_field_and_name(i.new_value)[0] for i in rel.replace.replacements
    ]
    # Snowpark doesn't support replacing floats with integers, so we have to help it.
    # We are going to run replace twice, once for floats and once for integers.
    to_replace_stage_2 = [
        int(replace) if replace is not None else None
        for i, replace in enumerate(to_replace)
        if isinstance(replace, float) and int(replace) == replace
    ]
    # The values need to be prepared for running replace again.
    values_stage_2 = [
        int(value) if value is not None else None
        for i, value in enumerate(values)
        if isinstance(to_replace[i], float) and int(to_replace[i]) == to_replace[i]
    ]
    if len(rel.replace.cols) > 0:
        columns: list[str] = [
            # Use the mapping to get the Snowpark internal column name
            input_df._column_map.get_snowpark_column_name_from_spark_column_name(c)
            for c in rel.replace.cols
        ]
        result: snowpark.DataFrame = input_df.replace(
            to_replace,
            values,
            columns,
            include_decimal=True,
        ).replace(
            to_replace_stage_2,
            values_stage_2,
            columns,
            include_decimal=True,
        )
    else:
        result: snowpark.DataFrame = input_df.replace(
            to_replace, values, include_decimal=True
        ).replace(to_replace_stage_2, values_stage_2, include_decimal=True)
    result._column_map = input_df._column_map
    return result


def map_sample(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Sample a DataFrame based on a Relation's sample.
    """
    input_df: snowpark.DataFrame = map_relation(rel.sample.input)
    frac = rel.sample.upper_bound
    if frac < 0 or frac > 1:
        raise IllegalArgumentException("Sample fraction must be between 0 and 1")
    # The seed argument is not supported here. There are a number of reasons that implementing
    # this will be complicated in Snowflake. Here is a list of complications:
    #
    # 1. Spark Connect always provides a seed, even if the user has not provided one. This seed
    #    is a randomly generated number, so we cannot detect if the user has provided a seed or not.
    # 2. Snowflake only supports seed on tables, not on views.
    # 3. Snowpark almost always creates a new view in the form of nested queries for every query.
    #
    # Given these three issues, users would be required to write their own temporary tables prior
    # to sampling, which is not a good user experience and has significant performance implications.
    # For these reasons, we choose to ignore the seed argument until we have a plan for how to solve
    # these issues.
    if rel.sample.with_replacement:
        # TODO: Use a random number generator with ROW_NUMBER and SELECT.
        raise SnowparkConnectNotImplementedError(
            "Sample with replacement is not supported"
        )
    else:
        result: snowpark.DataFrame = input_df.sample(frac=frac)
        result._column_map = input_df._column_map
        return result


def map_tail(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Tail a DataFrame based on a Relation's tail.

    The tail is an integer that is applied to the DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.tail.input)
    num_rows = input_df.count()
    result: snowpark.DataFrame = input_df.limit(
        num_rows, offset=max(0, num_rows - rel.tail.limit)
    )
    result._column_map = input_df._column_map
    return result
