import re

import pandas
import pyspark.sql.connect.proto.catalog_pb2 as catalog_proto

from snowflake import snowpark
from snowflake.snowpark_connect.relation.catalogs.abstract_spark_catalog import (
    AbstractSparkCatalog,
)
from snowflake.snowpark_connect.relation.catalogs.snowflake_catalog import (
    SnowflakeCatalog,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)

SNOWFLAKE_CATALOG = SnowflakeCatalog()

CATALOGS = {SNOWFLAKE_CATALOG.metadata.name: SNOWFLAKE_CATALOG}

CURRENT_CATALOG = SNOWFLAKE_CATALOG


def get_current_catalog() -> AbstractSparkCatalog:
    return CURRENT_CATALOG


def set_current_catalog(catalog_name) -> None:
    if catalog_name in CATALOGS:
        return CATALOGS[catalog_name]

    raise Exception(
        f"Catalog '{catalog_name}' plugin class not found: spark.sql.catalog.{catalog_name} is not defined"
    )


def map_catalog(
    rel: catalog_proto.Catalog,
) -> pandas.DataFrame | snowpark.DataFrame:
    match rel.WhichOneof("cat_type"):
        # Database related APIs
        case "current_database":
            return get_current_catalog().currentDatabase()
        case "database_exists":
            return get_current_catalog().databaseExists(
                rel.database_exists.db_name,
            )
        case "get_database":
            return get_current_catalog().getDatabase(
                rel.get_database.db_name,
            )
        case "list_databases":
            return get_current_catalog().listDatabases(
                rel.list_databases.pattern,
            )
        case "set_current_database":
            return get_current_catalog().setCurrentDatabase(
                rel.set_current_database.db_name,
            )
        # Table related APIs
        case "get_table":
            return get_current_catalog().getTable(rel.get_table.table_name)
        case "list_tables":
            return get_current_catalog().listTables(
                schemaName=rel.list_tables.db_name, pattern=rel.list_tables.pattern
            )
        case "list_catalogs":
            pattern = re.compile(rel.list_catalogs.pattern)
            return pandas.DataFrame(
                [
                    cat.metadata
                    for name, cat in CATALOGS.items()
                    if pattern.match(name) is not None
                ]
            )
        case "current_catalog":
            return pandas.DataFrame(
                {"current_catalog": [get_current_catalog().metadata.name]}
            )
        case "set_current_catalog":
            set_current_catalog(rel.set_current_catalog.catalog_name)
            return pandas.DataFrame(
                {"current_catalog": [get_current_catalog().metadata.name]}
            )
        case "table_exists":
            return get_current_catalog().tableExists(
                rel.table_exists.table_name, rel.table_exists.db_name
            )
        # Column related APIs
        case "list_columns":
            return get_current_catalog().listColumns(
                rel.list_columns.table_name, rel.list_columns.db_name
            )
        # View related APIs
        case "drop_global_temp_view":
            return get_current_catalog().dropGlobalTempView(
                rel.drop_global_temp_view.view_name
            )
        case "drop_temp_view":
            return get_current_catalog().dropTempView(rel.drop_temp_view.view_name)
        case "recover_partitions":
            # This is a no-op operation in SAS as Snowpark doesn't have the concept of partitions.
            # All the data in the dataframe will be treated as a single partition, and this will not
            # have any side effects.
            logger.warning("recover_partitions is triggered with no-op")
            return pandas.DataFrame()
        # Table related APIs
        case "create_table":
            return get_current_catalog().createTable(
                rel.create_table.table_name,
                rel.create_table.path,
                rel.create_table.source,
                rel.create_table.schema,
                rel.create_table.description,
                **rel.create_table.options,
            )
        # Caching related APIs
        case "cache_table":
            return get_current_catalog().cacheTable(
                rel.cache_table.table_name,
                rel.cache_table.storage_level,
            )
        case "clear_cache":
            return get_current_catalog().clearCache()
        case "is_cached":
            return get_current_catalog().isCached(rel.is_cached.table_name)
        case "refresh_by_path":
            return get_current_catalog().refreshByPath(rel.refresh_by_path.path)
        case "refresh_table":
            return get_current_catalog().refreshTable(rel.refresh_table.table_name)
        case "uncache_table":
            return get_current_catalog().uncacheTable(rel.uncache_table.table_name)
        case other:
            # TODO: list_function implementation is blocked on SNOW-1787268
            raise SnowparkConnectNotImplementedError(f"Other Relation {other}")
