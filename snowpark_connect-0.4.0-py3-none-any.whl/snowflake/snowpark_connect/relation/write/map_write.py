import os
import shutil
from pathlib import Path

import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.commands_pb2 as commands_proto

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake.snowpark.functions import col, lit, object_construct
from snowflake.snowpark_connect.config import global_config, str_to_bool
from snowflake.snowpark_connect.relation.io_utils import is_cloud_path
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.relation.stage_locator import get_paths_from_stage
from snowflake.snowpark_connect.relation.utils import random_string
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def get_param_from_options(params, options, source):
    match source:
        case "csv":
            params["format_type_options"]["FILE_EXTENSION"] = source
            if "header" in options:
                params["header"] = str_to_bool(options["header"])
            params["single"] = False
        case "json":
            params["format_type_options"]["FILE_EXTENSION"] = source
        case "parquet":
            params["header"] = True

    if (
        source in ("csv", "parquet", "json") and "nullValue" in options
    ):  # TODO: Null value handling if not specified
        params["format_type_options"]["NULL_IF"] = options["nullValue"]


def map_write(request: proto_base.ExecutePlanRequest):
    write_op = request.plan.command.write_operation
    write_mode = None
    match write_op.mode:
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_APPEND:
            write_mode = "append"
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_ERROR_IF_EXISTS:
            write_mode = "errorifexists"
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_OVERWRITE:
            write_mode = "overwrite"
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_IGNORE:
            write_mode = "ignore"

    input_df: snowpark.DataFrame = handle_column_names(
        map_relation(write_op.input), write_op.source
    )
    session: snowpark.Session = snowpark.Session.builder.getOrCreate()

    match write_op.source:
        case "csv" | "parquet" | "json":
            if write_op.HasField("table"):
                raise SnowparkConnectNotImplementedError(
                    "Save to table is not yet supported for csv, parquet, or json format"
                )
            write_path = get_paths_from_stage(
                [write_op.path],
                session=session,
            )[0]
            # we need a random prefix to support "append" mode
            # otherwise copy into with overwrite=False will fail if the file already exists
            temp_file_prefix_on_stage = f"{write_path}/{random_string(10, 'sas_file_')}"
            overwrite = (
                write_op.mode
                == commands_proto.WriteOperation.SaveMode.SAVE_MODE_OVERWRITE
            )
            parameters = {
                "location": temp_file_prefix_on_stage,
                "file_format_type": write_op.source,
                "format_type_options": {
                    "COMPRESSION": "NONE",
                },
                "overwrite": overwrite,
            }
            rewritten_df: snowpark.DataFrame = rewrite_df(input_df, write_op.source)
            get_param_from_options(parameters, write_op.options, write_op.source)
            if write_op.partitioning_columns:
                if write_op.source != "parquet":
                    raise SnowparkConnectNotImplementedError(
                        "Partitioning is only supported for parquet format"
                    )
                partitioning_columns = [f'"{c}"' for c in write_op.partitioning_columns]
                if len(partitioning_columns) > 1:
                    raise SnowparkConnectNotImplementedError(
                        "Multiple partitioning columns are not yet supported"
                    )
                else:
                    parameters["partition_by"] = partitioning_columns[0]
            rewritten_df.write.copy_into_location(**parameters)
            if not is_cloud_path(write_op.path):
                store_files_locally(
                    temp_file_prefix_on_stage,
                    write_op.path,
                    overwrite,
                    session,
                )
        case "jdbc":
            from snowflake.snowpark_connect.relation.write.map_write_jdbc import (
                map_write_jdbc,
            )

            options = dict(write_op.options)
            if write_mode is None:
                write_mode = "errorifexists"
            map_write_jdbc(input_df, session, options, write_mode)
        case _:
            match write_op.table.save_method:
                case (
                    commands_proto.WriteOperation.SaveTable.TableSaveMethod.TABLE_SAVE_METHOD_SAVE_AS_TABLE
                ):
                    input_df.write.saveAsTable(
                        table_name=write_op.table.table_name, mode=write_mode
                    )
                case other:
                    raise SnowparkConnectNotImplementedError(
                        f"Save command not supported: {other}"
                    )


def rewrite_df(input_df: snowpark.DataFrame, source: str) -> snowpark.DataFrame:
    """
    Rewrite dataframe if needed.
        json: construct the dataframe to 1 column in json format
            1. Append columns which represents the column name
            2. Use object_construct to aggregate the dataframe into 1 column

    """
    if source != "json":
        return input_df
    rand_salt = random_string(10, "_")
    rewritten_df = input_df.with_columns(
        [co + rand_salt for co in input_df.columns],
        [lit(unquote_if_quoted(co)) for co in input_df.columns],
    )
    construct_key_values = []
    for co in input_df.columns:
        construct_key_values.append(col(co + rand_salt))
        construct_key_values.append(col(co))
    return rewritten_df.select(object_construct(*construct_key_values))


def handle_column_names(df: snowpark.DataFrame, source: str) -> snowpark.DataFrame:
    """
    Handle column names.

    Quote column name in these scenarios:
        0. Not write to table
        1. Customer enabled case sensitivity in config
    """
    if not hasattr(df, "_column_map"):
        return df
    column_map = df._column_map
    case_sensitive = global_config.spark_sql_caseSensitive
    for column in df.columns:
        spark_column_name = unquote_if_quoted(
            column_map.get_spark_column_name_from_snowpark_column_name(column)
        )
        if source in ("csv", "parquet", "json") or case_sensitive:
            spark_column_name = f'"{spark_column_name}"'
        df = df.withColumnRenamed(column, spark_column_name)
    return df


def store_files_locally(
    stage_path: str, target_path: str, overwrite: bool, session: snowpark.Session
) -> None:
    if overwrite and os.path.isdir(target_path):
        _truncate_directory(Path(target_path))
    snowpark.file_operation.FileOperation(session).get(stage_path, target_path)


def _truncate_directory(directory_path: Path) -> None:
    if not directory_path.exists():
        raise FileNotFoundError(
            f"The specified directory {directory_path} does not exist."
        )
    # Iterate over all the files and directories in the specified directory
    for file in directory_path.iterdir():
        # Check if it is a file or directory and remove it
        if file.is_file() or file.is_symlink():
            file.unlink()
        elif file.is_dir():
            shutil.rmtree(file)
