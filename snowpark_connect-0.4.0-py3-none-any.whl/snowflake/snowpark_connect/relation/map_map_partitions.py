import copy

import pandas
import pyspark.cloudpickle.cloudpickle as pkl
import pyspark.sql.connect.proto.relations_pb2 as relation_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.type_mapping import map_pyspark_types_to_snowpark_types


def map_map_partitions(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Map a function over the partitions of the input DataFrame.

    This is a simple wrapper around the `mapInPandas` method in Snowpark.
    """
    input_df = map_relation(rel.map_partitions.input)
    udf_function, output_dtype = pkl.loads(rel.map_partitions.func.python_udf.command)
    output_dtype = map_pyspark_types_to_snowpark_types(output_dtype)
    # This is done to avoid pickling the entire Snowpark DataFrame with cloudpickle.
    udf_function = copy.copy(udf_function)
    column_names = input_df.columns
    udf_column_name = "UDF_OUTPUT"

    def wrapped_udf(*args):
        """Spark MapInPandas functions assume the data is an interator of pandas DataFrames."""
        return udf_function(pandas.DataFrame(iter([list(args)]), columns=column_names))

    func = snowpark_fn.udf(
        wrapped_udf,
        return_type=output_dtype,
        input_types=[f.datatype for f in input_df.schema.fields],
        name="spark_map_partitions_udf",
        replace=True,
        packages=[
            "py4j==0.10.9.7",
            "numpy",
            "pandas",
            "filelock",
            "typing-extensions >=4.8.0",
            "sympy",
            "networkx",
            "jinja2",
            "fsspec",
            "pytorch",
            "pyarrow",
        ],
    )
    result = input_df.select(func(*input_df.columns))
    return build_column_map(result, [udf_column_name], [udf_column_name])
