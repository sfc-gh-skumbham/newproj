import os

from snowflake import snowpark
from snowflake.snowpark.exceptions import SnowparkClientException
from snowflake.snowpark.session import _get_active_session
from snowflake.snowpark_connect.constants import (
    DEFAULT_CONNECTION_NAME,
    DEFAULT_CONNECTION_NAME_IN_SPCS,
)
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.udf_cache import init_builtin_udf_cache


def _get_current_snowpark_session() -> snowpark.Session | None:
    # TODO: this is a temporary solution to get the current session, it would be better to add a function in snowpark
    try:
        session = _get_active_session()
        # if session._conn._conn.expired:
        #     _remove_session(session)
        #     return self.create()
        return session
    except SnowparkClientException as ex:
        if ex.error_code == "1403":  # No session
            return None
        raise


def config_snowpark_session(session: snowpark.Session):
    from snowflake.snowpark_connect.config import global_config
    from snowflake.snowpark_connect.utils.telemetry import TelemetryClient

    logger.info(f"Initializing session {session}")

    session._sas_telemetry_client = TelemetryClient(session._conn._conn)
    # custom udfs
    session._udfs = {}
    session._udtfs = {}
    # built-in udf cache
    init_builtin_udf_cache(session)

    session.ast_enabled = False
    session.eliminate_numeric_sql_value_cast_enabled = False
    session.reduce_describe_query_enabled = True
    session._join_alias_fix = True
    session.connection.arrow_number_to_decimal_setter = True

    session.sql("ALTER SESSION SET TIMESTAMP_TYPE_MAPPING = TIMESTAMP_LTZ").collect()
    session.sql(
        f"ALTER SESSION SET TIMEZONE = '{global_config.spark_sql_session_timeZone}'"
    ).collect()

    db = session.get_current_database()
    prev_schema = session.get_current_schema()
    # This schema is used for "global temp views".
    # If schema is created, it is also changed in the context of the session
    session.sql(
        f"create schema if not exists {global_config.spark_sql_globalTempDatabase}"
    ).collect()
    match (prev_schema, session.get_current_schema()):
        case (None, curr) if curr is not None:
            # session.use_schema(None) is not allowed.
            # Instead, we call `use_database` which will set schema in context to the default one.
            session.use_database(db)
        case (prev, curr) if prev != curr:
            session.use_schema(prev)


def get_or_create_snowpark_session(
    custom_configs: dict | None = None,
) -> snowpark.Session:
    """
    snowpark connect code should use this function to create or get snowpark session
    """
    session_configs = {}
    if (
        os.path.exists("/snowflake/session/token")
        and os.getenv("SNOWFLAKE_HOME") is not None
    ):
        # running in SPCS
        session_configs["connection_name"] = DEFAULT_CONNECTION_NAME_IN_SPCS
        session_configs["warehouse"] = os.getenv("SNOWFLAKE_WAREHOUSE")
    else:
        session_configs["connection_name"] = DEFAULT_CONNECTION_NAME

    if os.getenv("SNOWFLAKE_DATABASE") is not None:
        session_configs["database"] = os.getenv("SNOWFLAKE_DATABASE")

    # add custom session configs
    if custom_configs:
        session_configs.update(custom_configs)

    old_session = _get_current_snowpark_session()
    new_session = snowpark.Session.builder.configs(session_configs).getOrCreate()
    if old_session is None or old_session.session_id != new_session.session_id:
        # every new session needs to be configured
        config_snowpark_session(new_session)
    return new_session
