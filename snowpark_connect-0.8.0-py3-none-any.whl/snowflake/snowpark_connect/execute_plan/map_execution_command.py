import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.constants import SERVER_SIDE_SESSION_ID
from snowflake.snowpark_connect.execute_plan.utils import pandas_to_arrow_batches_bytes
from snowflake.snowpark_connect.expression import map_udf
from snowflake.snowpark_connect.relation import map_udtf
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.relation.map_sql import map_sql_to_pandas_df
from snowflake.snowpark_connect.relation.write.map_write import map_write, map_write_v2
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_execution_command(
    request: proto_base.ExecutePlanRequest,
) -> proto_base.ExecutePlanResponse | None:
    logger.info(request.plan.command.WhichOneof("command_type").upper())
    match request.plan.command.WhichOneof("command_type"):
        case "create_dataframe_view":
            req = request.plan.command.create_dataframe_view
            input_df = map_relation(req.input)
            # Use real column names when writing to sf.
            assert hasattr(
                input_df, "_column_map"
            ), "input_df does not have the _column_map attribute"
            column_map = input_df._column_map
            for column in input_df.columns:
                input_df = input_df.withColumnRenamed(
                    column,
                    column_map.get_spark_column_name_from_snowpark_column_name(column),
                )
            view_name = req.name

            if req.is_global:
                view_name = [global_config.spark_sql_globalTempDatabase, view_name]

            if req.replace:
                input_df.create_or_replace_temp_view(view_name)
            else:
                input_df.create_temp_view(view_name)
        case "write_stream_operation_start":
            match request.plan.command.write_stream_operation_start.format:
                case "console":
                    # TODO: Make the console output work with Spark style formatting.
                    # result_df: pandas.DataFrame = map_relation(
                    #     relation_proto.Relation(
                    #         show_string=relation_proto.ShowString(
                    #             input=request.plan.command.write_stream_operation_start.input,
                    #             num_rows=100,
                    #             truncate=False,
                    #         )
                    #     )
                    # )
                    # logger.info(result_df.iloc[0, 0])
                    map_relation(
                        request.plan.command.write_stream_operation_start.input
                    ).show()
        case "sql_command":
            pandas_df, schema = map_sql_to_pandas_df(
                request.plan.command.sql_command.sql,
                request.plan.command.sql_command.args,
                request.plan.command.sql_command.pos_args,
            )
            # SELECT query in SQL command will return None instead of Pandas DF to enable lazy evaluation
            if pandas_df is None:
                return None
            return proto_base.ExecutePlanResponse(
                session_id=request.session_id,
                operation_id=SERVER_SIDE_SESSION_ID,
                sql_command_result=proto_base.ExecutePlanResponse.SqlCommandResult(
                    relation=relation_proto.Relation(
                        local_relation=relation_proto.LocalRelation(
                            data=pandas_to_arrow_batches_bytes(pandas_df),
                            schema=schema,
                        )
                    )
                ),
            )
        case "write_operation":
            map_write(request)

        case "write_operation_v2":
            map_write_v2(request)

        case "register_function":
            map_udf.register_udf(request.plan.command.register_function)

        case "register_table_function":
            map_udtf.register_udtf(request.plan.command.register_table_function)

        case other:
            raise SnowparkConnectNotImplementedError(
                f"Command type {other} not implemented"
            )
