import typing

import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.read.utils import (
    get_spark_column_names_from_snowpark_columns,
    rename_columns_as_snowflake_standard,
)
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)
from snowflake.snowpark_connect.utils.udf_cache import sproc_text_read


def read_text(
    path: str,
    schema: snowpark.types.StructType | None,
    session: snowpark.Session,
    options: typing.MutableMapping[str, str],
) -> snowpark.DataFrame:
    # TODO: handle stage name with double quotes
    files_paths = [
        "/".join(f[0].split("/")[1:]) for f in session.sql(f"LIST {path}").collect()
    ]
    stage_name = path.split("/")[0]
    line_sep = options.get("lineSep") or "\n"
    column_name = (
        schema[0].name if schema is not None and len(schema.fields) > 0 else '"value"'
    )

    result = []
    for fp in files_paths:
        content = session.sql(
            f"CALL {sproc_text_read(session).name}(BUILD_SCOPED_FILE_URL({stage_name},'{fp}'));"
        ).collect()[0][0]
        if options.get("wholetext", "False").lower() == "true":
            result.append(content)
        else:
            content = content.split(line_sep)
            if len(content) > 0 and len(content[-1]) == 0:
                # Remove last empty line
                content = content[:-1]
            result.extend(content)
    return session.createDataFrame(result, [column_name])


def map_read_text(
    rel: relation_proto.Relation,
    schema: snowpark.types.StructType | None,
    session: snowpark.Session,
    paths: list[str],
) -> snowpark.DataFrame:
    """
    Read a TEXT file into a Snowpark DataFrame.
    """
    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise SnowparkConnectNotImplementedError(
            "Streaming is not supported for CSV files."
        )

    df = read_text(paths[0], schema, session, rel.read.data_source.options)
    if len(paths) > 1:
        for p in paths[1:]:
            df = df.union_all(
                read_text(
                    p,
                    schema,
                    session,
                    rel.read.data_source.options,
                )
            )

    spark_column_names = get_spark_column_names_from_snowpark_columns(df.columns)

    renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(
        df, rel.common.plan_id
    )
    return build_column_map(
        renamed_df,
        spark_column_names,
        snowpark_column_names,
        [f.datatype for f in df.schema.fields],
    )
