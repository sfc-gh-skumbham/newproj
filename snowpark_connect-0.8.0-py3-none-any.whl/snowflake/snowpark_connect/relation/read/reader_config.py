from copy import copy
from typing import Any

from snowflake.snowpark_connect.config import GlobalConfig
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger


class ReaderConfig(GlobalConfig):

    # spark reader options that snowpark is able to handle
    supported_options = set()

    default_global_config = {
        # TODO: Snowpark does not support mode argument
        # "mode": "PERMISSIVE",
        # TODO: Snowpark does not support locale argument
        # "locale": "en-US",
        "compression": "none",
    }

    boolean_config_list = []

    int_config_list = []

    float_config_list = []

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__()
        self.global_config = copy(self.default_global_config)
        for key, value in options.items():
            self.set(key, value)

    def convert_to_snowpark_args(self) -> dict[str, Any]:
        snowpark_config = {}

        for key, value in self.global_config.items():
            if key in self.supported_options:
                snowpark_config[key] = value
            else:
                logger.debug(f"unsupported reader option: {key}")

        for key in snowpark_config.keys():
            snowpark_config[key] = super()._get_config_setting(key)
        return snowpark_config


class CsvReaderConfig(ReaderConfig):
    # spark reader options that snowpark is able to handle.
    supported_options = {
        "schema",
        "sep",
        "encoding",
        "quote",
        # escape has different semantics in snowpark, but should work for standard use-cases
        "escape",
        "comment",
        "header",
        "inferSchema",
        # "ignoreLeadingWhiteSpace",
        # "ignoreTrailingWhiteSpace",
        "nullValue",
        # "nanValue",
        # "positiveInf",
        # "negativeInf",
        "dateFormat",
        "timestampFormat",
        # "maxColumns",
        # "maxCharsPerColumn",
        # "maxMalformedLogPerPartition",
        # "mode",
        # "columnNameOfCorruptRecord",
        # "multiLine",
        # "charToEscapeQuoteEscaping",
        # "samplingRatio",
        # "enforceSchema",
        # "emptyValue",
        # "locale",
        "lineSep",
        "pathGlobFilter",
        # "recursiveFileLookup",
        # "modifiedBefore",
        # "modifiedAfter",
        # "unescapedQuoteHandling",
        "compression",
        # "escapeQuotes",
        # "quoteAll",
    }

    default_global_config = dict(
        ReaderConfig.default_global_config,
        **{
            "header": "false",
            "inferSchema": "true",
            "quote": '"',
            "comment": "#",
            "nullValue": "",
            # TODO: Snowpark does not support NaN value argument.
            # "nanValue": "NaN",
            "dateFormat": "yyyy-MM-dd",
            "timestampFormat": "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            # TODO: Snowpark does not support maxColumns argument
            # "maxColumns": "20480",
            # TODO: Snowpark does not support maxCharsPerColumn argument
            # "maxCharsPerColumn": "1000000",
            # TODO: Snowpark does not support maxMalformedLogPerPartition argument
            # "maxMalformedLogPerPartition": "10",
            "charset": "UTF-8",
            # TODO: Snowpark does not support multiLine argument
            # "multiLine": "false",
            # TODO: Snowpark does not support ignoreLeadingWhiteSpace argument
            # "ignoreLeadingWhiteSpace": "false",
            # TODO: Snowpark does not support ignoreTrailingWhiteSpace argument
            # "ignoreTrailingWhiteSpace": "false",
            # TODO: Snowpark does not support samplingRatio argument
            # "samplingRatio": "1.0",
            # TODO: Snowpark does not support emptyValue argument
            # "emptyValue": "",
            "lineSep": "\n",
            "sep": ",",
            # TODO: Snowpark does not support escapeQuotes argument
            # "escapeQuotes": "true",
            # TODO: Snowpark does not support quoteAll argument
            # "quoteAll": "false",
            "escape": "\\\\",
        },
    )

    boolean_config_list = ReaderConfig.boolean_config_list + [
        "header",
        "inferSchema",
        "multiLine",
        "ignoreLeadingWhiteSpace",
        "ignoreTrailingWhiteSpace",
        "escapeQuotes",
        "quoteAll",
    ]

    int_config_list = ReaderConfig.int_config_list + [
        "maxColumns",
        "maxCharsPerColumn",
        "maxMalformedLogPerPartition",
    ]

    float_config_list = ReaderConfig.float_config_list + ["samplingRatio"]

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__(options)

    def convert_to_snowpark_args(self) -> dict[str, Any]:
        renamed_args = {
            "inferSchema": "INFER_SCHEMA",
            "quote": "FIELD_OPTIONALLY_ENCLOSED_BY",
            "nullValue": "NULL_IF",
            "dateFormat": "DATE_FORMAT",
            "timestampFormat": "TIMESTAMP_FORMAT",
            "lineSep": "RECORD_DELIMITER",
            "sep": "FIELD_DELIMITER",
            "header": "PARSE_HEADER",
            "pathGlobFilter": "PATTERN",
        }
        snowpark_config = super().convert_to_snowpark_args()
        # spark does not escape unenclosed fields
        snowpark_config["ESCAPE_UNENCLOSED_FIELD"] = "NONE"
        # Rename the keys to match the Snowpark configuration.
        for spark_arg, snowpark_arg in renamed_args.items():
            if spark_arg not in snowpark_config:
                continue
            snowpark_config[snowpark_arg] = snowpark_config[spark_arg]
            del snowpark_config[spark_arg]

        return snowpark_config


class JsonReaderConfig(ReaderConfig):
    # spark reader options that snowpark is able to handle.
    supported_options = {
        "schema",
        # "primitivesAsString",
        # "prefersDecimal",
        # "allowComments",
        # "allowUnquotedFieldNames",
        # "allowSingleQuotes",
        # "allowNumericLeadingZero",
        # "allowBackslashEscapingAnyCharacter",
        # "mode",
        # "columnNameOfCorruptRecord",
        "dateFormat",
        "timestampFormat",
        "multiLine",
        "multiline",
        # "allowUnquotedControlChars",
        # "lineSep",
        # "samplingRatio",
        # "dropFieldIfAllNull",
        "encoding",
        # "locale",
        # "pathGlobFilter",
        # "recursiveFileLookup",
        # "modifiedBefore",
        # "modifiedAfter",
        # "allowNonNumericNumbers",
        "compression",
        # "ignoreNullFields",
    }
    default_global_config = dict(
        ReaderConfig.default_global_config,
        **{
            # TODO: primitivesAsString: Union[bool, str, None] = None,
            # TODO: prefersDecimal: Union[bool, str, None] = None,
            # TODO: allowComments: Union[bool, str, None] = None,
            # TODO: allowUnquotedFieldNames: Union[bool, str, None] = None,
            # TODO: allowSingleQuotes: Union[bool, str, None] = None,
            # TODO: allowNumericLeadingZero: Union[bool, str, None] = None,
            # TODO: allowBackslashEscapingAnyCharacter: Union[bool, str, None] = None,
            # TODO: columnNameOfCorruptRecord: Optional[str] = None,
            "dateFormat": "auto",
            "timestampFormat": "auto",
            # TODO: multiLine: Union[bool, str, None] = None,
            # TODO: allowUnquotedControlChars: Union[bool, str, None] = None,
            # TODO: lineSep: Optional[str] = None,
            # TODO: samplingRatio: Union[str, float, None] = None,
            # TODO: dropFieldIfAllNull: Union[bool, str, None] = None,
            # TODO: encoding: Optional[str] = None,
            # TODO: pathGlobFilter: Union[bool, str, None] = None,
            # TODO: recursiveFileLookup: Union[bool, str, None] = None,
            # TODO: modifiedBefore: Union[bool, str, None] = None,
            # TODO: modifiedAfter: Union[bool, str, None] = None,
            # TODO: allowNonNumericNumbers: Union[bool, str, None] = None,
        },
    )

    boolean_config_list = ReaderConfig.boolean_config_list + ["multiLine", "multiline"]

    int_config_list = ReaderConfig.int_config_list + []

    float_config_list = ReaderConfig.float_config_list + ["samplingRatio"]

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__(options)

    def convert_to_snowpark_args(self) -> dict[str, Any]:
        renamed_args = {
            "inferSchema": "INFER_SCHEMA",
            "dateFormat": "DATE_FORMAT",
            "timestampFormat": "TIMESTAMP_FORMAT",
            "multiLine": "STRIP_OUTER_ARRAY",
            "multiline": "STRIP_OUTER_ARRAY",
        }
        snowpark_config = super().convert_to_snowpark_args()
        # Rename the keys to match the Snowpark configuration.
        for spark_arg, snowpark_arg in renamed_args.items():
            if spark_arg not in snowpark_config:
                continue
            snowpark_config[snowpark_arg] = snowpark_config[spark_arg]
            del snowpark_config[spark_arg]
        return snowpark_config


class ParquetReaderConfig(ReaderConfig):
    # spark reader options that snowpark is able to handle.
    supported_options = {
        # "mergeSchema",
        # "pathGlobFilter",
        # "recursiveFileLookup",
        # "modifiedBefore",
        # "modifiedAfter",
        # "datetimeRebaseMode",
        # "int96RebaseMode",
        # "mode",
        "compression",
    }

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__(options)
