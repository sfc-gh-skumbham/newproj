import re

import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.expression.literal import get_literal_field_and_name
from snowflake.snowpark_connect.expression.map_expression import (
    map_single_column_expression,
)
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.relation.map_relation import map_relation


def map_group_by_aggregate(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Groups the DataFrame using the specified columns.

    Aggregations come in as expressions, which are mapped to `snowpark.Column`
    objects.
    """
    (
        input_df,
        agg_name_list,
        new_name_list,
        snowpark_grouping_expressions,
        snowpark_agg_expressions,
    ) = map_aggregate_helper(rel)
    if len(snowpark_grouping_expressions) == 0:
        result = input_df.agg(*snowpark_agg_expressions)
    else:
        result = input_df.group_by(*snowpark_grouping_expressions).agg(
            *snowpark_agg_expressions
        )
    return build_column_map(result, agg_name_list + new_name_list, result.columns)


def map_rollup_aggregate(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Create a multidimensional rollup for the current DataFrame using the specified columns.

    Aggregations come in as expressions, which are mapped to `snowpark.Column`
    objects.
    """
    (
        input_df,
        agg_name_list,
        new_name_list,
        snowpark_grouping_expressions,
        snowpark_agg_expressions,
    ) = map_aggregate_helper(rel)
    if len(snowpark_grouping_expressions) == 0:
        result = input_df.agg(*snowpark_agg_expressions)
    else:
        result = input_df.rollup(*snowpark_grouping_expressions).agg(
            *snowpark_agg_expressions
        )
    return build_column_map(result, agg_name_list + new_name_list, result.columns)


def map_cube_aggregate(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Create a multidimensional cube for the current DataFrame using the specified columns.

    Aggregations come in as expressions, which are mapped to `snowpark.Column`
    objects.
    """
    (
        input_df,
        agg_name_list,
        new_name_list,
        snowpark_grouping_expressions,
        snowpark_agg_expressions,
    ) = map_aggregate_helper(rel)
    if len(snowpark_grouping_expressions) == 0:
        result = input_df.agg(*snowpark_agg_expressions)
    else:
        result = input_df.cube(*snowpark_grouping_expressions).agg(
            *snowpark_agg_expressions
        )
    return build_column_map(result, agg_name_list + new_name_list, result.columns)


def map_pivot_aggregate(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Pivots a column of the current DataFrame and performs the specified aggregation.

    There are 2 versions of the pivot function: one that requires the caller to specify the list of the distinct values
    to pivot on and one that does not.
    """
    (
        input_df,
        agg_name_list,
        new_name_list,
        snowpark_grouping_expressions,
        snowpark_agg_expressions,
    ) = map_aggregate_helper(rel)
    pivot_column = map_single_column_expression(
        rel.aggregate.pivot.col, input_df._column_map, ExpressionTyper(input_df)
    )
    pivot_values = [
        get_literal_field_and_name(lit)[0] for lit in rel.aggregate.pivot.values
    ]
    result = (
        input_df.group_by(*snowpark_grouping_expressions)
        .pivot(pivot_column[1].col, pivot_values if pivot_values else None)
        .agg(*snowpark_agg_expressions)
    )

    spark_columns = [string_parser(s) for s in result.columns]
    return build_column_map(
        result, agg_name_list + spark_columns[len(agg_name_list) :], result.columns
    )


def string_parser(s):
    double_quote_list = re.findall(r'"(.*?)"', s)
    spark_string = ""
    for entry in double_quote_list:
        if "'" in entry:
            entry = entry.replace("'", "")
            if len(entry) > 0:
                spark_string += entry
        elif entry.isdigit() or re.compile(r"^\d+?\.\d+?$").match(entry):
            # skip quoting digits or decimal numbers as column names.
            spark_string += entry
        else:
            spark_string += '"' + entry + '"'
    return s if spark_string == "" else spark_string


def map_aggregate_helper(rel: relation_proto.Relation):
    input_df = map_relation(rel.aggregate.input)
    grouping_expressions = rel.aggregate.grouping_expressions
    expressions = rel.aggregate.aggregate_expressions
    snowpark_grouping_expressions: list[snowpark.Column] = []
    agg_name_list: list[str] = []
    snowpark_agg_expressions: list[snowpark.Column] = []
    new_name_list: list[str] = []
    typer = ExpressionTyper(input_df)
    for exp in grouping_expressions:
        new_name, snowpark_column = map_single_column_expression(
            exp, input_df._column_map, typer
        )
        snowpark_grouping_expressions.append(snowpark_column.col)
        agg_name_list.append(new_name)
    for exp in expressions:
        new_name, snowpark_column = map_single_column_expression(
            exp, input_df._column_map, typer
        )
        snowpark_agg_expressions.append(snowpark_column.col)
        new_name_list.append(new_name)

    return (
        input_df,
        agg_name_list,
        new_name_list,
        snowpark_grouping_expressions,
        snowpark_agg_expressions,
    )
