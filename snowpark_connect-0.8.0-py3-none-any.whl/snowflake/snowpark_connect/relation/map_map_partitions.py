import copy

import pyspark.cloudpickle.cloudpickle as pkl
import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake import snowpark
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.type_mapping import map_pyspark_types_to_snowpark_types
from snowflake.snowpark_connect.utils.udf_utils import CreateUdfInputs, create_udf


def map_map_partitions(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Map a function over the partitions of the input DataFrame.

    This is a simple wrapper around the `mapInPandas` method in Snowpark.
    """
    input_df = map_relation(rel.map_partitions.input)
    udf_function, output_dtype = pkl.loads(rel.map_partitions.func.python_udf.command)
    output_dtype = map_pyspark_types_to_snowpark_types(output_dtype)
    # This is done to avoid pickling the entire Snowpark DataFrame with cloudpickle.
    udf_function = copy.copy(udf_function)
    column_names = input_df.columns
    udf_column_name = "UDF_OUTPUT"
    eval_type = rel.map_partitions.func.python_udf.eval_type

    func = create_udf(
        CreateUdfInputs(
            "map_partitions",
            eval_type,
            output_dtype=output_dtype,
            input_types=[f.datatype for f in input_df.schema.fields],
            udf_function=udf_function,
            column_names=column_names,
        )
    )
    result = input_df.select(func(*input_df.columns))
    return build_column_map(
        result, [udf_column_name], [udf_column_name], [output_dtype]
    )
