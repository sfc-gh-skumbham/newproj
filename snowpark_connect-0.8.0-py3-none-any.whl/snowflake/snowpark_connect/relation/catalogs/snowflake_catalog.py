import typing

import pandas
import pyspark.sql.connect.proto.types_pb2 as types_proto

from snowflake import snowpark
from snowflake.snowpark import functions
from snowflake.snowpark.types import BooleanType
from snowflake.snowpark_connect import column_name_handler
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.relation.catalogs.abstract_spark_catalog import (
    AbstractSparkCatalog,
    _get_current_snowflake_schema,
    _process_multi_layer_database,
    _process_multi_layer_identifier,
)
from snowflake.snowpark_connect.type_mapping import proto_to_snowpark_type
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


class SnowflakeCatalog(AbstractSparkCatalog):
    def __init__(self) -> None:
        super().__init__(name="spark_catalog", description=None)

    def listDatabases(
        self,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """List all databases accessible in Snowflake with an optional name to filter by."""
        catalog = get_or_create_snowpark_session().catalog
        # This pattern is case-sensitive while our SAS implementation is not
        if pattern is not None and pattern == pattern.lower():
            pattern = pattern.upper()

        dbs = catalog.list_schemas(pattern=pattern)
        names: list[str] = list()
        catalogs: list[str] = list()
        descriptions: list[str | None] = list()
        locationUris: list[str] = list()
        for db in dbs:
            names.append(db.name)
            catalogs.append(self.name)
            descriptions.append(db.comment)
            locationUris.append(f"snowflake://{db.name}")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "description": descriptions,
                "locationUri": locationUris,
            }
        )

    def getDatabase(
        self,
        spark_dbName: str,
    ) -> pandas.DataFrame:
        """Listing a single database that's accessible in Snowflake."""
        if "." in spark_dbName:
            # TODO: down the line we need to support another catalog being returned here
            _, sf_database = _process_multi_layer_database(spark_dbName)
            return self.listDatabases(pattern=sf_database)
        return self.listDatabases(pattern=spark_dbName)

    def databaseExists(
        self,
        spark_dbName: str,
    ) -> pandas.DataFrame:
        """Whether a database with provided name exists in Snowflake."""
        if "." in spark_dbName:
            # TODO: down the line we need to support another catalog being returned here
            _, sf_database = _process_multi_layer_database(spark_dbName)
            return pandas.DataFrame(
                {"exists": [not self.getDatabase(sf_database).empty]}
            )
        return pandas.DataFrame({"exists": [not self.getDatabase(spark_dbName).empty]})

    def listTables(
        self,
        snowflake_dbName: typing.Optional[str] = None,
        snowflake_schemaName: typing.Optional[str] = None,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """Listing all tables/views accessible in Snowflake, optionally filterable on database, schema, and a pattern for the table names."""
        # In all of the other functions we keep with the Spark naming, but in this function dbName refers to a
        # a Snowflake database and schemaName refers to a Snowflake schema. This is necessary because of the
        # tableName possibly being a multi-layer-namespace identifier in tableExists.
        catalog = get_or_create_snowpark_session().catalog
        tables = catalog.list_tables(
            database=snowflake_dbName,
            schema=snowflake_schemaName,
            pattern=pattern.upper() if isinstance(pattern, str) else pattern,
        )
        views = catalog.list_views(
            database=snowflake_dbName,
            schema=snowflake_schemaName,
            pattern=pattern.upper() if isinstance(pattern, str) else pattern,
        )
        names: list[str] = list()
        catalogs: list[str] = list()
        namespaces: list[list[str | None]] = list()
        names: list[str] = list()
        descriptions: list[str | None] = list()
        table_types: list[str | None] = list()
        is_temporaries: list[bool] = list()
        for table in tables:
            names.append(table.name)
            catalogs.append(self.name)
            namespaces.append([table.schema_name])
            descriptions.append(table.comment)
            table_types.append(table.kind)
            is_temporaries.append(table.kind == "TEMPORARY")
        for view in views:
            names.append(view.name)
            catalogs.append(self.name)
            namespaces.append([view.schema_name])
            descriptions.append(view.comment)
            table_types.append(view.kind)
            is_temporaries.append(view.kind == "TEMPORARY")
        return pandas.DataFrame(
            {
                "name": names,
                "catalog": catalogs,
                "namespace": namespaces,
                "description": descriptions,
                "tableType": table_types,
                "isTemporary": is_temporaries,
            }
        )

    def getTable(
        self,
        spark_tableName: str,
    ) -> pandas.DataFrame:
        """Listing a single table/view with provided name that's accessible in Snowflake."""
        # TODO: down the line we need to support another catalog being returned here
        _, sf_database, sf_schema, sf_table = _process_multi_layer_identifier(
            spark_tableName
        )
        return self.listTables(
            snowflake_dbName=sf_database,
            snowflake_schemaName=sf_schema,
            pattern=sf_table,
        )

    def tableExists(
        self,
        spark_tableName: str,
        spark_dbName: typing.Optional[str],
    ) -> pandas.DataFrame:
        """Whether a table/view with provided name exists in Snowflake, optionally filterable with dbName.
        If no database is specified, first try to treat tableName as a multi-layer-namespace identifier
        (or fully qualified name), then try tableName as a normal table name in the current database if necessary.
        Argument dbName is not actually implemented yet while we figure out how to map databases from Spark to Snowflake.
        """
        db_name = None if spark_dbName == "" else spark_dbName
        if db_name is not None:
            tables = self.listTables(
                snowflake_schemaName=db_name, pattern=spark_tableName
            )
        else:
            # Multi layer identifier case
            _, sf_database, sf_schema, sf_table = _process_multi_layer_identifier(
                spark_tableName
            )
            tables = self.listTables(
                snowflake_dbName=sf_database,
                snowflake_schemaName=sf_schema,
                pattern=sf_table,
            )
        return pandas.DataFrame(
            {
                "exists": [not tables.empty],
            }
        )

    def listColumns(
        self,
        spark_tableName: str,
        spark_dbName: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        """List all columns in a table/view, optionally database name filter can be provided."""
        catalog = get_or_create_snowpark_session().catalog
        if spark_dbName == "":
            _, sf_database, sf_schema, sf_table = _process_multi_layer_identifier(
                spark_tableName
            )
            columns = catalog.list_columns(
                database=sf_database,
                schema=sf_schema,
                table_name=sf_table,
            )
        else:
            columns = catalog.list_columns(
                schema=spark_dbName,
                table_name=spark_tableName,
            )
        names: list[str] = list()
        descriptions: list[str | None] = list()
        data_types: list[str] = list()
        nullables: list[bool] = list()
        is_partitions: list[bool] = list()
        is_buckets: list[bool] = list()
        for column in columns:
            names.append(column.name)
            descriptions.append(column.comment)
            data_types.append(column.datatype)
            nullables.append(bool(column.nullable))
            is_partitions.append(False)
            is_buckets.append(False)

        return pandas.DataFrame(
            {
                "name": names,
                "description": descriptions,
                "dataType": data_types,
                "nullable": nullables,
                "isPartition": is_partitions,
                "isBucket": is_buckets,
            }
        )

    def currentDatabase(self) -> pandas.DataFrame:
        """Get the currently used database's name."""
        db_name = _get_current_snowflake_schema()
        assert db_name is not None, "current database could not be confirmed"
        if db_name[0] == '"' and db_name[-1] == '"':
            new_db_name = db_name[1:-1]
            if new_db_name.upper() == new_db_name:
                # Only remove the double quotes if the identifier is all upper case
                db_name = new_db_name
        return pandas.DataFrame({"current_database": [db_name]})

    def setCurrentDatabase(
        self,
        spark_dbName: str,
    ) -> pandas.DataFrame:
        """Set the currently used database's name."""
        catalog = get_or_create_snowpark_session().catalog
        catalog.setCurrentSchema(spark_dbName)
        return pandas.DataFrame({"current_database": [spark_dbName]})

    def dropGlobalTempView(
        self,
        spark_view_name: str,
    ) -> snowpark.DataFrame:
        session = get_or_create_snowpark_session()
        schema = global_config.spark_sql_globalTempDatabase
        result_df = session.sql(
            "drop view if exists identifier(?)", params=[f"{schema}.{spark_view_name}"]
        )
        result_df = result_df.select(
            functions.contains('"status"', functions.lit("successfully dropped")).alias(
                "value"
            )
        )
        columns = ["value"]
        return column_name_handler.build_column_map(
            result_df, columns, columns, [BooleanType()]
        )

    def dropTempView(
        self,
        spark_view_name: str,
    ) -> snowpark.DataFrame:
        """Drop the current temporary view."""
        session = get_or_create_snowpark_session()
        result_df = session.sql(
            "drop view if exists identifier(?)", params=[spark_view_name]
        )
        result_df = result_df.select(
            functions.contains('"status"', functions.lit("successfully dropped")).alias(
                "value"
            )
        )
        columns = ["value"]
        return column_name_handler.build_column_map(
            result_df, columns, columns, [BooleanType()]
        )

    def createTable(
        self,
        tableName: str,
        path: str,
        source: str,
        schema: types_proto.DataType,
        description: str,
        **options: typing.Any,
    ) -> snowpark.DataFrame:
        """Create either an external, or a managed table.

        If path is supplied in which the data for this table exists. When path is specified, an external table is
        created from the data at the given path. Otherwise a managed table is created.

        In case a managed table is being created, schema is required.
        """
        if source == "":
            source = global_config.get("spark.sql.sources.default")
        if source not in ("csv", "json", "avro", "parquet", "orc", "xml"):
            raise SnowparkConnectNotImplementedError(
                f"Source '{source}' is not currently supported by Catalog.createTable. "
                "Maybe default value through 'spark.sql.sources.default' should be set."
            )
        session = get_or_create_snowpark_session()
        if path == "":
            # Managed table
            if schema.ByteSize() == 0:
                raise SnowparkConnectNotImplementedError(
                    f"Unable to infer schema for {source.upper()}. It must be specified manually.",
                )
            sp_schema = proto_to_snowpark_type(schema)
            columns = [c.name for c in schema.struct.fields]
            column_types = [f.datatype for f in sp_schema.fields]
            return column_name_handler.build_column_map(
                session.createDataFrame([], sp_schema), columns, columns, column_types
            )
        else:
            # External table
            raise SnowparkConnectNotImplementedError(
                "External table creation is not supported currently."
            )
