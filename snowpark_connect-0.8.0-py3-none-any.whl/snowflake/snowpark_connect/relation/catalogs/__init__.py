from .snowflake_catalog import SnowflakeCatalog

SNOWFLAKE_CATALOG = SnowflakeCatalog()

CATALOGS = {
    "snowflake_catalog": SNOWFLAKE_CATALOG,
    "spark_catalog": SNOWFLAKE_CATALOG,
}
