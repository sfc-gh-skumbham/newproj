import inspect

import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from pyspark.errors.exceptions.base import PySparkTypeError
from pyspark.serializers import CloudPickleSerializer

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark.types import StructType, VariantType
from snowflake.snowpark_connect.column_name_handler import (
    ColumnNameMap,
    build_column_map,
)
from snowflake.snowpark_connect.expression.map_expression import (
    map_single_column_expression,
)
from snowflake.snowpark_connect.expression.map_udf import infer_udf_dependencies
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import (
    parse_ddl_string,
    proto_to_snowpark_type,
)
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session


def udtf_helper(udtf_proto: relation_proto.CommonInlineUserDefinedTableFunction):
    udtf = udtf_proto.python_udtf
    callable_func = CloudPickleSerializer().loads(udtf.command)
    callable_func.process = callable_func.eval
    if hasattr(callable_func, "terminate"):
        callable_func.end_partition = callable_func.terminate
    func_signature = inspect.signature(callable_func.process)

    modules = infer_udf_dependencies(callable_func.process)
    packages = [module.__name__ for module in modules]

    # Set all input types to VariantType regardless of type hints so that we can pass all arguments as VariantType.
    # Otherwise, we will run into issues with type mismatches. This only applies for UDTF registration.
    # We subtract one here since UDTF functions are class methods and always have "self" as the first parameter.
    input_types = [VariantType()] * (len(func_signature.parameters) - 1)

    parsed_return = udtf.return_type
    if udtf.return_type.HasField("unparsed"):
        parsed_return = parse_ddl_string(udtf.return_type.unparsed.data_type_string)
    output_schema = proto_to_snowpark_type(parsed_return)
    if not isinstance(output_schema, StructType):
        raise PySparkTypeError(
            f"Invalid Python user-defined table function return type. Expect a struct type, but got {parsed_return}"
        )
    spark_column_names = [f.name for f in parsed_return.struct.fields]

    return (
        callable_func,
        output_schema,
        input_types,
        udtf_proto.function_name,
        packages,
        func_signature,
        spark_column_names,
    )


def register_udtf(
    udtf_proto: relation_proto.CommonInlineUserDefinedTableFunction,
) -> snowpark.udtf.UserDefinedTableFunction:
    match udtf_proto.WhichOneof("function"):
        case "python_udtf":
            session = get_or_create_snowpark_session()
            (
                callable_func,
                output_schema,
                input_types,
                function_name,
                packages,
                _,
                spark_column_names,
            ) = udtf_helper(udtf_proto)

            udtf = session.udtf.register(
                handler=callable_func,
                output_schema=output_schema,
                input_types=input_types,
                replace=True,
                packages=packages,
            )
            session._udtfs[function_name.lower()] = (udtf, spark_column_names)
            return udtf
        case _:
            raise ValueError(f"Not python udtf {udtf_proto.function}")


def map_common_inline_user_defined_table_function(
    rel: relation_proto.CommonInlineUserDefinedTableFunction,
) -> snowpark.DataFrame:
    session = get_or_create_snowpark_session()
    match rel.WhichOneof("function"):
        case "python_udtf":
            (
                callable_func,
                output_schema,
                _,
                function_name,
                packages,
                func_signature,
                spark_column_names,
            ) = udtf_helper(rel)

            column_map = ColumnNameMap([], [])
            snowpark_udtf_args = []
            input_types = []
            for arg_exp in rel.arguments:
                (_, snowpark_udtf_arg_tc) = map_single_column_expression(
                    arg_exp, column_map, ExpressionTyper.dummy_typer(session)
                )
                snowpark_udtf_arg = snowpark_udtf_arg_tc.col
                snowpark_udtf_args.append(snowpark_udtf_arg)
                input_types.append(snowpark_udtf_arg_tc.typ)

            snowpark_udtf = snowpark_fn.udtf(
                handler=callable_func,
                output_schema=output_schema,
                input_types=input_types,
                name=function_name,
                replace=True,
                packages=packages,
            )
            df = session.table_function(snowpark_udtf(*snowpark_udtf_args))
            snowpark_columns = [f.name for f in output_schema.fields]
            snowpark_column_types = [f.datatype for f in output_schema.fields]
            return build_column_map(
                df,
                spark_column_names,
                snowpark_column_names=snowpark_columns,
                snowpark_column_types=snowpark_column_types,
            )
        case _:
            raise ValueError(f"Not python udtf {rel.python_udtf}")
