import cloudpickle as pkl
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from pyspark.errors.exceptions.base import AnalysisException

import snowflake.snowpark.functions as snowpark_fn
import snowflake.snowpark.types as snowpark_types
import snowflake.snowpark_connect.proto.snowflake_relation_ext_pb2 as snowflake_proto
from snowflake import snowpark
from snowflake.snowpark_connect import column_name_handler
from snowflake.snowpark_connect.column_name_handler import build_column_map
from snowflake.snowpark_connect.relation.map_relation import map_relation
from snowflake.snowpark_connect.utils.context import push_outer_dataframe
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def map_extension(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    The Extension relation type contains any extensions we use for adding new
    functionality to Spark Connect.

    The extension will require new protobuf messages to be defined in the
    snowflake_connect_server/proto directory.
    """
    extension = snowflake_proto.Extension()
    rel.extension.Unpack(extension)
    match extension.WhichOneof("op"):
        case "rdd_map":
            rdd_map = extension.rdd_map
            input_df: snowpark.DataFrame = map_relation(rdd_map.input)

            column_name = "_RDD_"
            if len(input_df.columns) > 1:
                input_df = input_df.select(
                    snowpark_fn.array_construct(*input_df.columns).as_(column_name)
                )
                input_type = snowpark_types.ArrayType(snowpark_types.IntegerType())
                return_type = snowpark_types.ArrayType(snowpark_types.IntegerType())
            else:
                input_df = input_df.rename(input_df.columns[0], column_name)
                input_type = snowpark_types.VariantType()
                return_type = snowpark_types.VariantType()
            func = snowpark_fn.udf(
                pkl.loads(rdd_map.func),
                return_type=return_type,
                input_types=[input_type],
                name="my_udf",
                replace=True,
            )
            result = input_df.select(func(column_name).as_(column_name))
            return build_column_map(result, [column_name], [column_name], [return_type])
        case "subquery_column_aliases":
            subquery_aliases = extension.subquery_column_aliases
            rel.extension.Unpack(subquery_aliases)
            input_df: snowpark.DataFrame = map_relation(subquery_aliases.input)
            snowpark_col_names = input_df._column_map.get_snowpark_columns()
            if len(subquery_aliases.aliases) != len(snowpark_col_names):
                raise AnalysisException(
                    "Number of column aliases does not match number of columns. "
                    f"Number of column aliases: {len(subquery_aliases.aliases)}; "
                    f"number of columns: {len(snowpark_col_names)}."
                )
            return build_column_map(
                input_df, subquery_aliases.aliases, snowpark_col_names
            )
        case "lateral_join":
            lateral_join = extension.lateral_join
            left_df: snowpark.DataFrame = map_relation(lateral_join.left)
            left_queries = left_df.queries["queries"]
            if len(left_queries) != 1:
                raise SnowparkConnectNotImplementedError(
                    f"Unexpected number of queries: {len(left_queries)}"
                )
            left_query = left_queries[0]
            with push_outer_dataframe(left_df):
                right_df: snowpark.DataFrame = map_relation(lateral_join.right)
            right_queries = right_df.queries["queries"]
            if len(right_queries) != 1:
                raise SnowparkConnectNotImplementedError(
                    f"Unexpected number of queries: {len(right_queries)}"
                )
            right_query = right_queries[0]
            input_df_sql = f"WITH __left AS ({left_query}) SELECT * FROM __left INNER JOIN LATERAL ({right_query})"
            session = snowpark.Session.get_active_session()
            input_df = session.sql(input_df_sql)
            return column_name_handler.build_column_map(
                input_df,
                left_df._column_map.get_spark_columns()
                + right_df._column_map.get_spark_columns(),
                left_df._column_map.get_snowpark_columns()
                + right_df._column_map.get_snowpark_columns(),
            )
        case other:
            raise SnowparkConnectNotImplementedError(f"Unexpected extension {other}")
