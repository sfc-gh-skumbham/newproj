from collections.abc import MutableMapping, MutableSequence
from contextlib import contextmanager
from contextvars import ContextVar
from functools import reduce

import jpype
import pandas
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
import sqlglot
from google.protobuf.any_pb2 import Any
from sqlglot.expressions import Identifier

import snowflake.snowpark_connect.proto.snowflake_relation_ext_pb2 as snowflake_proto
from snowflake import snowpark
from snowflake.snowpark._internal.analyzer.analyzer_utils import (
    quote_name_without_upper_casing,
)
from snowflake.snowpark._internal.type_utils import convert_sp_to_sf_type
from snowflake.snowpark_connect.config import (
    auto_uppercase_ddl,
    reset_config_param,
    set_config_param,
)
from snowflake.snowpark_connect.expression.map_expression import (
    ColumnNameMap,
    map_single_column_expression,
)
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.relation.map_relation import (
    GROUP_TYPE_GROUPING_SETS,
    map_relation,
)
from snowflake.snowpark_connect.utils.context import (
    gen_sql_plan_id,
    get_session_id,
    push_evaluating_sql_scope,
    push_sql_scope,
    set_sql_args,
    set_sql_plan_name,
)
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)

from .. import column_name_handler
from ..config import sessions_config, str_to_bool
from ..expression.map_sql_expression import (
    _window_specs,
    as_java_list,
    as_java_map,
    executing_mapped_sql,
    map_logical_plan_expression,
    sql_parser,
)

_ctes = ContextVar[dict[str, relation_proto.Relation]]("_ctes", default={})


@contextmanager
def _push_cte_scope():
    """
    Creates a new CTE scope when evaluating nested WITH clauses.
    """
    cur = _ctes.get()
    token = _ctes.set(cur.copy())
    try:
        yield
    finally:
        _ctes.reset(token)


@contextmanager
def _push_window_specs_scope():
    """
    Creates a new window specs  scope when evaluating nested  clauses.
    """
    cur = _window_specs.get()
    token = _window_specs.set(cur.copy())
    try:
        yield
    finally:
        _window_specs.reset(token)


def _find_pos_args(node, positions: list[int]):
    if str(node.nodeName()) == "PosParameter":
        positions.append(node.pos())
    else:
        for child in as_java_list(node.children()):
            _find_pos_args(child, positions)
        if hasattr(node, "expressions"):
            for child in as_java_list(node.expressions()):
                _find_pos_args(child, positions)


def parse_pos_args(
    logical_plan,
    pos_args: MutableSequence[expressions_proto.Expression.Literal],
) -> dict[int, expressions_proto.Expression]:
    # Spark Connect gives us positional parameters as a regular list,
    # while Spark parser refers to them by their character indexes in the query.
    # Therefore, we need to find all positional parameters, sort their locations,
    # and match them to the list from Spark Connect.
    if not pos_args:
        return {}

    positions: list[int] = []
    _find_pos_args(logical_plan, positions)
    return dict(zip(sorted(positions), pos_args))


def execute_logical_plan(logical_plan) -> snowpark.DataFrame:
    proto = map_logical_plan_relation(logical_plan)
    with executing_mapped_sql(), push_evaluating_sql_scope():
        return map_relation(proto)


def _spark_to_snowflake_single_id(name: str) -> str:
    name = quote_name_without_upper_casing(name)
    return name.upper() if auto_uppercase_ddl() else name


def _spark_to_snowflake(multipart_id: jpype.JObject) -> str:
    return ".".join(
        _spark_to_snowflake_single_id(str(part)) for part in as_java_list(multipart_id)
    )


def _rename_columns(
    df: snowpark.DataFrame, user_specified_columns
) -> snowpark.DataFrame:
    user_columns = [str(col._1()) for col in as_java_list(user_specified_columns)]

    if user_columns:
        columns = zip(df.columns, user_columns)
    else:
        columns = df._column_map.snowpark_to_spark_map().items()

    for orig_column, user_column in columns:
        df = df.with_column_renamed(
            orig_column, _spark_to_snowflake_single_id(user_column)
        )

    return df


def _create_table_as_select(logical_plan, mode: str) -> None:
    # TODO: for as select create tables we'd map multi layer identifier here
    name = _spark_to_snowflake(logical_plan.name().nameParts())
    comment = logical_plan.tableSpec().comment()

    df = execute_logical_plan(logical_plan.query())
    columns = df._column_map.snowpark_to_spark_map().items()
    for orig_column, user_column in columns:
        df = df.with_column_renamed(
            orig_column, _spark_to_snowflake_single_id(user_column)
        )

    df.write.save_as_table(
        name,
        comment=None if comment.isEmpty() else comment.get(),
        mode=mode,
    )


def is_pure_select_or_cte(sql_string):
    """
    Utility function to check if the sql string is a pure select or cte query with select statement.
    """
    try:
        parsed = sqlglot.parse_one(sql_string, read="snowflake")
        if isinstance(parsed, sqlglot.expressions.Select):
            return True
    except Exception:
        return False


def _spark_field_to_sql(field: jpype.JObject, is_column: bool) -> str:
    # Column names will be uppercased according to "snowpark.connect.auto-uppercase.ddl",
    # and struct fields will be left as is. This should allow users to use the same names
    # in spark and Snowflake in most cases.
    if is_column:
        name = _spark_to_snowflake_single_id(str(field.name()))
    else:
        name = quote_name_without_upper_casing(str(field.name()))
    data_type_str = _spark_datatype_to_sql(field.dataType())
    # TODO: Support comments
    return f"{name} {data_type_str}"


def _spark_datatype_to_sql(data_type: jpype.JObject) -> str:
    match data_type.typeName():
        case "array":
            element_type_str = _spark_datatype_to_sql(data_type.elementType())
            return f"ARRAY({element_type_str})"
        case "map":
            key_type_str = _spark_datatype_to_sql(data_type.keyType())
            value_type_str = _spark_datatype_to_sql(data_type.valueType())
            return f"MAP({key_type_str}, {value_type_str})"
        case "struct":
            field_types_str = ", ".join(
                _spark_field_to_sql(f, False) for f in data_type.fields()
            )
            return f"OBJECT({field_types_str})"
        case _:
            return data_type.sql()


def _normalize_identifiers(node):
    """
    Fix spark-quoted identifiers parsed with sqlglot.

    sqlglot detects quoted spark identifiers which makes them quoted in the Snowflake SQL string.
    This behaviour is not consistent with Spark, where non-column identifiers are case insensitive.
    The identifiers need to be uppercased to match Snowflake's behaviour. Users can disable this by setting
    the `snowpark.connect.auto_uppercase_ddl` config to False.
    """
    if isinstance(node, Identifier):
        fixed = node.this.upper() if auto_uppercase_ddl() else node.this
        return Identifier(this=fixed, quoted=True)
    return node


def map_sql_to_pandas_df(
    sql_string: str,
    named_args: MutableMapping[str, expressions_proto.Expression.Literal],
    pos_args: MutableSequence[expressions_proto.Expression.Literal],
) -> tuple[pandas.DataFrame, str] | tuple[None, None]:
    """
    Convert a sql string into a pandas DataFrame and its json schema.
    returns a tuple of empty Pandas DataFrame and schema string in case of DDL statements.
    returns a tuple of None for SELECT queries to enable lazy evaluation
    """

    snowpark_connect_sql_passthrough = get_sql_passthrough()

    if not snowpark_connect_sql_passthrough:
        logical_plan = sql_parser().parsePlan(sql_string)
        parsed_pos_args = parse_pos_args(logical_plan, pos_args)
        set_sql_args(named_args, parsed_pos_args)

        session = get_or_create_snowpark_session()

        rows: list | None = None

        while (
            class_name := str(logical_plan.getClass().getSimpleName())
        ) == "UnresolvedHint":
            logical_plan = logical_plan.child()

        match class_name:
            case "CreateNamespace":
                name = _spark_to_snowflake(logical_plan.name().multipartIdentifier())
                previous_name = session.sql("SELECT CURRENT_SCHEMA()").collect()[0][0]
                if_not_exists = "IF NOT EXISTS " if logical_plan.ifNotExists() else ""
                session.sql(f"CREATE SCHEMA {if_not_exists}{name}").collect()
                if previous_name is not None:
                    session.sql(
                        f"USE SCHEMA {_spark_to_snowflake_single_id(previous_name)}"
                    ).collect()
                else:
                    # TODO: Unset the schema
                    pass
            case "CreateTable":
                name = _spark_to_snowflake(logical_plan.name().nameParts())
                columns = ", ".join(
                    _spark_field_to_sql(f, True)
                    for f in logical_plan.tableSchema().fields()
                )
                if_not_exists = (
                    "IF NOT EXISTS " if logical_plan.ignoreIfExists() else ""
                )
                # NOTE: We are intentionally ignoring any FORMAT=... parameters here.
                session.sql(f"CREATE TABLE {if_not_exists}{name} ({columns})").collect()
            case "CreateTableAsSelect":
                mode = "ignore" if logical_plan.ignoreIfExists() else "errorifexists"
                _create_table_as_select(logical_plan, mode=mode)
            case "CreateTableLikeCommand":
                source = _spark_to_snowflake(logical_plan.sourceTable().nameParts())
                name = _spark_to_snowflake(logical_plan.targetTable().nameParts())
                if_not_exists = "IF NOT EXISTS " if logical_plan.ifNotExists() else ""
                session.sql(
                    f"CREATE TABLE {if_not_exists}{name} LIKE {source}"
                ).collect()
            case "CreateView":
                df = execute_logical_plan(logical_plan.query())

                name = _spark_to_snowflake(logical_plan.child().nameParts())
                comment = logical_plan.comment()

                df = _rename_columns(df, logical_plan.userSpecifiedColumns())

                # TODO: Support logical_plan.replace() == False
                df.create_or_replace_view(
                    name,
                    comment=str(comment.get()) if comment.isDefined() else None,
                )
            case "CreateViewCommand":
                df = execute_logical_plan(logical_plan.plan())

                name = _spark_to_snowflake_single_id(
                    str(logical_plan.name().identifier())
                )
                comment = logical_plan.comment()

                df = _rename_columns(df, logical_plan.userSpecifiedColumns())

                if logical_plan.replace():
                    df.create_or_replace_temp_view(
                        name,
                        comment=str(comment.get()) if comment.isDefined() else None,
                    )
                else:
                    df.create_temp_view(
                        name,
                        comment=str(comment.get()) if comment.isDefined() else None,
                    )
            case "DescribeColumn":
                name = _spark_to_snowflake(logical_plan.column().nameParts())
                rows = session.sql(f"DESCRIBE TABLE {name}").collect()
            case "DescribeNamespace":
                name = _spark_to_snowflake(
                    logical_plan.namespace().multipartIdentifier()
                )
                rows = session.sql(f"DESCRIBE SCHEMA {name}").collect()
                if not rows:
                    rows = None
            case "DescribeRelation":
                name = _spark_to_snowflake(
                    logical_plan.relation().multipartIdentifier()
                )
                rows = session.sql(f"DESCRIBE TABLE {name}").collect()
                if not rows:
                    rows = None
            case "DropFunctionCommand":
                func_name = logical_plan.identifier().funcName().lower()
                input_types, snowpark_name = [], ""
                if func_name in session._udfs:
                    input_types, snowpark_name = (
                        session._udfs[func_name]._input_types,
                        session._udfs[func_name].name,
                    )
                    del session._udfs[func_name]
                elif func_name in session._udtfs:
                    input_types, snowpark_name = (
                        session._udtfs[func_name][0]._input_types,
                        session._udtfs[func_name][0].name,
                    )
                    del session._udtfs[func_name]
                else:
                    if not logical_plan.ifExists():
                        raise ValueError(
                            f"Function {func_name} not found among registered UDFs or UDTFs."
                        )
                argument_string = (
                    f"({', '.join(convert_sp_to_sf_type(arg) for arg in input_types)})"
                )
                session.sql(
                    f"DROP FUNCTION {'IF EXISTS' if logical_plan.ifExists() else ''} {snowpark_name}{argument_string}"
                ).collect()
            case "DropNamespace":
                name = _spark_to_snowflake(
                    logical_plan.namespace().multipartIdentifier()
                )
                if_exists = "IF EXISTS " if logical_plan.ifExists() else ""
                session.sql(f"DROP SCHEMA {if_exists}{name}").collect()
            case "DropTable":
                name = _spark_to_snowflake(logical_plan.child().nameParts())
                if_exists = "IF EXISTS " if logical_plan.ifExists() else ""
                session.sql(f"DROP TABLE {if_exists}{name}").collect()
            case "DropView":
                name = _spark_to_snowflake(logical_plan.child().nameParts())
                if_exists = "IF EXISTS " if logical_plan.ifExists() else ""
                session.sql(f"DROP VIEW {if_exists}{name}").collect()
            case "ExplainCommand":
                logical_plan_name = logical_plan.logicalPlan().nodeName()
                if logical_plan_name in (
                    "Project",
                    "Aggregate",
                    "Sort",
                    "UnresolvedWith",
                ):
                    expr = execute_logical_plan(logical_plan.logicalPlan()).queries[
                        "queries"
                    ][0]
                elif logical_plan_name == "InsertIntoStatement":
                    expr = execute_logical_plan(
                        logical_plan.logicalPlan().query()
                    ).queries["queries"][0]
                else:
                    # TODO: Support other logical plans
                    raise SnowparkConnectNotImplementedError(
                        f"{logical_plan_name} is not supported yet with EXPLAIN."
                    )
                final_sql = f"EXPLAIN USING TEXT {expr}"
                rows = session.sql(final_sql).collect()
            case "InsertIntoStatement":
                df = execute_logical_plan(logical_plan.query())
                queries = df.queries["queries"]
                if len(queries) != 1:
                    raise SnowparkConnectNotImplementedError(
                        f"Unexpected number of queries: {len(queries)}"
                    )

                name = _spark_to_snowflake(logical_plan.table().multipartIdentifier())

                user_columns = [
                    _spark_to_snowflake_single_id(str(col))
                    for col in as_java_list(logical_plan.userSpecifiedCols())
                ]
                overwrite_str = "OVERWRITE" if logical_plan.overwrite() else ""
                cols_str = "(" + ", ".join(user_columns) + ")" if user_columns else ""

                session.sql(
                    f"INSERT {overwrite_str} INTO {name} {cols_str} {queries[0]}",
                ).collect()
            case "RenameTable":
                name = _spark_to_snowflake(logical_plan.child().multipartIdentifier())
                new_name = _spark_to_snowflake(logical_plan.newName())
                session.sql(f"ALTER TABLE {name} RENAME TO {new_name}").collect()
            case "ReplaceTableAsSelect":
                _create_table_as_select(logical_plan, mode="overwrite")
            case "ResetCommand":
                key = logical_plan.config().get()
                reset_config_param(get_session_id(), key, session)
            case "SetCatalogAndNamespace":
                # TODO: add catalog setting here
                name = _spark_to_snowflake(logical_plan.child().multipartIdentifier())
                session.sql(f"USE SCHEMA {name}").collect()
            case "SetCommand":
                kv_result_tuple = logical_plan.kv().get()
                key = kv_result_tuple._1()
                val = kv_result_tuple._2().get()
                set_config_param(get_session_id(), key, val, session)
            case "SetNamespaceCommand":
                name = _spark_to_snowflake(logical_plan.namespace())
                session.sql(f"USE SCHEMA {name}").collect()
            case "SetNamespaceLocation" | "SetNamespaceProperties":
                raise SnowparkConnectNotImplementedError(
                    "Altering databases is not currently supported."
                )
            case "ShowNamespaces":
                name = _spark_to_snowflake(
                    logical_plan.namespace().multipartIdentifier()
                )
                if name:
                    raise SnowparkConnectNotImplementedError(
                        "'IN' clause is not supported while listing databases"
                    )
                if logical_plan.pattern().isDefined():
                    # Snowflake SQL requires a "%" pattern.
                    # Snowpark catalog requires a regex and does client-side filtering.
                    # Spark, however, uses a regex-like pattern that treats '*' and '|' differently.
                    raise SnowparkConnectNotImplementedError(
                        "'LIKE' clause is not supported while listing databases"
                    )
                rows = session.sql("SHOW SCHEMAS").collect()
                if not rows:
                    rows = None
            case "ShowTables":
                name = _spark_to_snowflake(
                    logical_plan.namespace().multipartIdentifier()
                )
                if logical_plan.pattern().isDefined():
                    # Snowflake SQL requires a "%" pattern.
                    # Snowpark catalog requires a regex and does client-side filtering.
                    # Spark, however, uses a regex-like pattern that treats '*' and '|' differently.
                    raise SnowparkConnectNotImplementedError(
                        "'LIKE' clause is not supported while listing tables"
                    )
                if name:
                    rows = session.sql(f"SHOW TABLES IN {name}").collect()
                else:
                    rows = session.sql("SHOW TABLES").collect()
            case "ShowViews":
                name = _spark_to_snowflake(
                    logical_plan.namespace().multipartIdentifier()
                )
                if logical_plan.pattern().isDefined():
                    # Snowflake SQL requires a "%" pattern.
                    # Snowpark catalog requires a regex and does client-side filtering.
                    # Spark, however, uses a regex-like pattern that treats '*' and '|' differently.
                    raise SnowparkConnectNotImplementedError(
                        "'LIKE' clause is not supported while listing views"
                    )
                if name:
                    rows = session.sql(f"SHOW VIEWS IN {name}").collect()
                else:
                    rows = session.sql("SHOW VIEWS").collect()
            case "TruncateTable":
                name = _spark_to_snowflake(logical_plan.table().multipartIdentifier())
                session.sql(f"TRUNCATE TABLE {name}").collect()
            case command if (
                command.startswith("Alter")
                or command.startswith("Create")
                or command.startswith("Drop")
                or command.startswith("Rename")
                or command.startswith("Replace")
                or command.startswith("Set")
                or command.startswith("Truncate")
                or command.startswith("AddColumns")
            ):
                parsed_sql = sqlglot.parse_one(sql_string, dialect="spark").transform(
                    _normalize_identifiers
                )
                snowflake_sql = parsed_sql.sql(dialect="snowflake")
                session.sql(snowflake_sql).collect()
            case command if command.startswith("Describe") or command.startswith(
                "Show"
            ):
                parsed_sql = sqlglot.parse_one(sql_string, dialect="spark").transform(
                    _normalize_identifiers
                )
                snowflake_sql = parsed_sql.sql(dialect="snowflake")
                rows = session.sql(snowflake_sql).collect()
            case _:
                execute_logical_plan(logical_plan)
                return None, None
    else:
        # spark.sql("select or cte+select") queries should be executed lazily.
        # This returns an empty dataframe and empty schema.
        if is_pure_select_or_cte(sql_string):
            return None, None
        session = snowpark.Session.get_active_session()
        sql_df = session.sql(sql_string)
        columns = sql_df.columns
        column_name_handler.build_column_map(sql_df, columns, columns)
        rows = sql_df.collect()

    if rows:
        return pandas.DataFrame(rows), ""
    return pandas.DataFrame({"": [""]}), ""


def get_sql_passthrough() -> bool:
    session_config = sessions_config.get(get_session_id(), None)
    if (
        session_config is not None
        and session_config.get("snowpark.connect.sql.passthrough") is not None
    ):
        snowpark_connect_sql_passthrough = str_to_bool(
            session_config.get("snowpark.connect.sql.passthrough")
        )
    else:
        snowpark_connect_sql_passthrough = False

    return snowpark_connect_sql_passthrough


def map_sql(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Map a SQL string to a DataFrame.

    The SQL string is executed and the resulting DataFrame is returned.

    In passthough mode as True, SAS calls session.sql() and not calling Spark Parser.
    This is to mitigate any issue not covered by spark logical plan to protobuf conversion.
    """

    snowpark_connect_sql_passthrough = get_sql_passthrough()

    if not snowpark_connect_sql_passthrough:
        logical_plan = sql_parser().parseQuery(rel.sql.query)

        parsed_pos_args = parse_pos_args(logical_plan, rel.sql.pos_args)
        set_sql_args(rel.sql.args, parsed_pos_args)

        return execute_logical_plan(logical_plan)
    else:
        session = snowpark.Session.get_active_session()
        sql_df = session.sql(rel.sql.query)
        columns = sql_df.columns
        return column_name_handler.build_column_map(sql_df, columns, columns)


def map_logical_plan_relation(
    rel, plan_id: int | None = None
) -> relation_proto.Relation:
    if plan_id is None:
        plan_id = gen_sql_plan_id()

    class_name = str(rel.getClass().getSimpleName())
    match class_name:
        case "Aggregate":
            # TODO: How are other group types specified in `rel`?
            group_type = relation_proto.Aggregate.GROUP_TYPE_GROUPBY

            with push_sql_scope():
                input = map_logical_plan_relation(rel.child())

                group_expression_list = as_java_list(rel.groupingExpressions())
                if len(group_expression_list) == 1:
                    first_group_exp = group_expression_list[0]
                    group_class_name = str(first_group_exp.getClass().getSimpleName())
                    if group_class_name == "Rollup":
                        group_type = relation_proto.Aggregate.GROUP_TYPE_ROLLUP
                    elif group_class_name == "Cube":
                        group_type = relation_proto.Aggregate.GROUP_TYPE_CUBE
                    elif group_class_name == "GroupingSets":
                        group_type = GROUP_TYPE_GROUPING_SETS

                if group_type == GROUP_TYPE_GROUPING_SETS:
                    group_by_expressions = [
                        (map_logical_plan_expression(e))
                        for e in as_java_list(first_group_exp.children())
                    ]
                elif (
                    group_type == relation_proto.Aggregate.GROUP_TYPE_ROLLUP
                    or group_type == relation_proto.Aggregate.GROUP_TYPE_CUBE
                ):
                    group_by_expressions = [
                        (f"__group_by_{idx}", map_logical_plan_expression(e))
                        for idx, e in enumerate(
                            as_java_list(first_group_exp.children())
                        )
                    ]
                else:
                    # DataFrame operations automatically include all GROUP BY columns.
                    # Give them dummy aliases.
                    group_by_expressions = [
                        (f"__group_by_{idx}", map_logical_plan_expression(e))
                        for idx, e in enumerate(as_java_list(rel.groupingExpressions()))
                    ]

                aggregate_expressions = [
                    map_logical_plan_expression(e)
                    for e in as_java_list(rel.aggregateExpressions())
                ]

            if group_type == GROUP_TYPE_GROUPING_SETS:
                proto = relation_proto.Relation(
                    aggregate=relation_proto.Aggregate(
                        input=input,
                        group_type=group_type,
                        grouping_expressions=group_by_expressions,
                        aggregate_expressions=aggregate_expressions,
                    )
                )
            else:
                proto = relation_proto.Relation(
                    aggregate=relation_proto.Aggregate(
                        input=input,
                        group_type=group_type,
                        grouping_expressions=[
                            expressions_proto.Expression(
                                alias=expressions_proto.Expression.Alias(
                                    expr=e,
                                    name=[alias],
                                ),
                            )
                            for alias, e in group_by_expressions
                        ],
                        aggregate_expressions=aggregate_expressions,
                    )
                )

                # Now drop the dummy columns.
                proto = relation_proto.Relation(
                    drop=relation_proto.Drop(
                        input=proto,
                        column_names=[alias for alias, _ in group_by_expressions],
                    )
                )
        case "Distinct":
            proto = relation_proto.Relation(
                deduplicate=relation_proto.Deduplicate(
                    input=map_logical_plan_relation(rel.child())
                )
            )
        case "Except":
            proto = relation_proto.Relation(
                set_op=relation_proto.SetOperation(
                    left_input=map_logical_plan_relation(rel.left()),
                    right_input=map_logical_plan_relation(rel.right()),
                    set_op_type=relation_proto.SetOperation.SET_OP_TYPE_EXCEPT,
                    is_all=rel.isAll(),
                )
            )
        case "Filter":
            proto = relation_proto.Relation(
                filter=relation_proto.Filter(
                    input=map_logical_plan_relation(rel.child()),
                    condition=map_logical_plan_expression(rel.condition()),
                )
            )
        case "GlobalLimit":
            # TODO: What's a global limit and what's a local limit?
            proto = map_logical_plan_relation(rel.child())
        case "Intersect":
            proto = relation_proto.Relation(
                set_op=relation_proto.SetOperation(
                    left_input=map_logical_plan_relation(rel.left()),
                    right_input=map_logical_plan_relation(rel.right()),
                    set_op_type=relation_proto.SetOperation.SET_OP_TYPE_INTERSECT,
                    is_all=rel.isAll(),
                )
            )
        case "Join":
            join_type_sql = str(rel.joinType().sql())
            join_type_name = f"JOIN_TYPE_{join_type_sql.replace(' ', '_')}"
            condition = rel.condition()

            left = map_logical_plan_relation(rel.left())
            right = map_logical_plan_relation(rel.right())
            join_condition = (
                map_logical_plan_expression(condition.get())
                if condition.isDefined()
                else None
            )

            proto = relation_proto.Relation(
                join=relation_proto.Join(
                    left=left,
                    right=right,
                    join_condition=join_condition,
                    join_type=getattr(relation_proto.Join.JoinType, join_type_name),
                    using_columns=[],
                )
            )
        case "LocalLimit":
            proto = relation_proto.Relation(
                limit=relation_proto.Limit(
                    input=map_logical_plan_relation(rel.child()),
                    limit=rel.limitExpr().value(),
                )
            )
        case "Offset":
            proto = relation_proto.Relation(
                offset=relation_proto.Offset(
                    input=map_logical_plan_relation(rel.child()),
                    offset=rel.offsetExpr().value(),
                )
            )
        case "OneRowRelation":
            # TODO: What are we actually supposed to return here?
            proto = relation_proto.Relation(
                range=relation_proto.Range(
                    start=0,
                    end=1,
                    step=1,
                )
            )
        case "Pivot":
            pivot_column = map_logical_plan_expression(rel.pivotColumn())
            session = snowpark.Session.get_active_session()
            m = ColumnNameMap([], [], None)

            pivot_values = [
                map_logical_plan_expression(e) for e in as_java_list(rel.pivotValues())
            ]

            pivot_literals = []

            for expr_proto in pivot_values:
                expr = map_single_column_expression(
                    expr_proto, m, ExpressionTyper.dummy_typer(session)
                )
                value = session.range(1).select(expr[1].col).collect()[0][0]
                pivot_literals.append(
                    expressions_proto.Expression.Literal(string=str(value))
                )

            aggregate_expressions = [
                map_logical_plan_expression(e) for e in as_java_list(rel.aggregates())
            ]

            proto = relation_proto.Relation(
                aggregate=relation_proto.Aggregate(
                    input=map_logical_plan_relation(rel.child()),
                    aggregate_expressions=aggregate_expressions,
                    group_type=relation_proto.Aggregate.GroupType.GROUP_TYPE_PIVOT,
                    pivot=relation_proto.Aggregate.Pivot(
                        col=pivot_column, values=pivot_literals
                    ),
                )
            )

        case "PlanWithUnresolvedIdentifier":
            expr_proto = map_logical_plan_expression(rel.identifierExpr())
            session = snowpark.Session.get_active_session()
            m = ColumnNameMap([], [], None)
            expr = map_single_column_expression(
                expr_proto, m, ExpressionTyper.dummy_typer(session)
            )
            value = session.range(1).select(expr[1].col).collect()[0][0]

            proto = relation_proto.Relation(
                read=relation_proto.Read(
                    named_table=relation_proto.Read.NamedTable(
                        unparsed_identifier=value,
                    )
                )
            )
        case "Project":
            with push_sql_scope():
                input = map_logical_plan_relation(rel.child())
                expressions = [
                    map_logical_plan_expression(e)
                    for e in as_java_list(rel.projectList())
                ]
            proto = relation_proto.Relation(
                project=relation_proto.Project(
                    input=input,
                    expressions=expressions,
                )
            )
        case "Sort":
            proto = relation_proto.Relation(
                sort=relation_proto.Sort(
                    input=map_logical_plan_relation(rel.child()),
                    order=[
                        map_logical_plan_expression(e).sort_order
                        for e in as_java_list(rel.order())
                    ],
                )
            )
        case "SubqueryAlias":
            alias = str(rel.alias())
            proto = relation_proto.Relation(
                subquery_alias=relation_proto.SubqueryAlias(
                    input=map_logical_plan_relation(rel.child()),
                    alias=alias,
                )
            )
            set_sql_plan_name(alias, plan_id)
        case "Union":
            children = as_java_list(rel.children())
            assert len(children) == 2, len(children)

            proto = relation_proto.Relation(
                set_op=relation_proto.SetOperation(
                    left_input=map_logical_plan_relation(children[0]),
                    right_input=map_logical_plan_relation(children[1]),
                    set_op_type=relation_proto.SetOperation.SET_OP_TYPE_UNION,
                    by_name=rel.byName(),
                    allow_missing_columns=rel.allowMissingCol(),
                )
            )
        case "Unpivot":
            value_column_names = [e for e in as_java_list(rel.valueColumnNames())]
            variable_column_name = rel.variableColumnName()

            values = []
            for e1 in as_java_list(rel.values().get()):
                for e in as_java_list(e1):
                    values.append(map_logical_plan_expression(e))

            # Need to find ids which are not part of values and remaining cols of df
            input_rel = map_logical_plan_relation(rel.child())
            input_df: snowpark.DataFrame = map_relation(input_rel)
            column_map = input_df._column_map
            typer = ExpressionTyper(input_df)
            unpivot_spark_names = []
            for v in values:
                spark_name, typed_column = map_single_column_expression(
                    v, column_map, typer
                )
                unpivot_spark_names.append(spark_name)

            id_cols = []
            for column in input_df.columns:
                spark_column = (
                    column_map.get_spark_column_name_from_snowpark_column_name(column)
                )
                if spark_column not in unpivot_spark_names:
                    id_cols.append(
                        expressions_proto.Expression(
                            unresolved_attribute=expressions_proto.Expression.UnresolvedAttribute(
                                unparsed_identifier=spark_column
                            )
                        )
                    )

            proto = relation_proto.Relation(
                unpivot=relation_proto.Unpivot(
                    input=input_rel,
                    ids=id_cols,
                    values=relation_proto.Unpivot.Values(values=values),
                    variable_column_name=variable_column_name,
                    value_column_name=value_column_names[0],
                )
            )
        case "UnresolvedHaving":
            proto = relation_proto.Relation(
                filter=relation_proto.Filter(
                    input=map_logical_plan_relation(rel.child()),
                    condition=map_logical_plan_expression(rel.havingCondition()),
                )
            )
        case "UnresolvedHint":
            proto = relation_proto.Relation(
                hint=relation_proto.Hint(
                    input=map_logical_plan_relation(rel.child()),
                    name=str(rel.name()),
                    parameters=[
                        map_logical_plan_expression(e)
                        for e in as_java_list(rel.parameters())
                    ],
                )
            )
        case "UnresolvedInlineTable":
            names = [str(name) for name in as_java_list(rel.names())]
            one_row = relation_proto.Relation(
                range=relation_proto.Range(
                    start=0,
                    end=1,
                    step=1,
                )
            )
            rows = (
                relation_proto.Relation(
                    common=relation_proto.RelationCommon(
                        plan_id=gen_sql_plan_id(),
                    ),
                    project=relation_proto.Project(
                        input=one_row,
                        expressions=(
                            expressions_proto.Expression(
                                alias=expressions_proto.Expression.Alias(
                                    expr=map_logical_plan_expression(val),
                                    name=[name],
                                )
                            )
                            for name, val in zip(names, as_java_list(row))
                        ),
                    ),
                )
                for row in as_java_list(rel.rows())
            )

            proto = reduce(
                lambda left, right: relation_proto.Relation(
                    common=relation_proto.RelationCommon(
                        plan_id=gen_sql_plan_id(),
                    ),
                    set_op=relation_proto.SetOperation(
                        left_input=left,
                        right_input=right,
                        set_op_type=relation_proto.SetOperation.SET_OP_TYPE_UNION,
                        is_all=True,
                    ),
                ),
                rows,
            )
        case "UnresolvedRelation":
            name = str(rel.name())
            set_sql_plan_name(name, plan_id)

            cte_proto = _ctes.get().get(name)
            if cte_proto is not None:
                # The name corresponds to a `WITH` alias rather than a table.
                # TODO: We currently evaluate the query each time its alias is used;
                # we should eventually start using `WITH` in Snowflake SQL.
                proto = cte_proto
            else:
                proto = relation_proto.Relation(
                    read=relation_proto.Read(
                        named_table=relation_proto.Read.NamedTable(
                            unparsed_identifier=name,
                        )
                    )
                )
        case "UnresolvedSubqueryColumnAliases":
            child = map_logical_plan_relation(rel.child())
            aliases = [str(a) for a in as_java_list(rel.outputColumnNames())]
            any_proto = Any()
            any_proto.Pack(
                snowflake_proto.Extension(
                    subquery_column_aliases=snowflake_proto.SubqueryColumnAliases(
                        input=child,
                        aliases=aliases,
                    )
                )
            )
            proto = relation_proto.Relation(extension=any_proto)
        case "UnresolvedTableValuedFunction":
            name = ".".join(str(part) for part in as_java_list(rel.name()))
            args = [
                map_logical_plan_expression(exp)
                for exp in as_java_list(rel.functionArgs())
            ]

            match name:
                case "range":
                    m = ColumnNameMap([], [], None)
                    session = snowpark.Session.get_active_session()
                    args = (
                        session.range(1)
                        .select(
                            [
                                map_single_column_expression(arg, m, None)[1].col
                                for arg in args
                            ]
                        )
                        .collect()[0]
                    )

                    start, step = 0, 1
                    match args:
                        case [_]:
                            [end] = args
                        case [_, _]:
                            [start, end] = args
                        case [_, _, _]:
                            [start, end, step] = args

                    proto = relation_proto.Relation(
                        range=relation_proto.Range(
                            start=start,
                            end=end,
                            step=step,
                        )
                    )
                case other:
                    proto = relation_proto.Relation(
                        project=relation_proto.Project(
                            input=relation_proto.Relation(
                                range=relation_proto.Range(
                                    start=0,
                                    end=1,
                                    step=1,
                                )
                            ),
                            expressions=[
                                expressions_proto.Expression(
                                    unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                                        function_name=name,
                                        arguments=args,
                                    )
                                )
                            ],
                        ),
                    )
        case "UnresolvedWith":
            with _push_cte_scope():
                for cte in as_java_list(rel.cteRelations()):
                    name = str(cte._1())
                    cte_proto = map_logical_plan_relation(cte._2())
                    _ctes.get()[name] = cte_proto

                proto = map_logical_plan_relation(rel.child())
        case "LateralJoin":
            left = map_logical_plan_relation(rel.left())
            right = map_logical_plan_relation(rel.right().plan())
            any_proto = Any()
            any_proto.Pack(
                snowflake_proto.Extension(
                    lateral_join=snowflake_proto.LateralJoin(
                        left=left,
                        right=right,
                    )
                )
            )
            proto = relation_proto.Relation(extension=any_proto)
        case "WithWindowDefinition":
            map_obj = as_java_map(rel.windowDefinitions())
            with _push_window_specs_scope():
                for key, window_spec in map_obj.items():
                    _window_specs.get()[key] = window_spec
                proto = map_logical_plan_relation(rel.child())
        case other:
            raise SnowparkConnectNotImplementedError(f"Unimplemented relation: {other}")

    proto.common.plan_id = plan_id

    return proto
