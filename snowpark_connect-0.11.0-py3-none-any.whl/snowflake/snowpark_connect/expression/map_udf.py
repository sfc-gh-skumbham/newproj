import inspect
from types import ModuleType
from typing import Callable

import pyspark.sql.connect.proto.commands_pb2 as commands_proto
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from pyspark.errors.exceptions.base import AnalysisException
from pyspark.serializers import CloudPickleSerializer

from snowflake import snowpark
from snowflake.snowpark.types import VariantType
from snowflake.snowpark_connect.column_name_handler import ColumnNameMap
from snowflake.snowpark_connect.config import global_config
from snowflake.snowpark_connect.expression.typer import ExpressionTyper
from snowflake.snowpark_connect.type_mapping import proto_to_snowpark_type
from snowflake.snowpark_connect.typed_column import TypedColumn
from snowflake.snowpark_connect.utils.context import (
    get_is_aggregate_function,
    get_is_evaluating_join_condition,
)
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session


def infer_udf_dependencies(func: Callable) -> dict[str, ModuleType]:
    """Try to infer required packages. Doesn't guarantee 100% correctness."""

    func_code = func.__code__
    # names in the global scope
    global_names = func.__globals__
    # names accessed in func (potential module references)
    code_names = func_code.co_names

    return [
        global_names[name]
        for name in code_names
        if name in global_names
        and isinstance(global_names[name], ModuleType)
        and (
            global_names[name].__file__
            and "site-packages" in global_names[name].__file__
        )
    ]


def register_udf(udf_proto: commands_proto) -> snowpark.udf.UserDefinedFunction:
    session = get_or_create_snowpark_session()
    match udf_proto.WhichOneof("function"):
        case "python_udf":
            udf = udf_proto.python_udf
            callable_func, pyspark_output_type = CloudPickleSerializer().loads(
                udf.command
            )
            # If any of the parameters don't have type hint, we use Snowflake Variant type.
            func_signature = inspect.signature(callable_func)
            input_types = [VariantType()] * len(func_signature.parameters)

            modules = infer_udf_dependencies(callable_func)
            packages = [module.__name__ for module in modules]
            snowpark_type = proto_to_snowpark_type(udf.output_type)

            udf = session.udf.register(
                func=callable_func,
                return_type=snowpark_type,
                input_types=input_types,
                replace=True,
                packages=packages,
            )
            session._udfs[udf_proto.function_name.lower()] = udf
            return udf
        case _:
            if udf_proto.java_udf.class_name not in session._cached_java_udfs:
                raise AnalysisException(
                    f"Can not load class {udf_proto.java_udf.class_name}"
                )
            else:
                raise ValueError(f"Not python udf {udf_proto.function}")


def map_common_inline_user_defined_udf(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    from snowflake.snowpark_connect.expression.map_expression import (
        map_single_column_expression,
    )

    exp_udf = exp.common_inline_user_defined_function
    name, is_aggregate_function = get_is_aggregate_function()
    if not exp_udf.deterministic and name != "default" and is_aggregate_function:
        raise AnalysisException(
            f"[AGGREGATE_FUNCTION_WITH_NONDETERMINISTIC_EXPRESSION] Non-deterministic expression {name}({exp_udf.function_name})should not appear in the arguments of an aggregate function."
        )
    match exp_udf.WhichOneof("function"):
        case "python_udf":
            udf = exp_udf.python_udf
            (
                callable_func,
                pyspark_output_type,
            ) = CloudPickleSerializer().loads(udf.command)

            modules = infer_udf_dependencies(callable_func)
            packages = [module.__name__ for module in modules]

            # TODO: client provided python version in python_udf.python_ver, which helps to know what
            #  CloudPickleSerializer to use? In the future, we probably don't want to unpack and pack func in sas layer,
            #  which requires modifying Snowpark.
            snowpark_udf_args = []
            snowpark_udf_arg_names = []
            for arg_exp in exp_udf.arguments:
                snowpark_udf_arg_name, snowpark_udf_arg = map_single_column_expression(
                    arg_exp, column_mapping, typer
                )
                snowpark_udf_arg = snowpark_udf_arg.col
                snowpark_udf_args.append(snowpark_udf_arg)
                snowpark_udf_arg_names.append(snowpark_udf_arg_name)

            is_evaluating_join_condition = get_is_evaluating_join_condition()
            is_left_evaluable, is_right_evaluable = False, False

            for snowpark_udf_arg_name in snowpark_udf_arg_names:
                # UDFs can only reference EITHER the left OR the right side of the join but not both.
                # Example: Assume left has column a and right has column b.
                # lambda a: str(a) is fine because it will only reference either the left dataframe or the right dataframe.
                # lambda a, b: a == b is not fine because it will refence both of the dataframes.
                is_left_evaluable = (
                    is_left_evaluable
                    or snowpark_udf_arg_name in is_evaluating_join_condition[2]
                )
                is_right_evaluable = (
                    is_right_evaluable
                    or snowpark_udf_arg_name in is_evaluating_join_condition[3]
                )
                # Check for implicit cartesian product only on inner joins. If crossjoin is disabled, throw an exception.
                if (
                    is_evaluating_join_condition[0] == "INNER"
                    and not global_config.spark_sql_crossJoin_enabled
                    and is_left_evaluable
                    and is_right_evaluable
                ):
                    raise AnalysisException(
                        f"Detected implicit cartesian product for {is_evaluating_join_condition[0]} join between logical plans. \n"
                        f"Join condition is missing or trivial. \n"
                        f"Either: use the CROSS JOIN syntax to allow cartesian products between those relations, or; "
                        f"enable implicit cartesian products by setting the configuration variable spark.sql.crossJoin.enabled=True."
                    )
                if (
                    is_evaluating_join_condition[0] != "INNER"
                    and is_evaluating_join_condition[1]
                    and is_left_evaluable
                    and is_right_evaluable
                ):
                    raise AnalysisException(
                        f"[UNSUPPORTED_FEATURE.PYTHON_UDF_IN_ON_CLAUSE] The feature is not supported: "
                        f"Python UDF in the ON clause of a {is_evaluating_join_condition[0]} JOIN. "
                        f"In case of an INNNER JOIN consider rewriting to a CROSS JOIN with a WHERE clause."
                    )
            input_types = []
            for udf_arg in snowpark_udf_args:
                input_types.extend(typer.type(udf_arg))

            # TODO: if inferred packages is incorrect, how to make session level packages a fallback?
            # Both udf and pandas_udf can use the same snowpark.udf api.
            snowpark_type = proto_to_snowpark_type(udf.output_type)
            snowpark_udf = snowpark.functions.udf(
                func=callable_func,
                return_type=snowpark_type,
                input_types=input_types,
                replace=True,
                packages=packages,
            )

            return (
                f"{exp_udf.function_name}({', '.join(snowpark_udf_arg_names)})",
                TypedColumn(snowpark_udf(*snowpark_udf_args), lambda: [snowpark_type]),
            )
        case _:
            raise ValueError(
                f"Not python udf {exp.common_inline_user_defined_function.function}"
            )
