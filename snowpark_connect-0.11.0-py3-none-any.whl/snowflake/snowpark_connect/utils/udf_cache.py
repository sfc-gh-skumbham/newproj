import functools
import importlib.resources
import threading
from collections.abc import Callable
from types import ModuleType
from typing import List, Optional, Tuple, Union

from snowflake.snowpark import Session
from snowflake.snowpark.column import Column
from snowflake.snowpark.functions import call_udf, udf, udtf
from snowflake.snowpark.stored_procedure import StoredProcedure
from snowflake.snowpark.types import DataType, StructType

_lock = threading.RLock()

_BUILTIN_UDF_PREFIX = "__SC_BUILTIN_"

_JAVA_UDFS_JAR_NAME = "java_udfs-1.0-SNAPSHOT.jar"


def init_builtin_udf_cache(session: Session) -> None:
    with _lock:
        session._cached_udfs = {}
        session._cached_udtfs = {}
        session._cached_java_udfs = {}


def _hash_types(types: list) -> str:
    return f"{abs(hash(tuple(types))):016X}"


def _udxf_name(
    fn: Callable,
    input_types: Optional[List[DataType]] = None,
    output_schema: Optional[DataType] = None,
) -> str:
    """
    Generates a unique name for a UDXF based on the function name, input types and output schema.
    Names are prefixed to be easily searchable in Snnowhouse.
    """
    input_types_hash = _hash_types(input_types) if input_types is not None else ""
    output_schema_hash = (
        _hash_types([output_schema]) if output_schema is not None else ""
    )
    return f"{_BUILTIN_UDF_PREFIX}{input_types_hash}_{output_schema_hash}_{fn.__name__.upper()}"


def cached_udf(
    fn: Callable = None,
    *,
    input_types: Optional[List[DataType]] = None,
    return_type: Optional[DataType] = None,
    imports: Optional[List[Union[str, Tuple[str, str]]]] = None,
    packages: Optional[List[Union[str, ModuleType]]] = None,
):
    """
    A drop-in replacement for Snowpark's `udf` that caches the UDF in the active session.

    The UDF is cached based on its name and input types. Make sure any new cached functions are unique.
    """

    def _cached_udf(func: Callable):
        with _lock:
            cache = Session.get_active_session()._cached_udfs
            name = _udxf_name(func, input_types, return_type)
            # Check if the udf is already cached
            if name in cache:
                return cache[name]

        # Register the function outside the lock to avoid contention when registering multiple functions.
        # It's possible that multiple threads will try to register the same function,
        # but this will not cause any issues.
        wrapped_func = udf(
            func,
            name=name,
            return_type=return_type,
            input_types=input_types,
            imports=imports,
            packages=packages,
            is_permanent=False,
            replace=True,
        )

        with _lock:
            # Cache the udf
            cache[name] = wrapped_func

        return wrapped_func

    if fn is None:
        # return decorator
        return _cached_udf
    else:
        # return udf
        return _cached_udf(fn)


def cached_udtf(
    fn: Callable = None,
    *,
    output_schema: Union[StructType, List[str]],
    input_types: Optional[List[DataType]] = None,
    imports: Optional[List[Union[str, Tuple[str, str]]]] = None,
    packages: Optional[List[Union[str, ModuleType]]] = None,
):
    """
    A drop-in replacement for Snowpark's `udtf` that caches the UDTF in the active session.

    The UDTF is cached based on its name and input types. Make sure any new cached functions are unique.
    """

    def _cached_udtf(func: Callable):
        with _lock:
            cache = Session.get_active_session()._cached_udtfs
            name = _udxf_name(func, input_types, output_schema)

            if name in cache:
                return cache[name]

        # Register the function outside the lock to avoid contention
        wrapped_func = udtf(
            func,
            name=name,
            output_schema=output_schema,
            input_types=input_types,
            imports=imports,
            packages=packages,
            is_permanent=False,
            replace=True,
        )

        with _lock:
            cache[name] = wrapped_func

        return wrapped_func

    if fn is None:
        # return decorator
        return _cached_udtf
    else:
        # return udtf
        return _cached_udtf(fn)


def _create_temporary_java_udf(
    session: Session,
    function_name: str,
    input_types: list[str],
    return_type: str,
    imports: list[str],
    java_handler: str,
    packages: list[str] | None = None,
) -> None:
    args_str = ",".join(f"arg{idx} {type_}" for idx, type_ in enumerate(input_types))
    imports_str = ",".join(f"'{import_}'" for import_ in imports)
    packages_str = ",".join(f"'{pkg}'" for pkg in packages) if packages else ""

    session.sql(
        f"""CREATE OR REPLACE TEMPORARY FUNCTION {function_name}({args_str})
                          RETURNS {return_type}
                          LANGUAGE JAVA
                          IMPORTS = ({imports_str})
                          HANDLER = '{java_handler}'
                          PACKAGES = ({packages_str})
                          RUNTIME_VERSION = 17
      """
    ).collect()


def register_cached_java_udf(
    java_handler: str,
    input_types: list[str],
    return_type: str,
    packages: list[str] | None = None,
) -> Callable[..., Column]:
    """
    Register a cached Java UDF. To use it, you need to:
    - Implement a handler function in the java_udfs subproject.
    - Build a jar using `mvn clean package` command and make sure the generated jar isn't too big (couple of KBs).
    - Copy the jar to `snowflake.snowpark_connect.resources`

    input_types and return_type should be valid sql type names, e.g. STRING, VARCHAR, FLOAT etc.
    """

    input_types_hash = _hash_types(input_types)
    java_fun_name = java_handler.split(".")[-1]

    function_name = f"{_BUILTIN_UDF_PREFIX}{java_fun_name.upper()}{input_types_hash}"

    with _lock:
        session = Session.get_active_session()
        cache = session._cached_java_udfs
        stage = session.get_session_stage()

        if len(cache) == 0:
            # This is the first Java UDF being registered, so we need to upload the JAR with UDF definitions first
            jar_path = importlib.resources.files(
                "snowflake.snowpark_connect.resources"
            ).joinpath(_JAVA_UDFS_JAR_NAME)

            upload_result = session.file.put(str(jar_path), stage, overwrite=True)

            if upload_result[0].status != "UPLOADED":
                raise RuntimeError(
                    f"Failed to upload JAR with UDF definitions to stage: {upload_result[0].message}"
                )

        udf_is_cached = function_name in cache

    if not udf_is_cached:
        _create_temporary_java_udf(
            session,
            function_name,
            input_types,
            return_type,
            [f"{stage}/{_JAVA_UDFS_JAR_NAME}"],
            java_handler,
            packages,
        )

        with _lock:
            cache[function_name] = True

    return functools.partial(
        call_udf,
        function_name,
    )


@functools.cache
def sproc_text_read(session: Session) -> StoredProcedure:
    from snowflake.snowpark.files import SnowflakeFile

    session.add_packages("snowflake-snowpark-python")

    def run(session: Session, file_path: str) -> str:
        return SnowflakeFile.open(file_path).read()

    return session.sproc.register(
        run, name="__SNOWPARK_CONNECT_READ_TEXT_SPROC__", if_not_exists=True
    )
