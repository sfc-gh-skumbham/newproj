import re
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Mapping

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relations_proto

from snowflake import snowpark

# TODO: remove session id from context when we host SAS in Snowflake server

_session_id = ContextVar[str]("_session_id")
_plan_id_map = ContextVar[Mapping[int, snowpark.DataFrame]]("_plan_id_map")
_alias_map = ContextVar[Mapping[str, snowpark.DataFrame | None]]("_alias_map")
_spark_version = ContextVar[str]("_spark_version")
_is_aggregate_function = ContextVar(
    "_is_aggregate_function", default=("default", False)
)
_is_evaluating_sql = ContextVar[bool]("_is_evaluating_sql", default=False)
_is_evaluating_join_condition = ContextVar(
    "is_evaluating_join_condition", default=("default", False, [], [])
)

# We have to generate our own plan IDs that are different from Spark's.
# Spark plan IDs start at 0, so pick a "big enough" number to avoid overlaps.
_STARTING_SQL_PLAN_ID = 0x80000000

_next_sql_plan_id = ContextVar[int]("_next_sql_plan_id")
_sql_plan_name_map = ContextVar[dict[str, int]]("_sql_plan_name_map")
_sql_named_args = ContextVar[dict[str, expressions_proto.Expression]]("_sql_named_args")
_sql_pos_args = ContextVar[dict[int, expressions_proto.Expression]]("_sql_pos_args")
_sql_stashed_relations = ContextVar[list[relations_proto.Relation]](
    "_sql_stashed_relations"
)

_outer_dataframes = ContextVar[list[snowpark.DataFrame]]("_parent_dataframes")

_spark_client_type_regex = re.compile(r"spark/(?P<spark_version>\d+\.\d+\.\d+)")
_current_operation = ContextVar[str]("_current_operation", default="default")
_resolving_fun_args = ContextVar[bool]("_resolving_fun_args", default=False)
_resolving_lambda_fun = ContextVar[bool]("_resolving_lambdas", default=False)

_is_window_enabled = ContextVar[bool]("_is_window_enabled", default=False)
_is_in_pivot = ContextVar[bool]("_is_in_pivot", default=False)


def set_session_id(value: str) -> None:
    """Set the session ID for the current context"""
    _session_id.set(value)


def get_session_id() -> str:
    """Get the session ID for the current context."""
    return _session_id.get(None)


def set_plan_id_map(plan_id: int, df: snowpark.DataFrame) -> None:
    """Set the plan id map for the current context."""
    _plan_id_map.get()[plan_id] = df


def get_plan_id_map(plan_id: int) -> snowpark.DataFrame | None:
    """Set the plan id map for the current context."""
    return _plan_id_map.get().get(plan_id)


def get_alias_map() -> Mapping[str, snowpark.DataFrame | None]:
    """Set the alias map for the current thread."""
    return _alias_map.get()


def gen_sql_plan_id() -> int:
    next = _next_sql_plan_id.get()
    _next_sql_plan_id.set(next + 1)
    return next


def get_spark_version() -> str:
    """
    Get the spark version for the current context, as sent by the client in `client_type`.
    """
    return _spark_version.get()


def set_spark_version(client_type: str) -> None:
    """
    Set the client spark version for the current context.
    Takes a single `client_type: str` argument in format as sent by pyspark, e.g.
    "_SPARK_CONNECT_PYTHON spark/3.5.3 os/darwin python/3.11.11" and extracts the spark version - 3.5.3 in this case.
    """
    match = _spark_client_type_regex.search(client_type)
    version = match.group("spark_version") if match else ""
    _spark_version.set(version)


def get_is_aggregate_function() -> tuple[str, bool]:
    """
    Gets the value of _is_aggregate_function for the current context, defaults to False.
    """
    return _is_aggregate_function.get()


def set_is_aggregate_function(is_agg: tuple[str, bool]) -> None:
    """
    Sets the value of _is_aggregate_function for the current context.
    """
    _is_aggregate_function.set(is_agg)


def get_is_evaluating_sql() -> bool:
    """
    Gets the value of _is_evaluating_sql for the current context, defaults to False.
    """
    return _is_evaluating_sql.get()


@contextmanager
def push_evaluating_sql_scope():
    """
    Context manager that sets a flag indicating if a sql statement is being resolved.
    """
    prev = _is_evaluating_sql.get()
    try:
        _is_evaluating_sql.set(True)
        yield
    finally:
        _is_evaluating_sql.set(prev)


def get_is_evaluating_join_condition() -> tuple[str, bool, list, list]:
    """
    Gets the value of _is_evaluating_join_condition for the current context, defaults to False.
    """
    return _is_evaluating_join_condition.get()


@contextmanager
def push_evaluating_join_condition(join_type, left_keys, right_keys):
    """
    Context manager that sets a flag indicating if a join statement is being resolved.
    """
    prev = _is_evaluating_join_condition.get()
    try:
        _is_evaluating_join_condition.set((join_type, True, left_keys, right_keys))
        yield
    finally:
        _is_evaluating_join_condition.set(prev)


@contextmanager
def push_sql_scope():
    """
    Creates a new variable scope when evaluating nested SQL expressions.
    E.g., in `SELECT x, (SELECT 1 AS x)`, the two `x`s are different variables.
    """
    cur = _sql_plan_name_map.get()
    token = _sql_plan_name_map.set(cur.copy())
    try:
        yield
    finally:
        _sql_plan_name_map.reset(token)


@contextmanager
def push_operation_scope(operation: str):
    """
    Context manager that sets the current operation scope for column name resolution.
    Example:
    with push_operation_scope('filter'):
        df.filter(col('historical_name') > 0)  # Historical names allowed in filter
    """
    token = _current_operation.set(operation)
    try:
        yield
    finally:
        _current_operation.reset(token)


@contextmanager
def resolving_lambda_function():
    """
    Context manager that sets a flag indicating lambda function is being resolved.
    """
    prev = _resolving_lambda_fun.get()
    try:
        _resolving_lambda_fun.set(True)
        yield
    finally:
        _resolving_lambda_fun.set(prev)


def is_lambda_being_resolved() -> bool:
    """
    Returns True if lambda function is being resolved.
    """
    return _resolving_lambda_fun.get()


@contextmanager
def resolving_fun_args():
    """
    Context manager that sets a flag indicating function arguments are being resolved.
    """
    prev = _resolving_fun_args.get()
    try:
        _resolving_fun_args.set(True)
        yield
    finally:
        _resolving_fun_args.set(prev)


def is_function_argument_being_resolved() -> bool:
    """
    Returns True if function arguments are being resolved.
    """
    return _resolving_fun_args.get()


def get_current_operation_scope() -> str:
    """
    Returns the current operation scope for column name resolution.
    """
    return _current_operation.get()


def set_sql_plan_name(name: str, plan_id: int) -> None:
    _sql_plan_name_map.get()[name] = plan_id


def get_sql_plan(name: str) -> int:
    return _sql_plan_name_map.get().get(name)


def set_sql_args(
    named: dict[str, expressions_proto.Expression],
    pos: dict[int, expressions_proto.Expression],
) -> None:
    _sql_named_args.set(named)
    _sql_pos_args.set(pos)


def get_sql_named_arg(name: str) -> expressions_proto.Expression:
    return _sql_named_args.get()[name]


def get_sql_pos_arg(pos: int) -> expressions_proto.Expression:
    return _sql_pos_args.get()[pos]


def stash_sql_relation(rel: relations_proto.Relation) -> int:
    _sql_stashed_relations.get().append(rel)
    return len(_sql_stashed_relations.get()) - 1


def get_sql_relation(idx: int) -> relations_proto.Relation:
    return _sql_stashed_relations.get()[idx]


@contextmanager
def push_outer_dataframe(df: snowpark.DataFrame):
    _outer_dataframes.get().append(df)
    yield
    _outer_dataframes.get().pop()


def get_outer_dataframes() -> list[snowpark.DataFrame]:
    return _outer_dataframes.get()


def clear_context_data() -> None:
    _session_id.set(None)
    _plan_id_map.set({})
    _alias_map.set({})

    _next_sql_plan_id.set(_STARTING_SQL_PLAN_ID)
    _sql_plan_name_map.set({})
    _sql_named_args.set({})
    _sql_pos_args.set({})
    _sql_stashed_relations.set([])
    _is_aggregate_function.set(("default", False))
    _outer_dataframes.set([])


@contextmanager
def temporary_window_expression():
    """
    Temporarily sets the 'is_window_enabled' attribute of the given typer to True.

    Yields:
        None: The context manager only yields control; it does not return a value.
    -------

    """
    _is_window_enabled.set(True)
    try:
        yield
    finally:
        _is_window_enabled.set(False)


def is_window_enabled():
    return _is_window_enabled.get()


@contextmanager
def temporary_pivot_expression(value: bool):
    token = _is_in_pivot.set(value)
    try:
        yield
    finally:
        _is_in_pivot.reset(token)


def is_in_pivot() -> bool:
    return _is_in_pivot.get()
