from collections.abc import Callable
from functools import cached_property

import snowflake.snowpark.functions as snowpark_fn
from snowflake import snowpark
from snowflake.snowpark.column import Column

_EMPTY_COLUMN = Column("")


class TypedColumn:
    def __init__(
        self,
        col: Column,
        type_resolver: Callable[[], list[snowpark.types.DataType] | None],
    ) -> None:
        self.col = col
        self._type_resolver = type_resolver

    def __iter__(self):
        return iter((self.col, self._type_resolver))

    @property
    def typ(self) -> snowpark.types.DataType | None:
        assert (
            len(self.types) == 1
        ), f"Expected exactly single column expression, got {self.col} with types {self.types}"
        return self.types[0]

    @cached_property
    def types(self) -> list[snowpark.types.DataType] | None:
        return self._type_resolver()

    @classmethod
    def empty(cls):
        return TypedColumn(_EMPTY_COLUMN, lambda: None)

    def alias(self, alias_name: str):
        return TypedColumn(self.col.alias(alias_name), self._type_resolver)

    def is_empty(self) -> bool:
        return (
            isinstance(self.col, Column)
            and self.col._expression == _EMPTY_COLUMN._expression
        )

    def column(self, to_semi_structure: bool = False) -> Column:
        if to_semi_structure and len(self.types) <= 1:
            match self.typ:
                case snowpark.types.StructType() if self.typ.structured:
                    return snowpark_fn.cast(self.col, snowpark.types.StructType())
                case snowpark.types.MapType() if self.typ.structured:
                    # no more semi-structured map, use semi-structured struct instead
                    return snowpark_fn.cast(self.col, snowpark.types.StructType())
                case snowpark.types.ArrayType() if self.typ.structured:
                    return snowpark_fn.cast(self.col, snowpark.types.ArrayType())
        return self.col

    def over(self, window: snowpark.window.WindowSpec) -> Column:
        return self.col.over(window)


class TypedColumnWithDeferredCast(TypedColumn):
    def __init__(
        self,
        col: Column,
        type_resolver: Callable[[], list[snowpark.types.DataType] | None],
    ) -> None:
        super().__init__(col, type_resolver)

    def over(self, window: snowpark.window.WindowSpec) -> Column:
        return self.col.over(window).cast(self.typ)
