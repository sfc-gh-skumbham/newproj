# Proto source for reference:
# https://github.com/apache/spark/blob/branch-3.5/connector/connect/common/src/main/protobuf/spark/connect/base.proto#L420
import re
from copy import copy
from typing import Any, Dict

import pyspark.sql.connect.proto.base_pb2 as proto_base
from tzlocal import get_localzone_name

from snowflake import snowpark
from snowflake.snowpark._internal.analyzer.analyzer_utils import (
    quote_name_without_upper_casing,
)
from snowflake.snowpark.exceptions import SnowparkSQLException
from snowflake.snowpark_connect.utils.context import get_session_id
from snowflake.snowpark_connect.utils.session import get_or_create_snowpark_session
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def str_to_bool(boolean_str: str) -> bool:
    assert boolean_str in [
        "True",
        "true",
        "False",
        "false",
        "1",
        "0",
        "",  # This is the default value, equivalent to False.
    ], f"Invalid boolean value: {boolean_str}"
    return boolean_str in ["True", "true", "1"]


class GlobalConfig:
    """This class contains the global configuration for the Spark Server."""

    default_static_global_config = {
        "spark.sql.globalTempDatabase": "global_temp",
    }

    default_global_config = {
        # TODO: This will need to be changed to the actual host of the driver.
        "spark.driver.host": "sc://localhost:15002",
        "spark.sql.pyspark.inferNestedDictAsStruct.enabled": "false",
        "spark.sql.pyspark.legacy.inferArrayTypeFromFirstElement.enabled": "false",
        "spark.sql.repl.eagerEval.enabled": "false",
        "spark.sql.repl.eagerEval.maxNumRows": "20",
        "spark.sql.repl.eagerEval.truncate": "20",
        "spark.sql.session.localRelationCacheThreshold": "67108864",
        "spark.sql.session.timeZone": get_localzone_name(),  # spark by default uses jvm local timezone
        "spark.sql.timestampType": "TIMESTAMP_LTZ",
        "spark.sql.crossJoin.enabled": "true",
        "spark.sql.caseSensitive": "false",
        "spark.sql.mapKeyDedupPolicy": "EXCEPTION",
        "spark.sql.ansi.enabled": "false",
        "spark.sql.sources.default": "parquet",
        "spark.Catalog.databaseFilterInformationSchema": "false",
    }

    boolean_config_list = [
        "spark.sql.pyspark.inferNestedDictAsStruct.enabled",
        "spark.sql.pyspark.legacy.inferArrayTypeFromFirstElement.enabled",
        "spark.sql.repl.eagerEval.enabled",
        "spark.sql.crossJoin.enabled",
        "spark.sql.caseSensitive",
        "spark.sql.ansi.enabled",
        "spark.Catalog.databaseFilterInformationSchema",
    ]

    int_config_list = [
        "spark.sql.repl.eagerEval.maxNumRows",
        "spark.sql.repl.eagerEval.truncate",
        "spark.sql.session.localRelationCacheThreshold",
    ]

    # This is a mapping of the configuration key to a function that assigns the
    # configuration value to a Snowpark session. This is only needed for configurations
    # that we need to make available to the Snowpark session.
    snowpark_config_mapping = {
        # Snowpark uses query_tag for the application name.
        "spark.app.name": lambda session, name: setattr(
            session, "query_tag", f"Spark-Connect-App-Name={name}"
        ),
    }

    float_config_list = []

    def __init__(self) -> None:
        self.global_config = copy(self.default_global_config)
        for key in self.global_config.keys():
            setattr(self, key.replace(".", "_"), self._get_config_setting(key))

    def _get_config_setting(self, key: str) -> bool | int | float | str:
        """Get the configuration setting for the key based on the setting type."""
        if key in self.boolean_config_list:
            return str_to_bool(self.global_config[key])
        elif key in self.int_config_list:
            return int(self.global_config[key])
        elif key in self.float_config_list:
            return float(self.global_config[key])
        else:
            return self.global_config[key]

    def __getattr__(self, item):
        return self.get(item.replace("_", "."))

    def __getitem__(self, item: str) -> str:
        return self.get(item)

    def __setitem__(self, key: str, value: str) -> None:
        return self.set(key, value)

    def get(self, key, default=None) -> str:
        self._initialize_if_static_config_not_set(key)
        return self.global_config.get(key, default)

    def set(self, key: str, value: str) -> None:
        self.global_config[key] = value
        if key in self.snowpark_config_mapping.keys():
            snowpark_session = get_or_create_snowpark_session()
            self.snowpark_config_mapping[key](snowpark_session, value)
        # This is necessary to make the configuration available as an attribute.
        setattr(self, key.replace(".", "_"), self._get_config_setting(key))

    def _initialize_if_static_config_not_set(self, key):
        """
        Spark maintains set of 'static' config values that are immutable.
        SAS allows static configs only to be set once and only if they were never read before.
        This function initializes static configs with default values if they haven't been set.
        """
        if self.is_static_config(key) and not self.is_set(key):
            default_value = self.default_static_global_config[key]
            self.set(key, default_value)
            snowflake_session = get_or_create_snowpark_session()
            set_snowflake_parameters(key, default_value, snowflake_session)

    def is_static_config(self, key):
        return key in self.default_static_global_config.keys()

    def is_set(self, key):
        return key in self.global_config.keys()


SESSION_CONFIG_KEY_WHITELIST = {
    "spark.hadoop.fs.s3a.access.key",
    "spark.hadoop.fs.s3a.secret.key",
    "spark.hadoop.fs.s3a.session.token",
    "snowpark.connect.sql.passthrough",
    "snowpark.connect.iceberg.external_volume",
    "snowpark.connect.auto-uppercase.ddl",
    "snowpark.connect.auto-uppercase.dml",
    "snowpark.connect.udtf.compatibility_mode",
}
AZURE_SAS_KEY = re.compile(
    r"^fs\.azure\.sas\.[^\.]+\.[^\.]+\.blob\.core\.windows\.net$"
)


def valid_session_config_key(key: str):
    return (
        key in SESSION_CONFIG_KEY_WHITELIST  # AWS session keys
        or AZURE_SAS_KEY.match(key)  # Azure session keys
    )


class SessionConfig:
    """This class contains the session configuration for the Spark Server."""

    def __init__(self) -> None:
        self.config = {}

    def __getitem__(self, item: str) -> str:
        return self.get(item)

    def __setitem__(self, key: str, value: str) -> None:
        return self.set(key, value)

    def get(self, key, default=None) -> str:
        return self.config.get(key, default)

    def set(self, key: str, value: str) -> None:
        if not valid_session_config_key(key):
            return

        self.config[key] = value

    def unset(self, key) -> None:
        if key in self.config:
            del self.config[key]


# Set some default configuration that are necessary for the driver.
global_config = GlobalConfig()
sessions_config: Dict[str, SessionConfig] = {}


def route_config_proto(
    config: proto_base.ConfigRequest,
    snowpark_session: snowpark.Session,
) -> proto_base.ConfigResponse:
    global global_config
    global sessions_config

    match config.operation.WhichOneof("op_type"):
        case "set":
            logger.info("SET")

            for pair in config.operation.set.pairs:
                set_config_param(
                    config.session_id, pair.key, pair.value, snowpark_session
                )

            return proto_base.ConfigResponse(session_id=config.session_id)
        case "unset":
            logger.info("UNSET")
            for key in config.operation.unset.keys:
                _verify_static_config_not_modified(key)
                default_value = global_config.default_global_config.get(key, "")
                global_config[key] = default_value

                if config.session_id in sessions_config and valid_session_config_key(
                    key
                ):
                    sessions_config[config.session_id].unset(key)
                set_snowflake_parameters(key, default_value, snowpark_session)

            return proto_base.ConfigResponse(session_id=config.session_id)
        case "get":
            logger.info("GET")
            pairs = [
                proto_base.KeyValue(key=key, value=global_config.get(key, ""))
                for key in config.operation.get.keys
            ]
            return proto_base.ConfigResponse(
                session_id=config.session_id,
                pairs=pairs,
            )
        case "get_with_default":
            logger.info("GET_WITH_DEFAULT")
            result_pairs = [
                proto_base.KeyValue(
                    key=pair.key, value=global_config.get(pair.key, pair.value)
                )
                for pair in config.operation.get_with_default.pairs
            ]
            return proto_base.ConfigResponse(
                session_id=config.session_id,
                pairs=result_pairs,
            )
        case "get_option":
            logger.info("GET_OPTION")
            res = proto_base.ConfigResponse(session_id=config.session_id)
            for key in config.operation.get_option.keys:
                pair = res.pairs.add()
                pair.key = key
                val = global_config.get(key)
                if val:
                    pair.value = val
            return res
        case _:
            raise SnowparkConnectNotImplementedError(f"Unexpected request {config}")


def set_config_param(
    session_id: str, key, val, snowpark_session: snowpark.Session
) -> None:

    if session_id not in sessions_config:
        sessions_config[session_id] = SessionConfig()

    _verify_static_config_not_modified(key)
    global_config[key] = val
    if valid_session_config_key(key):
        sessions_config[session_id][key] = val
    set_snowflake_parameters(key, val, snowpark_session)


def reset_config_param(
    session_id: str, key, snowpark_session: snowpark.Session
) -> None:
    _verify_static_config_not_modified(key)

    default_value = global_config.default_global_config.get(key, "")
    global_config[key] = default_value

    if (
        session_id in sessions_config
        and valid_session_config_key(key)
        and key in sessions_config[session_id]
    ):
        sessions_config[session_id].unset(key)
    set_snowflake_parameters(key, default_value, snowpark_session)


def _verify_static_config_not_modified(key: str) -> None:
    # https://github.com/apache/spark/blob/v3.5.3/sql/core/src/main/scala/org/apache/spark/sql/RuntimeConfig.scala#L161
    # Spark does not allow to modify static configurations at runtime.
    if global_config.is_static_config(key) and global_config.is_set(key):
        raise ValueError(f"Cannot modify the value of a static config: {key}")


def set_snowflake_parameters(
    key: str, value: Any, snowpark_session: snowpark.Session
) -> None:
    match key:
        case "spark.sql.session.timeZone":
            if value:
                snowpark_session.sql(
                    f"ALTER SESSION SET TIMEZONE = '{value}'"
                ).collect()
            else:
                snowpark_session.sql("ALTER SESSION UNSET TIMEZONE").collect()
        case "spark.sql.globalTempDatabase":
            if not value:
                value = global_config.default_static_global_config.get(key)

            snowpark_name = quote_name_without_upper_casing(value)
            if auto_uppercase_ddl():
                snowpark_name = snowpark_name.upper()

            # Create the schema on demand. Before creating it, however,
            # check if it already exists, to handle the case where the schema exists
            # but the user does not have permissions to execute `CREATE SCHEMA`.
            try:
                snowpark_session.sql(
                    "DESC SCHEMA identifier(?)", [snowpark_name]
                ).collect()
            except SnowparkSQLException:
                db = snowpark_session.get_current_database()
                prev_schema = snowpark_session.get_current_schema()
                # Even though we checked that the schema doesn't exist,
                # use "IF NOT EXISTS" to avoid race conditions.
                snowpark_session.sql(
                    "CREATE SCHEMA IF NOT EXISTS identifier(?)", [snowpark_name]
                ).collect()
                # When schema is created, it is also changed in the context of the session
                match (prev_schema, snowpark_session.get_current_schema()):
                    case (None, curr) if curr is not None:
                        # session.use_schema(None) is not allowed.
                        # Instead, we call `use_database` which will set schema in context to the default one.
                        snowpark_session.use_database(db)
                    case (prev, curr) if prev != curr:
                        snowpark_session.use_schema(prev)
        case _:
            pass


def auto_uppercase_dml() -> bool:
    session_config = sessions_config.get(get_session_id(), None)
    return session_config is None or str_to_bool(
        session_config.get("snowpark.connect.auto-uppercase.dml", "true")
    )


def auto_uppercase_ddl() -> bool:
    session_config = sessions_config.get(get_session_id(), None)
    return session_config is None or str_to_bool(
        session_config.get("snowpark.connect.auto-uppercase.ddl", "true")
    )
